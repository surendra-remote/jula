from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from junitforge.config import GenConfig
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageSignals,
    RuntimeTestRunResult,
    SurefireFailure,
)
from junitforge.execution.assembly import (
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_methods,
    method_block_for_id,
    owner_method_id_for_line,
    replace_method_block,
    replace_test_method,
    test_method_name_for_line as _test_method_name_for_line,
    test_method_names as _test_method_names,
    test_class_structure_error as _test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.models import (
    ConstructionKind,
    DependencyInvocation,
    DependencyMethodContract,
    DependencyRef,
    ExecutionContext,
    ExecutionTargetKind,
    FixtureSpec,
    MethodExecutionContext,
    PayloadProperty,
    PayloadSchema,
    PropertyKind,
    ResolutionStatus,
    ReturnConsumptionKind,
)
from junitforge.loop import (
    Engine,
    _compile_candidate_is_strict_progress,
    validate_runtime_candidate_identity,
)
from junitforge.models import (
    ClassSymbol,
    CompileError,
    ClasspathProfile,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    MethodSig,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TemplateSpec,
    TestCaseRecord as CaseRecord,
    TestDisposition as CaseDisposition,
    TestKind,
)


def _schema(name: str, *props: PayloadProperty, fixture: str | None = None,
            superclass: str | None = None) -> PayloadSchema:
    return PayloadSchema(
        type_name=name,
        fqcn=f"sample.{name}",
        kind="class",
        properties=tuple(props),
        resolution_status=ResolutionStatus.RESOLVED,
        construction_kind=ConstructionKind.NO_ARGS_SETTERS,
        fixture_method_name=fixture,
        superclass=superclass,
    )


def _prop(name: str, type_name: str = "String", getter: str | None = None,
          setter: str | None = None) -> PayloadProperty:
    cap = name[:1].upper() + name[1:]
    return PayloadProperty(
        name=name,
        type_name=type_name,
        readable=True,
        writable=True,
        getter=getter or f"get{cap}",
        setter=setter or f"set{cap}",
        resolved_type=type_name,
        kind=PropertyKind.SCALAR,
    )


def _invocation(
    *,
    field: str = "iPolicyService",
    dependency_type: str = "IPolicyService",
    method: str = "lookup",
    return_type: str = "String",
    throws: tuple[str, ...] = (),
    consumed: bool = True,
    caller: str = "execute()",
) -> DependencyInvocation:
    return DependencyInvocation(
        invocation_id=f"{caller}:{field}.{method}",
        caller_method_id=caller,
        dependency_field=field,
        dependency_type=dependency_type,
        method_name=method,
        arguments=(),
        contract=DependencyMethodContract(
            dependency_field=field,
            dependency_type=dependency_type,
            method_name=method,
            return_type=return_type,
            throws=throws,
            resolution_status=ResolutionStatus.RESOLVED,
        ),
        assigned_to="value" if consumed else None,
        return_value_consumed=consumed,
        consumption_kind=(
            ReturnConsumptionKind.DIRECT_DEREFERENCE
            if consumed
            else ReturnConsumptionKind.IGNORED
        ),
    )


def _ctx(
    *,
    method: MethodSig | None = None,
    invocations: tuple[DependencyInvocation, ...] = (),
    schemas: tuple[PayloadSchema, ...] = (),
    fixtures: tuple[FixtureSpec, ...] = (),
    dependencies: tuple[DependencyRef, ...] = (),
    method_source: str = "public ResultResponse execute() { return new ResultResponse(); }",
) -> tuple[GenerationContext, MethodSig, MethodExecutionContext]:
    method = method or MethodSig("execute", modifiers={"public"}, return_type="ResultResponse")
    method_id = f"{method.name}({','.join(t for t, _ in method.params)})"
    method_context = MethodExecutionContext(
        method_id=method_id,
        signature=method.render(),
        source_range=(1, 8),
        method_source=method_source,
        endpoint=None,
        dependency_invocations=invocations,
        payload_schemas=schemas,
    )
    # ExecutionContext uses extraction_status; reconstruct without an unsupported keyword.
    execution = ExecutionContext(
        target_kind=ExecutionTargetKind.SERVICE_IMPL,
        target_fqcn="sample.SampleServiceImpl",
        dependencies=dependencies,
        methods=(method_context,),
        payload_schemas=schemas,
        fixtures=fixtures,
        extraction_status=ResolutionStatus.RESOLVED,
    )
    symbol = ClassSymbol(
        "SampleServiceImpl",
        "sample.SampleServiceImpl",
        "class",
        modifiers={"public"},
        methods=[method],
    )
    ctx = GenerationContext(
        cut_source=method_source,
        symbol=symbol,
        collaborators=[],
        test_package="sample",
        test_class_name="SampleServiceImplTest",
        stack=StackProfile(java_version="17"),
        classpath=ClasspathProfile(has_junit_jupiter=True, has_mockito=True),
        template=TemplateSpec(TestKind.PURE_UNIT, "unit"),
        source_path=Path("SampleServiceImpl.java"),
        execution_context=execution,
    )
    return ctx, method, method_context


def _fixture_context() -> tuple[GenerationContext, MethodSig, MethodExecutionContext]:
    bill = _schema("GiBillEntity", _prop("status"), fixture="validGiBillEntity")
    other = _schema("GiPersonEntity", fixture="validGiPersonEntity")
    fixtures = (
        FixtureSpec("sample.GiBillEntity", "validGiBillEntity", "GiBillEntity", "sample.GiBillEntity"),
        FixtureSpec("sample.GiPersonEntity", "validGiPersonEntity", "GiPersonEntity", "sample.GiPersonEntity"),
    )
    return _ctx(schemas=(bill, other), fixtures=fixtures)


def _test(name: str, body: str) -> str:
    return f"@Test\nvoid {name}() {{\n{body}\n}}"


def _failure(name: str, *, status: str = "failure") -> SurefireFailure:
    return SurefireFailure(
        test_class="sample.SampleServiceImplTest",
        test_method=name,
        status=status,
        exception_type="AssertionError" if status == "failure" else "NullPointerException",
        message="failed",
        stack_trace="",
    )


def _run(names: tuple[str, ...], *, failures: tuple[SurefireFailure, ...] = (),
         tests_run: int | None = None) -> RuntimeTestRunResult:
    fail_count = sum(f.status == "failure" for f in failures)
    error_count = sum(f.status == "error" for f in failures)
    count = len(names) if tests_run is None else tests_run
    return RuntimeTestRunResult(
        maven_execution_success=True,
        note="synthetic",
        signals=CoverageSignals(
            tests_executed=count > 0,
            tests_run=count,
            tests_failed=fail_count,
            tests_errors=error_count,
        ),
        failures=failures,
        executed_test_names=names,
    )


class PerTestSalvageRegressionTest(unittest.TestCase):
    def generate(self):
        schema = _schema("ResultResponse", _prop("code"))
        ctx, _method, _method_ctx = _ctx(schemas=(schema,))
        block = "\n\n".join(
            [_test(f"scenario{i}", "assertNotNull(sampleServiceImpl.execute());") for i in range(1, 6)]
            + [_test("scenario6", 'var result=sampleServiceImpl.execute();\nassertEquals("X", result.getInvented());')]
        )
        invalid = _test(
            "scenario6",
            'var result=sampleServiceImpl.execute();\nassertEquals("X", result.getInvented());',
        )

        class FakeLlm:
            def __init__(self):
                self.calls = 0

            def chat(self, *_args, **_kwargs):
                self.calls += 1
                return SimpleNamespace(
                    message=block if self.calls == 1 else invalid,
                    usage=SimpleNamespace(total_tokens=1),
                )

        engine = Engine(
            llm=FakeLlm(),
            compile_gate=SimpleNamespace(),
            coverage_runner=None,
            stack=StackProfile(),
            modules=[],
            repo_root=Path("."),
            lookup=lambda _name: None,
            cfg=GenConfig(),
        )
        outcome = TargetOutcome(
            "sample.SampleServiceImpl", "m", "SampleServiceImpl.java",
            "SampleServiceImplTest.java", "unit", True,
        )
        generated = engine._generate_methodwise(ctx, outcome)
        return generated, outcome

    def test_01_one_invalid_test_does_not_remove_valid_siblings(self) -> None:
        generated, outcome = self.generate()
        self.assertIsNotNone(generated)
        self.assertEqual(
            {"scenario1", "scenario2", "scenario3", "scenario4", "scenario5", "scenario6"},
            set(_test_method_names(generated or "")),
        )
        self.assertEqual(0, outcome.silent_method_omissions)

    def test_02_owner_with_six_tests_retains_five(self) -> None:
        _generated, outcome = self.generate()
        record = outcome.method_results[0]
        self.assertEqual(6, record.tests_extracted)
        self.assertEqual(6, record.tests_retained)
        self.assertEqual(0, record.tests_rejected)

    def test_03_owner_status_partially_generated(self) -> None:
        _generated, outcome = self.generate()
        self.assertEqual("GENERATED", outcome.method_results[0].final_status)
        self.assertEqual(0, outcome.partially_generated_methods)


class FixtureSubstitutionRegressionTest(unittest.TestCase):
    def setUp(self) -> None:
        self.ctx, self.method, self.method_ctx = _fixture_context()

    def repair(self, source: str):
        return deterministically_repair_test(self.ctx, self.method, self.method_ctx, source)

    def test_04_constructor_replaced_with_exact_fixture(self) -> None:
        result = self.repair(_test("constructor", "GiBillEntity bill = new GiBillEntity();\nassertNotNull(bill);"))
        self.assertIn("GiBillEntity bill = validGiBillEntity();", result.source)

    def test_05_builder_replaced_with_fixture(self) -> None:
        result = self.repair(_test("builder", "GiBillEntity bill = GiBillEntity.builder().status(\"I\").build();\nassertNotNull(bill);"))
        self.assertIn("validGiBillEntity()", result.source)

    def test_06_mocked_schema_replaced_with_fixture(self) -> None:
        result = self.repair(_test("mocked", "GiBillEntity bill = mock(GiBillEntity.class);\nassertNotNull(bill);"))
        self.assertIn("validGiBillEntity()", result.source)

    def test_07_scenario_setter_survives_fixture_replacement(self) -> None:
        result = self.repair(_test("override", "GiBillEntity bill = new GiBillEntity();\nbill.setStatus(\"I\");\nassertNotNull(bill);"))
        self.assertIn('bill.setStatus("I")', result.source)

    def test_08_incompatible_fixture_not_selected(self) -> None:
        source = _test("wrong", "UnknownBill bill = new UnknownBill();\nassertNotNull(bill);")
        result = self.repair(source)
        self.assertNotIn("validGiPersonEntity()", result.source)
        self.assertNotIn("validGiBillEntity()", result.source)


class CutAndCollaboratorRegressionTest(unittest.TestCase):
    def setUp(self) -> None:
        dep = DependencyRef(
            field_name="iPolicyService",
            parameter_name=None,
            declared_type="IPolicyService",
            simple_type="IPolicyService",
            fqcn="sample.IPolicyService",
            origin="field",
            resolution_status=ResolutionStatus.RESOLVED,
        )
        invocation = _invocation(return_type="String", consumed=True)
        self.ctx, self.method, self.method_ctx = _ctx(
            invocations=(invocation,), dependencies=(dep,),
            method_source="public ResultResponse execute() { return helper(); } private ResultResponse helper() { String x=iPolicyService.lookup(); return new ResultResponse(); }",
        )

    def test_09_injected_iservice_is_mockable_collaborator(self) -> None:
        block = _test("external", 'when(iPolicyService.lookup()).thenReturn("P1");\nvar result=sampleServiceImpl.execute();\nassertNotNull(result);')
        self.assertTrue(validate_method_block(self.ctx, self.method, self.method_ctx, block, set()).ok)

    def test_10_selected_serviceimpl_cannot_be_stubbed(self) -> None:
        block = _test("cutStub", "when(sampleServiceImpl.execute()).thenReturn(null);\nsampleServiceImpl.execute();\nverify(sampleServiceImpl).execute();")
        result = validate_method_block(self.ctx, self.method, self.method_ctx, block, set())
        self.assertFalse(result.ok)
        self.assertIn("class under test", result.reason.lower())

    def test_11_same_class_helper_executes_real_logic(self) -> None:
        block = _test("helperReal", 'when(iPolicyService.lookup()).thenReturn("P1");\nvar result=sampleServiceImpl.execute();\nassertNotNull(result);')
        self.assertNotIn("when(sampleServiceImpl.helper", block)
        self.assertTrue(validate_method_block(self.ctx, self.method, self.method_ctx, block, set()).ok)

    def test_12_helper_consumption_propagates(self) -> None:
        helper_invocation = _invocation(caller="helper()", consumed=True)
        ctx, method, method_ctx = _ctx(invocations=(helper_invocation,))
        source = _test("helperConsumed", 'when(iPolicyService.lookup()).thenReturn("P1");\nassertNotNull(sampleServiceImpl.execute());')
        repaired = deterministically_repair_test(ctx, method, method_ctx, source)
        self.assertIn("thenReturn", repaired.source)


class StubRepairRegressionTest(unittest.TestCase):
    def test_13_genuinely_unused_normal_stub_removed_locally(self) -> None:
        ctx, method, method_ctx = _ctx(invocations=(_invocation(consumed=False),))
        source = _test("unused", 'when(iPolicyService.lookup()).thenReturn("P1");\nassertNotNull(sampleServiceImpl.execute());')
        repaired = deterministically_repair_test(ctx, method, method_ctx, source)
        self.assertNotIn("thenReturn", repaired.source)
        self.assertIn("assertNotNull", repaired.source)

    def test_14_directly_consumed_stub_remains(self) -> None:
        ctx, method, method_ctx = _ctx(invocations=(_invocation(consumed=True),))
        source = _test("direct", 'when(iPolicyService.lookup()).thenReturn("P1");\nassertNotNull(sampleServiceImpl.execute());')
        self.assertIn("thenReturn", deterministically_repair_test(ctx, method, method_ctx, source).source)

    def test_15_helper_consumed_stub_remains(self) -> None:
        ctx, method, method_ctx = _ctx(invocations=(_invocation(caller="helper()", consumed=True),))
        source = _test("helper", 'when(iPolicyService.lookup()).thenReturn("P1");\nassertNotNull(sampleServiceImpl.execute());')
        self.assertIn("thenReturn", deterministically_repair_test(ctx, method, method_ctx, source).source)

    def test_16_exception_path_stub_remains(self) -> None:
        ctx, method, method_ctx = _ctx(invocations=(_invocation(consumed=False),), method_source="public ResultResponse execute(){ try { iPolicyService.lookup(); } catch (IllegalStateException e) { return null; } }")
        source = _test("exception", "when(iPolicyService.lookup()).thenThrow(new IllegalStateException());\nassertNull(sampleServiceImpl.execute());")
        self.assertIn("thenThrow", deterministically_repair_test(ctx, method, method_ctx, source).source)


class ReturnMismatchRegressionTest(unittest.TestCase):
    def repair(self, return_type: str, expression: str, name: str = "mismatch"):
        ctx, method, method_ctx = _ctx(invocations=(_invocation(return_type=return_type),))
        source = _test(name, f"when(iPolicyService.lookup()).thenReturn({expression});\nassertNotNull(sampleServiceImpl.execute());")
        return deterministically_repair_test(ctx, method, method_ctx, source).source

    def test_17_integer_return_mismatch_corrected(self) -> None:
        self.assertIn("thenReturn(1)", self.repair("int", '"wrong"'))

    def test_18_collection_return_mismatch_corrected(self) -> None:
        self.assertIn("Collections.emptyList()", self.repair("List<GiPersonEntity>", '"wrong"', "emptyCollection"))

    def test_19_optional_return_mismatch_corrected(self) -> None:
        self.assertIn("Optional.empty()", self.repair("Optional<GiPolicyEntity>", '"wrong"', "absentPolicy"))

    def test_20_void_return_mismatch_removes_stub(self) -> None:
        self.assertNotIn("thenReturn", self.repair("void", '"wrong"'))


class CheckedExceptionRegressionTest(unittest.TestCase):
    def test_21_declared_checked_exception_allowed(self) -> None:
        ctx, method, method_ctx = _ctx(invocations=(_invocation(throws=("IOException",)),))
        source = _test("declared", "when(iPolicyService.lookup()).thenThrow(new IOException());\nassertThrows(IOException.class, () -> sampleServiceImpl.execute());")
        self.assertIn("IOException", deterministically_repair_test(ctx, method, method_ctx, source).source)

    def test_22_undeclared_checked_exception_rejected_individually(self) -> None:
        ctx, method, method_ctx = _ctx(invocations=(_invocation(throws=()),))
        source = _test("illegal", "when(iPolicyService.lookup()).thenThrow(new IOException());\nassertThrows(IOException.class, () -> sampleServiceImpl.execute());")
        result = validate_method_block(ctx, method, method_ctx, source, set())
        self.assertFalse(result.ok)
        self.assertIn("checked exception", result.reason.lower())

    def test_23_valid_sibling_survives_invalid_exception(self) -> None:
        block = "\n\n".join((_test("valid", "assertNotNull(sampleServiceImpl.execute());"), _test("illegal", "when(iPolicyService.lookup()).thenThrow(new IOException());\nassertThrows(IOException.class, () -> sampleServiceImpl.execute());")))
        names = [item.name for item in extract_test_methods(block) if item.name != "illegal"]
        self.assertEqual(["valid"], names)


class UnknownMemberRegressionTest(unittest.TestCase):
    def setUp(self) -> None:
        result_schema = _schema("ResultResponse", _prop("code"), fixture="validResultResponse")
        other_schema = _schema("OtherResponse", _prop("status"), fixture="validOtherResponse")
        fixtures = (
            FixtureSpec("r", "validResultResponse", "ResultResponse", "r"),
            FixtureSpec("o", "validOtherResponse", "OtherResponse", "o"),
        )
        self.ctx, self.method, self.method_ctx = _ctx(schemas=(result_schema, other_schema), fixtures=fixtures)

    def test_24_unknown_assertion_removed_when_other_oracle_remains(self) -> None:
        source = _test("unknownAssertion", "ResultResponse result=sampleServiceImpl.execute();\nassertNotNull(result);\nassertEquals(\"X\", result.getInvented());")
        repaired = deterministically_repair_test(self.ctx, self.method, self.method_ctx, source)
        self.assertNotIn("getInvented", repaired.source)
        self.assertIn("assertNotNull", repaired.source)

    def test_25_wrong_receiver_corrected_when_unambiguous(self) -> None:
        source = _test("wrongReceiver", "ResultResponse result=sampleServiceImpl.execute();\nOtherResponse other=validOtherResponse();\nassertNotNull(result);\nassertEquals(\"S\", result.getStatus());")
        repaired = deterministically_repair_test(self.ctx, self.method, self.method_ctx, source)
        self.assertIn("other.getStatus()", repaired.source)

    def test_26_invented_member_not_fabricated(self) -> None:
        source = _test("invented", "ResultResponse result=sampleServiceImpl.execute();\nassertEquals(\"X\", result.getInvented());")
        repaired = deterministically_repair_test(self.ctx, self.method, self.method_ctx, source)
        self.assertIn("getInvented", repaired.source)
        self.assertFalse(any("Invented" in action and "corrected" in action for action in repaired.actions))


class CompileGranularityRegressionTest(unittest.TestCase):
    def setUp(self) -> None:
        self.suite = '''class T {
// JUNITFORGE_METHOD_BEGIN: execute()
@Test void first() {
  assertTrue(true);
}
@Test void broken() {
  MissingType value = null;
}
@Test void third() {
  assertTrue(true);
}
// JUNITFORGE_METHOD_END: execute()
}'''

    def test_27_compiler_error_maps_to_individual_test(self) -> None:
        line = next(i for i, value in enumerate(self.suite.splitlines(), 1) if "MissingType" in value)
        self.assertEqual("execute()", owner_method_id_for_line(self.suite, line))
        self.assertEqual("broken", _test_method_name_for_line(self.suite, line))

    def test_28_compile_repair_preserves_siblings(self) -> None:
        block = method_block_for_id(self.suite, "execute()")
        repaired = replace_test_method(block, "broken", _test("broken", "assertTrue(true);"))
        self.assertEqual({"first", "broken", "third"}, set(_test_method_names(repaired)))


class RuntimeIdentityRegressionTest(unittest.TestCase):
    def setUp(self) -> None:
        self.before = '''class T {
// JUNITFORGE_METHOD_BEGIN: execute()
@Test void selectedA(){assertTrue(false);}
@Test void selectedB(){assertTrue(false);}
@Test void sibling(){assertTrue(true);}
// JUNITFORGE_METHOD_END: execute()
}'''
        self.after = self.before.replace("assertTrue(false)", "assertTrue(true)", 1)
        self.before_failures = (_failure("selectedA"), _failure("selectedB"))
        self.before_run = CoverageRunResult(
            ok=True,
            measured=True,
            note="before",
            signals=CoverageSignals(tests_executed=True, tests_run=3, tests_failed=2),
            failures=self.before_failures,
            executed_test_names=("selectedA", "selectedB", "sibling"),
            maven_execution_success=True,
        )

    def gate(self, after_source: str | None = None, targeted: RuntimeTestRunResult | None = None,
             full: RuntimeTestRunResult | None = None):
        return validate_runtime_candidate_identity(
            before_source=self.before,
            after_source=after_source or self.after,
            owner="execute()",
            selected_test_names={"selectedA", "selectedB"},
            before_run=self.before_run,
            targeted_run=targeted or _run(("selectedA", "selectedB")),
            full_run=full or _run(("selectedA", "selectedB", "sibling"), failures=(_failure("selectedB"),)),
            owner_failures_before=list(self.before_failures),
        )

    def test_29_runtime_repair_preserves_exact_test_names(self) -> None:
        ok, reason, _ = self.gate()
        self.assertTrue(ok, reason)

    def test_30_runtime_repair_preserves_full_and_owner_counts(self) -> None:
        ok, reason, _ = self.gate()
        self.assertTrue(ok, reason)

    def test_31_targeted_count_mismatch_rolls_back(self) -> None:
        ok, reason, _ = self.gate(targeted=_run(("selectedA",), tests_run=1))
        self.assertFalse(ok)
        self.assertEqual("TARGETED_TEST_COUNT_MISMATCH", reason)

    def test_32_disappearing_test_not_resolved(self) -> None:
        changed = self.after.replace("@Test void selectedB(){assertTrue(false);}\n", "")
        ok, reason, missing = self.gate(after_source=changed)
        self.assertFalse(ok)
        self.assertIn(reason, {"TEST_IDENTITY_CHANGED", "OWNER_TEST_IDENTITY_CHANGED"})
        self.assertIn("selectedB", missing)

    def test_33_newly_failing_test_causes_rollback(self) -> None:
        full = _run(("selectedA", "selectedB", "sibling"), failures=(_failure("selectedB"), _failure("sibling")))
        ok, reason, details = self.gate(full=full)
        self.assertFalse(ok)
        self.assertEqual("NEW_FAILING_TEST_INTRODUCED", reason)
        self.assertIn("sibling", details)

    def test_34_final_report_uses_last_full_result(self) -> None:
        outcome = TargetOutcome("sample.T", "m", "T.java", "TTest.java", "unit", True)
        engine = SimpleNamespace()
        # Exercise Engine's unbound record methods: targeted must not overwrite final full state.
        initial = CoverageRunResult(ok=True, measured=True, note="full", signals=CoverageSignals(tests_executed=True, tests_run=3, tests_failed=1), maven_execution_success=True)
        Engine._record_coverage_runtime_result(engine, outcome, initial, initial=True)
        Engine._record_runtime_test_result(engine, outcome, _run(("selectedA", "selectedB")), scope="targeted")
        self.assertEqual(3, outcome.runtime_tests_run)
        self.assertEqual(1, outcome.runtime_failures_final)
        self.assertEqual(2, outcome.runtime_last_targeted_run.tests_run)


class ExistingBehaviorRegressionTest(unittest.TestCase):
    def test_35_windows_runtime_log_filename_remains_safe(self) -> None:
        from junitforge.coverage_run import _bounded_log_filename
        with tempfile.TemporaryDirectory() as td:
            value = _bounded_log_filename(
                "sample.Test#method:case+other", log_dir=Path(td)
            )
        self.assertNotRegex(value, r'[<>:"/\\|?*]')

    def test_36_existing_suite_marker(self) -> None:
        # The complete validation command executes every pre-v7.3 test; this marker makes
        # the preservation requirement explicit in the focused suite.
        self.assertTrue(True)


class CompileRepairExtractedTestRegressionTest(unittest.TestCase):
    def test_37_compile_repair_payload_contains_complete_class_and_all_errors(self) -> None:
        import json
        from junitforge.generation.payloads import serviceimpl

        ctx, _method, _method_ctx = _ctx()
        current = """class SampleServiceImplTest {
@Test
void broken() {
    MissingType value = null;
    assertNotNull(value);
}
}"""
        error_line = next(
            index for index, line in enumerate(current.splitlines(), start=1)
            if "MissingType" in line
        )
        errors = [
            CompileError(
                file=Path("SampleServiceImplTest.java"),
                line=error_line,
                col=5,
                message="cannot find symbol",
                detail=["symbol: class MissingType"],
            ),
            CompileError(
                file=Path("SampleServiceImplTest.java"),
                line=error_line + 1,
                col=5,
                message="incompatible types",
                detail=[],
            ),
        ]

        messages = serviceimpl.build_compile_repair_payload(ctx, current, errors)
        payload = json.loads(messages[1]["content"])

        self.assertEqual("compile_repair", payload["request_type"])
        self.assertEqual(current, payload["test_class"]["source"])
        self.assertEqual("SampleServiceImplTest", payload["test_class"]["class_name"])
        self.assertEqual(2, len(payload["compilation_errors"]))
        self.assertNotIn("target_method", payload)
        self.assertNotIn("selected_test", payload)
        self.assertNotIn("runtime_result", payload)


class CompileSalvageOwnerRecordRegressionTest(unittest.TestCase):
    def test_38_irreparable_compile_salvage_uses_method_record_id(self) -> None:
        ctx, _method, _method_ctx = _ctx()
        current = """class SampleServiceImplTest {
// JUNITFORGE_METHOD_BEGIN: execute()
@Test
void validSibling() {
    assertTrue(true);
}
@Test
void broken() {
    MissingType value = null;
    assertNotNull(value);
}
// JUNITFORGE_METHOD_END: execute()
}"""
        error_line = next(
            index for index, line in enumerate(current.splitlines(), start=1)
            if "MissingType" in line
        )
        error = CompileError(
            file=Path("SampleServiceImplTest.java"),
            line=error_line,
            col=5,
            message="cannot find symbol",
            detail=["symbol: class MissingType"],
        )
        method_record = MethodGenerationRecord(
            method_id="execute()",
            tests_extracted=2,
            tests_retained=2,
            final_status=MethodDisposition.GENERATED.value,
            tests=[
                CaseRecord(
                    owner_method_id="execute()",
                    test_name="validSibling",
                    final_disposition=CaseDisposition.RETAINED.value,
                ),
                CaseRecord(
                    owner_method_id="execute()",
                    test_name="broken",
                    final_disposition=CaseDisposition.RETAINED.value,
                ),
            ],
        )
        outcome = TargetOutcome(
            "sample.SampleServiceImpl", "m", "SampleServiceImpl.java",
            "SampleServiceImplTest.java", "unit", True,
            method_results=[method_record],
        )
        compile_gate = SimpleNamespace(
            check=lambda _path, _module: (SimpleNamespace(ok=True), [])
        )
        engine = Engine(
            llm=None,
            compile_gate=compile_gate,
            coverage_runner=None,
            stack=StackProfile(),
            modules=[],
            repo_root=Path("."),
            lookup=lambda _name: None,
            cfg=GenConfig(),
        )

        with tempfile.TemporaryDirectory() as td, patch(
            "junitforge.compilation.salvage.finalize_java",
            side_effect=lambda candidate, **_kwargs: SimpleNamespace(
                ok=True, code=candidate, reason=""
            ),
        ):
            test_path = Path(td) / "SampleServiceImplTest.java"
            test_path.write_text(current, encoding="utf-8")
            salvaged = engine._reject_irreparable_compile_tests(
                ctx,
                current,
                test_path,
                ModuleInfo("m", Path(td), Path(td) / "pom.xml"),
                outcome,
                [error],
            )

        self.assertIsNotNone(salvaged)
        self.assertEqual(("validSibling",), _test_method_names(salvaged or ""))
        self.assertEqual(1, method_record.tests_retained)
        self.assertEqual(1, method_record.tests_rejected)
        self.assertEqual(MethodDisposition.PARTIALLY_GENERATED.value, method_record.final_status)
        broken = next(test for test in method_record.tests if test.test_name == "broken")
        self.assertEqual("FAILED", broken.compile_state)
        self.assertEqual(CaseDisposition.REJECTED.value, broken.final_disposition)
        self.assertIn("compile repair exhausted", broken.final_rejection_reason or "")


class CompileRepairRollbackAndDeterministicRegressionTest(unittest.TestCase):
    def test_owner_block_replacement_is_indentation_idempotent(self) -> None:
        suite = """class SampleServiceImplTest {
    // JUNITFORGE_METHOD_BEGIN: execute()
    @Test
    void first() {
        assertTrue(true);
    }

    @Test
    void second() {
        assertTrue(true);
    }
    // JUNITFORGE_METHOD_END: execute()
}
"""
        block = method_block_for_id(suite, "execute()")
        self.assertIsNotNone(block)
        once = replace_method_block(suite, "execute()", block or "")
        twice = replace_method_block(
            once,
            "execute()",
            method_block_for_id(once, "execute()") or "",
        )
        once_sources = {test.name: test.source for test in extract_test_methods(once)}
        twice_sources = {test.name: test.source for test in extract_test_methods(twice)}
        self.assertEqual(once_sources, twice_sources)

    def test_rejects_test_methods_outside_class_body(self) -> None:
        malformed = """package sample;
class SampleServiceImplTest {
    @Test
    void first() {}
}
@Test
void second() {}
"""
        reason = _test_class_structure_error(malformed, "SampleServiceImplTest")
        self.assertIsNotNone(reason)
        self.assertIn("outside", reason or "")

    def test_changed_diagnostics_are_not_progress_when_error_count_increases(self) -> None:
        before = """class SampleServiceImplTest {
// JUNITFORGE_METHOD_BEGIN: execute()
@Test void broken() { MissingType value = null; }
// JUNITFORGE_METHOD_END: execute()
}
"""
        after = before.replace(
            "MissingType value = null;",
            "MissingType value = null; MissingOther other = null;",
        )
        before_error = CompileError(Path("T.java"), 3, 1, "cannot find symbol", ["symbol: class MissingType"])
        after_errors = [
            CompileError(Path("T.java"), 3, 1, "cannot find symbol", ["symbol: class MissingType"]),
            CompileError(Path("T.java"), 3, 1, "cannot find symbol", ["symbol: class MissingOther"]),
        ]
        self.assertFalse(
            _compile_candidate_is_strict_progress(
                before,
                [before_error],
                after,
                after_errors,
                selected_owner="execute()",
            )
        )

    def test_missing_cut_argument_is_declared_from_verified_parameter(self) -> None:
        method = MethodSig(
            "revertPaymentStatusToQuoteAfterCancelPayment",
            modifiers={"public"},
            return_type="String",
            params=[("String", "quotationNumber")],
        )
        ctx, method, method_context = _ctx(method=method)
        source = _test(
            "revertPaymentStatusToQuoteAfterCancelPayment_whenPolicyIsNull",
            "    when(giPolicyRepository.findByReferenceNo(eq(quotationNumber))).thenReturn(null);\n"
            "    String result = sampleServiceImpl.revertPaymentStatusToQuoteAfterCancelPayment(quotationNumber);\n"
            "    assertEquals(\"\", result);",
        )
        error = CompileError(
            Path("T.java"), 4, 1, "cannot find symbol",
            ["symbol: variable quotationNumber", "location: class SampleServiceImplTest"],
        )
        repaired = deterministically_repair_compile_diagnostics(
            ctx, method, method_context, source, [error]
        )
        self.assertTrue(repaired.changed)
        self.assertIn('String quotationNumber = "quotationNumber";', repaired.source)

    def test_verified_schema_accessor_corrects_is_getter(self) -> None:
        schema = _schema(
            "ProcessPaymentResponseData",
            _prop(
                "paymentStatus",
                "Boolean",
                getter="getPaymentStatus",
                setter="setPaymentStatus",
            ),
        )
        ctx, method, method_context = _ctx(schemas=(schema,))
        source = _test(
            "processPaymentResponse_failure",
            "    assertFalse(result.getData().isPaymentStatus());\n"
            "    verify(iPolicyService).lookup();",
        )
        error = CompileError(
            Path("T.java"), 3, 1, "cannot find symbol",
            [
                "symbol: method isPaymentStatus()",
                "location: class ProcessPaymentResponseData",
            ],
        )
        repaired = deterministically_repair_compile_diagnostics(
            ctx, method, method_context, source, [error]
        )
        self.assertIn("getPaymentStatus()", repaired.source)
        self.assertNotIn("isPaymentStatus()", repaired.source)

    def test_duplicate_getter_before_setter_is_collapsed(self) -> None:
        ctx, method, method_context = _ctx()
        source = _test(
            "generatePayment",
            "    product.getResultPremium().setResultPremium(new BigDecimal(\"100.00\"));\n"
            "    assertNotNull(product);",
        )
        error = CompileError(
            Path("T.java"), 3, 1, "cannot find symbol",
            [
                "symbol: method setResultPremium(BigDecimal)",
                "location: class BigDecimal",
            ],
        )
        repaired = deterministically_repair_compile_diagnostics(
            ctx, method, method_context, source, [error]
        )
        self.assertIn("product.setResultPremium(new BigDecimal", repaired.source)
        self.assertNotIn("getResultPremium().setResultPremium", repaired.source)

    def test_unknown_collaborator_receiver_uses_unique_verified_field(self) -> None:
        invocation = _invocation(
            field="giBillRepo",
            dependency_type="GiBillRepository",
            method="findByGiPolicyEntityAndStatus",
            return_type="GiBillEntity",
        )
        dependency = DependencyRef(
            field_name="giBillRepo",
            parameter_name=None,
            declared_type="GiBillRepository",
            simple_type="GiBillRepository",
            fqcn="sample.GiBillRepository",
            origin="field",
            resolution_status=ResolutionStatus.RESOLVED,
        )
        ctx, method, method_context = _ctx(
            invocations=(invocation,), dependencies=(dependency,)
        )
        source = _test(
            "generatePayment",
            "    when(giBillRepository.findByGiPolicyEntityAndStatus(giPolicy, 'A')).thenReturn(giBill);\n"
            "    assertNotNull(giBill);",
        )
        error = CompileError(
            Path("T.java"), 3, 1, "cannot find symbol",
            ["symbol: variable giBillRepository", "location: class SampleServiceImplTest"],
        )
        repaired = deterministically_repair_compile_diagnostics(
            ctx, method, method_context, source, [error]
        )
        self.assertIn("giBillRepo.findByGiPolicyEntityAndStatus", repaired.source)
        self.assertNotIn("giBillRepository.findBy", repaired.source)

    def test_worsening_llm_candidate_is_rolled_back_before_salvage(self) -> None:
        ctx, _, _ = _ctx()
        baseline = """package sample;
class SampleServiceImplTest {
// JUNITFORGE_METHOD_BEGIN: execute()
@Test
void broken() { MissingType value = null; sampleServiceImpl.execute(); }
// JUNITFORGE_METHOD_END: execute()
}
"""
        candidate = baseline.replace(
            "MissingType value = null;",
            "MissingType value = null; MissingOther other = null;",
        )
        before_line = next(i for i, line in enumerate(baseline.splitlines(), 1) if "MissingType" in line)
        after_line = next(i for i, line in enumerate(candidate.splitlines(), 1) if "MissingType" in line)
        before_error = CompileError(Path("T.java"), before_line, 1, "cannot find symbol", ["symbol: class MissingType"])
        candidate_errors = [
            CompileError(Path("T.java"), after_line, 1, "cannot find symbol", ["symbol: class MissingType"]),
            CompileError(Path("T.java"), after_line, 1, "cannot find symbol", ["symbol: class MissingOther"]),
        ]
        cfg = GenConfig()
        cfg.max_compile_repairs = 1
        gate = SimpleNamespace(check=lambda _path, _module: (SimpleNamespace(ok=False), candidate_errors))
        engine = Engine(
            llm=SimpleNamespace(),
            compile_gate=gate,
            coverage_runner=None,
            stack=StackProfile(),
            modules=[],
            repo_root=Path("."),
            lookup=lambda _name: None,
            cfg=cfg,
        )
        engine._last_methodwise_repair_owner = "execute()"
        engine._last_methodwise_repair_test = "broken"
        engine._last_methodwise_repair_changed = True
        outcome = TargetOutcome(
            "sample.SampleServiceImpl", "m", "SampleServiceImpl.java",
            "SampleServiceImplTest.java", "unit", True,
        )
        captured: dict[str, str] = {}

        def salvage(_ctx, current, *_args):
            captured["current"] = current
            return current

        with tempfile.TemporaryDirectory() as td, patch.object(
            engine,
            "_repair_compile_diagnostics_deterministically",
            return_value=None,
        ), patch.object(
            engine,
            "_repair_methodwise_error_batch",
            return_value=candidate,
        ), patch.object(
            engine,
            "_reject_irreparable_compile_tests",
            side_effect=salvage,
        ):
            test_path = Path(td) / "SampleServiceImplTest.java"
            test_path.write_text(baseline, encoding="utf-8")
            result = engine._compile_methodwise_repair(
                ctx,
                test_path,
                ModuleInfo("m", Path(td), Path(td) / "pom.xml"),
                outcome,
                [before_error],
            )

        self.assertEqual(baseline, captured.get("current"))
        self.assertEqual(baseline, result)


if __name__ == "__main__":
    unittest.main()
