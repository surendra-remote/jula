"""High-level per-target pipeline orchestration."""

from __future__ import annotations

import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.audit import NullAuditRecorder
from junitforge.audit.console import stage as console_stage
from junitforge.audit.recorder import sha256_text
from junitforge import __version__
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get

log = get("junitforge.loop")

from junitforge.compilation.compiler import CompilerMixin
from junitforge.compilation.deterministic_repairs import DeterministicRepairsMixin
from junitforge.compilation.diagnostics import CompileDiagnosticsMixin
from junitforge.compilation.repair_coordinator import CompilationRepairMixin
from junitforge.compilation.salvage import CompileSalvageMixin
from junitforge.coverage.augmentation import CoverageAugmentationMixin
from junitforge.coverage.coordinator import CoverageCoordinatorMixin
from junitforge.coverage.parse import CoverageParseMixin
from junitforge.coverage.run import CoverageRunMixin
from junitforge.generation.method_generator import GenerationMixin
from junitforge.pipeline.context import PipelineContextMixin, prepare_target
from junitforge.pipeline.result import create_target_outcome
from junitforge.pipeline.state import PipelineState
from junitforge.publication.publisher import PublicationMixin
from junitforge.runtime.repair_coordinator import RuntimeRepairMixin
from junitforge.runtime.runner import RuntimeRunnerMixin
from junitforge.runtime.state import RuntimeStateMixin



@dataclass
class GenerationPipeline(
    GenerationMixin,
    CompilerMixin,
    DeterministicRepairsMixin,
    CompilationRepairMixin,
    CompileSalvageMixin,
    CompileDiagnosticsMixin,
    RuntimeRepairMixin,
    RuntimeRunnerMixin,
    RuntimeStateMixin,
    CoverageAugmentationMixin,
    CoverageCoordinatorMixin,
    CoverageRunMixin,
    CoverageParseMixin,
    PublicationMixin,
    PipelineContextMixin
):
    llm: LLMClient
    compile_gate: CompileGate
    coverage_runner: CoverageRunner | None
    stack: StackProfile
    modules: list[ModuleInfo]
    repo_root: Path
    lookup: Callable[[str], ClassSymbol | None]
    cfg: GenConfig
    kb: KbIndex | None = None
    test_path_fn: _Callable = test_path_for
    symbol_resolver: object | None = None
    configuration_values: dict[str, str] | None = None
    audit: object | None = None

    def __post_init__(self) -> None:
        if self.audit is None:
            self.audit = NullAuditRecorder()

    def run_target(self, source_path: Path) -> TargetOutcome:
        target_started = perf_counter()
        audit_target = source_path.stem
        self.audit.register_target(audit_target, source_path)
        prepared = prepare_target(self, source_path)
        outcome = prepared.outcome
        if prepared.symbol is not None:
            audit_target = prepared.symbol.name
        if prepared.terminal:
            console_stage(
                "FINAL",
                "%s | status=%s | elapsed=%.2fs | audit=%s",
                audit_target,
                outcome.status,
                perf_counter() - target_started,
                self.audit.target_dir(audit_target),
            )
            self.audit.finalize_target(audit_target, outcome=outcome)
            return outcome
        symbol = prepared.symbol
        module = prepared.module
        test_path = prepared.test_path
        ctx = prepared.context
        assert symbol is not None and module is not None and test_path is not None and ctx is not None

        original = test_path.read_text(encoding="utf-8") if test_path.exists() else None
        pipeline_state = PipelineState(original_source=original)

        generation_started = perf_counter()
        console_stage(
            "GENERATION",
            "started | entry_methods=%d",
            len(ctx.execution_context.methods) if ctx.execution_context else 0,
        )
        code = self._generate(ctx, outcome, module=module, test_path=test_path)
        generation_elapsed = perf_counter() - generation_started
        if code is None:
            outcome.status = "generation_failed"
            self._restore_or_remove(test_path, original)
            console_stage(
                "GENERATION",
                "failed | methods_processed=%d | retained_tests=%d",
                len(outcome.method_results),
                outcome.retained_tests,
                level="warning",
            )
            console_stage(
                "PUBLICATION",
                "rollback | restored=%s",
                "original_test" if original is not None else "none",
                level="warning",
            )
            self.audit.write_json(symbol.name, "13-publication/decision.json", {
                "stage": "publication",
                "target_class": symbol.name,
                "selected_source_state": "original" if original is not None else "none",
                "rollback_performed": True,
                "reason": "generation failed",
            })
            console_stage(
                "FINAL",
                "%s | status=%s | elapsed=%.2fs | audit=%s",
                symbol.name,
                outcome.status,
                perf_counter() - target_started,
                self.audit.target_dir(symbol.name),
            )
            self.audit.finalize_target(symbol.name, outcome=outcome)
            return outcome
        console_stage(
            "GENERATION",
            "completed | methods_processed=%d | tests_generated=%d | rejected=%d | elapsed=%.2fs",
            len(outcome.method_results),
            outcome.retained_tests,
            outcome.rejected_tests,
            generation_elapsed,
        )
        test_path.parent.mkdir(parents=True, exist_ok=True)
        pipeline_state.record_generated_candidate(code)
        test_path.write_text(code, encoding="utf-8")
        self.audit.write_text(symbol.name, "07-class-assembly/assembled.java", code)
        self.audit.write_json(symbol.name, "07-class-assembly/registry.json", outcome.method_results)
        self.audit.write_json(symbol.name, "07-class-assembly/summary.json", {
            "production_methods_selected": outcome.selected_production_methods,
            "methods_processed": len(outcome.method_results),
            "tests_generated": outcome.retained_tests + outcome.rejected_tests,
            "tests_retained": outcome.retained_tests,
            "tests_structurally_rejected": outcome.rejected_tests,
            "assembled_source_hash": sha256_text(code),
            "test_names": [test.test_name for method in outcome.method_results for test in method.tests],
        })

        compile_started = perf_counter()
        console_stage("COMPILE", "%s started", ctx.test_class_name)
        good = self._compile_with_repair(ctx, test_path, module, outcome)
        compile_elapsed = perf_counter() - compile_started
        if good is None:
            self._capture_failed_test_snapshot(test_path, outcome)
            self._restore_or_remove(test_path, original)
            outcome.status = "compile_failed"
            outcome.notes.append(
                "reverted non-compiling test (restored original)"
                if original is not None else "removed non-compiling test"
            )
            console_stage(
                "COMPILE",
                "failed | errors=%d | elapsed=%.2fs | audit=08-compile/compiler-errors.json",
                len(outcome.compile_errors),
                compile_elapsed,
                level="error",
            )
            console_stage(
                "PUBLICATION",
                "%s | reason=new generated test never compiled",
                "rollback" if original is not None else "removed",
                level="warning",
            )
            self.audit.write_json(symbol.name, "13-publication/decision.json", {
                "stage": "publication",
                "target_class": symbol.name,
                "selected_source_state": "original" if original is not None else "none",
                "rollback_performed": True,
                "reason": "new generated test never compiled",
            })
            console_stage(
                "FINAL",
                "%s | status=%s | failures=%d | errors=%d | elapsed=%.2fs | audit=%s",
                symbol.name,
                outcome.status,
                outcome.runtime_failures_final,
                outcome.runtime_errors_final,
                perf_counter() - target_started,
                self.audit.target_dir(symbol.name),
                level="error",
            )
            self.audit.finalize_target(symbol.name, outcome=outcome)
            return outcome

        console_stage(
            "COMPILE",
            "passed | tests=%d | elapsed=%.2fs",
            outcome.retained_tests,
            compile_elapsed,
        )
        pipeline_state.record_compiling_source(good)

        runner_present = self.coverage_runner is not None
        runner_available = bool(runner_present and self.coverage_runner.available())
        if self.cfg.run_coverage and runner_present and runner_available:
            self._coverage_loop(ctx, module, test_path, symbol, good, outcome, original)
        else:
            outcome.status = "compiled"
            skip_reason = (
                "disabled" if not self.cfg.run_coverage else
                "runner_not_configured" if not runner_present else
                "runner_unavailable"
            )
            outcome.notes.append(f"coverage skipped during generation; reason={skip_reason}")
            console_stage("COVERAGE", "skipped | reason=%s", skip_reason)

        selected_state = (
            "runtime-green" if outcome.runtime_failures_final == 0 and outcome.runtime_errors_final == 0
            else "compiling"
        )
        console_stage("PUBLICATION", "source=%s | published", selected_state)
        self.audit.write_json(symbol.name, "13-publication/decision.json", {
            "stage": "publication",
            "target_class": symbol.name,
            "selected_source_state": selected_state,
            "source_hash": sha256_text(test_path.read_text(encoding="utf-8") if test_path.exists() else good),
            "test_count": outcome.retained_tests,
            "compile_passed": True,
            "runtime_failures": outcome.runtime_failures_final,
            "runtime_errors": outcome.runtime_errors_final,
            "coverage_status": outcome.status,
            "published_path": str(test_path),
            "rollback_performed": False,
            "reason": "strongest validated source selected",
        })
        elapsed = perf_counter() - target_started
        coverage_fragment = f" | line_coverage={outcome.line_pct:.2f}%" if outcome.line_pct is not None else ""
        console_stage(
            "FINAL",
            "%s | status=%s | methods=%d | tests=%d | failures=%d | errors=%d%s",
            symbol.name,
            outcome.status,
            outcome.selected_production_methods,
            outcome.retained_tests,
            outcome.runtime_failures_final,
            outcome.runtime_errors_final,
            coverage_fragment,
        )
        console_stage("FINAL", "elapsed=%.2fs | audit=%s", elapsed, self.audit.target_dir(symbol.name))
        if self.audit.failures:
            outcome.notes.append(f"audit write failures: {len(self.audit.failures)}")
        self.audit.finalize_target(symbol.name, outcome=outcome)
        return outcome


    def _generate(
        self,
        ctx: GenerationContext,
        outcome: TargetOutcome,
        *,
        module: ModuleInfo | None = None,
        test_path: Path | None = None,
    ) -> str | None:
        execution = ctx.execution_context
        if execution is not None and execution.target_kind.value in {"controller", "service-impl"}:
            return self._generate_methodwise(ctx, outcome, module=module, test_path=test_path)
        return self._generate_classwide(ctx, outcome)


    def _chat(self, messages, temperature, max_tokens, outcome: TargetOutcome) -> str | None:
        started = perf_counter()
        log.debug("[TIMING] LLM repair/augmentation start | messages=%d | maxTokens=%d", len(messages), max_tokens)
        try:
            resp = self.llm.chat(messages, temperature=temperature, max_tokens=max_tokens)
        except Exception as exc:  # noqa: BLE001
            outcome.notes.append(f"llm error: {str(exc)[:140]}")
            return None
        if getattr(resp, "usage", None):
            outcome.tokens_used += resp.usage.total_tokens
        self.audit.record_llm_usage(getattr(resp, "usage", None))
        log.debug(
            "[TIMING] LLM repair/augmentation end: %.3fs | tokens=%d",
            perf_counter() - started,
            resp.usage.total_tokens if getattr(resp, "usage", None) else 0,
        )
        return resp.message
