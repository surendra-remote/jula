"""Runtime repair identity and acceptance validation."""

from __future__ import annotations

import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get

log = get("junitforge.loop")


def validate_runtime_candidate_identity(
    *,
    before_source: str,
    after_source: str,
    owner: str,
    selected_test_names: set[str],
    before_run: CoverageRunResult | RuntimeTestRunResult,
    targeted_run: RuntimeTestRunResult,
    full_run: RuntimeTestRunResult,
    owner_failures_before: list[SurefireFailure],
    require_full_green: bool = False,
) -> tuple[bool, str, tuple[str, ...]]:
    """Authoritative v7.3 runtime acceptance gate with exact test identity preservation."""
    before_names = tuple(test_method_names(before_source))
    after_names = tuple(test_method_names(after_source))
    before_owner_block = method_block_for_id(before_source, owner) or ""
    after_owner_block = method_block_for_id(after_source, owner) or ""
    before_owner_names = tuple(test_method_names(before_owner_block))
    after_owner_names = tuple(test_method_names(after_owner_block))

    missing_all = tuple(sorted(set(before_names) - set(after_names)))
    added_all = tuple(sorted(set(after_names) - set(before_names)))
    if len(after_names) != len(before_names) or missing_all or added_all:
        return False, "TEST_IDENTITY_CHANGED", missing_all
    missing_owner = tuple(sorted(set(before_owner_names) - set(after_owner_names)))
    added_owner = tuple(sorted(set(after_owner_names) - set(before_owner_names)))
    if len(after_owner_names) != len(before_owner_names) or missing_owner or added_owner:
        return False, "OWNER_TEST_IDENTITY_CHANGED", missing_owner
    missing_selected_source = tuple(sorted(selected_test_names - set(after_names)))
    if missing_selected_source:
        return False, "SELECTED_TEST_DISAPPEARED", missing_selected_source

    changed_passed_tests: list[str] = []
    for test_name in before_names:
        if test_name in selected_test_names:
            continue
        before_test = test_method_for_name(before_source, test_name)
        after_test = test_method_for_name(after_source, test_name)
        if before_test is None or after_test is None or before_test.source != after_test.source:
            changed_passed_tests.append(test_name)
    if changed_passed_tests:
        return False, "PASSED_TEST_SOURCE_CHANGED", tuple(sorted(changed_passed_tests))

    expected_targeted = len(selected_test_names)
    if targeted_run.signals.tests_run != expected_targeted:
        missing = tuple(sorted(selected_test_names - set(targeted_run.executed_test_names)))
        return False, "TARGETED_TEST_COUNT_MISMATCH", missing
    targeted_executed = set(targeted_run.executed_test_names)
    if targeted_executed and not selected_test_names.issubset(targeted_executed):
        return False, "SELECTED_TEST_NOT_EXECUTED_TARGETED", tuple(
            sorted(selected_test_names - targeted_executed)
        )
    if not targeted_run.maven_execution_success or not targeted_run.signals.tests_executed:
        return False, "TARGETED_EXECUTION_FAILED", tuple(sorted(selected_test_names))
    if require_full_green and not targeted_run.tests_green:
        return False, "TARGETED_TESTS_NOT_GREEN", tuple(
            sorted({failure.test_method for failure in targeted_run.failures})
        )

    if full_run.signals.tests_run != before_run.signals.tests_run:
        missing = tuple(sorted(set(before_names) - set(full_run.executed_test_names)))
        return False, "FULL_TEST_COUNT_MISMATCH", missing
    full_executed = set(full_run.executed_test_names)
    if full_executed and not set(before_names).issubset(full_executed):
        return False, "FULL_TEST_IDENTITY_MISMATCH", tuple(sorted(set(before_names) - full_executed))
    if full_executed and not selected_test_names.issubset(full_executed):
        return False, "SELECTED_TEST_NOT_EXECUTED_FULL", tuple(
            sorted(selected_test_names - full_executed)
        )
    if not full_run.maven_execution_success or not full_run.signals.tests_executed:
        return False, "FULL_EXECUTION_FAILED", ()
    if require_full_green and not full_run.tests_green:
        return False, "FULL_SUITE_NOT_GREEN", tuple(
            sorted({failure.test_method for failure in full_run.failures})
        )

    before_failing_names = {failure.test_method for failure in before_run.failures}
    after_failing_names = {failure.test_method for failure in full_run.failures}
    newly_failing = tuple(sorted(after_failing_names - before_failing_names))
    if newly_failing:
        return False, "NEW_FAILING_TEST_INTRODUCED", newly_failing

    selected_still_failing = selected_test_names & after_failing_names
    owner_before_severity = sum(2 if failure.status == "error" else 1 for failure in owner_failures_before)
    owner_after_severity = sum(
        2 if failure.status == "error" else 1
        for failure in full_run.failures
        if failure.test_method in selected_test_names
    )
    if owner_after_severity >= owner_before_severity or selected_still_failing == selected_test_names:
        return False, "OWNER_FAILURE_SEVERITY_NOT_IMPROVED", tuple(sorted(selected_still_failing))
    before_suite_severity = before_run.signals.tests_errors * 2 + before_run.signals.tests_failed
    after_suite_severity = full_run.signals.tests_errors * 2 + full_run.signals.tests_failed
    if after_suite_severity > before_suite_severity:
        return False, "FULL_SUITE_SEVERITY_WORSENED", ()
    return True, "ACCEPTED", ()
