"""Runtime failure ownership, grouping, and structured repair diagnostics."""

from __future__ import annotations

from collections import defaultdict
import re

from junitforge.coverage_run import SurefireFailure
from junitforge.execution.assembly import (
    owner_method_id_for_line,
    owner_method_id_for_test_name,
)
from junitforge.pipeline.result import owner_for_test


def _map_runtime_failure_owner(
    suite: str,
    failure: SurefireFailure,
    outcome=None,
) -> tuple[str | None, str, str]:
    if outcome is not None:
        owner = owner_for_test(outcome, failure.test_method)
        if owner:
            return owner, "registry", "high"
    owner = owner_method_id_for_test_name(suite, failure.test_method)
    if owner:
        return owner, "registry", "high"
    owner = owner_method_id_for_line(suite, failure.generated_test_line)
    if owner:
        return owner, "line", "high"
    prefix = failure.test_method.split("_", 1)[0].split("when", 1)[0]
    if prefix:
        candidates = []
        for line in suite.splitlines():
            stripped = line.strip()
            if stripped.startswith("// JUNITFORGE_METHOD_BEGIN: "):
                method_id = stripped.split(":", 1)[1].strip()
                method_name = method_id.split("(", 1)[0]
                if method_name == prefix:
                    candidates.append(method_id)
        if len(candidates) == 1:
            return candidates[0], "name", "medium"
    return None, "unmapped", "low"


def _group_runtime_failures(
    suite: str,
    failures: tuple[SurefireFailure, ...] | list[SurefireFailure],
    outcome=None,
) -> tuple[dict[str, list[SurefireFailure]], list[SurefireFailure]]:
    grouped: dict[str, list[SurefireFailure]] = defaultdict(list)
    unmapped: list[SurefireFailure] = []
    for failure in failures:
        owner, _, confidence = _map_runtime_failure_owner(suite, failure, outcome)
        if owner and confidence != "low":
            grouped[owner].append(failure)
        else:
            unmapped.append(failure)
    return dict(grouped), unmapped


def _expected_actual(message: str) -> tuple[str | None, str | None]:
    text = message or ""
    match = re.search(
        r"expected:\s*(?:<(?P<expected_angle>.*?)>|(?P<expected>\S+))\s*"
        r"(?:but was:|but was)\s*(?:<(?P<actual_angle>.*?)>|(?P<actual>\S+))",
        text,
        flags=re.IGNORECASE | re.DOTALL,
    )
    if not match:
        return None, None
    return (
        match.group("expected_angle") or match.group("expected"),
        match.group("actual_angle") or match.group("actual"),
    )


def runtime_diagnostic(failure: SurefireFailure, *, stack_limit: int = 5000) -> dict[str, object]:
    status = (failure.status or "").lower()
    assertion = (
        status == "failure"
        or "AssertionFailedError" in (failure.exception_type or "")
        or failure.category.startswith("ASSERTION_")
        or failure.category in {
            "EXPECTED_EXCEPTION_NOT_THROWN",
            "WANTED_BUT_NOT_INVOKED",
            "NEVER_WANTED_BUT_INVOKED",
            "MOCK_ARGUMENT_MISMATCH",
        }
    )
    expected, actual = _expected_actual(failure.message)
    return {
        "type": "assertion_failure" if assertion else "runtime_error",
        "exception": failure.exception_type or None,
        "message": failure.message or "",
        "expected": expected,
        "actual": actual,
        "source_line": failure.generated_test_line,
        "stack_trace": (failure.stack_trace or "")[:stack_limit],
        "category": failure.category,
    }


def _runtime_failure_excerpt(failures: list[SurefireFailure], limit: int = 9000) -> str:
    chunks: list[str] = []
    for failure in failures:
        chunk = "\n".join(
            (
                f"TEST: {failure.test_class}#{failure.test_method}",
                f"STATUS: {failure.status}",
                f"CATEGORY: {failure.category}",
                f"EXCEPTION: {failure.exception_type}",
                f"MESSAGE: {failure.message}",
                f"GENERATED_TEST_LINE: {failure.generated_test_line}",
                f"PRODUCTION_FRAME: {failure.production_file}:{failure.production_line}",
                "STACK TRACE:",
                failure.stack_trace,
            )
        )
        chunks.append(chunk)
        if sum(len(value) for value in chunks) >= limit:
            break
    return "\n\n---\n\n".join(chunks)[:limit]


def _failure_signatures(
    failures: tuple[SurefireFailure, ...] | list[SurefireFailure],
) -> set[str]:
    return {failure.signature for failure in failures}


__all__ = [
    "_failure_signatures",
    "_group_runtime_failures",
    "_map_runtime_failure_owner",
    "_runtime_failure_excerpt",
    "runtime_diagnostic",
]
