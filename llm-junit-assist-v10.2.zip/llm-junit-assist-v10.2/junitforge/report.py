"""Honest JSON + Markdown reporting.

Coverage numbers come only from parsed JaCoCo. Integration-only / unmeasured
classes are reported as such with reasons and exact uncovered lines - never a
fabricated percentage.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from junitforge.models import StackProfile, TargetOutcome


def write_reports(report_dir: Path, repo_path: Path, stack: StackProfile,
                  outcomes: list[TargetOutcome], timestamp: str | None = None) -> tuple[Path, Path]:
    report_dir.mkdir(parents=True, exist_ok=True)
    ts = timestamp or datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    json_path = report_dir / f"report_{ts}.json"
    md_path = report_dir / f"report_{ts}.md"

    payload = {
        "timestamp_utc": ts,
        "repo_path": str(repo_path),
        "stack": asdict(stack),
        "tests_executed": any(o.runtime_tests_run > 0 for o in outcomes),
        "summary": _summary(outcomes),
        "remediations": _remediations(outcomes),
        "targets": [asdict(o) for o in outcomes],
    }
    json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    md_path.write_text(_markdown(payload, outcomes), encoding="utf-8")
    return json_path, md_path


def _summary(outcomes: list[TargetOutcome]) -> dict:
    by_status: dict[str, int] = {}
    for o in outcomes:
        by_status[o.status] = by_status.get(o.status, 0) + 1
    measured = [o for o in outcomes if o.line_pct is not None]
    avg_line = round(sum(o.line_pct or 0 for o in measured) / len(measured), 1) if measured else None
    avg_branch = round(sum(o.branch_pct or 0 for o in measured) / len(measured), 1) if measured else None
    return {
        "total": len(outcomes),
        "by_status": by_status,
        "measured": len(measured),
        "avg_line_pct": avg_line,
        "avg_branch_pct": avg_branch,
        "tokens_used": sum(o.tokens_used for o in outcomes),
        "selected_production_methods": sum(o.selected_production_methods for o in outcomes),
        "fully_generated_methods": sum(o.fully_generated_methods for o in outcomes),
        "partially_generated_methods": sum(o.partially_generated_methods for o in outcomes),
        "rejected_methods": sum(o.rejected_methods for o in outcomes),
        "retained_tests": sum(o.retained_tests for o in outcomes),
        "rejected_tests": sum(o.rejected_tests for o in outcomes),
        "fixture_substitutions": sum(o.fixture_substitutions for o in outcomes),
        "unnecessary_stubs_removed": sum(o.unnecessary_stubs_removed for o in outcomes),
        "return_type_mismatches_corrected": sum(
            o.return_type_mismatches_corrected for o in outcomes
        ),
        "invalid_checked_exception_scenarios_removed": sum(
            o.invalid_checked_exception_scenarios_removed for o in outcomes
        ),
        "unknown_member_tests_repaired": sum(o.unknown_member_tests_repaired for o in outcomes),
        "tests_lost_during_compile_repair": sum(
            o.tests_lost_during_compile_repair for o in outcomes
        ),
        "tests_lost_during_runtime_repair": sum(
            o.tests_lost_during_runtime_repair for o in outcomes
        ),
        "silent_method_omissions": sum(o.silent_method_omissions for o in outcomes),
    }


# Detectable "missing test dependency" signals -> maven coordinate to add.
_DEP_SIGNALS = {
    "reactor-test": "io.projectreactor:reactor-test",
    "spring-boot-starter-test": "org.springframework.boot:spring-boot-starter-test",
    "spring-boot-webmvc-test": "org.springframework.boot:spring-boot-webmvc-test",
    "spring-boot-webflux-test": "org.springframework.boot:spring-boot-webflux-test",
}


def _remediations(outcomes: list[TargetOutcome]) -> dict[str, dict[str, list[str]]]:
    """dep coordinate -> {module -> [fqcns]} aggregated from outcome notes."""
    out: dict[str, dict[str, list[str]]] = {}
    for o in outcomes:
        blob = " ".join(o.notes).lower()
        for signal, coord in _DEP_SIGNALS.items():
            if signal in blob:
                out.setdefault(coord, {}).setdefault(o.module, []).append(o.fqcn)
    return out


def _markdown(payload: dict, outcomes: list[TargetOutcome]) -> str:
    s = payload["summary"]
    st = payload["stack"]
    lines = [
        "# junitforge report",
        "",
        f"- Timestamp (UTC): {payload['timestamp_utc']}",
        f"- Repository: {payload['repo_path']}",
        f"- Stack: Spring Boot {st.get('boot_major')} / Spring {st.get('spring_major')} / "
        f"Java {st.get('java_version')} (jakarta={st.get('jakarta')}, "
        f"@MockitoBean={st.get('has_mockitobean')})",
        f"- Tests executed: {payload['tests_executed']}",
        f"- Targets: {s['total']} | measured: {s['measured']} | "
        f"avg line: {s['avg_line_pct']}% | avg branch: {s['avg_branch_pct']}%",
        f"- Status: {', '.join(f'{k}={v}' for k, v in s['by_status'].items())}",
        f"- Tokens used: {s['tokens_used']:,}",
        f"- Production methods: selected={s['selected_production_methods']}, "
        f"generated={s['fully_generated_methods']}, partial={s['partially_generated_methods']}, "
        f"rejected={s['rejected_methods']}, silent omissions={s['silent_method_omissions']}",
        f"- Test salvage: retained={s['retained_tests']}, rejected={s['rejected_tests']}, "
        f"compile-loss={s['tests_lost_during_compile_repair']}, "
        f"runtime-loss={s['tests_lost_during_runtime_repair']}",
        f"- Focused repairs: fixtures={s['fixture_substitutions']}, "
        f"unused stubs={s['unnecessary_stubs_removed']}, "
        f"return mismatches={s['return_type_mismatches_corrected']}, "
        f"checked-exception scenarios removed={s['invalid_checked_exception_scenarios_removed']}, "
        f"unknown members={s['unknown_member_tests_repaired']}",
        "",
        "## Targets",
        "",
        "| Class | Kind | Status | Tests | Failures | Errors | Line% | Branch% | Rounds | Test |",
        "|---|---|---|---:|---:|---:|---:|---:|---:|---|",
    ]
    for o in sorted(outcomes, key=lambda x: (x.module, x.fqcn)):
        line = "-" if o.line_pct is None else f"{o.line_pct:.0f}"
        branch = "-" if o.branch_pct is None else f"{o.branch_pct:.0f}"
        test = Path(o.test_path).name if o.test_path else "-"
        lines.append(
            f"| {o.fqcn} | {o.classification} | {o.status} | {o.runtime_tests_run} | "
            f"{o.runtime_failures_final} | {o.runtime_errors_final} | {line} | {branch} | "
            f"{o.rounds} | {test} |"
        )

    method_targets = [o for o in outcomes if o.method_results]
    if method_targets:
        lines += ["", "## Production-method disposition", ""]
        for o in method_targets:
            lines.append(f"### {o.fqcn}")
            lines.append("")
            lines.append(
                "| Method | Planned | LLM | Extracted | Valid before repair | "
                "Deterministic | LLM repair | Retained | Rejected | Status |"
            )
            lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|---|")
            for record in o.method_results:
                lines.append(
                    f"| {record.method_id} | {record.scenarios_planned} | "
                    f"{record.tests_returned_by_llm} | {record.tests_extracted} | "
                    f"{record.tests_valid_before_repair} | "
                    f"{record.tests_deterministically_repaired} | "
                    f"{record.tests_sent_to_llm_repair} | {record.tests_retained} | "
                    f"{record.tests_rejected} | {record.final_status} |"
                )
            rejected = [
                (record, test)
                for record in o.method_results
                for test in record.tests
                if test.final_disposition == "REJECTED"
            ]
            if rejected:
                lines.append("")
                lines.append("Rejected individual scenarios:")
                for record, test in rejected:
                    category = (
                        test.validation_diagnostics[-1]
                        if test.validation_diagnostics else "UNCLASSIFIED"
                    )
                    lines.append(
                        f"- `{test.test_name}` → `{record.method_id}`; category={category}; "
                        f"deterministic={bool(test.deterministic_repair_history)}; "
                        f"llm={bool(test.llm_repair_history)}; compile={test.compile_state}; "
                        f"reason={test.final_rejection_reason or 'not retained'}"
                    )

    runtime_problem = [
        o for o in outcomes
        if o.runtime_failures_initial or o.runtime_errors_initial or o.runtime_repair_attempts
    ]
    if runtime_problem:
        lines += ["", "## Runtime validation and repair", ""]
        for o in runtime_problem:
            lines.append(
                f"- **{o.fqcn}**: initial={o.runtime_failures_initial}F/{o.runtime_errors_initial}E, "
                f"final={o.runtime_failures_final}F/{o.runtime_errors_final}E, "
                f"repair attempts={o.runtime_repair_attempts}, coverage_current={o.coverage_current}"
            )
            if o.runtime_initial_full_run:
                snap = o.runtime_initial_full_run
                lines.append(
                    f"  - initial full: {snap.tests_run} tests, {snap.failures}F/{snap.errors}E"
                )
            if o.runtime_last_targeted_run:
                snap = o.runtime_last_targeted_run
                lines.append(
                    f"  - last targeted: {snap.tests_run} tests, {snap.failures}F/{snap.errors}E; "
                    f"names={', '.join(snap.executed_test_names) or 'unavailable'}"
                )
            if o.runtime_last_full_run:
                snap = o.runtime_last_full_run
                lines.append(
                    f"  - authoritative last full: {snap.tests_run} tests, "
                    f"{snap.failures}F/{snap.errors}E"
                )
            if o.runtime_last_green_full_run:
                snap = o.runtime_last_green_full_run
                lines.append(f"  - last green full: {snap.tests_run} tests")
            if o.runtime_failure_categories:
                categories = ", ".join(
                    f"{name}={count}" for name, count in sorted(o.runtime_failure_categories.items())
                )
                lines.append(f"  - remaining categories: {categories}")
            if o.runtime_failure_categories_initial:
                initial_categories = ", ".join(
                    f"{name}={count}"
                    for name, count in sorted(o.runtime_failure_categories_initial.items())
                )
                lines.append(f"  - initial categories: {initial_categories}")
            for history in o.runtime_repair_history:
                lines.append(f"  - repair: {history}")
            if o.remaining_runtime_owners:
                lines.append("  - remaining owners: " + ", ".join(o.remaining_runtime_owners))
            if o.surefire_report_paths:
                lines.append("  - Surefire reports: " + ", ".join(o.surefire_report_paths))
            if o.coverage_log_path:
                lines.append(f"  - coverage log: {o.coverage_log_path}")

    detailed_coverage = [
        o for o in outcomes
        if o.instruction_pct is not None or o.method_pct is not None
    ]
    if detailed_coverage:
        lines += ["", "## ServiceImpl coverage details", ""]
        for o in detailed_coverage:
            lines.append(f"### {o.fqcn}")
            lines.append("")
            lines.append(
                f"- Tests: {o.runtime_tests_run}; failures={o.runtime_failures_final}; "
                f"errors={o.runtime_errors_final}; skipped={o.runtime_skipped_final}"
            )
            lines.append(
                f"- Instructions: {o.instruction_covered} covered / "
                f"{o.instruction_missed} missed ({o.instruction_pct:.2f}%)"
            )
            lines.append(
                f"- Lines: {o.line_covered} covered / {o.line_missed} missed "
                f"({(o.line_pct or 0):.2f}%)"
            )
            lines.append(
                f"- Branches: {o.branch_covered} covered / {o.branch_missed} missed "
                f"({(o.branch_pct or 0):.2f}%)"
            )
            lines.append(
                f"- Methods: {o.method_covered} covered / {o.method_missed} missed "
                f"({o.method_pct:.2f}%)"
            )
            if o.uncovered_lines:
                lines.append("- Uncovered lines: " + ", ".join(map(str, o.uncovered_lines)))
            if o.partially_covered_branch_lines:
                lines.append(
                    "- Partially covered branch lines: "
                    + ", ".join(map(str, o.partially_covered_branch_lines))
                )
            if o.jacoco_xml_path:
                lines.append(f"- JaCoCo XML: `{o.jacoco_xml_path}`")
            if o.jacoco_exec_path:
                lines.append(f"- JaCoCo execution data: `{o.jacoco_exec_path}`")
            if o.coverage_source_sha256:
                lines.append(f"- Coverage source SHA-256: `{o.coverage_source_sha256}`")
            lines.append("")

    # Honest gaps: list exact uncovered lines for below-threshold classes.
    gaps = [o for o in outcomes if o.uncovered_lines]
    if gaps:
        lines += ["", "## Uncovered code (exact lines from JaCoCo)", ""]
        for o in gaps:
            ul = ", ".join(map(str, o.uncovered_lines[:40]))
            extra = " ..." if len(o.uncovered_lines) > 40 else ""
            lines.append(f"- **{o.fqcn}** ({o.line_pct:.0f}% line): lines {ul}{extra}")
            if o.uncovered_branches:
                ub = ", ".join(map(str, o.uncovered_branches[:30]))
                lines.append(f"  - partial/uncovered branches at lines: {ub}")

    integ = [o for o in outcomes if o.status == "integration_only"]
    if integ:
        lines += ["", "## Integration-only (not unit-generated)", ""]
        for o in integ:
            lines.append(f"- **{o.fqcn}**: {'; '.join(o.notes) or 'integration test recommended'}")

    rem = _remediations(outcomes)
    if rem:
        lines += ["", "## Suggested remediations (would unlock more unit coverage)", ""]
        for dep, info in rem.items():
            for module, classes in info.items():
                lines.append(f"- Add `{dep}` (test scope) to module **{module}** "
                             f"→ enables unit tests for {len(classes)} class(es): "
                             + ", ".join(sorted(c.rsplit('.', 1)[-1] for c in classes)))

    failed = [
        o for o in outcomes
        if o.status in (
            "compile_failed",
            "generation_failed",
            "runtime_failed",
            "repair_exhausted",
            "coverage_unmeasured",
        )
    ]
    if failed:
        lines += ["", "## Failed", ""]
        for o in failed:
            lines.append(f"- **{o.fqcn}** ({o.status})")
            for e in o.compile_errors[:6]:
                lines.append(f"  - {e}")
    return "\n".join(lines) + "\n"
