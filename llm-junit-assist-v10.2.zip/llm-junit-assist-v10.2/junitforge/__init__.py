"""junitforge - standalone, coverage-driven JUnit 5 test generator.

Version 10.2 builds on the v10 modular pipeline (derived from v7.3.3) and
introduces the finalized ServiceImpl-only LLM workflow: structured method
generation, complete-class compile repair, failing-test runtime repair, and
JaCoCo measurement/reporting without validation-repair or coverage-augmentation
LLM calls.
"""

__version__ = "10.2"
