"""Per-test compile salvage after bounded repair exhaustion."""

from __future__ import annotations

import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get

log = get("junitforge.loop")

from junitforge.publication.summary import _refresh_generation_counters
from junitforge.runtime.state import _mark_retained_compile_state


class CompileSalvageMixin:
    def _reject_irreparable_compile_tests(
        self,
        ctx: GenerationContext,
        current: str,
        test_path: Path,
        module: ModuleInfo,
        outcome: TargetOutcome,
        errors,
    ) -> str | None:
        """Reject only tests that still own compiler errors after bounded repair."""
        affected: dict[tuple[str, str], list[str]] = defaultdict(list)
        for error in errors:
            owner = owner_method_id_for_line(current, error.line)
            test_name = test_method_name_for_line(current, error.line)
            if owner and test_name:
                affected[(owner, test_name)].append(error.render())
        if not affected:
            return None

        candidate = current
        rejected_names: list[str] = []
        for (owner, test_name), diagnostics in sorted(affected.items()):
            owner_block = method_block_for_id(candidate, owner)
            if owner_block is None or test_method_for_name(owner_block, test_name) is None:
                continue
            updated_block = remove_test_method(owner_block, test_name)
            if updated_block is None:
                continue
            if test_method_names(updated_block):
                candidate = replace_method_block(candidate, owner, updated_block)
            else:
                # Retain an empty owner marker so reporting still accounts for the method.
                candidate = replace_method_block(candidate, owner, "")
            rejected_names.append(test_name)
            for record in outcome.method_results:
                # MethodGenerationRecord is owner-level and identifies the production
                # method through method_id. owner_method_id belongs to TestCaseRecord.
                if record.method_id != owner:
                    continue
                for test in record.tests:
                    if test.test_name != test_name:
                        continue
                    if test.final_disposition == TestDisposition.RETAINED.value:
                        record.tests_retained = max(0, record.tests_retained - 1)
                        record.tests_rejected += 1
                    test.compile_state = "FAILED"
                    test.final_disposition = TestDisposition.REJECTED.value
                    test.final_rejection_reason = (
                        "compile repair exhausted for individual test: " + " | ".join(diagnostics[:3])
                    )
                if record.tests_retained == 0:
                    record.final_status = MethodDisposition.REJECTED.value
                elif record.tests_rejected:
                    record.final_status = MethodDisposition.PARTIALLY_GENERATED.value

        if not rejected_names:
            return None
        finalized = finalize_java(
            candidate,
            test_package=ctx.test_package,
            test_class_name=ctx.test_class_name,
            template=ctx.template,
            cut_symbol=ctx.symbol,
            collaborators=ctx.collaborators,
            source_imports=ctx.source_imports,
        )
        if not finalized.ok or not finalized.code:
            return None
        test_path.write_text(finalized.code, encoding="utf-8")
        result, remaining = self._compile_candidate(test_path, module)
        if not result.ok:
            return None
        outcome.notes.append(
            "compile repair rejected only irreparable tests: " + ", ".join(sorted(rejected_names))
        )
        outcome.compile_errors = []
        _mark_retained_compile_state(outcome, "PASSED")
        _refresh_generation_counters(outcome)
        log.debug(
            "[METHOD_COMPILE_REPAIR] per_test_salvage.success | rejected_tests=%s | retained_tests=%d",
            sorted(rejected_names), len(test_method_names(finalized.code)),
        )
        return finalized.code
