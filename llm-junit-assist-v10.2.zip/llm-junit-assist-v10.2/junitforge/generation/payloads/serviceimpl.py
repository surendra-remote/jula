"""Structured ServiceImpl LLM request payloads for v10.2.

ServiceImpl is intentionally isolated from controller, DTO/entity, and other
payload builders. Validation repair and coverage augmentation are disabled for
this target type in v10.2.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import json
import re
from typing import Any

from junitforge.execution.assembly import cut_variable_name
from junitforge.generation.source_closure import build_source_closure


_SYSTEM_MESSAGE = (
    "You are a deterministic Java JUnit 5 test-generation engine. "
    "Follow the structured user payload as authoritative for allowed symbols, "
    "generation or repair scope, Mockito, assertions, and output. "
    "Do not invent unsupported APIs or behavior. Return only the requested output."
)

_GENERATION_INSTRUCTION = {'objective': {'tests_to_generate': 1,
               'requested_test_kind': 'normal_success',
               'coverage_scope': 'The authorized target method and all same-class helpers reached by the selected '
                                 'execution path.',
               'authorized_cut_invocation': 'Invoke only the authorized public target method on the supplied '
                                            'class-under-test instance.',
               'output_format': 'One raw Java JUnit 5 @Test method only.'},
 'path_selection': {'instruction': 'Analyze the target method and all reachable supplied same-class helper method '
                                   'bodies as one interprocedural execution unit. Derive feasible execution paths and '
                                   'select one complete path satisfying the requested test kind.',
                    'requirements': ['Derive paths only from control-flow constructs present in the supplied source.',
                                     'Trace if/else branches, ternary expressions, switch cases, loops, null guards, '
                                     'short-circuit expressions, Optional operations, stream operations, returns, '
                                     'throws, catches, and helper calls.',
                                     'Carry values, branch decisions, collaborator returns, object mutations, returned '
                                     'values, and exceptions across same-class helper boundaries.',
                                     'Each candidate path must represent one internally consistent execution from '
                                     'entry of the authorized target method to a terminal outcome.',
                                     'Reject paths containing mutually incompatible conditions.',
                                     'Reject paths requiring one value to satisfy contradictory predicates.',
                                     'Reject paths depending on unresolved methods, constants, types, fields, '
                                     'constructors, enum values, or collaborator contracts.',
                                     'Do not combine branch conditions, collaborator calls, fixture states, or '
                                     'expected outcomes from different paths.',
                                     'After selecting the path, identify only the collaborator calls and same-class '
                                     'helpers reached by that path.',
                                     'Use the selected path to determine fixture state, object relationships, '
                                     'collection contents, collaborator behavior, and observable assertions.'],
                    'requested_test_kind_rules': {'normal_success': ['Select a path that completes normally without '
                                                                     'entering a source-proven failure or exception '
                                                                     'outcome.',
                                                                     'The path must execute meaningful production '
                                                                     'behavior rather than terminate immediately '
                                                                     'because of invalid input.',
                                                                     'For a void method, successful normal completion '
                                                                     'must be demonstrated through source-proven state '
                                                                     'changes or collaborator interactions.',
                                                                     'For a non-void method, derive the expected '
                                                                     'result from the selected return path and '
                                                                     'source-proven mutations.'],
                                                  'handled_failure': ['Select a path where production code handles an '
                                                                      'error and returns, records, or exposes a '
                                                                      'source-proven failure outcome.'],
                                                  'propagated_exception': ['Select a path where a source-proven '
                                                                           'exception leaves the authorized public '
                                                                           'method.'],
                                                  'alternate_branch': ['Select one feasible path exercising the '
                                                                       'requested branch outcome without combining it '
                                                                       'with another execution path.']}},
 'source_analysis': {'instructions': ['Treat the supplied target method and helper method sources as authoritative.',
                                      'Trace assignments, returns, dereferences, branches, loops, Optional flows, '
                                      'collection operations, collaborator calls, and exceptions across helper '
                                      'boundaries.',
                                      'A collaborator return is consumed when it is assigned and later read, '
                                      'dereferenced, branch-tested, used in another call, returned by a helper, or '
                                      'propagated to the target method.',
                                      'A return flow classified as unresolved or unknown must not be treated as '
                                      'ignored.',
                                      'If a required return flow cannot be resolved sufficiently to create a '
                                      'type-correct stub, do not select a path depending on that flow.',
                                      'Respect lazy and conditional execution, including Optional.orElseGet, '
                                      'short-circuit boolean expressions, ternary expressions, callbacks, streams, and '
                                      'loops.',
                                      'Ignore commented-out calls and unreachable source.',
                                      'Do not invent methods, fields, constants, types, constructors, enum values, '
                                      'collaborator behavior, or production outcomes.']},
 'same_class_helper_rule': {'instructions': ['Any same-class helper reached by the selected path must execute as a '
                                             'real method.',
                                             'Never stub, spy, verify, or directly invoke a same-class helper.',
                                             'Cover private, protected, package-visible, and public same-class helpers '
                                             'only through the authorized public target method.',
                                             'Analyze collaborator calls inside reached helpers exactly as '
                                             'collaborator calls inside the target method.',
                                             'Do not include setup for helpers that are not reached by the selected '
                                             'path.']},
 'fixture_rule': {'instructions': ['Use the supplied compiled fixture methods for every fixture-supported application '
                                   'DTO or entity.',
                                   'Assume each compiled fixture provides the normal populated baseline produced by '
                                   'the deterministic test skeleton.',
                                   'Do not construct or recreate fixture-supported application objects using new, '
                                   'builders, mocks, spies, or reflection.',
                                   'A non-fixture-supported type may be constructed only when its verified '
                                   'constructor, builder, factory, or other construction contract is supplied in the '
                                   'request.',
                                   'Inspect the target method and reached same-class helper sources to determine which '
                                   'fixture fields or relationships must be adjusted for the selected path.',
                                   'Apply only the smallest mutations required to satisfy selected-path conditions, '
                                   'dereferences, collaborator arguments, or expected behavior.',
                                   'Do not replace a populated nested object graph when a smaller field mutation is '
                                   'sufficient.',
                                   'Preserve object identity when the same logical object is attached to another '
                                   'object, returned by a collaborator, passed through helpers, persisted, or later '
                                   'dereferenced.',
                                   'Ensure every intermediate object dereferenced by the selected path is non-null and '
                                   'every collection read has sufficient contents.',
                                   'Do not reconstruct the complete project-specific object graph when the supplied '
                                   'fixture already provides a usable baseline.',
                                   'If a selected path requires a field or object relationship that cannot be '
                                   'established using the supplied fixtures and verified available members, do not '
                                   'select that path.',
                                   'Do not invent project-specific field values or object relationships that are not '
                                   'supported by the supplied source.']},
 'fixture_value_rule': {'instructions': ['Use exact resolved constants when source conditions compare against those '
                                         'constants.',
                                         'Use verified enum constants for enum-typed fields.',
                                         'Use deterministic type-correct values for unconstrained scalar fields.',
                                         'Choose values that satisfy the exact predicates of the selected path.',
                                         'When multiple values must compare equal, derive them from one deterministic '
                                         'source value.',
                                         'When values must compare differently, choose values whose difference remains '
                                         'unambiguous under the production comparison logic.',
                                         'Do not guess unresolved constant or enum values.',
                                         'Do not mutate fields unrelated to the selected path.']},
 'collaborator_rule': {'instructions': ['Derive Mockito behavior from the exact target and reached helper method '
                                        'bodies.',
                                        'Stub only collaborator calls reached by the selected path.',
                                        'Every reached non-void collaborator call whose return is consumed must '
                                        'receive a type-correct stub.',
                                        'Do not omit a required stub because the collaborator call occurs inside a '
                                        'same-class helper.',
                                        'Do not stub a collaborator call whose return is conclusively ignored unless '
                                        'the selected path requires a source-proven side effect to be simulated.',
                                        'Normal void collaborator calls require no stub.',
                                        'Use doThrow only when the selected path intentionally requires a collaborator '
                                        'exception.',
                                        'Use Mockito matchers for arguments created or transformed inside production '
                                        'code.',
                                        'Never reference production-local variables or helper parameters directly in '
                                        'the test.',
                                        'Use an exact test-visible expression only when the expression is available in '
                                        'test scope and is equivalent after all production transformations.',
                                        'When one argument uses a Mockito matcher, all arguments in that invocation '
                                        'must use Mockito matchers.']},
 'repository_rule': {'instructions': ['Treat repository methods according to return consumption and selected-path '
                                      'behavior, not merely because they are repository operations.',
                                      'A lookup return used by Optional logic, fallback selection, a branch, a '
                                      'dereference, another call, a helper return, or the target return requires a '
                                      'stub.',
                                      'For lazy fallback logic, stub only lookups executed by the selected path.',
                                      'A save or update result returned by a helper, assigned and later read, '
                                      'branch-tested, or dereferenced requires a stub.',
                                      'When a save method must return the same submitted entity, use '
                                      'thenAnswer(invocation -> invocation.getArgument(0)).',
                                      'When a save or update return is conclusively ignored and no '
                                      'persistence-generated mutation is later read, no normal return stub is '
                                      'required.',
                                      'When production later depends on persistence-generated state, simulate only the '
                                      'source-proven mutation required by the selected path.',
                                      'Normal void repository calls require no doNothing stub.']},
 'collection_rule': {'instructions': ['Use an empty collection only when the selected path permits or requires no '
                                      'existing elements.',
                                      'Populate the minimum number of elements required by the selected path.',
                                      'Provide at least one element when production executes get(0), '
                                      'iterator().next(), findFirst().get(), or equivalent.',
                                      'Use mutable collections only when test setup or production code mutates them.',
                                      'Do not use a null collection when the selected path streams, iterates, checks, '
                                      'indexes, or mutates it.',
                                      'Preserve element identity when an element selected from a collection is passed '
                                      'to later helpers or collaborator calls.']},
 'assertion_rule': {'instructions': ['Derive assertions only from observable behavior produced by the selected path.',
                                     'For a non-void method, assert the returned value according to its verified type '
                                     'and the selected return path.',
                                     'Do not require assertNotNull when the verified successful result may '
                                     'legitimately be null.',
                                     'For a void method, assert source-proven state changes or behaviorally important '
                                     'collaborator interactions.',
                                     'For returned objects, assert only fields assigned, mutated, or deterministically '
                                     'preserved on the selected path.',
                                     'For primitives, strings, enums, collections, arrays, Optional values, and '
                                     'entities, use type-appropriate JUnit assertions.',
                                     'Assert exact values only when they are deterministically derived from fixtures, '
                                     'constants, configuration, inputs, or collaborator returns.',
                                     'For nondeterministic but required values, assert only the source-proven '
                                     'constraint such as non-null, non-empty, positive, or collection size.',
                                     'Do not assert fields populated only by an unselected branch.',
                                     'Do not combine success assertions with handled-failure or propagated-exception '
                                     'assertions.',
                                     'Verify only interactions that demonstrate the selected behavior or distinguish '
                                     'the selected path.']},
 'strict_mockito_rule': {'instructions': ['Keep every stub inside the generated test method.',
                                          'Do not use lenient().',
                                          'Do not create stubs for calls not reached by the selected path.',
                                          'Do not stub or verify the class under test.',
                                          'Do not use doNothing for normal void calls.',
                                          'Do not use exact object equality for arguments constructed internally by '
                                          'production code unless the same instance is supplied by the test.',
                                          'Do not verify every collaborator call when the interaction is not '
                                          'behaviorally relevant.']},
 'compile_safety': {'instructions': ['Use only symbols explicitly supplied in the request.',
                                     'For fixture-supported application types, use only their supplied fixture '
                                     'methods.',
                                     'For non-fixture-supported types, use only supplied constructors, builders, '
                                     'factories, setters, getters, and enum constants.',
                                     'Use only supplied collaborator methods, constants, configuration fields, and '
                                     'fixture methods.',
                                     'Do not add imports.',
                                     'Do not define helper methods.',
                                     'Do not create or start a Spring test context.',
                                     'Do not directly invoke private methods.',
                                     'Do not use ReflectionTestUtils.invokeMethod.',
                                     'Use only JUnit Jupiter assertions and Mockito APIs available in the existing '
                                     'compiled test skeleton.',
                                     'If a compile-safe implementation requires an unresolved symbol or unsupported '
                                     'operation, do not generate that path.']},
 'output': {'instructions': ['Output exactly one complete Java @Test method.',
                             'Do not output markdown fences.',
                             'Do not output prose.',
                             'Do not output package or import declarations.',
                             'Do not output a class declaration.',
                             'Do not output fields, setup methods, or additional helper methods.']}}

_COMPILE_REPAIR_INSTRUCTIONS = {'objective': 'Repair all supplied compilation errors in the complete ServiceImpl test class.',
 'preservation_rules': ['Preserve every existing @Test method whenever it can be repaired.',
                        'Preserve every existing test name.',
                        'Do not remove tests merely to obtain compilation success.',
                        'Do not disable or comment out tests.',
                        'Do not introduce new tests.',
                        'Do not change test intent unnecessarily.',
                        'Do not remove valid sibling tests.'],
 'compile_rules': ['Return valid Java 17 source.',
                   'Use JUnit Jupiter assertions only.',
                   'Use Mockito APIs correctly.',
                   'Do not introduce AssertJ, Hamcrest, Truth, PowerMock, or Spring context tests.',
                   'Do not invent application fields, methods, constructors, getters, setters, collaborators, or '
                   'overloads.',
                   'Repair incompatible argument types, return types, matcher types, imports, symbols, checked '
                   'exceptions, and Java syntax.',
                   'Do not mix raw arguments and Mockito matchers in the same invocation.',
                   'Use primitive-compatible matchers such as anyChar(), anyInt(), anyLong(), anyBoolean(), '
                   'anyDouble(), and anyFloat() where required.',
                   'Do not use doNothing() for non-void methods.',
                   'Do not use thenReturn() for void methods.',
                   'Do not reference private production fields or production-only local variables that are unavailable '
                   'in test scope.',
                   'Do not assert that unequal objects must have different hash codes.'],
 'output': 'Return exactly one complete corrected Java test class. Return no Markdown, explanation, or surrounding '
           'prose.'}

_RUNTIME_REPAIR_INSTRUCTIONS = {'objective': 'Repair every supplied runtime error and assertion failure for the selected ServiceImpl public entry '
              'method. Each supplied test failed runtime execution. Return corrected versions of only those tests.',
 'repair_scope': ['Modify only the supplied failing test methods.',
                  'Every supplied test must be returned exactly once.',
                  'Preserve the exact name of every supplied @Test method.',
                  'Preserve the production-method ownership of every supplied test.',
                  'Do not add new tests.',
                  'Do not remove, rename, merge, duplicate, disable, or comment out any supplied test.',
                  'Tests not included in this request have already passed and must not be affected.'],
 'diagnostic_rule': ['Treat each failing test together with only the runtime diagnostics attached to that test.',
                     'Repair all diagnostics attached to each supplied test.',
                     'Use the exception type, message, source line, expected value, actual value, Mockito diagnostic, '
                     'and bounded stack trace as repair evidence.',
                     'Repair the demonstrated root cause rather than suppressing the error or failure.',
                     'Do not infer unrelated failures.'],
 'runtime_error_rule': ['For null-related errors, initialize or populate only the required fixture value, nested '
                        'object, collaborator return, or configuration value.',
                        'For UnnecessaryStubbingException, remove only the stub identified as unnecessary in that '
                        'test.',
                        'For Mockito misuse, correct matcher consistency, matcher type, stubbing form, verification '
                        'count, or invocation arguments.',
                        'For unexpected propagated exceptions, correct the arrangement, required collaborator stub, '
                        'fixture value, or expected exception according to demonstrated execution.',
                        'Do not catch and ignore exceptions.',
                        'Do not introduce @Disabled, assumptions, empty catch blocks, or failure-suppression logic.'],
 'assertion_failure_rule': ['Correct assertions only when supplied runtime evidence demonstrates that the current '
                            'expectation is incorrect.',
                            'Preserve meaningful behavioural verification.',
                            'Do not weaken assertions to assertNotNull, assertTrue(true), empty assertions, or '
                            'similarly non-specific checks merely to obtain a passing result.',
                            'For expected-versus-actual mismatches, correct the arrangement or expectation according '
                            'to the demonstrated scenario and result.',
                            'For assertThrows failures, correct the expected exception, invocation arrangement, or '
                            'collaborator behaviour.',
                            'For Mockito verification failures, correct the expected invocation, arguments, or count '
                            'only when supported by runtime evidence.',
                            'Do not delete a failing assertion without replacing it with a valid assertion that still '
                            'verifies the intended scenario.'],
 'source_faithfulness_rule': ['Use only classes, fields, methods, constructors, getters, setters, constants, fixture '
                              'helpers, mocks, and collaborator APIs present in the supplied tests and shared context.',
                              'Do not invent application APIs.',
                              'Exercise production behaviour only through the selected public ServiceImpl entry '
                              'method.',
                              'Do not call private, protected, or package-visible same-class helper methods directly.',
                              'Do not mock, spy, stub, or verify same-class helper methods.'],
 'fixture_rule': ['Reuse supplied fixture helpers when available.',
                  'Change fixture values only when required by attached diagnostics.',
                  'Prefer a test-local correction over changing shared fixture behaviour.',
                  'Do not replace a verified fixture with manual construction unless the fixture itself is the '
                  'demonstrated cause.',
                  'Do not introduce arbitrary values unrelated to the failing scenario.'],
 'collaborator_rule': ['Use only collaborator fields and methods already present in the supplied test or required '
                       'shared context.',
                       'Add or modify a stub only when required by the demonstrated execution path.',
                       'Do not add unnecessary return stubbing when production code ignores the returned value.',
                       'Do not use doNothing() for non-void methods.',
                       'Do not use thenReturn() for void methods.',
                       'Do not introduce unverified collaborator APIs.'],
 'mockito_rule': ['Do not mix raw arguments and Mockito matchers in the same invocation.',
                  'Use primitive-compatible matchers such as anyChar(), anyInt(), anyLong(), anyBoolean(), '
                  'anyDouble(), and anyFloat() where required.',
                  'Use eq(value) only when the exact value exists in test scope and is relevant to the scenario.',
                  'Do not reference private production fields or production-only local variables.',
                  'Preserve strict-stubbing compatibility.'],
 'assertion_framework_rule': ['Use JUnit Jupiter assertions only.',
                              'Do not introduce AssertJ, Hamcrest, Truth, PowerMock, or Spring context testing.',
                              'Do not assert that unequal objects must have different hash codes.'],
 'compile_safety': ['Returned tests must be valid Java 17.',
                    'Returned tests must compile inside the existing generated test class.',
                    'Do not introduce unsupported imports, fields, annotations, fixture helpers, setup methods, or '
                    'libraries.',
                    'Do not return partial Java syntax.'],
 'acceptance_expectation': ['Every returned test must compile.',
                            'Every returned test must pass targeted runtime execution.',
                            'The complete generated test class must pass with zero errors and zero failures.',
                            'A candidate that breaks a previously passing test is invalid and must be rolled back.'],
 'output': ['Return exactly one complete corrected @Test method for every supplied failing test.',
            'Preserve exact test names and the number of supplied tests.',
            'Return corrected tests in the same order as the request.',
            'Do not return passing tests.',
            'Do not return package declarations, imports, class declarations, setup methods, fixture helpers, '
            'Markdown, explanations, or surrounding prose.']}


@dataclass(frozen=True, slots=True)
class ServiceImplPayloadStageDisabled:
    request_type: str
    reason: str
    disabled: bool = True


def _messages(payload: dict[str, Any]) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": _SYSTEM_MESSAGE},
        {"role": "user", "content": json.dumps(payload, indent=2, ensure_ascii=False)},
    ]


def _method_id(method) -> str:
    return f"{method.name}({','.join(type_name for type_name, _ in method.params)})"


def _method_context(ctx, method):
    method_id = _method_id(method)
    execution = getattr(ctx, "execution_context", None)
    return next((item for item in getattr(execution, "methods", ()) if item.method_id == method_id), None)


def _simple_name(type_name: str) -> str:
    text = (type_name or "Object").strip()
    if "<" in text:
        text = text.split("<", 1)[0]
    return text.rsplit(".", 1)[-1].replace("[]", "")


def _variable_name(type_name: str) -> str:
    simple = _simple_name(type_name)
    return simple[:1].lower() + simple[1:] if simple else "value"


def _fixture_payload(ctx, method_context) -> list[dict[str, Any]]:
    execution = getattr(ctx, "execution_context", None)
    if execution is None or method_context is None:
        return []
    by_id = {fixture.fixture_id: fixture for fixture in execution.fixtures}
    result: list[dict[str, Any]] = []
    for fixture_id in method_context.required_fixture_ids:
        fixture = by_id.get(fixture_id)
        if fixture is None or not fixture.supported:
            continue
        result.append({
            "type": fixture.return_type,
            "fixture_method": fixture.method_name,
            "invocation": f"{fixture.return_type} {_variable_name(fixture.return_type)} = {fixture.method_name}();",
            "status": "compiled",
        })
    return result


def _contract_signature(contract) -> str:
    parameters = ", ".join(
        f"{type_name} {name}" if name else type_name
        for type_name, name in zip(
            contract.parameter_types,
            contract.parameter_names or ("",) * len(contract.parameter_types),
        )
    )
    return f"{contract.return_type or 'void'} {contract.method_name}({parameters})"


def _collaborator_payload(method_context) -> list[dict[str, Any]]:
    if method_context is None:
        return []
    grouped: dict[tuple[str, str], dict[str, Any]] = {}
    seen_methods: set[tuple[str, str, str, tuple[str, ...]]] = set()
    for invocation in method_context.dependency_invocations:
        contract = invocation.contract
        receiver_key = (invocation.dependency_field, invocation.dependency_type)
        receiver = grouped.setdefault(receiver_key, {
            "field": invocation.dependency_field,
            "type": invocation.dependency_type,
            "methods": [],
        })
        key = (
            invocation.dependency_field,
            contract.method_name,
            contract.return_type or "void",
            tuple(contract.parameter_types),
        )
        if key in seen_methods:
            continue
        seen_methods.add(key)
        receiver["methods"].append({
            "method_id": f"{contract.method_name}({','.join(contract.parameter_types)})",
            "signature": _contract_signature(contract),
            "return_type": contract.return_type or "void",
            "parameter_types": list(contract.parameter_types),
        })
    return list(grouped.values())


def build_generation_payload(ctx, method=None, *_args, mode: str = "method", **_kwargs):
    if mode != "method" or method is None:
        raise ValueError("ServiceImpl generation requires one selected public entry method")
    method_context = _method_context(ctx, method)
    if method_context is None:
        raise ValueError(f"ServiceImpl method context missing for {_method_id(method)}")
    closure = build_source_closure(ctx, method_context)
    target_source = closure.method_source or method_context.method_source
    payload = {
        "request_type": "method_test_generation",
        "target_class": {
            "fqcn": ctx.symbol.fqcn,
            "test_instance": cut_variable_name(ctx.symbol.name),
        },
        "target_method": {
            "method_id": method_context.method_id,
            "signature": method.render(),
            "source": target_source,
        },
        "reachable_same_class_methods": [
            {
                "method_id": item.method_id,
                "signature": item.signature,
                "visibility": item.visibility,
                "source": item.source,
            }
            for item in closure.reachable_methods
        ],
        "fixtures": _fixture_payload(ctx, method_context),
        "collaborators": _collaborator_payload(method_context),
        "generation_instruction": deepcopy(_GENERATION_INSTRUCTION),
    }
    return _messages(payload)


def build_validation_repair_payload(*_args, **_kwargs):
    return ServiceImplPayloadStageDisabled(
        request_type="validation_repair",
        reason="ServiceImpl LLM validation repair is disabled",
    )


def _source_line(source: str, line: int | None) -> str | None:
    if line is None or line < 1:
        return None
    lines = source.splitlines()
    return lines[line - 1].strip() if line <= len(lines) else None


def build_compile_repair_payload(ctx, current_test=None, errors=None, *_args, **kwargs):
    source = kwargs.get("current") or kwargs.get("source") or current_test or ""
    diagnostics = list(kwargs.get("compilation_errors") or errors or ())
    payload_errors = []
    for error in diagnostics:
        line = getattr(error, "line", None)
        payload_errors.append({
            "line": line,
            "column": getattr(error, "col", None),
            "message": getattr(error, "message", None) or str(error),
            "source_line": _source_line(source, line),
        })
    return _messages({
        "request_type": "compile_repair",
        "test_class": {
            "class_name": ctx.test_class_name,
            "source": source,
        },
        "compilation_errors": payload_errors,
        "repair_instructions": deepcopy(_COMPILE_REPAIR_INSTRUCTIONS),
    })




def _extract_braced_member(source: str, name: str) -> str | None:
    match = re.search(rf"\b{re.escape(name)}\s*\(", source)
    if not match:
        return None
    start = source.rfind("\n", 0, match.start()) + 1
    annotation_start = source.rfind("\n@", 0, start)
    if annotation_start >= 0 and source[annotation_start + 1 : start].strip().startswith("@"): 
        start = annotation_start + 1
    brace = source.find("{", match.end())
    if brace < 0:
        return None
    depth = 0
    in_string = False
    quote = ""
    escape = False
    for index in range(brace, len(source)):
        char = source[index]
        if in_string:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == quote:
                in_string = False
            continue
        if char in {"\"", "'"}:
            in_string = True
            quote = char
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return source[start : index + 1].strip()
    return None


def _required_shared_context(ctx, test_class_source: str, failing_tests: list[dict[str, Any]]) -> dict[str, list[str]]:
    combined = "\n".join(str(test.get("source", "")) for test in failing_tests)
    required_mock_fields: list[str] = []
    execution = getattr(ctx, "execution_context", None)
    for dependency in getattr(execution, "dependencies", ()) or ():
        field_name = getattr(dependency, "field_name", None)
        if not field_name or not re.search(rf"\b{re.escape(field_name)}\b", combined):
            continue
        line_match = re.search(
            rf"(?m)(?:^\s*@Mock\s*\n)?^\s*(?:private|protected|public)?\s*"
            rf"[^;\n]+\b{re.escape(field_name)}\s*;",
            test_class_source,
        )
        if line_match:
            required_mock_fields.append(line_match.group(0).strip())

    required_fixture_helpers: list[str] = []
    for fixture in getattr(execution, "fixtures", ()) or ():
        if not getattr(fixture, "supported", False):
            continue
        if not re.search(rf"\b{re.escape(fixture.method_name)}\s*\(", combined):
            continue
        source = _extract_braced_member(test_class_source, fixture.method_name)
        if source:
            required_fixture_helpers.append(source)

    required_setup_fragments: list[str] = []
    if cut_variable_name(ctx.symbol.name) in combined:
        setup = _extract_braced_member(test_class_source, "setUp")
        if setup is None:
            before_each = re.search(r"@BeforeEach", test_class_source)
            if before_each:
                method_match = re.search(r"\b([A-Za-z_$][\w$]*)\s*\(", test_class_source[before_each.end():])
                if method_match:
                    setup = _extract_braced_member(test_class_source, method_match.group(1))
        if setup:
            required_setup_fragments.append(setup)

    return {
        "required_mock_fields": required_mock_fields,
        "required_setup_fragments": required_setup_fragments,
        "required_fixture_helpers": required_fixture_helpers,
    }


def build_runtime_repair_payload(
    ctx,
    method=None,
    *_args,
    failing_tests=None,
    shared_test_context=None,
    test_class_source: str = "",
    **_kwargs,
):
    if method is None:
        raise ValueError("ServiceImpl runtime repair requires the owning production method")
    failing_tests = list(failing_tests or ())
    if shared_test_context is None:
        shared_test_context = _required_shared_context(ctx, test_class_source, failing_tests)
    payload = {
        "request_type": "runtime_repair",
        "target_class": {
            "fqcn": ctx.symbol.fqcn,
            "test_class_name": ctx.test_class_name,
        },
        "target_method": {"method_id": _method_id(method)},
        "failing_tests": failing_tests,
        "shared_test_context": shared_test_context,
        "repair_instructions": deepcopy(_RUNTIME_REPAIR_INSTRUCTIONS),
    }
    return _messages(payload)


def build_coverage_augmentation_payload(*_args, **_kwargs):
    return ServiceImplPayloadStageDisabled(
        request_type="coverage_augmentation",
        reason="ServiceImpl coverage augmentation is disabled",
    )


def build_coverage_repair_payload(*_args, **_kwargs):
    return ServiceImplPayloadStageDisabled(
        request_type="coverage_repair",
        reason="ServiceImpl coverage repair is disabled",
    )


__all__ = [
    "ServiceImplPayloadStageDisabled",
    "build_generation_payload",
    "build_validation_repair_payload",
    "build_compile_repair_payload",
    "build_runtime_repair_payload",
    "build_coverage_augmentation_payload",
    "build_coverage_repair_payload",
]
