"""Method-wise and class-wide test generation."""

from __future__ import annotations

import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.audit.console import stage as console_stage
from junitforge.audit.paths import safe_name
from junitforge.audit.recorder import sha256_text
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get

log = get("junitforge.loop")
from junitforge.generation.response_extractor import extract_generated_tests

from junitforge.generation.payloads import payload_builder_for_context
from junitforge.generation.skeleton_generator import generate_and_validate_skeleton
from junitforge.generation.validation import (
    is_serviceimpl_context,
    repair_validation_failure_deterministically,
    validate_generated_test,
)
from junitforge.pipeline.result import sync_test_registry_sources
from junitforge.publication.summary import _refresh_generation_counters


class GenerationMixin:
    def _generate_methodwise(
        self,
        ctx: GenerationContext,
        outcome: TargetOutcome,
        *,
        module: ModuleInfo | None = None,
        test_path: Path | None = None,
    ) -> str | None:
        """Generate method blocks concurrently, assemble deterministically, finalize once."""
        execution = ctx.execution_context
        if execution is None:
            return None
        _t = perf_counter()
        try:
            skeleton_result = generate_and_validate_skeleton(
                ctx,
                compile_gate=self.compile_gate,
                module=module,
                test_path=test_path,
                outcome=outcome,
            )
        except Exception as exc:  # noqa: BLE001
            outcome.notes.append(f"method-wise skeleton failed: {type(exc).__name__}: {exc}")
            return None
        skeleton = skeleton_result.source
        skeleton_elapsed = perf_counter() - _t
        self.audit.write_text(ctx.symbol.name, "05-skeleton/generated.java", skeleton)
        compile_result = getattr(skeleton_result, "compile_result", None)
        self.audit.write_json(ctx.symbol.name, "05-skeleton/compile-command.json", {
            "command": getattr(compile_result, "cmd", []),
            "working_directory": str(getattr(module, "root", self.repo_root)) if module is not None else str(self.repo_root),
            "elapsed_seconds": skeleton_elapsed,
        })
        self.audit.write_json(ctx.symbol.name, "05-skeleton/compile-result.json", {
            "exit_code": getattr(compile_result, "return_code", None),
            "success": skeleton_result.compiled,
            "compiler_error_count": len(skeleton_result.diagnostics),
            "diagnostic_summary": list(skeleton_result.diagnostics),
        })
        if skeleton_result.compiled:
            self.audit.write_text(ctx.symbol.name, "05-skeleton/compiled.java", skeleton)
        if skeleton_result.compiled is False:
            return None

        method_by_id = {
            f"{method.name}({','.join(type_name for type_name, _ in method.params)})": method
            for method in (ctx.symbol.methods or [])
        }
        jobs = []
        skipped_records: list[MethodGenerationRecord] = []
        for order, method_context in enumerate(execution.methods):
            production_method = method_by_id.get(method_context.method_id)
            if production_method is None:
                outcome.notes.append(f"method context skipped; signature not found: {method_context.method_id}")
                skipped_records.append(
                    MethodGenerationRecord(
                        method_id=method_context.method_id,
                        scenarios_planned=max(1, len(method_context.branches) + 1),
                        final_status=MethodDisposition.SKIPPED.value,
                    )
                )
                continue
            jobs.append((order, production_method, method_context))

        workers = max(1, min(int(os.getenv("JUNITFORGE_METHOD_WORKERS", "3")), len(jobs) or 1))
        batch_started = perf_counter()
        results = []
        with heartbeat(
            "llm.batch",
            interval_seconds=90.0,
            target=ctx.symbol.name,
            methods=len(jobs),
            workers=workers,
        ):
            with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="junitforge-method") as pool:
                futures = [pool.submit(self.generate_one, job, ctx, len(jobs)) for job in jobs]
                for future in as_completed(futures):
                    results.append(future.result())
        _elapsed = perf_counter() - batch_started

        current = skeleton
        accepted = 0
        existing_names: set[str] = set()
        outcome.selected_production_methods = len(execution.methods)
        outcome.method_results = list(skipped_records)
        for order, method_context, block, names, tokens, reason, record in sorted(
            results, key=lambda item: item[0]
        ):
            outcome.tokens_used += tokens
            outcome.method_results.append(record)
            if block is None:
                console_stage(
                    "METHOD_GENERATION",
                    "%s failed | reason=%s",
                    method_context.method_id,
                    reason or "no extractable @Test method",
                    level="warning",
                )
                outcome.notes.append(
                    f"method generation rejected [{method_context.method_id}]: {reason}"
                )
                continue

            surviving_sources: list[str] = []
            surviving_names: list[str] = []
            for extracted in extract_generated_tests(block):
                if extracted.name in existing_names:
                    matching = next(
                        (
                            test
                            for test in record.tests
                            if test.test_name == extracted.name
                            and test.final_disposition == TestDisposition.RETAINED.value
                        ),
                        None,
                    )
                    if matching is not None:
                        matching.final_disposition = TestDisposition.REJECTED.value
                        matching.validation_state = "REJECTED"
                        matching.final_rejection_reason = "duplicate test name across production-method owners"
                        record.tests_retained -= 1
                        record.tests_rejected += 1
                    continue
                surviving_sources.append(extracted.source)
                surviving_names.append(extracted.name)

            if not surviving_sources:
                record.final_status = MethodDisposition.REJECTED.value
                outcome.notes.append(
                    f"method generation rejected [{method_context.method_id}]: no unique valid tests remain"
                )
                continue

            if record.tests_rejected:
                record.final_status = MethodDisposition.PARTIALLY_GENERATED.value
            else:
                record.final_status = MethodDisposition.GENERATED.value
            current = insert_method_block(
                current,
                method_context.method_id,
                "\n\n".join(surviving_sources),
            )
            existing_names.update(surviving_names)
            accepted += 1
            status_label = (
                "partially generated"
                if record.final_status == MethodDisposition.PARTIALLY_GENERATED.value
                else "generated"
            )
            outcome.notes.append(
                f"method {status_label} [{method_context.method_id}]: "
                f"{len(surviving_names)} retained, {record.tests_rejected} rejected"
            )
            console_stage(
                "METHOD_GENERATION",
                "%s | generated=%d | retained=%d | rejected=%d",
                method_context.method_id,
                record.tests_extracted,
                len(surviving_names),
                record.tests_rejected,
            )

        _refresh_generation_counters(outcome)

        if accepted == 0 or not test_method_names(current):
            outcome.notes.append("method-wise generation produced no accepted test methods")
            return None

        _t = perf_counter()
        final = finalize_java(
            current,
            test_package=ctx.test_package,
            test_class_name=ctx.test_class_name,
            template=ctx.template,
            cut_symbol=ctx.symbol,
            collaborators=ctx.collaborators,
            source_imports=ctx.source_imports,
        )
        _elapsed = perf_counter() - _t
        if not final.ok or not final.code:
            outcome.notes.append(f"assembled method-wise test rejected: {final.reason}")
            return None
        outcome.notes.extend(final.issues)
        sync_test_registry_sources(outcome, final.code, accepted=True)
        outcome.notes.append(f"method-wise generation complete: {accepted}/{len(execution.methods)} production methods")
        return final.code


    def generate_one(self, job, ctx, total_jobs):
        order, production_method, method_context = job
        started = perf_counter()
        console_stage("METHOD_GENERATION", "%s started", method_context.method_id)
        builder = payload_builder_for_context(ctx)
        messages = builder.build_generation_payload(ctx, production_method, "", mode="method")
        method_dir = f"06-method-generation/{safe_name(method_context.method_id)}"
        self.audit.write_json(ctx.symbol.name, f"{method_dir}/request.json", {
            "request_type": "method_test_generation",
            "target_class": ctx.symbol.fqcn,
            "method_id": method_context.method_id,
            "model_id": self.cfg.model_id,
            "temperature": self.cfg.temperature_gen,
            "max_tokens": self.cfg.max_tokens_gen,
            "messages": messages,
        })
        try:
            with heartbeat(
                "llm.method",
                interval_seconds=90.0,
                target=ctx.symbol.name,
                method=method_context.method_id,
                worker_index=order + 1,
            ):
                resp = self.llm.chat(
                    messages,
                    temperature=self.cfg.temperature_gen,
                    max_tokens=self.cfg.max_tokens_gen,
                )
            raw = resp.message
            tokens = resp.usage.total_tokens if getattr(resp, "usage", None) else 0
            self.audit.record_llm_usage(getattr(resp, "usage", None))
            self.audit.write_text(ctx.symbol.name, f"{method_dir}/response.txt", raw or "")
        except Exception as exc:  # noqa: BLE001
            record = MethodGenerationRecord(
                method_id=method_context.method_id,
                scenarios_planned=max(1, len(method_context.branches) + 1),
                final_status=MethodDisposition.REJECTED.value,
            )
            return order, method_context, None, (), 0, f"llm error: {str(exc)[:180]}", record

        extracted = extract_generated_tests(raw or "")
        self.audit.write_text(
            ctx.symbol.name,
            f"{method_dir}/extracted-tests.java",
            "\n\n".join(item.source for item in extracted),
        )
        record = MethodGenerationRecord(
            method_id=method_context.method_id,
            scenarios_planned=max(1, len(method_context.branches) + 1),
            tests_returned_by_llm=(raw or "").count("@Test"),
            tests_extracted=len(extracted),
        )
        retained_sources: list[str] = []
        retained_names: list[str] = []

        for extracted_test in extracted:
            test_record = TestCaseRecord(
                owner_method_id=method_context.method_id,
                test_name=extracted_test.name,
                scenario_id=extracted_test.scenario_id,
                generated_source=extracted_test.source,
                source_start_line=extracted_test.start_line,
                source_end_line=extracted_test.end_line,
            )
            initial_validation = validate_generated_test(
                ctx, production_method, method_context, extracted_test.source, set()
            )
            if initial_validation.ok:
                record.tests_valid_before_repair += 1
                test_record.validation_state = "VALID"
                test_record.final_disposition = TestDisposition.RETAINED.value
                retained_sources.append(extracted_test.source)
                retained_names.append(extracted_test.name)
                record.tests.append(test_record)
                continue

            test_record.validation_diagnostics.append(initial_validation.reason)
            deterministic = repair_validation_failure_deterministically(
                ctx, production_method, method_context, extracted_test.source
            )
            candidate = deterministic.source
            test_record.deterministic_repair_history.extend(deterministic.actions)
            deterministic_validation = validate_generated_test(
                ctx, production_method, method_context, candidate, set()
            )
            if deterministic_validation.ok:
                record.tests_deterministically_repaired += 1
                test_record.validation_state = "VALID_AFTER_DETERMINISTIC_REPAIR"
                test_record.generated_source = candidate
                test_record.final_disposition = TestDisposition.RETAINED.value
                retained_sources.append(candidate)
                retained_names.append(extracted_test.name)
                record.tests.append(test_record)
                continue

            test_record.validation_diagnostics.append(deterministic_validation.reason)
            if is_serviceimpl_context(ctx):
                test_record.llm_repair_history.append("disabled:ServiceImpl LLM validation repair")
            else:
                record.tests_sent_to_llm_repair += 1
                repair_messages = builder.build_validation_repair_payload(
                    ctx,
                    production_method,
                    candidate,
                    extracted_test.name,
                    deterministic_validation.reason,
                )
                try:
                    with heartbeat(
                        "llm.test.validation_repair",
                        interval_seconds=90.0,
                        target=ctx.symbol.name,
                        method=method_context.method_id,
                        test=extracted_test.name,
                        worker_index=order + 1,
                    ):
                        repaired = self.llm.chat(
                            repair_messages,
                            temperature=self.cfg.temperature_repair,
                            max_tokens=self.cfg.max_tokens_repair,
                        )
                    if getattr(repaired, "usage", None):
                        tokens += repaired.usage.total_tokens
                    self.audit.record_llm_usage(getattr(repaired, "usage", None))
                    repaired_tests = extract_generated_tests(repaired.message or "")
                    if len(repaired_tests) != 1:
                        raise ValueError("repair must return exactly one @Test method")
                    repaired_test = repaired_tests[0]
                    if repaired_test.name != extracted_test.name:
                        raise ValueError(
                            f"repair changed test name from {extracted_test.name} to {repaired_test.name}"
                        )
                    post_deterministic = repair_validation_failure_deterministically(
                        ctx, production_method, method_context, repaired_test.source
                    )
                    repaired_candidate = post_deterministic.source
                    test_record.deterministic_repair_history.extend(post_deterministic.actions)
                    repaired_validation = validate_generated_test(
                        ctx, production_method, method_context, repaired_candidate, set()
                    )
                    test_record.llm_repair_history.append(
                        "accepted" if repaired_validation.ok else f"rejected:{repaired_validation.reason}"
                    )
                    if repaired_validation.ok:
                        test_record.validation_state = "VALID_AFTER_LLM_REPAIR"
                        test_record.generated_source = repaired_candidate
                        test_record.final_disposition = TestDisposition.RETAINED.value
                        retained_sources.append(repaired_candidate)
                        retained_names.append(extracted_test.name)
                        record.tests.append(test_record)
                        continue
                    test_record.validation_diagnostics.append(repaired_validation.reason)
                except Exception as exc:  # noqa: BLE001
                    test_record.llm_repair_history.append(f"error:{type(exc).__name__}:{str(exc)[:160]}")

            test_record.validation_state = "REJECTED"
            test_record.final_disposition = TestDisposition.REJECTED.value
            test_record.final_rejection_reason = (
                test_record.validation_diagnostics[-1]
                if test_record.validation_diagnostics
                else "validation repair failed"
            )
            record.tests.append(test_record)

        record.tests_retained = len(retained_sources)
        record.tests_rejected = len(record.tests) - record.tests_retained
        if record.tests_retained == 0:
            record.final_status = MethodDisposition.REJECTED.value
            reason = (
                "; ".join(
                    f"{test.test_name}: {test.final_rejection_reason or 'rejected'}"
                    for test in record.tests
                )
                or "no @Test methods returned"
            )
            self.audit.write_json(ctx.symbol.name, f"{method_dir}/structural-validation.json", {
                "tests": record.tests,
                "accepted": 0,
                "rejected": record.tests_rejected,
                "reason": reason,
            })
            self.audit.write_json(ctx.symbol.name, f"{method_dir}/registry-after.json", record)
            console_stage(
                "METHOD_GENERATION",
                "%s completed | elapsed=%.2fs",
                method_context.method_id,
                perf_counter() - started,
            )
            return order, method_context, None, (), tokens, reason, record
        record.final_status = (
            MethodDisposition.PARTIALLY_GENERATED.value
            if record.tests_rejected
            else MethodDisposition.GENERATED.value
        )
        block = "\n\n".join(retained_sources).strip()
        elapsed = perf_counter() - started
        self.audit.write_json(ctx.symbol.name, f"{method_dir}/structural-validation.json", {
            "tests": record.tests,
            "accepted": record.tests_retained,
            "rejected": record.tests_rejected,
        })
        self.audit.write_json(ctx.symbol.name, f"{method_dir}/registry-after.json", record)
        console_stage("METHOD_GENERATION", "%s completed | elapsed=%.2fs", method_context.method_id, elapsed)
        return (
            order,
            method_context,
            block,
            tuple(retained_names),
            tokens,
            None,
            record,
        )


    def _generate_classwide(self, ctx: GenerationContext, outcome: TargetOutcome) -> str | None:
        """Existing whole-class path retained for DTO/entity and other stable types."""
        builder = payload_builder_for_context(ctx)
        messages = builder.build_generation_payload(ctx, mode="classwide")
        for attempt in range(self.cfg.max_gen_reasks + 1):
            raw = self._chat(messages, self.cfg.temperature_gen, self.cfg.max_tokens_gen, outcome)
            candidate = inject_reusable_fixtures(raw or "", ctx)
            res = finalize_java(
                candidate, test_package=ctx.test_package, test_class_name=ctx.test_class_name,
                template=ctx.template, cut_symbol=ctx.symbol, collaborators=ctx.collaborators,
                source_imports=ctx.source_imports)
            if res.ok and res.code:
                outcome.notes.extend(res.issues)
                return res.code
            if attempt < self.cfg.max_gen_reasks:
                correction = (
                    f"Your previous output was rejected: {res.reason}. "
                    "Return one valid Java test file per the output contract."
                )
                messages = messages + [{"role": "user", "content": correction}]
        outcome.notes.append(f"generation rejected: {res.reason}")
        return None
