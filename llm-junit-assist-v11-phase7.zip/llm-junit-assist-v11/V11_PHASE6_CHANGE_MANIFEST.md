# llm-junit-assist v11 Phase 6 Change Manifest

## Scope

Phase 6 implements registry-owned, transactional, per-test runtime repair on top of the completed Phase 5 project. It does not introduce a second registry, runtime framework, compile-repair framework, or source-commit mechanism.

## Implementation files

| File | Responsibility |
|---|---|
| `junitforge/generation/payloads/serviceimpl.py` | Builds a single-test focused runtime-repair payload; selects only relevant production paths, collaborator/fixture/type contracts, constants, assertions, and source-proven expectations; preserves permanent instructions without duplication. |
| `junitforge/runtime/result_parser.py` | Maps Surefire runtime failures to stable registry `test_id` values using executed class, executed method, owner metadata, and registry identity; line numbers are excluded from Phase 6 runtime identity. |
| `junitforge/runtime/candidate_validator.py` | Enforces exact test identity, immutable sibling source, targeted execution, complete-class execution, and full-green acceptance. |
| `junitforge/runtime/repair_coordinator.py` | Implements the per-test transaction: diagnostics → candidate → structural/semantic validation → temporary assembly → one direct compile → targeted execution → full-class execution → Phase 1 commit or rollback. It never invokes compile-repair coordination. |
| `junitforge/runtime/state.py` | Deep-copies mutable runtime snapshots so rollback restores the prior authoritative state without aliasing later mutations. |
| `junitforge/runtime/__init__.py` | Exposes the Phase 6 runtime coordinator, stable ownership helpers, and source-identity validator. |
| `junitforge/registry.py` | Bumps the persisted registry document to schema version 6 and keeps runtime diagnostics append-only while retaining current diagnostics separately. |
| `junitforge/models.py` | Allows structured runtime repair history records on `TargetOutcome`. |
| `junitforge/loop.py` | Preserves backward-compatible exports for the new stable runtime ownership and source-identity helpers. |

## Test files

| File | Responsibility |
|---|---|
| `tests/test_v11_phase6_transactional_runtime_repair.py` | Adds synthetic integration/regression coverage for all Phase 6 transactional gates, stable identity, payload bounds, metadata persistence, duplicate-response stopping, rollback baselines, and zero nested compile-repair calls. |
| `tests/test_v101_serviceimpl_payload_workflow.py` | Updates prior runtime tests to the Phase 6 single-test payload, direct compile gate, recorded runtime failure state, and no-nested-compile-repair contract. |
| `tests/test_v721_runtime_repair_gate.py` | Updates prior targeted/full runtime gate tests to compile candidates directly once and assert the compile-repair coordinator is not invoked. |

## Validation and delivery files

| File | Responsibility |
|---|---|
| `V11_PHASE6_CHANGE_MANIFEST.md` | Records the Phase 6 scope, every changed file’s responsibility, and the only approved general-instruction clause replacement. |
| `V11_PHASE6_MODIFIED_FILES.txt` | Provides the exact changed/new-file inventory. |
| `V11_PHASE6_VALIDATION_REPORT.md` | Summarizes implemented behavior, validation results, zero nested compile-repair evidence, and explicit unverified behavior. |
| `V11_PHASE6_PYTEST_OUTPUT.txt` | Captures the complete pytest command, result, warnings, and exit code. |
| `V11_PHASE6_COMPILEALL_OUTPUT.txt` | Captures compileall execution and exit code. |
| `V11_PHASE6_IMPORT_SMOKE_OUTPUT.txt` | Captures import-smoke coverage for the public runtime, registry, payload, and compatibility exports. |
| `V11_PHASE6_SYNTHETIC_RUNTIME_REPAIR_OUTPUT.txt` | Captures the focused synthetic Phase 6 integration-suite result. |
| `V11_PHASE6_NO_NESTED_COMPILE_REPAIR_EVIDENCE.txt` | Captures AST evidence and focused tests proving zero nested compile-repair calls and one direct compile boundary. |

## General-instructions preservation

The authoritative ServiceImpl `general_instructions` fingerprint remains:

`e0873b732e770b07bfa940ab1f17e5fb3925b5c4b6ec4053add41280ff37cb43`

Exactly one existing clause directly contradicted the runtime-repair request type and is replaced only in the focused runtime payload copy:

| Existing clause | Replacement | Reason |
|---|---|---|
| `objective.requested_test_kind = "normal_success"` | `objective.requested_test_kind = "focused_runtime_repair"` | A runtime-repair request must repair the supplied failing test rather than request a new normal-success test. |

No other baseline clause is replaced, reordered, shortened, or removed. Runtime-specific permanent additions are emitted once under `approved_runtime_repair_additions`; method-specific facts remain in focused dynamic sections and are not copied into `general_instructions`.
