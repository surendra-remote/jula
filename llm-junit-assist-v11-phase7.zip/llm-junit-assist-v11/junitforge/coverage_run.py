"""Run JaCoCo coverage without editing the target pom.

The runner owns diagnostics for the Maven/Surefire/JaCoCo execution.  It never
modifies the target repository's pom and only retries a test selector when
Maven explicitly reports that the fully-qualified selector did not match.
"""

from __future__ import annotations

import re
import shutil
import subprocess
import hashlib
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from time import perf_counter

from junitforge.models import ModuleInfo
from junitforge.vendor.logging_utils import get

log = get(__name__)

JACOCO_VERSION = "0.8.13"

_SUREFIRE_SUMMARY_RE = re.compile(
    r"Tests run:\s*(?P<run>\d+)\s*,\s*Failures:\s*(?P<failures>\d+)\s*,\s*"
    r"Errors:\s*(?P<errors>\d+)\s*,\s*Skipped:\s*(?P<skipped>\d+)",
    flags=re.IGNORECASE,
)
_NO_TEST_MARKERS = (
    "No tests to run",
    "No tests were executed",
    "No tests matching pattern",
    "No tests matching pattern were executed",
)
_SELECTOR_MISMATCH_MARKERS = (
    "No tests matching pattern",
    "No tests matching pattern were executed",
)
_SUREFIRE_SKIPPED_MARKERS = (
    "Tests are skipped",
    "Skipping execution of surefire",
)
_JACOCO_REPORT_SKIPPED_MARKERS = (
    "Skipping JaCoCo execution due to missing execution data",
    "Skipping JaCoCo execution due to missing execution data file",
)

RUNTIME_FAILURE_CATEGORIES = (
    "ASSERTION_NULLABILITY_MISMATCH",
    "ASSERTION_VALUE_MISMATCH",
    "UNEXPECTED_NULL_POINTER",
    "EXPECTED_EXCEPTION_NOT_THROWN",
    "UNEXPECTED_EXCEPTION_PROPAGATED",
    "INVALID_CHECKED_EXCEPTION_STUB",
    "UNNECESSARY_STUBBING",
    "WANTED_BUT_NOT_INVOKED",
    "NEVER_WANTED_BUT_INVOKED",
    "MOCK_ARGUMENT_MISMATCH",
    "MISSING_COLLABORATOR_STUB",
    "RETRY_EXHAUSTED",
    "TIMEOUT_OR_SLOW_TEST",
    "FIXTURE_BRANCH_MISMATCH",
    "UNKNOWN_RUNTIME_FAILURE",
)


@dataclass(slots=True, frozen=True)
class CoverageSignals:
    tests_executed: bool = False
    tests_run: int = 0
    tests_failed: int = 0
    tests_errors: int = 0
    tests_skipped: int = 0
    no_tests_found: bool = False
    test_selector_mismatch: bool = False
    surefire_skipped: bool = False
    jacoco_prepare_agent_executed: bool = False
    jacoco_argline_configured: bool = False
    jacoco_javaagent_detected: bool = False
    jacoco_report_executed: bool = False
    jacoco_report_skipped: bool = False
    surefire_summaries: tuple[str, ...] = ()

    @property
    def tests_green(self) -> bool:
        return (
            self.tests_executed
            and self.tests_run > 0
            and self.tests_failed == 0
            and self.tests_errors == 0
        )


@dataclass(slots=True, frozen=True)
class SurefireFailure:
    test_class: str
    test_method: str
    status: str
    exception_type: str
    message: str
    stack_trace: str
    generated_test_line: int | None = None
    production_file: str | None = None
    production_line: int | None = None
    category: str = "UNKNOWN_RUNTIME_FAILURE"
    report_path: Path | None = None

    @property
    def signature(self) -> str:
        return "|".join(
            (
                self.test_class,
                self.test_method,
                self.status,
                self.exception_type,
                self.category,
                self.message[:160],
            )
        )


@dataclass
class RuntimeTestRunResult:
    maven_execution_success: bool
    note: str
    signals: CoverageSignals = field(default_factory=CoverageSignals)
    failures: tuple[SurefireFailure, ...] = ()
    log_tail: str = ""
    log_path: Path | None = None
    return_code: int | None = None
    report_paths: tuple[Path, ...] = ()
    executed_test_names: tuple[str, ...] = ()

    @property
    def tests_green(self) -> bool:
        return self.signals.tests_green


@dataclass
class CoverageRunResult:
    ok: bool
    measured: bool
    note: str
    xml_path: Path | None = None
    log_tail: str = ""
    log_path: Path | None = None
    return_code: int | None = None
    reason: str | None = None
    signals: CoverageSignals = field(default_factory=CoverageSignals)
    expected_exec_path: Path | None = None
    selected_exec_path: Path | None = None
    discovered_exec_paths: tuple[Path, ...] = ()
    discovered_xml_paths: tuple[Path, ...] = ()
    failures: tuple[SurefireFailure, ...] = ()
    report_paths: tuple[Path, ...] = ()
    executed_test_names: tuple[str, ...] = ()
    maven_execution_success: bool = False
    coverage_current: bool = False
    test_source_sha256: str | None = None
    coverage_source_sha256: str | None = None

    @property
    def tests_green(self) -> bool:
        return self.signals.tests_green


@dataclass
class CoverageRunner:
    repo_root: Path
    jacoco_version: str = JACOCO_VERSION
    mvn_path: str | None = None
    settings_file: Path | None = None
    local_repo: Path | None = None
    offline: bool = False
    timeout_sec: int = 240
    mvn_args: list[str] = field(default_factory=list)
    run_from_root: bool = True
    last_command: list[str] = field(default_factory=list, init=False)
    last_working_directory: Path | None = field(default=None, init=False)
    last_stdout: str = field(default="", init=False)
    last_stderr: str = field(default="", init=False)
    last_elapsed_seconds: float = field(default=0.0, init=False)
    last_started_epoch: float | None = field(default=None, init=False)

    def __post_init__(self) -> None:
        if self.mvn_path is None:
            self.mvn_path = shutil.which("mvn") or shutil.which("mvn.cmd") or "mvn"

    def xml_path(self, module: ModuleInfo) -> Path:
        return module.root / "target" / "site" / "jacoco" / "jacoco.xml"

    def exec_path(self, module: ModuleInfo) -> Path:
        return module.root / "target" / "jacoco.exec"

    def available(self) -> bool:
        return shutil.which(self.mvn_path or "mvn") is not None

    def warm_cache(self) -> None:
        cmd = [
            str(self.mvn_path),
            "-B",
            "-ntp",
            f"org.jacoco:jacoco-maven-plugin:{self.jacoco_version}:help",
        ]
        if self.settings_file:
            cmd += ["-s", str(self.settings_file)]
        if self.local_repo:
            cmd += [f"-Dmaven.repo.local={self.local_repo}"]

        log.debug("[COVERAGE_SETUP] warm_cache.command | %s", subprocess.list2cmdline(cmd))
        try:
            proc = subprocess.run(
                cmd,
                cwd=self.repo_root,
                capture_output=True,
                text=True,
                timeout=300,
                check=False,
            )
            log.debug("[COVERAGE_SETUP] warm_cache.end | return_code=%d", proc.returncode)
        except Exception as exc:  # noqa: BLE001
            log.debug("[COVERAGE_SETUP] warm_cache.failed | error=%s", exc)

    def measure(self, module: ModuleInfo, test_classes: list[str] | None = None) -> CoverageRunResult:
        if not self.available():
            return CoverageRunResult(
                False,
                False,
                "coverage Maven execution failed; reason=mvn_not_found",
                reason="mvn_not_found",
            )

        gid = f"org.jacoco:jacoco-maven-plugin:{self.jacoco_version}"
        
        cwd = self.repo_root if self.run_from_root else module.root
        pom = self.repo_root / "pom.xml" if self.run_from_root else module.pom
        fq_selectors = list(test_classes or [])
        simple_selectors = [selector.rsplit(".", 1)[-1] for selector in fq_selectors]
        test_source_sha256 = self._test_source_fingerprint(module, fq_selectors)
        run_started_epoch = time.time()

        exec_p = self.exec_path(module)
        xml_p = self.xml_path(module)
        root_exec = self.repo_root / "target" / "jacoco.exec"
        root_xml = self.repo_root / "target" / "site" / "jacoco" / "jacoco.xml"
        expected_paths = tuple(dict.fromkeys((exec_p, xml_p, root_exec, root_xml)))

        log.debug(
            "[COVERAGE_RUN] start | module=%s | module_root=%s | repository_root=%s | "
            "cwd=%s | pom=%s | selected_tests=%s | simple_selectors=%s | "
            "run_from_root=%s | offline=%s",
            module.name,
            module.root,
            self.repo_root,
            cwd,
            pom,
            ",".join(fq_selectors) or "<all>",
            ",".join(simple_selectors) or "<all>",
            self.run_from_root,
            self.offline,
        )
        log.debug(
            "[COVERAGE_RUN] expected_artifacts | module_exec=%s | module_xml=%s | "
            "root_exec=%s | root_xml=%s | configured_destfile=%s",
            exec_p,
            xml_p,
            root_exec,
            root_xml,
            exec_p,
        )
        stale_delete_failures = self._delete_stale(expected_paths)

        common = [
            str(self.mvn_path),
            "-B",
            "-ntp",
            "-f",
            str(pom),
            f"{gid}:prepare-agent",
            "test",
            f"{gid}:report",
            "-DskipTests=false",
            "-Dmaven.test.skip=false",
            "-DfailIfNoTests=false",
            "-Dsurefire.failIfNoSpecifiedTests=false",
            "-Dmaven.test.failure.ignore=true",
            "-Dcheckstyle.skip=true",
            "-Djavadoc.skip=true",
            "-Dpmd.skip=true",
            "-Dspotbugs.skip=true",
            "-DskipITs=true",
            f"-Djacoco.destFile={exec_p}",
        ]
        common.extend(self.mvn_args)
        if self.settings_file:
            common += ["-s", str(self.settings_file)]
        if self.local_repo:
            common += [f"-Dmaven.repo.local={self.local_repo}"]

        selector_sets: list[tuple[str, list[str]]] = [("fqcn", fq_selectors)]
        if fq_selectors and simple_selectors != fq_selectors:
            selector_sets.append(("simple", simple_selectors))

        final_proc: subprocess.CompletedProcess[str] | None = None
        final_blob = ""
        final_stdout = ""
        final_stderr = ""
        final_log_path: Path | None = None
        final_signals = CoverageSignals()
        final_command: list[str] = []
        selector_retry_allowed = False

        for selector_index, (selector_kind, selectors) in enumerate(selector_sets):
            if selector_index > 0 and not selector_retry_allowed:
                break
            if selector_index > 0:
                log.debug(
                    "[COVERAGE_RUN] selector.retry | original=%s | fallback=%s | "
                    "reason=no_tests_matching_pattern",
                    ",".join(fq_selectors),
                    ",".join(selectors),
                )

            base = list(common)
            if selectors:
                base.append("-Dtest=" + ",".join(selectors))

            offline_modes = [True, False] if self.offline else [False]
            for offline_mode in offline_modes:
                command = base + (["-o"] if offline_mode else [])
                command_text = subprocess.list2cmdline([str(value) for value in command])
                log.debug(
                    "[COVERAGE_RUN] maven.start | selector_kind=%s | offline=%s | cwd=%s",
                    selector_kind,
                    offline_mode,
                    cwd,
                )
                log.debug("[COVERAGE_RUN] maven.command | %s", command_text)
                started = perf_counter()
                self.last_command = [str(value) for value in command]
                self.last_working_directory = Path(cwd)
                self.last_started_epoch = run_started_epoch
                try:
                    proc = subprocess.run(
                        command,
                        cwd=cwd,
                        capture_output=True,
                        text=True,
                        timeout=self.timeout_sec,
                        check=False,
                    )
                    elapsed = perf_counter() - started
                    stdout = proc.stdout or ""
                    stderr = proc.stderr or ""
                    self.last_stdout = stdout
                    self.last_stderr = stderr
                    self.last_elapsed_seconds = elapsed
                except subprocess.TimeoutExpired as exc:
                    elapsed = perf_counter() - started
                    stdout = _timeout_text(exc.stdout)
                    stderr = _timeout_text(exc.stderr)
                    log_path = self._write_coverage_log(
                        module=module,
                        selectors=selectors,
                        selector_kind=selector_kind,
                        command=command,
                        cwd=cwd,
                        return_code=None,
                        elapsed=elapsed,
                        stdout=stdout,
                        stderr=stderr,
                    )
                    note = (
                        f"coverage Maven execution failed; reason=timeout; timeout_seconds={self.timeout_sec}; "
                        f"full_log={log_path}"
                    )
                    return CoverageRunResult(
                        False,
                        False,
                        note,
                        log_tail=_tail(stdout + stderr),
                        log_path=log_path,
                        reason="maven_timeout",
                        expected_exec_path=exec_p,
                    )
                except FileNotFoundError as exc:
                    return CoverageRunResult(
                        False,
                        False,
                        f"coverage Maven execution failed; reason=mvn_execution_failed; error={exc}",
                        reason="mvn_execution_failed",
                        expected_exec_path=exec_p,
                    )

                blob = stdout + stderr
                signals = parse_coverage_signals(blob)
                log_path = self._write_coverage_log(
                    module=module,
                    selectors=selectors,
                    selector_kind=selector_kind,
                    command=command,
                    cwd=cwd,
                    return_code=proc.returncode,
                    elapsed=elapsed,
                    stdout=stdout,
                    stderr=stderr,
                )
                log.debug(
                    "[COVERAGE_RUN] maven.end | return_code=%d | elapsed=%.3fs | "
                    "stdout_chars=%d | stderr_chars=%d | stdout_lines=%d | "
                    "stderr_lines=%d | full_log=%s",
                    proc.returncode,
                    elapsed,
                    len(stdout),
                    len(stderr),
                    len(stdout.splitlines()),
                    len(stderr.splitlines()),
                    log_path,
                )
                _log_signals(signals)

                final_proc = proc
                final_blob = blob
                final_stdout = stdout
                final_stderr = stderr
                final_log_path = log_path
                final_signals = signals
                final_command = command

                if offline_mode and _looks_offline_miss(blob):
                    log.debug("[COVERAGE_RUN] offline.retry_online | reason=dependency_cache_miss")
                    continue
                break

            selector_retry_allowed = final_signals.test_selector_mismatch
            if not selector_retry_allowed:
                break

        if final_proc is None:
            return CoverageRunResult(
                False,
                False,
                "coverage Maven execution failed; reason=not_executed",
                reason="not_executed",
                expected_exec_path=exec_p,
            )

        if "COMPILATION ERROR" in final_blob:
            _print_compiler_errors(final_blob)

        self._log_expected_artifacts(expected_paths)
        discovered_exec, discovered_xml = self._scan_artifacts(module)
        failures, report_paths, executed_test_names = _parse_surefire_report_details(
            module.root,
            fq_selectors,
            started_epoch=run_started_epoch,
        )
        if not failures and (final_signals.tests_failed or final_signals.tests_errors):
            failures = parse_surefire_failures_from_log(final_blob, fq_selectors)
            if failures:
                log.debug(
                    "[COVERAGE_RUN] surefire.fallback | source=full_maven_log | failures=%d",
                    len(failures),
                )
        if report_paths:
            log.debug(
                "[COVERAGE_RUN] surefire.reports | count=%d | paths=%s",
                len(report_paths),
                [str(path) for path in report_paths],
            )
        for failure in failures:
            log.debug(
                "[COVERAGE_RUN] failure.parsed | test=%s#%s | status=%s | "
                "category=%s | exception=%s | test_line=%s | production=%s:%s",
                failure.test_class,
                failure.test_method,
                failure.status,
                failure.category,
                failure.exception_type,
                failure.generated_test_line,
                failure.production_file,
                failure.production_line,
            )
        unchanged_stale = {
            path
            for path, before in stale_delete_failures.items()
            if _artifact_identity(path) == before
        }
        for path in sorted(unchanged_stale):
            log.debug(
                "[COVERAGE_RUN] stale.unchanged_after_run | path=%s | size=%d | modified_time=%s",
                path,
                _safe_size(path),
                _modified_time(path),
            )

        if final_proc.returncode != 0:
            note = _format_failure_note(
                reason="maven_execution_failed",
                return_code=final_proc.returncode,
                signals=final_signals,
                expected_exec=exec_p,
                discovered_exec=discovered_exec,
                log_path=final_log_path,
            )
            return CoverageRunResult(
                False,
                False,
                note,
                log_tail=_tail(final_blob),
                log_path=final_log_path,
                return_code=final_proc.returncode,
                reason="maven_execution_failed",
                signals=final_signals,
                expected_exec_path=exec_p,
                discovered_exec_paths=discovered_exec,
                discovered_xml_paths=discovered_xml,
                failures=failures,
                report_paths=report_paths,
                executed_test_names=executed_test_names,
                maven_execution_success=False,
                test_source_sha256=test_source_sha256,
            )

        selected_exec = _select_module_artifact(
            preferred=exec_p,
            root_fallback=root_exec,
            discovered=discovered_exec,
            module_root=module.root,
            excluded=unchanged_stale,
        )
        if selected_exec is None:
            empty_module_exec = any(
                path.exists() and path.is_file() and path.stat().st_size == 0
                and _is_within(path, module.root)
                for path in (exec_p, root_exec, *discovered_exec)
            )
            reason = (
                "jacoco_exec_empty"
                if empty_module_exec
                else classify_missing_exec(final_signals, discovered_exec, module.root)
            )
            if final_signals.tests_executed and not final_signals.jacoco_javaagent_detected:
                log.debug(
                    "[COVERAGE_RUN] diagnosis | Tests executed but JaCoCo agent attachment "
                    "was not detected. Check Surefire argLine configuration; a project "
                    "argLine may need to preserve the JaCoCo value using @{argLine}."
                )
            note = _format_failure_note(
                reason=reason,
                return_code=final_proc.returncode,
                signals=final_signals,
                expected_exec=exec_p,
                discovered_exec=discovered_exec,
                log_path=final_log_path,
            )
            return CoverageRunResult(
                False,
                False,
                note,
                log_tail=_tail(final_blob),
                log_path=final_log_path,
                return_code=final_proc.returncode,
                reason=reason,
                signals=final_signals,
                expected_exec_path=exec_p,
                discovered_exec_paths=discovered_exec,
                discovered_xml_paths=discovered_xml,
                failures=failures,
                report_paths=report_paths,
                executed_test_names=executed_test_names,
                maven_execution_success=True,
                test_source_sha256=test_source_sha256,
            )

        if selected_exec != exec_p:
            exec_p.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(selected_exec, exec_p)
            log.debug(
                "[COVERAGE_RUN] artifact.selected | kind=exec | source=%s | target=%s | size=%d",
                selected_exec,
                exec_p,
                exec_p.stat().st_size,
            )
            selected_exec = exec_p

        selected_xml = _select_module_artifact(
            preferred=xml_p,
            root_fallback=root_xml,
            discovered=discovered_xml,
            module_root=module.root,
            excluded=unchanged_stale,
        )
        if selected_xml is None:
            reason = "jacoco_xml_missing_after_non_empty_execution_data"
            note = _format_failure_note(
                reason=reason,
                return_code=final_proc.returncode,
                signals=final_signals,
                expected_exec=exec_p,
                discovered_exec=discovered_exec,
                log_path=final_log_path,
            )
            return CoverageRunResult(
                False,
                False,
                note,
                log_tail=_tail(final_blob),
                log_path=final_log_path,
                return_code=final_proc.returncode,
                reason=reason,
                signals=final_signals,
                expected_exec_path=exec_p,
                selected_exec_path=selected_exec,
                discovered_exec_paths=discovered_exec,
                discovered_xml_paths=discovered_xml,
                failures=failures,
                report_paths=report_paths,
                executed_test_names=executed_test_names,
                maven_execution_success=True,
                test_source_sha256=test_source_sha256,
            )

        if selected_xml != xml_p:
            xml_p.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(selected_xml, xml_p)
            log.debug(
                "[COVERAGE_RUN] artifact.selected | kind=xml | source=%s | target=%s | size=%d",
                selected_xml,
                xml_p,
                xml_p.stat().st_size,
            )

        coverage_source_sha256 = self._test_source_fingerprint(module, fq_selectors)
        coverage_current = bool(
            test_source_sha256
            and coverage_source_sha256
            and test_source_sha256 == coverage_source_sha256
        )
        return CoverageRunResult(
            ok=True,
            measured=True,
            note=(
                f"coverage measured; tests_run={final_signals.tests_run}; "
                f"tests_failed={final_signals.tests_failed}; "
                f"tests_errors={final_signals.tests_errors}; "
                f"tests_green={str(final_signals.tests_green).lower()}; "
                f"coverage_current={str(coverage_current).lower()}; "
                f"full_log={final_log_path}"
            ),
            xml_path=xml_p,
            log_tail=_tail(final_blob),
            log_path=final_log_path,
            return_code=final_proc.returncode,
            reason="coverage_measured",
            signals=final_signals,
            expected_exec_path=exec_p,
            selected_exec_path=selected_exec,
            discovered_exec_paths=discovered_exec,
            discovered_xml_paths=discovered_xml,
            failures=failures,
            report_paths=report_paths,
            executed_test_names=executed_test_names,
            maven_execution_success=True,
            coverage_current=coverage_current,
            test_source_sha256=test_source_sha256,
            coverage_source_sha256=coverage_source_sha256,
        )

    def run_tests(
        self,
        module: ModuleInfo,
        test_selectors: list[str],
        *,
        label: str = "runtime",
        timeout_sec: int | None = None,
    ) -> RuntimeTestRunResult:
        """Run selected tests through the target project's normal Maven lifecycle.

        This deliberately does not invoke JaCoCo report generation.  It is used
        by runtime repair to validate a candidate cheaply before the final green
        suite is measured by ``measure``.
        """
        if not self.available():
            return RuntimeTestRunResult(False, "runtime Maven execution failed; reason=mvn_not_found")

        cwd = self.repo_root if self.run_from_root else module.root
        pom = self.repo_root / "pom.xml" if self.run_from_root else module.pom
        fq_selectors = list(test_selectors)
        simple_selectors = [_simple_test_selector(selector) for selector in fq_selectors]
        selector_sets: list[tuple[str, list[str]]] = [("fqcn", fq_selectors)]
        if simple_selectors != fq_selectors:
            selector_sets.append(("simple", simple_selectors))

        common = [
            str(self.mvn_path),
            "-B",
            "-ntp",
            "-f",
            str(pom),
            "test",
            "-DskipTests=false",
            "-Dmaven.test.skip=false",
            "-DfailIfNoTests=false",
            "-Dsurefire.failIfNoSpecifiedTests=false",
            "-Dmaven.test.failure.ignore=true",
            "-Dcheckstyle.skip=true",
            "-Djavadoc.skip=true",
            "-Dpmd.skip=true",
            "-Dspotbugs.skip=true",
            "-DskipITs=true",
            "-Djacoco.skip=true",
        ]
        common.extend(self.mvn_args)
        if self.settings_file:
            common += ["-s", str(self.settings_file)]
        if self.local_repo:
            common += [f"-Dmaven.repo.local={self.local_repo}"]

        final_proc: subprocess.CompletedProcess[str] | None = None
        final_blob = ""
        final_log: Path | None = None
        final_signals = CoverageSignals()
        final_reports: tuple[Path, ...] = ()
        final_failures: tuple[SurefireFailure, ...] = ()
        executed_test_names: tuple[str, ...] = ()
        retry_allowed = False

        for index, (selector_kind, selectors) in enumerate(selector_sets):
            if index > 0 and not retry_allowed:
                break
            if index > 0:
                log.debug(
                    "[RUNTIME_TEST] selector.retry | original=%s | fallback=%s | "
                    "reason=no_tests_matching_pattern",
                    ",".join(fq_selectors),
                    ",".join(selectors),
                )
            command = list(common)
            if selectors:
                command.append("-Dtest=" + ",".join(selectors))
            if self.offline:
                command.append("-o")
            started_epoch = time.time()
            started = perf_counter()
            self.last_command = [str(value) for value in command]
            self.last_working_directory = Path(cwd)
            self.last_started_epoch = started_epoch
            log.debug(
                "[RUNTIME_TEST] start | label=%s | module=%s | selectors=%s | command=%s",
                label,
                module.name,
                selectors,
                subprocess.list2cmdline(command),
            )
            try:
                proc = subprocess.run(
                    command,
                    cwd=cwd,
                    capture_output=True,
                    text=True,
                    timeout=timeout_sec or self.timeout_sec,
                    check=False,
                )
                elapsed = perf_counter() - started
                stdout = proc.stdout or ""
                stderr = proc.stderr or ""
                self.last_stdout = stdout
                self.last_stderr = stderr
                self.last_elapsed_seconds = elapsed
            except subprocess.TimeoutExpired as exc:
                elapsed = perf_counter() - started
                stdout = _timeout_text(exc.stdout)
                stderr = _timeout_text(exc.stderr)
                log_path = self._write_runtime_log(
                    module=module,
                    selectors=selectors,
                    selector_kind=selector_kind,
                    label=label,
                    command=command,
                    cwd=cwd,
                    return_code=None,
                    elapsed=elapsed,
                    stdout=stdout,
                    stderr=stderr,
                )
                return RuntimeTestRunResult(
                    False,
                    f"runtime test execution timed out; full_log={log_path}",
                    log_tail=_tail(stdout + stderr),
                    log_path=log_path,
                    return_code=None,
                )

            blob = stdout + stderr
            signals = parse_coverage_signals(blob)
            failures, reports, executed_test_names = _parse_surefire_report_details(
                module.root,
                fq_selectors,
                started_epoch=started_epoch,
            )
            if not failures and (signals.tests_failed or signals.tests_errors):
                failures = parse_surefire_failures_from_log(blob, fq_selectors)
                if failures:
                    log.debug(
                        "[RUNTIME_TEST] surefire.fallback | source=full_maven_log | failures=%d",
                        len(failures),
                    )
            log_path = self._write_runtime_log(
                module=module,
                selectors=selectors,
                selector_kind=selector_kind,
                label=label,
                command=command,
                cwd=cwd,
                return_code=proc.returncode,
                elapsed=elapsed,
                stdout=stdout,
                stderr=stderr,
            )
            log.debug(
                "[RUNTIME_TEST] end | label=%s | return_code=%d | tests_run=%d | "
                "failures=%d | errors=%d | tests_green=%s | elapsed=%.3fs | full_log=%s",
                label,
                proc.returncode,
                signals.tests_run,
                signals.tests_failed,
                signals.tests_errors,
                signals.tests_green,
                elapsed,
                log_path,
            )
            final_proc = proc
            final_blob = blob
            final_log = log_path
            final_signals = signals
            final_reports = reports
            final_failures = failures
            retry_allowed = signals.test_selector_mismatch
            if not retry_allowed:
                break

        if final_proc is None:
            return RuntimeTestRunResult(False, "runtime Maven execution failed; reason=not_executed")

        return RuntimeTestRunResult(
            maven_execution_success=final_proc.returncode == 0,
            note=(
                f"runtime tests executed; tests_run={final_signals.tests_run}; "
                f"failures={final_signals.tests_failed}; errors={final_signals.tests_errors}; "
                f"tests_green={str(final_signals.tests_green).lower()}; full_log={final_log}"
            ),
            signals=final_signals,
            failures=final_failures,
            log_tail=_tail(final_blob),
            log_path=final_log,
            return_code=final_proc.returncode,
            report_paths=final_reports,
            executed_test_names=executed_test_names,
        )

    def invalidate_coverage(self, module: ModuleInfo) -> None:
        paths = tuple(
            dict.fromkeys(
                (
                    self.exec_path(module),
                    self.xml_path(module),
                    self.repo_root / "target" / "jacoco.exec",
                    self.repo_root / "target" / "site" / "jacoco" / "jacoco.xml",
                )
            )
        )
        self._delete_stale(paths)
        log.debug(
            "[COVERAGE_INVALIDATION] test_source_changed | module=%s | artifacts=%s",
            module.name,
            [str(path) for path in paths],
        )

    def _test_source_fingerprint(self, module: ModuleInfo, selectors: list[str]) -> str | None:
        paths: list[Path] = []
        for selector in selectors:
            class_name = selector.split("#", 1)[0]
            relative = Path(*class_name.split(".")).with_suffix(".java")
            path = module.root / "src" / "test" / "java" / relative
            if path.exists() and path.is_file():
                paths.append(path)
        if not paths:
            return None
        digest = hashlib.sha256()
        for path in sorted(set(paths)):
            digest.update(str(path.relative_to(module.root)).encode("utf-8"))
            digest.update(b"\0")
            digest.update(path.read_bytes())
            digest.update(b"\0")
        return digest.hexdigest()

    def _delete_stale(self, paths: tuple[Path, ...]) -> dict[Path, tuple[int, int | None]]:
        failures: dict[Path, tuple[int, int | None]] = {}
        for stale in paths:
            existed = stale.exists()
            size = _safe_size(stale)
            if not existed:
                log.debug("[COVERAGE_RUN] stale.absent | path=%s", stale)
                continue
            identity = _artifact_identity(stale)
            try:
                stale.unlink()
                log.debug(
                    "[COVERAGE_RUN] stale.deleted | path=%s | existed=true | size=%d",
                    stale,
                    size,
                )
            except OSError as exc:
                failures[stale] = identity
                log.warning(
                    "[COVERAGE] stale.delete_failed | path=%s | size=%d | error=%s",
                    stale,
                    size,
                    exc,
                )
        return failures

    def _write_coverage_log(
        self,
        *,
        module: ModuleInfo,
        selectors: list[str],
        selector_kind: str,
        command: list[str],
        cwd: Path,
        return_code: int | None,
        elapsed: float,
        stdout: str,
        stderr: str,
    ) -> Path:
        log_dir = self.repo_root / ".junitforge" / "coverage-logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        selector_token = _selector_log_token(selectors)
        filename = _bounded_log_filename(
            f"{stamp}-{_bounded_log_token(module.name, 32)}-"
            f"{_bounded_log_token(selector_kind, 16)}-{selector_token}",
            log_dir=log_dir,
        )
        path = log_dir / filename
        content = "\n".join(
            [
                f"module={module.name}",
                f"module_root={module.root}",
                f"cwd={cwd}",
                f"selector_kind={selector_kind}",
                f"selectors={selectors}",
                f"return_code={return_code}",
                f"elapsed_seconds={elapsed:.6f}",
                "command=" + subprocess.list2cmdline([str(value) for value in command]),
                "",
                "=== STDOUT ===",
                stdout,
                "",
                "=== STDERR ===",
                stderr,
                "",
            ]
        )
        return _write_log_text_best_effort(path, content, stamp=stamp, kind="coverage")

    def _write_runtime_log(
        self,
        *,
        module: ModuleInfo,
        selectors: list[str],
        selector_kind: str,
        label: str,
        command: list[str],
        cwd: Path,
        return_code: int | None,
        elapsed: float,
        stdout: str,
        stderr: str,
    ) -> Path:
        log_dir = self.repo_root / ".junitforge" / "runtime-logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        selector_token = _selector_log_token(selectors)
        filename = _bounded_log_filename(
            f"{stamp}-{_bounded_log_token(module.name, 32)}-"
            f"{_bounded_log_token(label, 44)}-"
            f"{_bounded_log_token(selector_kind, 16)}-{selector_token}",
            log_dir=log_dir,
        )
        path = log_dir / filename
        content = "\n".join(
            [
                f"module={module.name}",
                f"module_root={module.root}",
                f"cwd={cwd}",
                f"label={label}",
                f"selector_kind={selector_kind}",
                f"selectors={selectors}",
                f"return_code={return_code}",
                f"elapsed_seconds={elapsed:.6f}",
                "command=" + subprocess.list2cmdline([str(value) for value in command]),
                "",
                "=== STDOUT ===",
                stdout,
                "",
                "=== STDERR ===",
                stderr,
                "",
            ]
        )
        return _write_log_text_best_effort(path, content, stamp=stamp, kind="runtime")

    def _log_expected_artifacts(self, paths: tuple[Path, ...]) -> None:
        for path in paths:
            stat = _artifact_state(path)
            log.debug(
                "[COVERAGE_RUN] artifact.expected | path=%s | exists=%s | is_file=%s | "
                "size=%d | modified_time=%s",
                path,
                stat["exists"],
                stat["is_file"],
                stat["size"],
                stat["modified_time"],
            )

    def _scan_artifacts(self, module: ModuleInfo) -> tuple[tuple[Path, ...], tuple[Path, ...]]:
        exec_paths = tuple(sorted(self.repo_root.glob("**/target/jacoco.exec")))
        xml_paths = tuple(sorted(self.repo_root.glob("**/target/site/jacoco/jacoco.xml")))
        log.debug(
            "[COVERAGE_RUN] artifact_scan | exec_files=%d | xml_files=%d",
            len(exec_paths),
            len(xml_paths),
        )
        for kind, paths in (("exec", exec_paths), ("xml", xml_paths)):
            for path in paths:
                log.debug(
                    "[COVERAGE_RUN] artifact.found | kind=%s | path=%s | size=%d | "
                    "modified_time=%s | module_match=%s",
                    kind,
                    path,
                    _safe_size(path),
                    _modified_time(path),
                    _is_within(path, module.root),
                )
        return exec_paths, xml_paths


def parse_coverage_signals(blob: str) -> CoverageSignals:
    summaries = tuple(line.strip() for line in blob.splitlines() if "Tests run:" in line)[-5:]
    matches = list(_SUREFIRE_SUMMARY_RE.finditer(blob))
    if matches:
        match = matches[-1]
        tests_run = int(match.group("run"))
        failures = int(match.group("failures"))
        errors = int(match.group("errors"))
        skipped = int(match.group("skipped"))
    else:
        tests_run = failures = errors = skipped = 0
    no_tests = any(marker.lower() in blob.lower() for marker in _NO_TEST_MARKERS)
    selector_mismatch = any(marker.lower() in blob.lower() for marker in _SELECTOR_MISMATCH_MARKERS)
    surefire_skipped = any(marker.lower() in blob.lower() for marker in _SUREFIRE_SKIPPED_MARKERS)
    lower = blob.lower()
    prepare_agent = "jacoco-maven-plugin" in lower and ":prepare-agent" in lower
    argline = "argline set to" in lower
    javaagent = "-javaagent:" in lower or "org.jacoco.agent" in lower
    report_executed = "jacoco-maven-plugin" in lower and ":report" in lower
    report_skipped = any(marker.lower() in lower for marker in _JACOCO_REPORT_SKIPPED_MARKERS)
    return CoverageSignals(
        tests_executed=tests_run > 0,
        tests_run=tests_run,
        tests_failed=failures,
        tests_errors=errors,
        tests_skipped=skipped,
        no_tests_found=no_tests,
        test_selector_mismatch=selector_mismatch,
        surefire_skipped=surefire_skipped,
        jacoco_prepare_agent_executed=prepare_agent,
        jacoco_argline_configured=argline,
        jacoco_javaagent_detected=javaagent,
        jacoco_report_executed=report_executed,
        jacoco_report_skipped=report_skipped,
        surefire_summaries=summaries,
    )


def parse_surefire_reports(
    module_root: Path,
    selectors: list[str] | tuple[str, ...],
    *,
    started_epoch: float | None = None,
) -> tuple[tuple[SurefireFailure, ...], tuple[Path, ...]]:
    """Compatibility wrapper returning failures and report paths."""
    failures, reports, _ = _parse_surefire_report_details(
        module_root, selectors, started_epoch=started_epoch
    )
    return failures, reports


def _parse_surefire_report_details(
    module_root: Path,
    selectors: list[str] | tuple[str, ...],
    *,
    started_epoch: float | None = None,
) -> tuple[tuple[SurefireFailure, ...], tuple[Path, ...], tuple[str, ...]]:
    """Parse fresh reports and preserve the identity of every executed test."""
    report_dir = module_root / "target" / "surefire-reports"
    if not report_dir.exists():
        return (), (), ()
    selected_classes = {
        selector.split("#", 1)[0]
        for selector in selectors
        if selector
    }
    failures: list[SurefireFailure] = []
    executed_names: list[str] = []
    used_reports: list[Path] = []
    for path in sorted(report_dir.glob("TEST-*.xml")):
        try:
            if started_epoch is not None and path.stat().st_mtime < started_epoch - 2.0:
                continue
            root = ET.parse(path).getroot()
        except (OSError, ET.ParseError) as exc:
            log.debug("[SUREFIRE_PARSE] report.invalid | path=%s | error=%s", path, exc)
            continue
        report_used = False
        for testcase in root.findall(".//testcase"):
            test_class = testcase.attrib.get("classname", "")
            if selected_classes and test_class not in selected_classes:
                continue
            test_method = testcase.attrib.get("name", "")
            if test_method:
                executed_names.append(test_method)
            problem = testcase.find("failure")
            status = "failure"
            if problem is None:
                problem = testcase.find("error")
                status = "error"
            if problem is None:
                report_used = True
                continue
            message = problem.attrib.get("message", "") or ""
            exception_type = problem.attrib.get("type", "") or ""
            stack_trace = problem.text or ""
            generated_line = _stack_line_for_test_class(stack_trace, test_class)
            production_file, production_line = _first_production_frame(
                stack_trace,
                excluded_test_class=test_class,
            )
            category = classify_runtime_failure(
                exception_type=exception_type,
                message=message,
                stack_trace=stack_trace,
            )
            failures.append(
                SurefireFailure(
                    test_class=test_class,
                    test_method=test_method,
                    status=status,
                    exception_type=exception_type,
                    message=message,
                    stack_trace=stack_trace,
                    generated_test_line=generated_line,
                    production_file=production_file,
                    production_line=production_line,
                    category=category,
                    report_path=path,
                )
            )
            report_used = True
        if report_used:
            used_reports.append(path)
    return tuple(failures), tuple(used_reports), tuple(dict.fromkeys(executed_names))


def parse_surefire_failures_from_log(
    blob: str,
    selectors: list[str] | tuple[str, ...],
) -> tuple[SurefireFailure, ...]:
    """Fallback parser for complete Maven output when Surefire XML is absent."""
    selected_classes = {
        selector.split("#", 1)[0]
        for selector in selectors
        if selector
    }
    header = re.compile(
        r"(?m)^\[ERROR\]\s+"
        r"(?P<class>[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)+)\."
        r"(?P<method>[A-Za-z_$][\w$]*(?:\([^\n)]*\))?)\s+--.*?<<<\s+"
        r"(?P<status>FAILURE|ERROR)!\s*$"
    )
    matches = list(header.finditer(blob))
    failures: list[SurefireFailure] = []
    for index, match in enumerate(matches):
        test_class = match.group("class")
        if selected_classes and test_class not in selected_classes:
            continue
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(blob)
        section = blob[start:end].strip()
        test_method = match.group("method").split("(", 1)[0]
        status = "failure" if match.group("status") == "FAILURE" else "error"
        first_nonempty = next((line.strip() for line in section.splitlines() if line.strip()), "")
        exception_type = first_nonempty.split(":", 1)[0] if first_nonempty else ""
        message = first_nonempty.split(":", 1)[1].strip() if ":" in first_nonempty else first_nonempty
        generated_line = _stack_line_for_test_class(section, test_class)
        production_file, production_line = _first_production_frame(
            section,
            excluded_test_class=test_class,
        )
        failures.append(
            SurefireFailure(
                test_class=test_class,
                test_method=test_method,
                status=status,
                exception_type=exception_type,
                message=message,
                stack_trace=section,
                generated_test_line=generated_line,
                production_file=production_file,
                production_line=production_line,
                category=classify_runtime_failure(
                    exception_type=exception_type,
                    message=message,
                    stack_trace=section,
                ),
            )
        )
    return tuple(failures)


def classify_runtime_failure(*, exception_type: str, message: str, stack_trace: str) -> str:
    blob = "\n".join((exception_type, message, stack_trace)).lower()
    if "checked exception is invalid for this method" in blob:
        return "INVALID_CHECKED_EXCEPTION_STUB"
    if "unnecessarystubbingexception" in blob or "unnecessary stubbings detected" in blob:
        return "UNNECESSARY_STUBBING"
    if "wanted but not invoked" in blob:
        return "WANTED_BUT_NOT_INVOKED"
    if "neverwantedbutinvoked" in blob or "never wanted here" in blob:
        return "NEVER_WANTED_BUT_INVOKED"
    if "argument(s) are different" in blob or "arguments are different" in blob:
        return "MOCK_ARGUMENT_MISMATCH"
    if "nullpointerexception" in blob or "cannot invoke" in blob and "because" in blob and "is null" in blob:
        return "UNEXPECTED_NULL_POINTER"
    if "expected:" in blob and "but was:" in blob:
        if "not <null>" in blob or "was: <null>" in blob:
            return "ASSERTION_NULLABILITY_MISMATCH"
        return "ASSERTION_VALUE_MISMATCH"
    if "expected" in blob and "to be thrown" in blob:
        return "EXPECTED_EXCEPTION_NOT_THROWN"
    if "timeout" in blob or "timed out" in blob:
        return "TIMEOUT_OR_SLOW_TEST"
    if "unable to generate" in blob or "retry" in blob and "exhaust" in blob:
        return "RETRY_EXHAUSTED"
    if "mockito" in blob and "thenreturn" in blob:
        return "MISSING_COLLABORATOR_STUB"
    if "runtimeexception" in blob or "exception" in exception_type.lower():
        return "UNEXPECTED_EXCEPTION_PROPAGATED"
    return "UNKNOWN_RUNTIME_FAILURE"


def _stack_line_for_test_class(stack_trace: str, test_class: str) -> int | None:
    simple = test_class.rsplit(".", 1)[-1]
    match = re.search(rf"{re.escape(simple)}\.java:(\d+)", stack_trace)
    return int(match.group(1)) if match else None


def _first_production_frame(
    stack_trace: str,
    *,
    excluded_test_class: str,
) -> tuple[str | None, int | None]:
    excluded_simple = excluded_test_class.rsplit(".", 1)[-1] + ".java"
    for match in re.finditer(r"([A-Za-z_$][\w$]*\.java):(\d+)", stack_trace):
        filename = match.group(1)
        if filename == excluded_simple:
            continue
        return filename, int(match.group(2))
    return None, None


def _simple_test_selector(selector: str) -> str:
    class_part, separator, method_part = selector.partition("#")
    simple = class_part.rsplit(".", 1)[-1]
    return simple + (separator + method_part if separator else "")


def classify_missing_exec(
    signals: CoverageSignals,
    discovered_exec: tuple[Path, ...],
    module_root: Path,
) -> str:
    if signals.test_selector_mismatch:
        return "selected_test_not_found"
    if signals.surefire_skipped:
        return "tests_skipped"
    if signals.no_tests_found or not signals.tests_executed:
        return "no_tests_executed"
    if discovered_exec and not any(_is_within(path, module_root) for path in discovered_exec):
        return "jacoco_exec_created_in_unexpected_module"
    if signals.jacoco_prepare_agent_executed and not signals.jacoco_javaagent_detected:
        return "jacoco_agent_attachment_not_detected"
    if signals.jacoco_report_skipped:
        return "jacoco_report_skipped_missing_execution_data"
    return "tests_executed_but_jacoco_exec_not_created"


def _select_module_artifact(
    *,
    preferred: Path,
    root_fallback: Path,
    discovered: tuple[Path, ...],
    module_root: Path,
    excluded: set[Path] | None = None,
) -> Path | None:
    excluded = excluded or set()
    for candidate in (preferred, root_fallback):
        if candidate in excluded:
            continue
        if candidate.exists() and candidate.is_file() and candidate.stat().st_size > 0:
            if candidate == root_fallback and not _is_within(candidate, module_root):
                continue
            return candidate
    matched = [
        path for path in discovered
        if path not in excluded
        and _is_within(path, module_root) and path.is_file() and path.stat().st_size > 0
    ]
    return matched[0] if len(matched) == 1 else None


def _format_failure_note(
    *,
    reason: str,
    return_code: int,
    signals: CoverageSignals,
    expected_exec: Path,
    discovered_exec: tuple[Path, ...],
    log_path: Path | None,
) -> str:
    return (
        "coverage unmeasured:"
        f"reason={reason};"
        f"maven_return_code={return_code};"
        f"tests_run={signals.tests_run};"
        f"tests_failed={signals.tests_failed};"
        f"tests_errors={signals.tests_errors};"
        f"tests_skipped={signals.tests_skipped};"
        f"agent_detected={str(signals.jacoco_javaagent_detected).lower()};"
        f"report_skipped={str(signals.jacoco_report_skipped).lower()};"
        f"expected_exec={expected_exec};"
        f"discovered_exec_files={len(discovered_exec)};"
        f"full_log={log_path}"
    )


def _log_signals(signals: CoverageSignals) -> None:
    log.debug(
        "[COVERAGE_RUN] execution_signals | tests_executed=%s | tests_run=%d | "
        "tests_failed=%d | tests_errors=%d | tests_skipped=%d | no_tests_found=%s | "
        "test_selector_mismatch=%s | surefire_skipped=%s | "
        "jacoco_prepare_agent_executed=%s | jacoco_argline_configured=%s | "
        "jacoco_javaagent_detected=%s | jacoco_report_executed=%s | "
        "jacoco_report_skipped=%s | test_summaries=%s",
        signals.tests_executed,
        signals.tests_run,
        signals.tests_failed,
        signals.tests_errors,
        signals.tests_skipped,
        signals.no_tests_found,
        signals.test_selector_mismatch,
        signals.surefire_skipped,
        signals.jacoco_prepare_agent_executed,
        signals.jacoco_argline_configured,
        signals.jacoco_javaagent_detected,
        signals.jacoco_report_executed,
        signals.jacoco_report_skipped,
        list(signals.surefire_summaries),
    )


def _artifact_state(path: Path) -> dict[str, object]:
    return {
        "exists": path.exists(),
        "is_file": path.is_file(),
        "size": _safe_size(path),
        "modified_time": _modified_time(path),
    }


def _artifact_identity(path: Path) -> tuple[int, int | None]:
    try:
        stat = path.stat()
        return stat.st_size, stat.st_mtime_ns
    except OSError:
        return 0, None


def _safe_size(path: Path) -> int:
    try:
        return path.stat().st_size if path.is_file() else 0
    except OSError:
        return 0


def _modified_time(path: Path) -> str:
    try:
        return datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds")
    except OSError:
        return "<unavailable>"


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (OSError, ValueError):
        return False


def _safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value or "unknown")


def _bounded_log_token(value: str, max_length: int) -> str:
    raw = value or "unknown"
    safe = _safe_name(raw).strip("._-") or "unknown"
    if len(safe) <= max_length:
        return safe
    digest = hashlib.sha256(raw.encode("utf-8", errors="replace")).hexdigest()[:10]
    head_length = max(1, max_length - len(digest) - 1)
    head = safe[:head_length].rstrip("._-") or "value"
    return f"{head}-{digest}"


def _selector_log_token(selectors: list[str]) -> str:
    if not selectors:
        return "all-tests"
    raw = "\n".join(selectors)
    digest = hashlib.sha256(raw.encode("utf-8", errors="replace")).hexdigest()[:12]
    first_class = selectors[0].split("#", 1)[0].rsplit(".", 1)[-1]
    method_count = 0
    for selector in selectors:
        if "#" in selector:
            methods = selector.split("#", 1)[1]
            method_count += len([name for name in methods.split("+") if name])
    count_token = f"{method_count}methods" if method_count else f"{len(selectors)}selectors"
    return f"{_bounded_log_token(first_class, 36)}-{count_token}-{digest}"


def _bounded_log_filename(stem: str, *, log_dir: Path) -> str:
    # Keep the filename component below the common Windows 255-character limit
    # and leave room for repositories that do not have long-path support enabled.
    path_budget = max(72, 230 - len(str(log_dir)))
    max_filename = min(170, path_budget)
    suffix = ".log"
    safe = _safe_name(stem).strip("._-") or "junitforge-log"
    if len(safe) + len(suffix) <= max_filename:
        return safe + suffix
    digest = hashlib.sha256(stem.encode("utf-8", errors="replace")).hexdigest()[:16]
    head_length = max(1, max_filename - len(suffix) - len(digest) - 1)
    head = safe[:head_length].rstrip("._-") or "junitforge-log"
    return f"{head}-{digest}{suffix}"


def _write_log_text_best_effort(path: Path, content: str, *, stamp: str, kind: str) -> Path:
    try:
        path.write_text(content, encoding="utf-8", errors="replace")
        return path
    except OSError as exc:
        digest = hashlib.sha256(content.encode("utf-8", errors="replace")).hexdigest()[:16]
        fallback = path.parent / f"{stamp}-{kind}-{digest}.log"
        log.debug(
            "[%s_LOG] primary_write_failed | path=%s | fallback=%s | error=%s",
            kind.upper(),
            path,
            fallback,
            exc,
        )
        try:
            fallback.write_text(content, encoding="utf-8", errors="replace")
        except OSError as fallback_exc:
            # Diagnostic logging must never abort generation or runtime repair.
            log.error(
                "[%s_LOG] fallback_write_failed | path=%s | error=%s",
                kind.upper(),
                fallback,
                fallback_exc,
            )
        return fallback


def _timeout_text(value: str | bytes | None) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value


def _print_compiler_errors(blob: str) -> None:
    print("\n" + "!" * 80)
    print("MAVEN COMPILER ERROR")
    print("!" * 80)
    for line in blob.splitlines():
        if "[ERROR]" in line and any(
            token in line
            for token in (
                ".java:",
                "cannot find symbol",
                "symbol:",
                "constructor",
                "incompatible types",
                "package",
            )
        ):
            print(line)
    print("!" * 80 + "\n")


def _looks_offline_miss(blob: str) -> bool:
    needles = (
        "is missing in the local repository",
        "Cannot access central",
        "in offline mode",
        "Could not resolve",
        "Failure to find",
        "Unable to find",
    )
    return any(needle in blob for needle in needles)


def _tail(blob: str, n: int = 4000) -> str:
    return blob[-n:] if len(blob) > n else blob
