"""Fixed console-stage vocabulary."""
from __future__ import annotations

from junitforge.vendor.logging_utils import get

log = get("junitforge.console")

STAGE_TAGS = (
    "TECH_STACK", "SOURCE_FILE_INFO", "PARSE", "CLASSIFY", "DESTINATION",
    "COLLABORATORS", "EXECUTION_CONTEXT", "GENERATION_CONTEXT", "GENERATION",
    "METHOD_GENERATION", "COMPILE", "COMPILE_REPAIR", "RUNTIME",
    "RUNTIME_REPAIR", "COVERAGE", "PUBLICATION", "FINAL",
)


def stage(tag: str, message: str, *args, level: str = "info") -> None:
    if tag not in STAGE_TAGS:
        raise ValueError(f"unsupported console stage tag: {tag}")
    getattr(log, level)(f"[{tag}] {message}", *args)
