"""Audit path construction."""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

_STAGE_DIRS = (
    "01-parse", "02-classification", "03-destination", "04-context",
    "05-skeleton", "06-method-generation", "07-class-assembly", "08-compile",
    "09-compile-repair", "10-runtime", "11-runtime-repair", "12-coverage",
    "13-publication",
)


def safe_name(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9._-]+", "_", value.strip())
    return text.strip("._-") or "unnamed"


@dataclass(frozen=True)
class AuditPaths:
    root: Path

    def target(self, target_class: str) -> Path:
        return self.root / safe_name(target_class)

    def ensure_target(self, target_class: str) -> Path:
        base = self.target(target_class)
        for stage in _STAGE_DIRS:
            (base / stage).mkdir(parents=True, exist_ok=True)
        return base

    def method(self, target_class: str, method_id: str) -> Path:
        path = self.target(target_class) / "06-method-generation" / safe_name(method_id)
        path.mkdir(parents=True, exist_ok=True)
        return path

    def compile_repair(self, target_class: str, attempt: int) -> Path:
        path = self.target(target_class) / "09-compile-repair" / f"attempt-{attempt:03d}"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def runtime_repair(self, target_class: str, method_id: str, attempt: int) -> Path:
        path = self.target(target_class) / "11-runtime-repair" / safe_name(method_id) / f"attempt-{attempt:03d}"
        path.mkdir(parents=True, exist_ok=True)
        return path


STAGE_DIRS = _STAGE_DIRS
