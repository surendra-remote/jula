"""Single authoritative structured audit recorder."""
from __future__ import annotations

import hashlib
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from junitforge.audit.models import AuditFailure
from junitforge.audit.paths import AuditPaths, safe_name
from junitforge.audit.serializer import dumps, redact_text, to_jsonable
from junitforge.vendor.logging_utils import get

log = get(__name__)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_text(value: str | None) -> str | None:
    if value is None:
        return None
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


class AuditRecorder:
    def __init__(self, repo_root: Path, *, version: str, enabled: bool = True, run_id: str | None = None):
        self.repo_root = Path(repo_root)
        self.version = version
        self.enabled = enabled
        self.run_id = run_id or datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        self.paths = AuditPaths(self.repo_root / "reports" / "audit" / self.run_id)
        self.paths.root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._manifest: dict[str, Any] = {}
        self.failures: list[AuditFailure] = []
        self.serialization_warnings: list[str] = []
        self._target_aliases: dict[str, str] = {}
        self.llm_call_count = 0
        self.input_tokens = 0
        self.output_tokens = 0
        self.total_tokens = 0

    @property
    def root(self) -> Path:
        return self.paths.root

    def start_run(self, *, repository_root: Path, configuration: dict[str, Any]) -> None:
        self._manifest = {
            "run_id": self.run_id,
            "tool_version": self.version,
            "started_at": utc_now(),
            "completed_at": None,
            "status": "running",
            "repository_root": str(repository_root),
            "configuration": configuration,
            "targets": [],
            "audit_failures": [],
        }
        self.write_json(None, "manifest.json", self._manifest)

    def register_target(self, target_class: str, source_file: Path) -> str:
        target = safe_name(target_class)
        self.paths.ensure_target(target)
        with self._lock:
            existing = next((item for item in self._manifest.get("targets", []) if item["audit_path"] == target), None)
            if existing is None:
                self._manifest.setdefault("targets", []).append({
                    "target_class": target_class,
                    "source_file": str(source_file),
                    "audit_path": target,
                    "status": "running",
                })
                self.write_json(None, "manifest.json", self._manifest)
        return target

    def alias_target(self, old: str, new: str) -> None:
        self._target_aliases[safe_name(old)] = safe_name(new)

    def target_name(self, value: str) -> str:
        name = safe_name(value)
        return self._target_aliases.get(name, name)

    def target_dir(self, target_class: str) -> Path:
        return self.paths.ensure_target(self.target_name(target_class))

    def write_json(self, target_class: str | None, relative: str | Path, value: Any) -> Path | None:
        if not self.enabled:
            return None
        base = self.paths.root if target_class is None else self.target_dir(target_class)
        path = base / relative
        try:
            text, warnings = dumps(value)
            self.serialization_warnings.extend(warnings)
            with self._lock:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(text, encoding="utf-8", newline="\n")
            return path
        except Exception as exc:  # noqa: BLE001
            self._failure("write_json", path, exc)
            return None

    def write_text(self, target_class: str, relative: str | Path, value: str, *, redact: bool = False) -> Path | None:
        if not self.enabled:
            return None
        path = self.target_dir(target_class) / relative
        try:
            with self._lock:
                path.parent.mkdir(parents=True, exist_ok=True)
                text = redact_text(value or "") if redact else (value or "")
                path.write_text(text, encoding="utf-8", newline="\n")
            return path
        except Exception as exc:  # noqa: BLE001
            self._failure("write_text", path, exc)
            return None

    def record_llm_call(self, *, target_class: str, relative_dir: str | Path, request: Any,
                        response: str, metadata: dict[str, Any]) -> None:
        self.record_llm_usage(metadata.get("usage"))
        self.write_json(target_class, Path(relative_dir) / "request.json", {
            "metadata": metadata,
            "messages": request,
        })
        self.write_text(target_class, Path(relative_dir) / "response.txt", response)

    def record_llm_usage(self, usage: Any = None) -> None:
        self.llm_call_count += 1
        if usage is None:
            return
        prompt = int(getattr(usage, "prompt_tokens", 0) or (usage.get("prompt_tokens", 0) if isinstance(usage, dict) else 0))
        completion = int(getattr(usage, "completion_tokens", 0) or (usage.get("completion_tokens", 0) if isinstance(usage, dict) else 0))
        total = int(getattr(usage, "total_tokens", 0) or (usage.get("total_tokens", 0) if isinstance(usage, dict) else 0))
        self.input_tokens += prompt
        self.output_tokens += completion
        self.total_tokens += total or prompt + completion

    def record_error(self, *, operation: str, target_class: str | None, error: BaseException | str) -> None:
        path = self.paths.root if target_class is None else self.target_dir(target_class)
        self._failure(operation, path, error)

    def record_stage_start(self, *, target_class: str, relative: str | Path, stage: str, **details: Any) -> Path | None:
        return self.write_json(target_class, relative, {"stage": stage, "status": "started", "started_at": utc_now(), **details})

    def record_stage_result(self, *, target_class: str, relative: str | Path, stage: str, **details: Any) -> Path | None:
        return self.write_json(target_class, relative, {"stage": stage, "status": details.pop("status", "completed"), "completed_at": utc_now(), **details})

    def record_command(self, *, target_class: str, relative: str | Path, command: Any, **details: Any) -> Path | None:
        return self.write_json(target_class, relative, {"command": command, **details})

    def record_diagnostics(self, *, target_class: str, relative: str | Path, diagnostics: Any, **details: Any) -> Path | None:
        return self.write_json(target_class, relative, {"diagnostics": diagnostics, **details})

    def record_source_snapshot(self, *, target_class: str, relative: str | Path, source: str) -> Path | None:
        return self.write_text(target_class, relative, source)

    def record_registry_snapshot(self, *, target_class: str, relative: str | Path, registry: Any) -> Path | None:
        return self.write_json(target_class, relative, registry)

    def record_repair_decision(self, *, target_class: str, relative: str | Path, decision: Any) -> Path | None:
        return self.write_json(target_class, relative, decision)

    def finalize_target(self, target_class: str, *, outcome: Any, stage_status: dict[str, Any] | None = None) -> None:
        target = self.target_name(target_class)
        summary = {
            "target_class": target_class,
            "completed_at": utc_now(),
            "outcome": outcome,
            "stage_status": stage_status or {},
            "audit_failures": [to_jsonable(item) for item in self.failures],
        }
        self.write_json(target, "final-manifest.json", summary)
        with self._lock:
            for item in self._manifest.get("targets", []):
                if item.get("audit_path") == target:
                    item["status"] = getattr(outcome, "status", None) or (outcome.get("status") if isinstance(outcome, dict) else "completed")
            self.write_json(None, "manifest.json", self._manifest)

    def finalize_run(self, *, status: str, outcomes: list[Any], totals: dict[str, Any] | None = None) -> None:
        self._manifest["completed_at"] = utc_now()
        self._manifest["status"] = status
        self._manifest["audit_failures"] = [to_jsonable(item) for item in self.failures]
        self._manifest["serialization_warnings"] = sorted(set(self.serialization_warnings))
        self.write_json(None, "manifest.json", self._manifest)
        self.write_json(None, "final-manifest.json", {
            **self._manifest,
            "targets_processed": len(outcomes),
            "outcomes": outcomes,
            "totals": {
                "llm_calls": self.llm_call_count,
                "input_tokens": self.input_tokens,
                "output_tokens": self.output_tokens,
                "tokens_used": self.total_tokens,
                **(totals or {}),
            },
            "audit_root": str(self.paths.root),
        })

    def _failure(self, operation: str, path: Path, error: BaseException | str) -> None:
        failure = AuditFailure(operation=operation, path=str(path), error=redact_text(str(error)))
        self.failures.append(failure)
        if len(self.failures) == 1:
            log.warning("audit write warning | operation=%s | path=%s | error=%s", operation, path, failure.error)


class NullAuditRecorder:
    enabled = False
    failures: list[Any] = []
    serialization_warnings: list[str] = []
    root = Path(".")
    run_id = "disabled"
    llm_call_count = 0
    input_tokens = 0
    output_tokens = 0
    total_tokens = 0

    def __getattr__(self, name):
        def no_op(*args, **kwargs):
            return None
        return no_op
