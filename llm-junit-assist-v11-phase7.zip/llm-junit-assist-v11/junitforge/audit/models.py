"""Lightweight audit models."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class AuditFailure:
    operation: str
    path: str
    error: str


@dataclass(slots=True)
class LlmAudit:
    request_type: str
    target_class: str
    method_id: str | None = None
    test_names: list[str] = field(default_factory=list)
    attempt: int = 1
    model_id: str = ""
    temperature: float = 0.0
    max_tokens: int = 0
    messages: Any = None
    raw_response: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    elapsed_seconds: float = 0.0
    status: str = "completed"
