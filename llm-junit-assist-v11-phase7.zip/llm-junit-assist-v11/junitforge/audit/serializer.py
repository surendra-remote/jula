"""Deterministic, redacting audit serialization."""
from __future__ import annotations

import dataclasses
import enum
import json
import re
from pathlib import Path
from typing import Any

_SECRET_KEY = re.compile(r"(?i)(api[_-]?key|access[_-]?token|refresh[_-]?token|auth[_-]?token|password|secret|authorization|bearer|credential)")
_SAFE_TELEMETRY_KEYS = {"input_tokens", "output_tokens", "prompt_tokens", "completion_tokens", "total_tokens", "tokens_used", "max_tokens"}
_SECRET_VALUE = re.compile(r"(?i)(bearer\s+[A-Za-z0-9._~+/=-]+|sk-[A-Za-z0-9_-]+)")


def redact_text(value: str) -> str:
    return _SECRET_VALUE.sub("<redacted>", value)


def to_jsonable(value: Any, warnings: list[str] | None = None) -> Any:
    warnings = warnings if warnings is not None else []
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return redact_text(value)
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, enum.Enum):
        return to_jsonable(value.value, warnings)
    if dataclasses.is_dataclass(value):
        return to_jsonable(dataclasses.asdict(value), warnings)
    if isinstance(value, BaseException):
        return {"type": type(value).__name__, "message": redact_text(str(value))}
    if isinstance(value, dict):
        result: dict[str, Any] = {}
        for key, item in value.items():
            name = str(key)
            if name.lower() not in _SAFE_TELEMETRY_KEYS and _SECRET_KEY.search(name):
                result[name] = "<redacted>"
            else:
                result[name] = to_jsonable(item, warnings)
        return result
    if isinstance(value, (list, tuple)):
        return [to_jsonable(item, warnings) for item in value]
    if isinstance(value, (set, frozenset)):
        return sorted((to_jsonable(item, warnings) for item in value), key=lambda item: repr(item))
    if hasattr(value, "__dict__"):
        return to_jsonable(vars(value), warnings)
    warnings.append(f"unsupported audit value converted with repr: {type(value).__name__}")
    return redact_text(repr(value))


def dumps(value: Any) -> tuple[str, list[str]]:
    warnings: list[str] = []
    payload = to_jsonable(value, warnings)
    return json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", warnings
