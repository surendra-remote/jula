"""junitforge - standalone, coverage-driven JUnit 5 test generator.

Final v11 integrates the authoritative registry, collaborator contracts,
compiled fixture graphs and variants, focused compile repair, transactional
runtime repair, reporting, and publication gates.
"""

__version__ = "11.0.0"
