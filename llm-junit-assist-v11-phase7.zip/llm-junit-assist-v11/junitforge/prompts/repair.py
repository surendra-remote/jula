"""Compile/runtime repair prompts aligned with unit-only generation rules."""

from __future__ import annotations

import re

from junitforge.execution.renderer import render_dependency_contracts, render_execution_context, render_verified_method_contract
from junitforge.models import CompileError, GenerationContext
from junitforge.parser.collaborators import render_collaborator
from junitforge.prompts.system import build_system_prompt


def _deterministic_repair_rules() -> str:
    return """
- Use only verified application types; never infer a class from a repository, collaborator, method, or variable name.
- For fixture-supported DTO/entity/request/response/schema types, call the existing fixture helper. Never use new, builder(), mock(), spy(new ...), or reflection to reconstruct the schema.
- Use only verified getters, setters, methods, enum constants, static constants, argument types, and collection families.
- Void normal-path collaborator calls require no stub; use doThrow only for a source-proven exception scenario.
- Non-void collaborator calls whose return is marked ignored require no normal stub and must never use doNothing(); optional verify(...) is allowed.
- Non-void collaborator calls whose return is marked consumed require a type-correct verified return stub.
- Preserve exact enum, temporal, primitive, generic, collection element, map key/value, and wrapper types.
- Do not reference production-only locals or private CUT fields directly in a test method.
- Use a verified test-side value only when exact matching is required; otherwise use a type-compatible Mockito matcher.
- Prefer primitive Mockito matchers such as anyChar(), anyInt(), and anyBoolean() for primitive parameters.
- Use only JUnit Jupiter assertions already supported by the deterministic skeleton.
- Do not use AssertJ, Hamcrest, Google Truth, or another assertion library, and do not add imports.
""".strip()


def _system(ctx: GenerationContext) -> str:
    return build_system_prompt(ctx.stack, ctx.template).replace("{TEST_CLASS_NAME}", ctx.test_class_name).replace("{TEST_PACKAGE}", ctx.test_package)


def _collabs(ctx: GenerationContext) -> str:
    if ctx.execution_context is not None:
        return render_dependency_contracts(ctx.execution_context)
    return "\n\n".join(render_collaborator(c) for c in ctx.collaborators) or "(none)"


def _execution_context(ctx: GenerationContext) -> str:
    if ctx.execution_context is None:
        return ""
    return render_execution_context(ctx.execution_context)


def _is_strict_serviceimpl(ctx: GenerationContext) -> bool:
    execution = getattr(ctx, "execution_context", None)
    target_kind = getattr(getattr(execution, "target_kind", None), "value", None)
    if target_kind is not None:
        return target_kind == "service-impl"
    if not ctx.symbol or ctx.symbol.kind != "class" or "abstract" in (ctx.symbol.modifiers or set()):
        return False
    annos = {a.split(".")[-1] for a in (ctx.symbol.annotations or [])}
    impls = {name.split(".")[-1] for name in (ctx.symbol.implements or [])}
    return (
        "Service" in annos
        or ctx.symbol.name.endswith("ServiceImpl")
        or any(name.endswith("Service") for name in impls)
    )


def _is_lombok_generated(method) -> bool:
    return "LombokGenerated" in {a.split(".")[-1] for a in (method.annotations or [])}


def _strict_service_methods(ctx: GenerationContext) -> list:
    if not ctx.symbol:
        return []
    return [
        method for method in (ctx.symbol.methods or [])
        if method.is_public and not method.is_static and not method.is_constructor and not _is_lombok_generated(method)
    ]


def _service_repair_rules(ctx: GenerationContext) -> str:
    if not _is_strict_serviceimpl(ctx):
        return ""
    names = ", ".join(method.name for method in _strict_service_methods(ctx)) or "(none)"
    return (
        "SERVICEIMPL HALLUCINATION REPAIR RULES:\n"
        f"- Exact allowed CUT method names: {names}.\n"
        "- Delete every test method that calls a CUT method outside that list. Do not rename an invented method to another guessed name.\n"
        "- Rebuild the affected test only from an exact listed CUT signature and its visible source path.\n"
        "- Never use the CUT as a Mockito when/doReturn/doThrow/doNothing/verify receiver; only dependencies may be Mockito receivers.\n"
        "- For collaborators, use only exact observed/declared contracts in DIRECT COLLABORATORS or AUTHORITATIVE EXECUTION CONTEXT.\n"
        "- If no exact CUT method or collaborator contract supports the broken test, remove that test instead of inventing an API."
    )


def _allowed_methods(ctx: GenerationContext) -> str:
    try:
        if _is_strict_serviceimpl(ctx):
            methods = [m.render() for m in _strict_service_methods(ctx)]
        else:
            methods = [m.render() for m in ctx.symbol.public_methods()]
    except Exception:
        methods = []
    header = "- EXACT SERVICEIMPL WHITELIST; no other CUT method is permitted\n" if _is_strict_serviceimpl(ctx) else ""
    return header + ("\n".join(f"- {m}" for m in methods) if methods else "- (none detected; do not invent)")


def _private_methods(ctx: GenerationContext) -> str:
    try:
        privates = [m.render() for m in (ctx.symbol.methods or []) if "private" in m.modifiers]
    except Exception:
        privates = []
    return "\n".join(f"- {m}" for m in privates) if privates else "(none detected)"


def _source_imports(ctx: GenerationContext) -> str:
    imports = list(getattr(ctx, "source_imports", None) or [])
    return "\n".join(f"- {i}" for i in imports) if imports else "(none detected)"


def _equals_hashcode_repair_rule(ctx: GenerationContext) -> str:
    source = ctx.cut_source or ""
    call_super_true = re.search(
        r"@(?:lombok\.)?EqualsAndHashCode\s*\([^)]*\bcallSuper\s*=\s*true\b[^)]*\)",
        source,
        flags=re.IGNORECASE | re.DOTALL,
    ) is not None
    if not call_super_true:
        return (
            "- Keep two-instance equals/hashCode tests only when manual equals/hashCode or "
            "Lombok @Data/@Value/@EqualsAndHashCode proves the contract. For manual equals, "
            "test only fields used by the method body."
        )
    return (
        "- SPECIAL @EqualsAndHashCode(callSuper = true) REPAIR: keep exactly two objects of the "
        "same concrete class; set identical values for every writable listed field; compare each "
        "initialized field through verified getters; then use assertEquals(first, second). "
        "HashCode assertions must be self-comparisons only: "
        "assertEquals(first.hashCode(), first.hashCode()) and "
        "assertEquals(second.hashCode(), second.hashCode()). Remove any comparison between "
        "first.hashCode() and second.hashCode(). Do not create or compare a parent object."
    )


def build_compile_repair_messages(
    ctx: GenerationContext,
    current_test: str,
    errors: list[CompileError],
    kb_hints: list[str] | None = None,
) -> list[dict]:
    err_block = "\n".join(f"- {e.render()}" for e in errors) or "- (compiler errors unavailable)"
    kb_block = "\n".join(f"- {h}" for h in (kb_hints or [])) or "(none)"
    execution_block = _execution_context(ctx)
    execution_section = f"{execution_block}\n\n" if execution_block else ""
    equality_repair_rule = _equals_hashcode_repair_rule(ctx)
    service_repair_rule = _service_repair_rules(ctx)

    user = f"""The generated JUnit test file failed compilation. Return the COMPLETE corrected Java test file, not a snippet.

=== COMPILE ERRORS ===
{err_block}

=== KNOWN FIX HINTS ===
{kb_block}

=== ALLOWED CLASS-UNDER-TEST METHODS ===
{_allowed_methods(ctx)}

=== PRIVATE METHODS DETECTED — DO NOT CALL DIRECTLY ===
{_private_methods(ctx)}

=== DIRECT COLLABORATORS ===
{_collabs(ctx)}

{execution_section}=== SOURCE IMPORTS FROM CLASS UNDER TEST ===
{_source_imports(ctx)}

=== CURRENT BROKEN TEST FILE ===
```java
{current_test}
```

REPAIR RULES:
{_deterministic_repair_rules()}
- Return exactly one complete Java file with package, imports, class, and tests.
- Keep the required package {ctx.test_package} and class name {ctx.test_class_name}.
- Fix the compile errors directly; do not rewrite working logic unnecessarily.
- Do not use Spring context annotations, @Autowired, @MockBean, or @MockitoBean.
- For controller tests, do not generate custom nested servlet mock classes. Never implement/extend HttpServletResponse, HttpServletRequest, ServletResponse, ServletRequest, FilterChain, ServletOutputStream, or PrintWriter. Use Mockito mock(...) or org.springframework.mock.web.MockHttpServletResponse/MockHttpServletRequest instead.
- Use jakarta.servlet.* only; never use javax.servlet.*.
- Do not invent methods or constructors.
- Fix wildcard-map capture errors by using Map<String, Object> for mutable fixture maps and explicitly casting nested Object values before put/putAll/replace/compute/merge. Never mutate Map<?, ?>.
{service_repair_rule}
- Add missing imports when needed, especially JUnit assertions, Mockito static imports, and production enum/constant imports shown in SOURCE IMPORTS FROM CLASS UNDER TEST.
- Mockito matcher rule: never mix raw values with any()/anyString()/eq()/isNull()/notNull()/argThat() in the same mocked method invocation. If one argument is a matcher, wrap exact raw values with eq(value). Prefer typed matchers such as anyString(), anyInt(), anyLong(), anyBoolean(), or any(Type.class).
- For custom exceptions extending Throwable/Exception/RuntimeException, inherited getMessage(), getCause(), getLocalizedMessage(), getSuppressed(), and getStackTrace() are valid methods even if not listed directly on the subclass.
- For @RestControllerAdvice/@ControllerAdvice tests, do not invent dependency setters such as setEnv()/setEnvironment(). If the handler has a private Environment field and no real setter, inject the mock with ReflectionTestUtils.setField(handler, "env", environment). Stubbing Environment.getProperty(...) is valid.
- For entity/DTO null-field tests, set each tested non-primitive field to null through its verified JavaBean setter or fluent mutator before assertNull(getter()). Do not assert default-null values on a new object.
- Keep canEqual tests only when canEqual is listed/available and package-accessible; otherwise remove them.
{equality_repair_rule}
- Keep constructor tests only for constructors explicitly listed/available, including Lombok @AllArgsConstructor and manually declared argument constructors.
- Keep builder tests only when builder() is available/listed.
- Keep toString content assertions only when source has explicit toString or Lombok @ToString/@Data/@Value and the asserted field is stable/non-excluded; otherwise use assertNotNull(instance.toString()).
- If a call uses a private method, remove that test method or cover the behavior through a public method. Do not use ReflectionTestUtils.invokeMethod for private helpers.
- If an accessor is derived from DB/annotation names, replace it with Java-field-derived accessor names.
- Output raw Java only. No markdown."""

    return [{"role": "system", "content": _system(ctx)}, {"role": "user", "content": user}]


def build_test_failure_repair_messages(ctx: GenerationContext, current_test: str, failure_excerpt: str) -> list[dict]:
    execution_block = _execution_context(ctx)
    execution_section = f"{execution_block}\n\n" if execution_block else ""
    equality_repair_rule = _equals_hashcode_repair_rule(ctx)
    service_repair_rule = _service_repair_rules(ctx)
    user = f"""A generated JUnit test failed at runtime. Return the COMPLETE corrected Java test file.

=== RUNTIME FAILURE / STACK TRACE ===
{failure_excerpt}

=== CLASS UNDER TEST SOURCE ===
```java
{ctx.cut_source}
```

=== DIRECT COLLABORATORS ===
{_collabs(ctx)}

{execution_section}=== SOURCE IMPORTS FROM CLASS UNDER TEST ===
{_source_imports(ctx)}

=== CURRENT TEST FILE ===
```java
{current_test}
```

REPAIR RULES:
{_deterministic_repair_rules()}
- Return exactly one complete Java file with package, imports, class, and tests.
- Keep package {ctx.test_package} and class name {ctx.test_class_name}.
- Align assertions and Mockito stubs with actual source behavior.
{service_repair_rule}
- Fix Mockito InvalidUseOfMatchersException by making each mocked method call use either all exact raw values or all matchers. If any argument uses any()/anyString()/eq()/isNull()/notNull()/argThat(), wrap raw exact arguments with eq(value).
- For custom exceptions extending Throwable/Exception/RuntimeException, inherited getMessage(), getCause(), getLocalizedMessage(), getSuppressed(), and getStackTrace() are valid methods even if not listed directly on the subclass.
- For @RestControllerAdvice/@ControllerAdvice tests, do not invent dependency setters such as setEnv()/setEnvironment(). If the handler has a private Environment field and no real setter, inject the mock with ReflectionTestUtils.setField(handler, "env", environment). Stubbing Environment.getProperty(...) is valid.
- For entity/DTO null-field tests, set each tested non-primitive field to null through its verified JavaBean setter or fluent mutator before assertNull(getter()).
- Keep canEqual tests only when canEqual is listed/available and package-accessible; otherwise remove them.
{equality_repair_rule}
- Keep constructor tests only for constructors explicitly listed/available.
- Keep builder tests only when builder() is available/listed.
- Avoid strict toString content assertions unless explicit toString or Lombok @ToString/@Data/@Value proves a stable contract.
- Do not weaken to trivial assertions such as assertTrue(true).
- Remove unused stubs that cause UnnecessaryStubbingException.
- Do not use Spring context annotations, @Autowired, @MockBean, or @MockitoBean.
- For controller tests, do not generate custom nested servlet mock classes. Never implement/extend HttpServletResponse, HttpServletRequest, ServletResponse, ServletRequest, FilterChain, ServletOutputStream, or PrintWriter. Use Mockito mock(...) or org.springframework.mock.web.MockHttpServletResponse/MockHttpServletRequest instead.
- Use jakarta.servlet.* only; never use javax.servlet.*.
- Output raw Java only. No markdown."""

    return [{"role": "system", "content": _system(ctx)}, {"role": "user", "content": user}]


# Spring Data inherited repository method rule
SPRING_DATA_REPOSITORY_METHODS = "findById, save, findAll, count, and deleteById are allowed on verified Spring Data repository collaborators; every other derived or inherited method must be declared or authoritatively resolved."


def build_method_generation_validation_repair_messages(
    ctx: GenerationContext,
    method,
    current_method_block: str,
    rejection_reason: str,
) -> list[dict]:
    """Repair one structurally rejected initial method-generation response.

    This is intentionally bounded to one retry.  It handles errors that occur
    before javac can arbitrate, especially Mockito stubbing/verifying of the CUT.
    """
    method_id = f"{method.name}({','.join(type_name for type_name, _ in method.params)})"
    execution_block = (
        render_execution_context(ctx.execution_context, method_id=method_id)
        if ctx.execution_context is not None else "(execution context unavailable)"
    )
    collaborator_block = (
        render_dependency_contracts(ctx.execution_context, method_id=method_id)
        if ctx.execution_context is not None else "(none authorized)"
    )
    verified_contract = (
        render_verified_method_contract(ctx.execution_context, method_id)
        if ctx.execution_context is not None else "(method contract unavailable)"
    )
    user = f"""The initial JUnit method response was structurally rejected. Return the corrected replacement @Test methods only.

=== ONLY AUTHORIZED PRODUCTION METHOD ===
{method.render()}

=== REJECTION REASON ===
{rejection_reason}

{execution_block}

{verified_contract}

=== EXACT COLLABORATORS AVAILABLE THROUGH THE PUBLIC METHOD AND ITS REAL SAME-CLASS CALL PATH ===
{collaborator_block}

=== REJECTED @TEST METHODS ===
```java
{current_method_block}
```

CORRECTION RULES:
{_deterministic_repair_rules()}
- Output raw Java @Test methods only; no package/import/class/setup/helper/prose.
- Call the selected CUT method normally.
- Never use the CUT as a receiver of when(...), doReturn/doThrow/doNothing(...).when(...), mock(...), spy(...), or verify(...).
- Same-class methods listed as reachable execute normally. Do not stub them. Stub only their exact listed collaborators.
- Replace any CUT spy/stub with the corresponding exact collaborator stubs from the authoritative context.
- If the public entry calls a concrete public/package-visible/protected method on the same class, let it run normally and add the exact collaborator stubs listed for that helper path.
- When the rejection reports missing required collaborator stubs, add every named source-proven non-void stub somewhere in the corrected suite. In particular, preserve the value flow between chained helper collaborators (for example encode quotationNo first, then pass the encoded value to the quotation client).
- Never mutate Map<?, ?>. For any map receiving put/putAll/replace/compute/merge, declare it as Map<String, Object>; cast nested Object values explicitly before mutation.
- Reuse only the listed compiled fixture roots; do not rebuild their DTO/entity/map graphs inline and do not invent helpers.
- Preserve meaningful branch coverage from the rejected block where source facts support it.
- Use only exact fields, map keys, constructors, setters, enums, constants, and collaborator contracts supplied above.
- Keep Mockito stubs local to the test that executes them; no lenient().
- Do not call a different CUT method or a private helper directly.
"""
    return [{"role": "system", "content": _system(ctx)}, {"role": "user", "content": user}]


def build_method_compile_repair_messages(
    ctx: GenerationContext,
    method,
    current_method_block: str,
    errors: list[CompileError],
) -> list[dict]:
    """Repair only the generated tests that belong to one production method."""
    method_id = f"{method.name}({','.join(type_name for type_name, _ in method.params)})"
    execution_block = (
        render_execution_context(ctx.execution_context, method_id=method_id)
        if ctx.execution_context is not None else "(execution context unavailable)"
    )
    collaborator_block = (
        render_dependency_contracts(ctx.execution_context, method_id=method_id)
        if ctx.execution_context is not None else "(none authorized)"
    )
    verified_contract = (
        render_verified_method_contract(ctx.execution_context, method_id)
        if ctx.execution_context is not None else "(method contract unavailable)"
    )
    err_block = "\n".join(f"- {error.render()}" for error in errors) or "- (errors unavailable)"
    user = f"""Repair ONLY the JUnit @Test methods generated for one production method.

=== ONLY AUTHORIZED PRODUCTION METHOD ===
{method.render()}

=== COMPILE ERRORS BELONGING TO THIS METHOD BLOCK ===
{err_block}

{execution_block}

{verified_contract}

=== METHOD-SPECIFIC COLLABORATOR CONTRACTS ===
{collaborator_block}

=== CURRENT BROKEN @TEST METHODS ===
```java
{current_method_block}
```

REPAIR RULES:
{_deterministic_repair_rules()}
- Output raw Java @Test methods only. No package, imports, class wrapper, fields, setup method, helpers, or prose.
- Preserve coverage of all source-proven branches for this production method unless a branch is unsupported because its schema/contract is unresolved.
- Fix only the listed compile errors. Do not call another class-under-test method.
- Use only the verified recursive payload schemas and exact collaborator receiver+method contracts in the authoritative context.
- Rebuild every listed intermediate dereference prefix before calling the CUT; a null-safe terminal utility does not make its parent object null-safe.
- Direct @Value fields are injected by the deterministic skeleton. Override only exact listed fields when the selected branch requires a different configuration value.
- Do not invent fields, getters, setters, constructors, builders, enum constants, exceptions, branches, status codes, or JSON paths.
- Never stub or verify the class under test.
- Same-class public/package-visible/protected helpers execute normally; preserve and stub their exact listed collaborator calls.
- Never call put/putAll/replace/compute/merge on Map<?, ?>. Change the local declaration/cast to Map<String, Object> before mutation.
- Keep branch-specific Mockito stubs local to the test that executes them; no lenient().
- Do not call private methods directly.
"""
    return [{"role": "system", "content": _system(ctx)}, {"role": "user", "content": user}]


def build_method_runtime_repair_messages(
    ctx: GenerationContext,
    method,
    current_method_block: str,
    failure_excerpt: str,
) -> list[dict]:
    """Repair runtime failures without exposing or rewriting other method tests."""
    method_id = f"{method.name}({','.join(type_name for type_name, _ in method.params)})"
    execution_block = (
        render_execution_context(ctx.execution_context, method_id=method_id)
        if ctx.execution_context is not None else "(execution context unavailable)"
    )
    collaborator_block = (
        render_dependency_contracts(ctx.execution_context, method_id=method_id)
        if ctx.execution_context is not None else "(none authorized)"
    )
    verified_contract = (
        render_verified_method_contract(ctx.execution_context, method_id)
        if ctx.execution_context is not None else "(method contract unavailable)"
    )
    user = f"""Repair ONLY the JUnit @Test methods for one production method after a runtime failure.

=== ONLY AUTHORIZED PRODUCTION METHOD ===
{method.render()}

=== FAILURE / STACK TRACE ===
{failure_excerpt}

{execution_block}

{verified_contract}

=== METHOD-SPECIFIC COLLABORATORS ===
{collaborator_block}

=== CURRENT @TEST METHODS FOR THIS PRODUCTION METHOD ===
```java
{current_method_block}
```

REPAIR RULES:
{_deterministic_repair_rules()}
- Output exactly the supplied affected raw Java @Test methods, preserving every test name and count.
- No package, imports, class wrapper, fields, setup, helper methods, or prose.
- Preserve source-proven branch coverage while fixing the runtime failure.
- Repair only the supplied affected tests. Do not rename, delete, merge, add, or omit a test. Do not modify sibling tests, production source, or tests owned by another production method.
- Use minimal JUnit Jupiter assertions. For an object success result, normally use one assertNotNull(result); for a verified null path use assertNull(result); for boolean, primitive, String, enum, or numeric results use one exact assertion; for a propagated exception use one assertThrows; for void methods verify only the principal observable interaction.
- Do not add @Disabled, Spring test-context annotations, broad try/catch blocks, or class-wide Mockito leniency.
- Do not remove all assertions or all verifications merely to make the test pass.
- Correct fixture values, nested response construction, matcher selection, and collaborator stubs before changing an assertion.
- Do not change assertNotNull to assertNull, true to false, or another expected value unless the supplied production source proves that outcome.
- For NullPointerException, build every verified intermediate dereference prefix required by the selected branch; do not guess missing fields. For StringUtils.defaultString(unit.getValue())-style code, unit must exist even when value is intentionally null.
- If a null-input scenario is not supported by the source contract and reaches only an unconditional dereference, replace it with a source-proven boundary scenario or use assertThrows only when the production method actually propagates that exception.
- Direct @Value fields are injected by the deterministic skeleton. Override only exact listed fields when the failing branch requires a different value.
- Remove branch-irrelevant stubs causing UnnecessaryStubbingException.
- Do not add lenient() unless the supplied context proves an unavoidable shared setup stub; never weaken Mockito strictness globally.
- Never make a mock throw a checked exception unless its exact method contract declares that checked exception. Use a source-proven unchecked exception or remove an impossible exception scenario.
- For WantedButNotInvoked or NeverWantedButInvoked, verify the production guard and branch-driving fixture first. Do not call the mock directly from the test to satisfy verification and do not blindly remove never().
- For retry scenarios, use source-proven ordered stubbing and do not introduce real sleeps or modify production retry configuration.
- Align Mockito arguments with exact observed invocation expressions and never mix raw values with matchers.
- Use only verified payload schemas and exact collaborator contracts.
- Do not call another CUT method, stub/verify the CUT, invoke private methods, use lenient(), or invent APIs/behavior.
"""
    return [{"role": "system", "content": _system(ctx)}, {"role": "user", "content": user}]


def build_individual_test_validation_repair_messages(
    ctx: GenerationContext,
    method,
    current_test: str,
    test_name: str,
    rejection_reason: str,
) -> list[dict]:
    """Bounded repair for one structurally invalid generated test."""
    method_id = f"{method.name}({','.join(type_name for type_name, _ in method.params)})"
    execution_block = (
        render_execution_context(ctx.execution_context, method_id=method_id)
        if ctx.execution_context is not None else "(execution context unavailable)"
    )
    collaborator_block = (
        render_dependency_contracts(ctx.execution_context, method_id=method_id)
        if ctx.execution_context is not None else "(none authorized)"
    )
    verified_contract = (
        render_verified_method_contract(ctx.execution_context, method_id)
        if ctx.execution_context is not None else "(method contract unavailable)"
    )
    user = f"""Repair exactly one rejected JUnit test method.

=== OWNER PRODUCTION METHOD ===
{method.render()}

=== TEST IDENTITY — MUST REMAIN EXACTLY UNCHANGED ===
{test_name}

=== EXACT VALIDATION DIAGNOSTIC ===
{rejection_reason}

{execution_block}

{verified_contract}

=== APPLICABLE COLLABORATOR CONTRACTS ===
{collaborator_block}

=== AFFECTED TEST ONLY ===
```java
{current_test}
```

REPAIR RULES:
{_deterministic_repair_rules()}
- Return exactly one raw Java @Test method and no other content.
- Keep the exact test method name `{test_name}`.
- Do not delete, merge, disable, or rename the test.
- Do not add or modify sibling tests.
- Repair only the supplied diagnostic.
- Use deterministic fixture helpers, verified members, verified collaborator return types, and declared exceptions from the supplied context.
- Same-class methods execute real code. Never stub or verify the class under test.
- Injected service interfaces are external collaborators and may be mocked only through their exact verified contracts.
- Do not invent application types, members, exceptions, constants, or behavior.
"""
    return [{"role": "system", "content": _system(ctx)}, {"role": "user", "content": user}]


def build_individual_test_compile_repair_messages(
    ctx: GenerationContext,
    method,
    current_test: str,
    test_name: str,
    errors: list[CompileError],
) -> list[dict]:
    """Compile repair scoped to one exact @Test method."""
    method_id = f"{method.name}({','.join(type_name for type_name, _ in method.params)})"
    execution_block = (
        render_execution_context(ctx.execution_context, method_id=method_id)
        if ctx.execution_context is not None else "(execution context unavailable)"
    )
    collaborator_block = (
        render_dependency_contracts(ctx.execution_context, method_id=method_id)
        if ctx.execution_context is not None else "(none authorized)"
    )
    verified_contract = (
        render_verified_method_contract(ctx.execution_context, method_id)
        if ctx.execution_context is not None else "(method contract unavailable)"
    )
    err_block = "\n".join(f"- {error.render()}" for error in errors) or "- (errors unavailable)"
    user = f"""Repair one JUnit test method that failed compilation.

=== OWNER PRODUCTION METHOD ===
{method.render()}

=== TEST IDENTITY — MUST REMAIN EXACTLY UNCHANGED ===
{test_name}

=== COMPILER DIAGNOSTICS MAPPED TO THIS TEST ===
{err_block}

{execution_block}

{verified_contract}

=== APPLICABLE COLLABORATOR CONTRACTS ===
{collaborator_block}

=== AFFECTED TEST ONLY ===
```java
{current_test}
```

REPAIR RULES:
{_deterministic_repair_rules()}
- Return exactly one raw Java @Test method and no other content.
- Keep the exact test method name `{test_name}`.
- Do not delete, merge, disable, or rename the test.
- Do not modify sibling tests or class-level source.
- Fix only the mapped compiler diagnostics.
- Same-class methods execute real code; only injected collaborators may be stubbed.
- Use only verified fixture helpers, members, contracts, types, exceptions, and constants.
"""
    return [{"role": "system", "content": _system(ctx)}, {"role": "user", "content": user}]
