"""Backward-compatible facade for the refactored per-target generation pipeline."""

from __future__ import annotations

from junitforge.compilation.candidate_validator import _compile_candidate_is_strict_progress
from junitforge.compilation.diagnostic_mapper import _select_method_repair_owner
from junitforge.pipeline.engine import GenerationPipeline

from junitforge.postprocess import finalize_java
from junitforge.prompts.repair import build_individual_test_compile_repair_messages
from junitforge.publication.summary import _refresh_generation_counters
from junitforge.runtime.candidate_validator import (
    validate_runtime_candidate_identity,
    validate_runtime_source_identity,
)
from junitforge.runtime.repair_coordinator import (
    _deterministic_runtime_replacement,
    _runtime_owner_priority,
    _targeted_selector,
)
from junitforge.runtime.result_parser import (
    _failure_signatures,
    _group_runtime_failures,
    _map_runtime_failure_owner,
    _runtime_failure_excerpt,
    group_runtime_failures_by_test,
    map_runtime_failure_test,
)
from junitforge.runtime.state import (
    _mark_retained_compile_state,
    _record_test_runtime_states,
    _runtime_snapshot,
)


class Engine(GenerationPipeline):
    """Compatibility name retained for CLI, tests, and direct callers."""


__all__ = [
    "Engine",
    "GenerationPipeline",
    "_compile_candidate_is_strict_progress",
    "_deterministic_runtime_replacement",
    "_failure_signatures",
    "_group_runtime_failures",
    "_map_runtime_failure_owner",
    "_mark_retained_compile_state",
    "_record_test_runtime_states",
    "_refresh_generation_counters",
    "_runtime_failure_excerpt",
    "_runtime_owner_priority",
    "_runtime_snapshot",
    "_select_method_repair_owner",
    "_targeted_selector",
    "group_runtime_failures_by_test",
    "map_runtime_failure_test",
    "validate_runtime_candidate_identity",
    "validate_runtime_source_identity",
]
