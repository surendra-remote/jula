"""Generated-test structural and semantic validation."""

from __future__ import annotations

import re

from junitforge.execution.assembly import (
    MethodBlockValidation,
    cut_variable_name,
    deterministically_repair_test,
    test_method_names,
    validate_method_block,
)
from junitforge.generation.semantic_validation import (
    SemanticCorrectionResult,
    deterministically_correct_serviceimpl,
    validate_serviceimpl_semantics,
)


def is_serviceimpl_context(ctx) -> bool:
    execution = getattr(ctx, "execution_context", None)
    target_kind = getattr(getattr(execution, "target_kind", None), "value", None)
    return target_kind == "service-impl"


def validate_serviceimpl_structural_test(
    ctx,
    production_method,
    source: str,
    existing_names=None,
) -> MethodBlockValidation:
    existing_names = existing_names or set()
    if not source.strip() or "@Test" not in source:
        return MethodBlockValidation(False, "no @Test methods returned")
    if re.search(r"(?m)^\s*(?:package|import)\b|\bclass\s+\w+", source):
        return MethodBlockValidation(False, "method response contains package/import/class wrapper")
    names = tuple(test_method_names(source))
    if not names:
        return MethodBlockValidation(False, "unable to identify generated test method names")
    if len(names) != len(set(names)):
        return MethodBlockValidation(False, "duplicate test names within method response")
    duplicates = set(names) & set(existing_names)
    if duplicates:
        return MethodBlockValidation(
            False,
            "duplicate test method names: " + ", ".join(sorted(duplicates)),
        )
    cut_var = cut_variable_name(ctx.symbol.name)
    if not re.search(
        rf"\b{re.escape(cut_var)}\s*\.\s*{re.escape(production_method.name)}\s*\(",
        source,
    ):
        return MethodBlockValidation(False, "ServiceImpl tests do not call the selected CUT method")
    return MethodBlockValidation(True, test_names=names)


def validate_generated_test(ctx, production_method, method_context, source, existing_names=None):
    if is_serviceimpl_context(ctx):
        structural = validate_serviceimpl_structural_test(
            ctx,
            production_method,
            source,
            existing_names,
        )
        if not structural.ok:
            return structural
        semantic = validate_serviceimpl_semantics(
            ctx, production_method, method_context, source
        )
        if not semantic.ok:
            return MethodBlockValidation(
                False,
                semantic.reason,
                test_names=structural.test_names,
                diagnostics=semantic.diagnostics,
            )
        return MethodBlockValidation(True, test_names=structural.test_names)
    return validate_method_block(
        ctx,
        production_method,
        method_context,
        source,
        existing_names or set(),
    )


def repair_validation_failure_deterministically(ctx, production_method, method_context, source):
    if is_serviceimpl_context(ctx):
        return deterministically_correct_serviceimpl(
            ctx, production_method, method_context, source
        )
    return deterministically_repair_test(ctx, production_method, method_context, source)


def validation_diagnostics(result) -> list[object]:
    diagnostics = list(getattr(result, "diagnostics", ()) or ())
    if diagnostics:
        return diagnostics
    return [result.reason] if getattr(result, "reason", "") else []


__all__ = [
    "is_serviceimpl_context",
    "repair_validation_failure_deterministically",
    "validate_generated_test",
    "validate_serviceimpl_structural_test",
    "validation_diagnostics",
]
