"""Other-target LLM payload compatibility builder.

This module preserves v7.3.3 prompt content while providing stage-specific
extension points for later target-specific redesigns.
"""

from __future__ import annotations

from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)


def build_generation_payload(*args, mode: str = "classwide", **kwargs):
    if mode == "method":
        return build_method_generation_messages(*args, **kwargs)
    return build_generation_messages(*args, **kwargs)


def build_validation_repair_payload(*args, mode: str = "individual", **kwargs):
    if mode == "method":
        return build_method_generation_validation_repair_messages(*args, **kwargs)
    return build_individual_test_validation_repair_messages(*args, **kwargs)


def build_compile_repair_payload(*args, mode: str = "classwide", **kwargs):
    if mode == "individual":
        return build_individual_test_compile_repair_messages(*args, **kwargs)
    if mode == "method":
        return build_method_compile_repair_messages(*args, **kwargs)
    return build_compile_repair_messages(*args, **kwargs)


def build_runtime_repair_payload(*args, **kwargs):
    return build_method_runtime_repair_messages(*args, **kwargs)


def build_coverage_augmentation_payload(*args, mode: str = "classwide", **kwargs):
    if mode == "method":
        return build_method_augmentation_messages(*args, **kwargs)
    return build_augmentation_messages(*args, **kwargs)
