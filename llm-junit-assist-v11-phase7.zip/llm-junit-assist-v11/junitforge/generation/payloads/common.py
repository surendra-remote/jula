"""Common target-type payload routing and compatibility helpers."""

from __future__ import annotations

from typing import Any


def target_kind_value(ctx: Any) -> str:
    execution = getattr(ctx, "execution_context", None)
    target_kind = getattr(execution, "target_kind", None)
    value = getattr(target_kind, "value", target_kind)
    if value:
        return str(value)
    template = getattr(ctx, "template", None)
    style = str(getattr(template, "style", "") or "").lower()
    if style == "entity-pojo":
        return "entity"
    if style == "dto-pojo":
        return "dto"
    symbol = getattr(ctx, "symbol", None)
    annotations = {str(a).lower() for a in getattr(symbol, "annotations", [])}
    name = str(getattr(symbol, "name", ""))
    if "serviceimpl" in name.lower():
        return "service-impl"
    if any("controller" in a for a in annotations) or name.endswith("Controller"):
        return "controller"
    if any("entity" in a for a in annotations):
        return "entity"
    if name.endswith("Dto") or name.endswith("DTO"):
        return "dto"
    return "other"
