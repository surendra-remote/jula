"""Structured ServiceImpl LLM request payloads for v11 Phase 4.

ServiceImpl is intentionally isolated from controller, DTO/entity, and other
payload builders. Permanent instructions preserve the existing baseline except for the five approved
fixture-only replacements; exact method-specific contracts remain dynamic.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
import re
from typing import Any

from junitforge.execution.assembly import cut_variable_name
from junitforge.generation.source_closure import build_source_closure


_SYSTEM_MESSAGE = (
    "You are a deterministic Java JUnit 5 test-generation engine. "
    "Follow the structured user payload as authoritative for allowed symbols, "
    "generation or repair scope, Mockito, assertions, and output. "
    "Do not invent unsupported APIs or behavior. Return only the requested output."
)

# Immutable fingerprint of the Phase 4 approved ServiceImpl permanent instruction set.
# Phase 4 preserves the baseline except for the five explicitly required minimal fixture-only replacements and two non-overlapping safety additions.
_PHASE1_GENERAL_INSTRUCTIONS_SHA256 = "e0873b732e770b07bfa940ab1f17e5fb3925b5c4b6ec4053add41280ff37cb43"

_GENERATION_INSTRUCTION = {'objective': {'tests_to_generate': 1,
               'requested_test_kind': 'normal_success',
               'coverage_scope': 'The authorized target method and all same-class helpers reached by the selected '
                                 'execution path.',
               'authorized_cut_invocation': 'Invoke only the authorized public target method on the supplied '
                                            'class-under-test instance.',
               'output_format': 'One raw Java JUnit 5 @Test method only.'},
 'path_selection': {'instruction': 'Analyze the target method and all reachable supplied same-class helper method '
                                   'bodies as one interprocedural execution unit. Derive feasible execution paths and '
                                   'select one complete path satisfying the requested test kind.',
                    'requirements': ['Derive paths only from control-flow constructs present in the supplied source.',
                                     'Trace if/else branches, ternary expressions, switch cases, loops, null guards, '
                                     'short-circuit expressions, Optional operations, stream operations, returns, '
                                     'throws, catches, and helper calls.',
                                     'Carry values, branch decisions, collaborator returns, object mutations, returned '
                                     'values, and exceptions across same-class helper boundaries.',
                                     'Each candidate path must represent one internally consistent execution from '
                                     'entry of the authorized target method to a terminal outcome.',
                                     'Reject paths containing mutually incompatible conditions.',
                                     'Reject paths requiring one value to satisfy contradictory predicates.',
                                     'Reject paths depending on unresolved methods, constants, types, fields, '
                                     'constructors, enum values, or collaborator contracts.',
                                     'Do not combine branch conditions, collaborator calls, fixture states, or '
                                     'expected outcomes from different paths.',
                                     'After selecting the path, identify only the collaborator calls and same-class '
                                     'helpers reached by that path.',
                                     'Use the selected path to determine fixture state, object relationships, '
                                     'collection contents, collaborator behavior, and observable assertions.'],
                    'requested_test_kind_rules': {'normal_success': ['Select a path that completes normally without '
                                                                     'entering a source-proven failure or exception '
                                                                     'outcome.',
                                                                     'The path must execute meaningful production '
                                                                     'behavior rather than terminate immediately '
                                                                     'because of invalid input.',
                                                                     'For a void method, successful normal completion '
                                                                     'must be demonstrated through source-proven state '
                                                                     'changes or collaborator interactions.',
                                                                     'For a non-void method, derive the expected '
                                                                     'result from the selected return path and '
                                                                     'source-proven mutations.'],
                                                  'handled_failure': ['Select a path where production code handles an '
                                                                      'error and returns, records, or exposes a '
                                                                      'source-proven failure outcome.'],
                                                  'propagated_exception': ['Select a path where a source-proven '
                                                                           'exception leaves the authorized public '
                                                                           'method.'],
                                                  'alternate_branch': ['Select one feasible path exercising the '
                                                                       'requested branch outcome without combining it '
                                                                       'with another execution path.']}},
 'source_analysis': {'instructions': ['Treat the supplied target method and helper method sources as authoritative.',
                                      'Trace assignments, returns, dereferences, branches, loops, Optional flows, '
                                      'collection operations, collaborator calls, and exceptions across helper '
                                      'boundaries.',
                                      'A collaborator return is consumed when it is assigned and later read, '
                                      'dereferenced, branch-tested, used in another call, returned by a helper, or '
                                      'propagated to the target method.',
                                      'A return flow classified as unresolved or unknown must not be treated as '
                                      'ignored.',
                                      'If a required return flow cannot be resolved sufficiently to create a '
                                      'type-correct stub, do not select a path depending on that flow.',
                                      'Respect lazy and conditional execution, including Optional.orElseGet, '
                                      'short-circuit boolean expressions, ternary expressions, callbacks, streams, and '
                                      'loops.',
                                      'Ignore commented-out calls and unreachable source.',
                                      'Do not invent methods, fields, constants, types, constructors, enum values, '
                                      'collaborator behavior, or production outcomes.']},
 'same_class_helper_rule': {'instructions': ['Any same-class helper reached by the selected path must execute as a '
                                             'real method.',
                                             'Never stub, spy, verify, or directly invoke a same-class helper.',
                                             'Cover private, protected, package-visible, and public same-class helpers '
                                             'only through the authorized public target method.',
                                             'Analyze collaborator calls inside reached helpers exactly as '
                                             'collaborator calls inside the target method.',
                                             'Do not include setup for helpers that are not reached by the selected '
                                             'path.']},
 'fixture_rule': {'instructions': ['Use the supplied compiled fixture methods for every fixture-supported application '
                                   'DTO or entity.',
                                   'Assume each compiled fixture provides the normal populated baseline produced by '
                                   'the deterministic test skeleton.',
                                   'Do not construct or recreate fixture-supported application objects using new, '
                                   'builders, mocks, spies, or reflection.',
                                   'A non-fixture-supported type may be constructed only when its verified '
                                   'constructor, builder, factory, or other construction contract is supplied in the '
                                   'request.',
                                   'Inspect the target method and reached same-class helper sources to determine the required fixture state for the selected path. Select an existing compiled fixture variant or request one bounded fixture-augmentation attempt. Do not adjust fixture-supported application objects inside the @Test method.',
                                   'Do not mutate fixture-supported application DTOs or entities inside @Test methods. Use a compiled fixture variant whose guaranteed state satisfies the selected path.',
                                   'Do not replace or mutate a compiled fixture graph inside an @Test method. Use a compiled fixture variant whose guaranteed graph satisfies the selected path.',
                                   'Preserve object identity when the same logical object is attached to another '
                                   'object, returned by a collaborator, passed through helpers, persisted, or later '
                                   'dereferenced.',
                                   'Ensure every intermediate object dereferenced by the selected path is non-null and '
                                   'every collection read has sufficient contents.',
                                   'Do not reconstruct the complete project-specific object graph when the supplied '
                                   'fixture already provides a usable baseline.',
                                   'If a selected path requires fixture state not provided by an existing compiled fixture, request one bounded fixture-augmentation attempt. If no valid compiled fixture can provide the required state, do not select that path.',
                                   'Do not invent project-specific field values or object relationships that are not '
                                   'supported by the supplied source.']},
 'fixture_value_rule': {'instructions': ['Use exact resolved constants when source conditions compare against those '
                                         'constants.',
                                         'Use verified enum constants for enum-typed fields.',
                                         'Use deterministic type-correct values for unconstrained scalar fields.',
                                         'Choose values that satisfy the exact predicates of the selected path.',
                                         'When multiple values must compare equal, derive them from one deterministic '
                                         'source value.',
                                         'When values must compare differently, choose values whose difference remains '
                                         'unambiguous under the production comparison logic.',
                                         'Do not guess unresolved constant or enum values.',
                                         'Do not mutate fields of fixture-supported application DTOs or entities inside @Test methods. Required selected-path state must come from a compiled fixture variant.']},
 'collaborator_rule': {'instructions': ['Derive Mockito behavior from the exact target and reached helper method '
                                        'bodies.',
                                        'Stub only collaborator calls reached by the selected path.',
                                        'Every reached non-void collaborator call whose return is consumed must '
                                        'receive a type-correct stub.',
                                        'Do not omit a required stub because the collaborator call occurs inside a '
                                        'same-class helper.',
                                        'Do not stub a collaborator call whose return is conclusively ignored unless '
                                        'the selected path requires a source-proven side effect to be simulated.',
                                        'Normal void collaborator calls require no stub.',
                                        'Use doThrow only when the selected path intentionally requires a collaborator '
                                        'exception.',
                                        'Use Mockito matchers for arguments created or transformed inside production '
                                        'code.',
                                        'Never reference production-local variables or helper parameters directly in '
                                        'the test.',
                                        'Use an exact test-visible expression only when the expression is available in '
                                        'test scope and is equivalent after all production transformations.',
                                        'When one argument uses a Mockito matcher, all arguments in that invocation '
                                        'must use Mockito matchers.',
                                        'Do not classify or stub an unresolved collaborator contract as void.']},
 'repository_rule': {'instructions': ['Treat repository methods according to return consumption and selected-path '
                                      'behavior, not merely because they are repository operations.',
                                      'A lookup return used by Optional logic, fallback selection, a branch, a '
                                      'dereference, another call, a helper return, or the target return requires a '
                                      'stub.',
                                      'For lazy fallback logic, stub only lookups executed by the selected path.',
                                      'A save or update result returned by a helper, assigned and later read, '
                                      'branch-tested, or dereferenced requires a stub.',
                                      'When a save method must return the same submitted entity, use '
                                      'thenAnswer(invocation -> invocation.getArgument(0)).',
                                      'When a save or update return is conclusively ignored and no '
                                      'persistence-generated mutation is later read, no normal return stub is '
                                      'required.',
                                      'When production later depends on persistence-generated state, simulate only the '
                                      'source-proven mutation required by the selected path.',
                                      'Normal void repository calls require no doNothing stub.']},
 'collection_rule': {'instructions': ['Use an empty collection only when the selected path permits or requires no '
                                      'existing elements.',
                                      'Populate the minimum number of elements required by the selected path.',
                                      'Provide at least one element when production executes get(0), '
                                      'iterator().next(), findFirst().get(), or equivalent.',
                                      'Use mutable collections only when test setup or production code mutates them.',
                                      'Do not use a null collection when the selected path streams, iterates, checks, '
                                      'indexes, or mutates it.',
                                      'Preserve element identity when an element selected from a collection is passed '
                                      'to later helpers or collaborator calls.']},
 'assertion_rule': {'instructions': ['Derive assertions only from observable behavior produced by the selected path.',
                                     'For a non-void method, assert the returned value according to its verified type '
                                     'and the selected return path.',
                                     'Do not require assertNotNull when the verified successful result may '
                                     'legitimately be null.',
                                     'For a void method, assert source-proven state changes or behaviorally important '
                                     'collaborator interactions.',
                                     'For returned objects, assert only fields assigned, mutated, or deterministically '
                                     'preserved on the selected path.',
                                     'For primitives, strings, enums, collections, arrays, Optional values, and '
                                     'entities, use type-appropriate JUnit assertions.',
                                     'Assert exact values only when they are deterministically derived from fixtures, '
                                     'constants, configuration, inputs, or collaborator returns.',
                                     'For nondeterministic but required values, assert only the source-proven '
                                     'constraint such as non-null, non-empty, positive, or collection size.',
                                     'Do not assert fields populated only by an unselected branch.',
                                     'Do not combine success assertions with handled-failure or propagated-exception '
                                     'assertions.',
                                     'Verify only interactions that demonstrate the selected behavior or distinguish '
                                     'the selected path.']},
 'strict_mockito_rule': {'instructions': ['Keep every stub inside the generated test method.',
                                          'Do not use lenient().',
                                          'Do not create stubs for calls not reached by the selected path.',
                                          'Do not stub or verify the class under test.',
                                          'Do not use doNothing for normal void calls.',
                                          'Do not use exact object equality for arguments constructed internally by '
                                          'production code unless the same instance is supplied by the test.',
                                          'Do not verify every collaborator call when the interaction is not '
                                          'behaviorally relevant.']},
 'compile_safety': {'instructions': ['Use only symbols explicitly supplied in the request.',
                                     'For fixture-supported application types, use only their supplied fixture '
                                     'methods.',
                                     'For non-fixture-supported types, use only supplied constructors, builders, '
                                     'factories, setters, getters, and enum constants.',
                                     'Use only supplied collaborator methods, constants, configuration fields, and '
                                     'fixture methods.',
                                     'Do not add imports.',
                                     'Do not define helper methods.',
                                     'Do not create or start a Spring test context.',
                                     'Do not directly invoke private methods.',
                                     'Do not use ReflectionTestUtils.invokeMethod.',
                                     'Use only JUnit Jupiter assertions and Mockito APIs available in the existing '
                                     'compiled test skeleton.',
                                     'Use only the supplied authorised static Mockito APIs and imports.',
                                     'If a compile-safe implementation requires an unresolved symbol or unsupported '
                                     'operation, do not generate that path.']},
 'output': {'instructions': ['Output exactly one complete Java @Test method.',
                             'Do not output markdown fences.',
                             'Do not output prose.',
                             'Do not output package or import declarations.',
                             'Do not output a class declaration.',
                             'Do not output fields, setup methods, or additional helper methods.']}}

_COMPILE_REPAIR_INSTRUCTIONS = {
    "objective": "Repair only the supplied registry-owned @Test method diagnostics.",
    "attempt_limit": 1,
    "identity_rules": [
        "Return exactly one corrected raw Java @Test method.",
        "Preserve the exact test name and registry test identity.",
        "Do not add, remove, rename, merge, duplicate, disable, or comment out tests.",
        "Do not modify sibling tests, fixtures, imports, setup, fields, or class structure.",
    ],
    "repair_rules": [
        "Fix only the supplied grouped compiler diagnostics.",
        "Use only the supplied relevant contracts, constants, configuration values, imports, and static APIs.",
        "Do not invent application symbols or behavior.",
        "Do not mix raw values and Mockito matchers in one invocation.",
        "Use primitive-compatible Mockito matchers where required.",
        "Do not use doNothing() for non-void methods or thenReturn() for void methods.",
        "Do not reference private production fields or production-only locals unavailable in test scope.",
    ],
    "output": "Exactly one raw Java @Test method; no Markdown, prose, imports, class declaration, fields, setup, or helpers.",
}


_RUNTIME_REPAIR_INSTRUCTIONS = {
    "objective": "Repair exactly one registry-owned failing JUnit 5 @Test method from the supplied runtime evidence.",
    "transaction_scope": [
        "Return the same test identity exactly once; do not add, remove, rename, merge, duplicate, disable, or comment out tests.",
        "Modify only the supplied failing test method. Sibling tests, fixtures, imports, setup, fields, and class structure are immutable.",
        "Use only the supplied focused production path and dynamically selected contracts.",
    ],
    "runtime_evidence": [
        "Repair the demonstrated root cause represented by the attached exception, assertion, Mockito diagnostic, expected/actual values, and bounded stack trace.",
        "Do not suppress failures with @Disabled, assumptions, empty catches, swallowed exceptions, or vacuous assertions.",
        "Do not weaken a meaningful assertion merely to obtain a passing result.",
    ],
    "transaction_acceptance": [
        "The candidate is accepted only after structural validation, semantic validation, one compilation, targeted execution, and complete retained-class execution all pass.",
        "A candidate compile failure is terminal for that attempt and must not request compile repair.",
        "A targeted or complete-class runtime failure is terminal for that attempt and must roll back.",
    ],
}



@dataclass(frozen=True, slots=True)
class ServiceImplPayloadStageDisabled:
    request_type: str
    reason: str
    disabled: bool = True


def _messages(payload: dict[str, Any]) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": _SYSTEM_MESSAGE},
        {"role": "user", "content": json.dumps(payload, indent=2, ensure_ascii=False)},
    ]


def _method_id(method) -> str:
    return f"{method.name}({','.join(type_name for type_name, _ in method.params)})"


def _method_context(ctx, method):
    method_id = _method_id(method)
    execution = getattr(ctx, "execution_context", None)
    return next((item for item in getattr(execution, "methods", ()) if item.method_id == method_id), None)


def _simple_name(type_name: str) -> str:
    text = (type_name or "Object").strip()
    if "<" in text:
        text = text.split("<", 1)[0]
    return text.rsplit(".", 1)[-1].replace("[]", "")


def _variable_name(type_name: str) -> str:
    simple = _simple_name(type_name)
    return simple[:1].lower() + simple[1:] if simple else "value"


def _fixture_payload(ctx, method_context) -> list[dict[str, Any]]:
    """Render only relevant, fully supported, skeleton-compiled fixture contracts."""
    execution = getattr(ctx, "execution_context", None)
    if execution is None or method_context is None:
        return []
    by_id = {fixture.fixture_id: fixture for fixture in execution.fixtures}
    result: list[dict[str, Any]] = []
    seen_methods: set[str] = set()
    required_ids = set(method_context.required_fixture_ids)
    selected_fixtures = [
        fixture for fixture in execution.fixtures
        if fixture.fixture_id in required_ids
        or (fixture.scenario_variant and fixture.baseline_fixture_id in required_ids)
    ]
    for fixture in selected_fixtures:
        if not fixture.exposed_to_generation:
            continue
        if fixture.method_name in seen_methods:
            continue
        seen_methods.add(fixture.method_name)
        result.append({
            "fixture_method_name": fixture.method_name,
            "application_type": fixture.return_type,
            "scenario_variant": fixture.scenario_variant,
            "normalized_state_signature": fixture.state_signature,
            "guaranteed_scalar_state": [
                {"path": path, "value": value}
                for path, value in fixture.guaranteed_scalar_state
            ],
            "guaranteed_nested_relationships": list(fixture.guaranteed_relationships),
            "required_collection_minimum_sizes": [
                {"path": path, "minimum_size": minimum_size}
                for path, minimum_size in fixture.minimum_collection_sizes
            ],
            "identity_guarantees": list(fixture.identity_guarantees),
            "support_status": fixture.support_status.value,
            "compiled_status": fixture.compile_status.value,
        })
    return result


def _contract_signature(contract) -> str | None:
    if contract.return_type is None:
        return None
    parameters = ", ".join(
        f"{type_name} {name}" if name else type_name
        for type_name, name in zip(
            contract.parameter_types,
            contract.parameter_names or ("",) * len(contract.parameter_types),
        )
    )
    return f"{contract.return_type} {contract.method_name}({parameters})"


def _aggregate_stubbing_requirement(requirements: list[str]) -> str:
    priority = ("unresolved", "required", "optional", "unnecessary", "forbidden")
    present = {value for value in requirements if value}
    return next((value for value in priority if value in present), "unresolved")


def _collaborator_payload(method_context) -> list[dict[str, Any]]:
    if method_context is None:
        return []
    grouped: dict[tuple[str, str], dict[str, Any]] = {}
    methods_by_key: dict[tuple[str, str, str | None, tuple[str, ...], str], dict[str, Any]] = {}
    for invocation in method_context.dependency_invocations:
        contract = invocation.contract
        receiver_key = (invocation.dependency_field, invocation.dependency_type)
        receiver = grouped.setdefault(receiver_key, {
            "field": invocation.dependency_field,
            "type": invocation.dependency_type,
            "methods": [],
        })
        key = (
            invocation.dependency_field,
            contract.method_name,
            contract.return_type,
            tuple(contract.parameter_types),
            contract.resolution_status.value,
        )
        method_payload = methods_by_key.get(key)
        if method_payload is None:
            method_payload = {
                "method_id": f"{contract.method_name}({','.join(contract.parameter_types)})",
                "method_name": contract.method_name,
                "signature": _contract_signature(contract),
                "return_type": contract.return_type,
                "parameter_types": list(contract.parameter_types),
                "resolution_status": contract.resolution_status.value,
                "declaring_type": contract.declaring_type,
                "inherited_spring_data": contract.inherited_spring_data,
                "repository_entity_type": contract.repository_entity_type,
                "repository_id_type": contract.repository_id_type,
                "repository_base_interface": contract.repository_base_interface,
                "diagnostics": list(contract.diagnostics),
                "return_value_consumed": False,
                "consumption_kind": [],
                "normal_stubbing": None,
                "invocations": [],
            }
            methods_by_key[key] = method_payload
            receiver["methods"].append(method_payload)
        requirement = invocation.normal_stubbing_requirement.value
        method_payload["invocations"].append({
            "invocation_id": invocation.invocation_id,
            "caller_method_id": invocation.caller_method_id,
            "invocation_expression": invocation.invocation_expression,
            "assigned_to": invocation.assigned_to,
            "return_value_consumed": invocation.return_value_consumed,
            "consumption_kind": invocation.consumption_kind.value,
            "resolution_status": invocation.return_flow_resolution_status.value,
            "normal_stubbing": requirement,
        })
        method_payload["return_value_consumed"] = bool(
            method_payload["return_value_consumed"] or invocation.return_value_consumed
        )
        kinds = method_payload["consumption_kind"]
        if invocation.consumption_kind.value not in kinds:
            kinds.append(invocation.consumption_kind.value)
        method_payload["normal_stubbing"] = _aggregate_stubbing_requirement(
            [method_payload["normal_stubbing"], requirement]
        )
    return list(grouped.values())



def _relevant_type_contracts(method_context) -> list[dict[str, Any]]:
    if method_context is None:
        return []
    required = set(getattr(method_context, "required_schema_ids", ()) or ())
    required.update(getattr(method_context, "input_payload_types", ()) or ())
    required.update(getattr(method_context, "output_payload_types", ()) or ())
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for schema in getattr(method_context, "payload_schemas", ()):
        schema_id = schema.fqcn or schema.type_name
        if required and schema_id not in required and schema.type_name not in required:
            continue
        if schema_id in seen:
            continue
        seen.add(schema_id)
        result.append({
            "application_type": schema_id,
            "construction_kind": schema.construction_kind.value,
            "getters": [
                {"property": prop.name, "method": prop.getter, "return_type": prop.resolved_type or prop.type_name}
                for prop in schema.properties if prop.getter
            ],
            "setters": [
                {"property": prop.name, "method": prop.setter, "parameter_type": prop.resolved_type or prop.type_name}
                for prop in schema.properties if prop.setter
            ],
            "enum_constants": list(schema.enum_constants),
            "collection_contracts": [
                {
                    "property": prop.name,
                    "family": prop.kind.value,
                    "element_type": prop.element_type,
                }
                for prop in schema.properties if prop.is_collection
            ],
        })
    return result


def _relevant_constants(ctx, method_context, source_text: str) -> list[dict[str, Any]]:
    execution = getattr(ctx, "execution_context", None)
    if execution is None:
        return []
    required_names = {item.field_name for item in getattr(method_context, "configuration_requirements", ())}
    result: list[dict[str, Any]] = []
    for config in getattr(execution, "configuration_fields", ()):
        if config.field_name not in required_names and not re.search(rf"\b{re.escape(config.field_name)}\b", source_text):
            continue
        result.append({
            "name": config.field_name,
            "type": config.type_name,
            "test_value": config.test_value,
            "property_key": config.property_key,
        })
    return result


def _focused_contract_warnings(type_contracts: list[dict[str, Any]]) -> list[str]:
    warnings: list[str] = []
    for contract in type_contracts:
        type_name = contract["application_type"]
        for setter in contract["setters"]:
            parameter = setter["parameter_type"]
            if parameter in {"char", "Character"}:
                warnings.append(f"{type_name}.{setter['method']}({parameter}): use a character literal such as 'P', not a String")
            elif parameter == "BigDecimal":
                warnings.append(f"{type_name}.{setter['method']}(BigDecimal): use BigDecimal.valueOf(...) or a supplied BigDecimal")
            elif parameter.startswith("Set<"):
                warnings.append(f"{type_name}.{setter['method']}({parameter}): use Set, not List")
            elif parameter.startswith("List<"):
                warnings.append(f"{type_name}.{setter['method']}({parameter}): use List, not Set")
    return warnings


def _authorised_generation_surface() -> dict[str, Any]:
    return {
        "junit_jupiter_assertions": [
            "assertEquals", "assertNotEquals", "assertTrue", "assertFalse", "assertNull",
            "assertNotNull", "assertSame", "assertNotSame", "assertThrows",
            "assertDoesNotThrow", "assertIterableEquals", "assertArrayEquals", "fail",
        ],
        "mockito_static_apis": [
            "when", "verify", "times", "never", "doThrow", "doAnswer", "doReturn",
            "any", "anyString", "anyChar", "anyInt", "anyLong", "anyBoolean",
            "anyDouble", "anyFloat", "anyShort", "anyByte", "eq", "same",
            "isNull", "notNull", "argThat", "nullable",
        ],
        "imports_may_be_added": False,
    }

def general_instructions_fingerprint() -> str:
    canonical = json.dumps(
        _GENERATION_INSTRUCTION,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def validate_general_instructions_preserved() -> None:
    actual = general_instructions_fingerprint()
    if actual != _PHASE1_GENERAL_INSTRUCTIONS_SHA256:
        raise RuntimeError(
            "ServiceImpl general_instructions changed outside the approved Phase 4 "
            f"dynamic payload sections: expected {_PHASE1_GENERAL_INSTRUCTIONS_SHA256}, got {actual}"
        )


def build_generation_payload(ctx, method=None, *_args, mode: str = "method", **_kwargs):
    if mode != "method" or method is None:
        raise ValueError("ServiceImpl generation requires one selected public entry method")
    validate_general_instructions_preserved()
    method_context = _method_context(ctx, method)
    if method_context is None:
        raise ValueError(f"ServiceImpl method context missing for {_method_id(method)}")
    closure = build_source_closure(ctx, method_context)
    target_source = closure.method_source or method_context.method_source
    helper_source = "\n".join(item.source for item in closure.reachable_methods)
    source_text = target_source + "\n" + helper_source
    type_contracts = _relevant_type_contracts(method_context)
    payload = {
        "request_type": "method_test_generation",
        "target_class": {
            "fqcn": ctx.symbol.fqcn,
            "test_instance": cut_variable_name(ctx.symbol.name),
        },
        "selected_scenario": {
            "scenario_id": f"{method_context.method_id}::normal_success",
            "test_kind": "normal_success",
            "requirements": ["one feasible, internally consistent source path"],
        },
        "target_method": {
            "method_id": method_context.method_id,
            "signature": method.render(),
            "source": target_source,
        },
        "reachable_same_class_methods": [
            {
                "method_id": item.method_id,
                "signature": item.signature,
                "visibility": item.visibility,
                "source": item.source,
            }
            for item in closure.reachable_methods
        ],
        "relevant_collaborator_contracts": _collaborator_payload(method_context),
        "relevant_fixture_contracts": _fixture_payload(ctx, method_context),
        "relevant_type_contracts": type_contracts,
        "relevant_constants": _relevant_constants(ctx, method_context, source_text),
        "authorised_imports_and_static_apis": _authorised_generation_surface(),
        "focused_warnings": _focused_contract_warnings(type_contracts),
        "general_instructions": deepcopy(_GENERATION_INSTRUCTION),
    }
    return _messages(payload)


def build_validation_repair_payload(
    ctx,
    method,
    invalid_test: str,
    test_name: str,
    diagnostics,
    *_args,
    **_kwargs,
):
    method_context = _method_context(ctx, method)
    if method_context is None:
        raise ValueError(f"ServiceImpl method context missing for {_method_id(method)}")
    rendered_diagnostics = []
    for diagnostic in diagnostics if isinstance(diagnostics, (list, tuple)) else [diagnostics]:
        if hasattr(diagnostic, "category"):
            rendered_diagnostics.append({
                "category": diagnostic.category,
                "message": diagnostic.message,
                "expression": diagnostic.expression,
                "authoritative_contract": diagnostic.authoritative_contract,
            })
        else:
            rendered_diagnostics.append({"message": str(diagnostic)})
    payload = {
        "request_type": "focused_method_generation_repair",
        "target_method": {
            "method_id": method_context.method_id,
            "signature": method.render(),
            "source": method_context.method_source,
        },
        "invalid_test": {"test_name": test_name, "source": invalid_test},
        "focused_diagnostics": rendered_diagnostics,
        "relevant_collaborator_contracts": _collaborator_payload(method_context),
        "relevant_fixture_contracts": _fixture_payload(ctx, method_context),
        "relevant_type_contracts": _relevant_type_contracts(method_context),
        "relevant_constants": _relevant_constants(ctx, method_context, method_context.method_source),
        "authorised_imports_and_static_apis": _authorised_generation_surface(),
        "repair_instructions": {
            "attempts": 1,
            "identity": "preserve the exact test name and return exactly one raw Java @Test method",
            "scope": "correct only supplied diagnostics using supplied contracts",
            "forbidden": ["complete test class", "Markdown", "invented Java symbols"],
        },
    }
    return _messages(payload)

def _source_line(source: str, line: int | None) -> str | None:
    if line is None or line < 1:
        return None
    lines = source.splitlines()
    return lines[line - 1].strip() if line <= len(lines) else None



def _diagnostic_payload(
    errors,
    source: str,
    *,
    source_start_line: int | None = None,
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for error in errors:
        line = getattr(error, "line", None)
        relative_line = (
            line - source_start_line + 1
            if isinstance(line, int) and isinstance(source_start_line, int)
            else line
        )
        result.append({
            "file": str(getattr(error, "file", "") or "") or None,
            "line": line,
            "column": getattr(error, "col", None),
            "message": getattr(error, "message", None) or str(error),
            "detail_lines": list(getattr(error, "detail", ()) or ()),
            "diagnostic_category": getattr(error, "diagnostic_category", "compiler_error"),
            "raw_compiler_text": getattr(error, "raw", "") or "",
            "test_source_line": relative_line,
            "source_line": _source_line(source, relative_line),
        })
    return result


def _referenced_text(source: str, diagnostics: list[dict[str, Any]]) -> str:
    return source + "\n" + "\n".join(
        " ".join(str(value or "") for value in (
            item.get("message"), item.get("source_line"), " ".join(item.get("detail_lines") or ())
        ))
        for item in diagnostics
    )


def _filter_fixtures_for_test(fixtures: list[dict[str, Any]], text: str) -> list[dict[str, Any]]:
    return [
        item for item in fixtures
        if re.search(rf"\b{re.escape(str(item.get('fixture_method_name') or ''))}\s*\(", text)
    ]


def _filter_collaborators_for_test(collaborators: list[dict[str, Any]], text: str) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for collaborator in collaborators:
        field = str(collaborator.get("field") or "")
        if field and re.search(rf"\b{re.escape(field)}\b", text):
            result.append(collaborator)
    return result


def _filter_types_for_test(contracts: list[dict[str, Any]], text: str) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for contract in contracts:
        application_type = str(contract.get("application_type") or "")
        simple = application_type.rsplit(".", 1)[-1]
        if simple and re.search(rf"\b{re.escape(simple)}\b", text):
            result.append(contract)
    return result


def _authorised_imports_for_test(ctx, text: str) -> list[str]:
    result: list[str] = []
    for item in getattr(ctx, "source_imports", ()) or ():
        rendered = str(item)
        simple = rendered.rstrip(";").rsplit(".", 1)[-1]
        if simple == "*" or (simple and re.search(rf"\b{re.escape(simple)}\b", text)):
            result.append(rendered)
    return result



def _relevant_application_constants(ctx, text: str) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for field in getattr(getattr(ctx, "symbol", None), "fields", ()) or ():
        modifiers = set(getattr(field, "modifiers", ()) or ())
        initializer = getattr(field, "initializer", None)
        name = str(getattr(field, "name", "") or "")
        if not name or not {"static", "final"}.issubset(modifiers) or initializer is None:
            continue
        if not re.search(rf"\b{re.escape(name)}\b", text):
            continue
        result.append({
            "name": name,
            "type": getattr(field, "type", None),
            "value_expression": initializer,
        })
    return result

def _focused_compile_general_instructions() -> dict[str, Any]:
    """Preserve Phase 4 instructions; replace only the conflicting test-kind label."""
    instructions = deepcopy(_GENERATION_INSTRUCTION)
    instructions["objective"]["requested_test_kind"] = "focused_compile_repair"
    return instructions


def build_compile_repair_payload(ctx, current_test=None, errors=None, *_args, **kwargs):
    mode = kwargs.get("mode", "individual")
    if mode not in {"individual", "focused"}:
        raise ValueError("ServiceImpl complete-class compile repair is disabled")
    method = kwargs.get("method")
    if method is None:
        raise ValueError("ServiceImpl focused compile repair requires the owner production method")
    test_name = kwargs.get("test_name")
    test_id = kwargs.get("test_id") or f"{_method_id(method)}::{test_name}"
    source = kwargs.get("current") or kwargs.get("source") or current_test or ""
    diagnostics = _diagnostic_payload(
        list(kwargs.get("compilation_errors") or errors or ()),
        source,
        source_start_line=kwargs.get("source_start_line"),
    )
    method_context = _method_context(ctx, method)
    if method_context is None:
        raise ValueError(f"ServiceImpl method context missing for {_method_id(method)}")
    referenced = _referenced_text(source, diagnostics)
    fixtures = _filter_fixtures_for_test(_fixture_payload(ctx, method_context), referenced)
    collaborators = _filter_collaborators_for_test(_collaborator_payload(method_context), referenced)
    types = _filter_types_for_test(_relevant_type_contracts(method_context), referenced)
    constants = _relevant_application_constants(ctx, referenced)
    configuration_values = [
        item for item in _relevant_constants(ctx, method_context, referenced)
        if re.search(rf"\b{re.escape(str(item.get('name') or ''))}\b", referenced)
    ]
    payload = {
        "request_type": "focused_compile_repair",
        "target_class": {
            "fqcn": ctx.symbol.fqcn,
            "test_class_name": ctx.test_class_name,
            "test_instance": cut_variable_name(ctx.symbol.name),
        },
        "owner_production_method_id": method_context.method_id,
        "test_id": test_id,
        "test_name": test_name,
        "current_test_source": source,
        "focused_diagnostics": diagnostics,
        "relevant_type_contracts": types,
        "relevant_collaborator_contracts": collaborators,
        "relevant_fixture_contracts": fixtures,
        "relevant_constants": constants,
        "relevant_configuration_values": configuration_values,
        "authorised_imports": _authorised_imports_for_test(ctx, referenced),
        "authorised_static_apis": _authorised_generation_surface(),
        "general_instructions": _focused_compile_general_instructions(),
        "approved_compile_repair_additions": deepcopy(_COMPILE_REPAIR_INSTRUCTIONS),
    }
    return _messages(payload)



def _extract_braced_member(source: str, name: str) -> str | None:
    match = re.search(rf"\b{re.escape(name)}\s*\(", source)
    if not match:
        return None
    start = source.rfind("\n", 0, match.start()) + 1
    annotation_start = source.rfind("\n@", 0, start)
    if annotation_start >= 0 and source[annotation_start + 1 : start].strip().startswith("@"): 
        start = annotation_start + 1
    brace = source.find("{", match.end())
    if brace < 0:
        return None
    depth = 0
    in_string = False
    quote = ""
    escape = False
    for index in range(brace, len(source)):
        char = source[index]
        if in_string:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == quote:
                in_string = False
            continue
        if char in {"\"", "'"}:
            in_string = True
            quote = char
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return source[start : index + 1].strip()
    return None


def _required_shared_context(ctx, test_class_source: str, failing_tests: list[dict[str, Any]]) -> dict[str, list[str]]:
    combined = "\n".join(str(test.get("source", "")) for test in failing_tests)
    required_mock_fields: list[str] = []
    execution = getattr(ctx, "execution_context", None)
    for dependency in getattr(execution, "dependencies", ()) or ():
        field_name = getattr(dependency, "field_name", None)
        if not field_name or not re.search(rf"\b{re.escape(field_name)}\b", combined):
            continue
        line_match = re.search(
            rf"(?m)(?:^\s*@Mock\s*\n)?^\s*(?:private|protected|public)?\s*"
            rf"[^;\n]+\b{re.escape(field_name)}\s*;",
            test_class_source,
        )
        if line_match:
            required_mock_fields.append(line_match.group(0).strip())

    required_fixture_helpers: list[str] = []
    for fixture in getattr(execution, "fixtures", ()) or ():
        if not getattr(fixture, "supported", False):
            continue
        if not re.search(rf"\b{re.escape(fixture.method_name)}\s*\(", combined):
            continue
        source = _extract_braced_member(test_class_source, fixture.method_name)
        if source:
            required_fixture_helpers.append(source)

    required_setup_fragments: list[str] = []
    if cut_variable_name(ctx.symbol.name) in combined:
        setup = _extract_braced_member(test_class_source, "setUp")
        if setup is None:
            before_each = re.search(r"@BeforeEach", test_class_source)
            if before_each:
                method_match = re.search(r"\b([A-Za-z_$][\w$]*)\s*\(", test_class_source[before_each.end():])
                if method_match:
                    setup = _extract_braced_member(test_class_source, method_match.group(1))
        if setup:
            required_setup_fragments.append(setup)

    return {
        "required_mock_fields": required_mock_fields,
        "required_setup_fragments": required_setup_fragments,
        "required_fixture_helpers": required_fixture_helpers,
    }


def _focused_runtime_general_instructions() -> dict[str, Any]:
    """Preserve the baseline and replace only the directly conflicting test-kind clause."""
    validate_general_instructions_preserved()
    instructions = deepcopy(_GENERATION_INSTRUCTION)
    instructions["objective"]["requested_test_kind"] = "focused_runtime_repair"
    return instructions


def _assertion_lines(source: str) -> list[str]:
    return [
        line.strip()
        for line in source.splitlines()
        if re.search(r"\b(?:assertEquals|assertNotEquals|assertTrue|assertFalse|assertNull|assertNotNull|assertSame|assertNotSame|assertThrows|assertDoesNotThrow|assertIterableEquals|assertArrayEquals|fail)\s*\(", line)
    ]


def build_runtime_repair_payload(
    ctx,
    method=None,
    *_args,
    failing_tests=None,
    shared_test_context=None,
    test_class_source: str = "",
    **_kwargs,
):
    """Build one bounded, registry-owned runtime repair payload."""
    if method is None:
        raise ValueError("ServiceImpl runtime repair requires the owning production method")
    failing_tests = list(failing_tests or ())
    if len(failing_tests) != 1:
        raise ValueError("ServiceImpl runtime repair requires exactly one failing registry test")
    failing = dict(failing_tests[0])
    test_name = str(failing.get("test_name") or "")
    test_id = str(failing.get("test_id") or f"{_method_id(method)}::{test_name}")
    if not test_name:
        raise ValueError("ServiceImpl runtime repair requires a stable test name")

    method_context = _method_context(ctx, method)
    if method_context is None:
        raise ValueError(f"ServiceImpl method context missing for {_method_id(method)}")
    closure = build_source_closure(ctx, method_context)
    target_source = closure.method_source or method_context.method_source
    helper_sources = [
        {
            "method_id": item.method_id,
            "signature": item.signature,
            "visibility": item.visibility,
            "source": item.source,
        }
        for item in closure.reachable_methods
    ]
    diagnostics = list(failing.get("diagnostics") or ())
    focused_text = "\n".join(
        [str(failing.get("source") or ""), target_source]
        + [item["source"] for item in helper_sources]
        + [json.dumps(item, sort_keys=True, default=str) for item in diagnostics]
    )
    fixtures = _filter_fixtures_for_test(_fixture_payload(ctx, method_context), focused_text)
    collaborators = _collaborator_payload(method_context)
    types = _filter_types_for_test(_relevant_type_contracts(method_context), focused_text)
    constants = _relevant_application_constants(ctx, focused_text)
    configuration_values = _relevant_constants(ctx, method_context, focused_text)

    payload = {
        "request_type": "focused_runtime_repair",
        "target_class": {
            "fqcn": ctx.symbol.fqcn,
            "test_class_name": ctx.test_class_name,
            "test_instance": cut_variable_name(ctx.symbol.name),
        },
        "failing_registry_test": {
            "test_id": test_id,
            "owner_method_id": _method_id(method),
            "test_name": test_name,
            "source": failing.get("source") or "",
            "runtime_status": failing.get("runtime_status"),
            "focused_diagnostics": diagnostics,
        },
        "relevant_production_path": {
            "target_method": {
                "method_id": method_context.method_id,
                "signature": method.render(),
                "source": target_source,
            },
            "reachable_same_class_methods": helper_sources,
        },
        "relevant_collaborator_contracts": collaborators,
        "relevant_fixture_contracts": fixtures,
        "relevant_type_contracts": types,
        "relevant_constants": constants,
        "relevant_configuration_values": configuration_values,
        "relevant_assertions": _assertion_lines(str(failing.get("source") or "")),
        "expected_source_proven_behavior": [
            {
                "category": item.get("category"),
                "expected": item.get("expected"),
                "actual": item.get("actual"),
                "exception": item.get("exception"),
                "message": item.get("message"),
            }
            for item in diagnostics
            if isinstance(item, dict)
        ],
        "authorised_imports": _authorised_imports_for_test(ctx, focused_text),
        "authorised_static_apis": _authorised_generation_surface(),
        "general_instructions": _focused_runtime_general_instructions(),
        "approved_runtime_repair_additions": deepcopy(_RUNTIME_REPAIR_INSTRUCTIONS),
    }
    return _messages(payload)


def build_coverage_augmentation_payload(*_args, **_kwargs):
    return ServiceImplPayloadStageDisabled(
        request_type="coverage_augmentation",
        reason="ServiceImpl coverage augmentation is disabled",
    )


def build_coverage_repair_payload(*_args, **_kwargs):
    return ServiceImplPayloadStageDisabled(
        request_type="coverage_repair",
        reason="ServiceImpl coverage repair is disabled",
    )


__all__ = [
    "ServiceImplPayloadStageDisabled",
    "build_generation_payload",
    "build_validation_repair_payload",
    "build_compile_repair_payload",
    "build_runtime_repair_payload",
    "build_coverage_augmentation_payload",
    "build_coverage_repair_payload",
]
