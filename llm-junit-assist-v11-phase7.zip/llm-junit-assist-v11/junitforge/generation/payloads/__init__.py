"""Target-type payload dispatcher."""

from __future__ import annotations

from . import controller, dto_entity, other, serviceimpl
from .common import target_kind_value


def payload_builder_for(target_kind: str):
    normalized = str(target_kind or "").strip().lower().replace("_", "-")
    if normalized in {"service-impl", "serviceimpl"}:
        return serviceimpl
    if normalized == "controller":
        return controller
    if normalized in {"dto", "entity", "dto-entity"}:
        return dto_entity
    return other


def payload_builder_for_context(ctx):
    return payload_builder_for(target_kind_value(ctx))


__all__ = ["payload_builder_for", "payload_builder_for_context"]
