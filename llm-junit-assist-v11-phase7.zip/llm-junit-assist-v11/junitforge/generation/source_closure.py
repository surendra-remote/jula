"""Verified same-class source-closure collection.

v7.3.3 already computes the transitive reachable-private-method identities in
its execution context. This module owns conversion of those verified identities
into exact source records without changing method eligibility or call-graph
semantics.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True, slots=True)
class SourceMethod:
    method_id: str
    signature: str
    visibility: str
    source: str


@dataclass(frozen=True, slots=True)
class SourceClosure:
    method_id: str
    method_source: str
    reachable_method_ids: tuple[str, ...]
    reachable_methods: tuple[SourceMethod, ...] = ()
    unresolved_method_ids: tuple[str, ...] = ()
    complete: bool = True


def normalized_method_id(method) -> str:
    return f"{method.name}({','.join(type_name for type_name, _ in method.params)})"


def collect_method_source(cut_source: str, method) -> str:
    """Return the exact source range already verified by the Java parser."""
    if method is None or getattr(method, "line", None) is None:
        return ""
    lines = cut_source.splitlines()
    start = max(1, int(method.line))
    end = max(start, int(getattr(method, "end_line", None) or start))
    if start > len(lines):
        return ""
    return "\n".join(lines[start - 1 : min(end, len(lines))])


def resolve_same_class_call(symbol, method_id: str):
    """Resolve one verified normalized method identity to the parsed method symbol."""
    for method in getattr(symbol, "methods", ()) or ():
        if normalized_method_id(method) == method_id:
            return method
    return None


def _visibility(method) -> str:
    modifiers = set(getattr(method, "modifiers", ()) or ())
    for value in ("public", "protected", "private"):
        if value in modifiers:
            return value
    return "package"


def walk_reachable_methods(ctx, method_ids: Iterable[str]) -> tuple[tuple[SourceMethod, ...], tuple[str, ...]]:
    """Collect exact sources for the already-computed transitive helper identities."""
    resolved: list[SourceMethod] = []
    unresolved: list[str] = []
    seen: set[str] = set()
    for method_id in method_ids:
        method_id = str(method_id)
        if not method_id or method_id in seen:
            continue
        seen.add(method_id)
        method = resolve_same_class_call(ctx.symbol, method_id)
        if method is None:
            unresolved.append(method_id)
            continue
        source = collect_method_source(ctx.cut_source, method)
        if not source:
            unresolved.append(method_id)
            continue
        resolved.append(
            SourceMethod(
                method_id=method_id,
                signature=method.render(),
                visibility=_visibility(method),
                source=source,
            )
        )
    return tuple(resolved), tuple(unresolved)


def validate_source_closure(closure: SourceClosure) -> tuple[bool, tuple[str, ...]]:
    diagnostics: list[str] = []
    if not closure.method_id:
        diagnostics.append("target method identity missing")
    if not closure.method_source.strip():
        diagnostics.append("target method source missing")
    diagnostics.extend(f"unresolved same-class helper: {item}" for item in closure.unresolved_method_ids)
    return not diagnostics, tuple(diagnostics)


def build_source_closure(ctx_or_method_context, method_context=None) -> SourceClosure:
    """Build a source closure from existing v7.3.3 execution facts.

    The one-argument form remains a lightweight compatibility adapter. The
    two-argument form accepts GenerationContext plus MethodExecutionContext and
    resolves exact helper source from parsed method ranges.
    """
    if method_context is None:
        method_context = ctx_or_method_context
        reachable = tuple(getattr(method_context, "reachable_private_methods", ()) or ())
        diagnostics = tuple(getattr(method_context, "diagnostics", ()) or ())
        return SourceClosure(
            method_id=str(getattr(method_context, "method_id", "")),
            method_source=str(getattr(method_context, "method_source", "")),
            reachable_method_ids=tuple(str(item) for item in reachable),
            unresolved_method_ids=(),
            complete=not diagnostics,
        )

    ctx = ctx_or_method_context
    reachable_ids = tuple(
        str(item) for item in (getattr(method_context, "reachable_private_methods", ()) or ())
    )
    reachable_methods, unresolved = walk_reachable_methods(ctx, reachable_ids)
    closure = SourceClosure(
        method_id=str(getattr(method_context, "method_id", "")),
        method_source=str(getattr(method_context, "method_source", "")),
        reachable_method_ids=reachable_ids,
        reachable_methods=reachable_methods,
        unresolved_method_ids=unresolved,
        complete=not unresolved and not tuple(getattr(method_context, "diagnostics", ()) or ()),
    )
    valid, _ = validate_source_closure(closure)
    if valid == closure.complete:
        return closure
    return SourceClosure(
        method_id=closure.method_id,
        method_source=closure.method_source,
        reachable_method_ids=closure.reachable_method_ids,
        reachable_methods=closure.reachable_methods,
        unresolved_method_ids=closure.unresolved_method_ids,
        complete=valid,
    )
