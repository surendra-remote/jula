"""Scenario-specific compiled fixture variants for ServiceImpl generation.

Variants extend the authoritative Phase 3 fixture catalogue.  They are staged,
validated, and compiled individually before publication into the execution
context.  A failed variant therefore affects only its owning candidate test.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
import hashlib
import re
import threading
from typing import Callable

from junitforge.execution.models import (
    FixtureCompileStatus,
    FixtureSpec,
    FixtureSupportStatus,
)
from junitforge.generation.semantic_validation import (
    ContractIndex,
    _compatible,
    _infer_expression_type,
    _simple,
)


_VARIANT_LOCK = threading.RLock()


@dataclass(slots=True, frozen=True)
class FixtureMutation:
    variable: str
    setter: str
    argument: str
    property_name: str
    authoritative_type: str


@dataclass(slots=True, frozen=True)
class FixtureVariantPlan:
    application_type: str
    variable: str
    baseline_method: str
    method_name: str
    normalized_state_signature: str
    mutations: tuple[FixtureMutation, ...]
    helper_source: str
    rewritten_test_source: str


@dataclass(slots=True, frozen=True)
class FixtureAugmentationResult:
    source: str
    variant: FixtureSpec | None = None
    actions: tuple[dict[str, object], ...] = ()
    attempted: bool = False
    accepted: bool = False
    reason: str = ""


def _state_signature(application_type: str, mutations: tuple[FixtureMutation, ...]) -> str:
    state = [
        f"{mutation.property_name}={re.sub(r'\\s+', '', mutation.argument)}:{mutation.authoritative_type}"
        for mutation in sorted(mutations, key=lambda item: (item.property_name, item.argument))
    ]
    return application_type + "|" + "|".join(state)


def _variant_name(application_type: str, signature: str) -> str:
    digest = hashlib.sha256(signature.encode("utf-8")).hexdigest()[:10]
    return f"valid{_simple(application_type)}Variant{digest}"


def _fixture_declarations(source: str, index: ContractIndex):
    pattern = re.compile(
        r"\b([A-Za-z_$][\w$]*(?:\s*<[^;=]+?>)?)\s+([A-Za-z_$][\w$]*)\s*=\s*"
        r"([A-Za-z_$][\w$]*)\s*\(\s*\)\s*;"
    )
    for match in pattern.finditer(source):
        fixture = index.fixtures_by_method.get(match.group(3))
        if fixture is not None:
            yield match, fixture


def _replace_scope_reference(argument: str, source: str, index: ContractIndex) -> tuple[str | None, str | None]:
    """Replace only references whose fixture source is verified in the test."""
    value = argument.strip()
    masked = re.sub(r"\"(?:[^\"\\]|\\.)*\"|\'(?:[^\'\\]|\\.)*\'", " ", value)
    identifiers = set(re.findall(r"\b([A-Za-z_$][\w$]*)\b", masked))
    keywords = {
        "true", "false", "null", "new", "List", "Set", "Map", "Optional",
        "BigDecimal", "valueOf", "of", "empty", "emptyList", "emptySet",
    }
    for identifier in sorted(identifiers):
        if identifier in keywords:
            continue
        if identifier in index.configuration_values:
            value = re.sub(
                rf"(?<![.\w$]){re.escape(identifier)}(?![\w$])",
                index.configuration_values[identifier],
                value,
            )
            continue
        if re.fullmatch(r"[A-Z][A-Z0-9_]*", identifier):
            constant_match = re.search(
                rf"\b(?:public|protected|private)?\s*static\s+final\s+[A-Za-z_$][\w$<>.?]*\s+{re.escape(identifier)}\s*=\s*([^;]+);",
                index.cut_source,
            )
            if constant_match:
                value = re.sub(
                    rf"(?<![.\w$]){re.escape(identifier)}(?![\w$])",
                    constant_match.group(1).strip(),
                    value,
                )
                continue
        declaration = re.search(
            rf"\b[A-Za-z_$][\w$]*(?:\s*<[^;=]+?>)?\s+{re.escape(identifier)}\s*=\s*"
            rf"([A-Za-z_$][\w$]*)\s*\(\s*\)\s*;",
            source,
        )
        if declaration and declaration.group(1) in index.fixtures_by_method:
            value = re.sub(rf"(?<![.\w$]){re.escape(identifier)}(?![\w$])", declaration.group(1) + "()", value)
            continue
        # Method names, enum type names, and enum constants are allowed only if known.
        if identifier in index.schemas or any(identifier == _simple(name) for name in index.schemas):
            continue
        if any(identifier in schema.enum_constants for schema in index.schemas.values()):
            continue
        if re.search(rf"\b{re.escape(identifier)}\s*\(", value):
            if identifier in index.fixtures_by_method or identifier in {
                "of", "valueOf", "empty", "emptyList", "emptySet", "ofNullable"
            }:
                continue
            return None, f"method {identifier} is not verified in fixture-helper scope"
        return None, f"identifier {identifier} is not valid in fixture-helper scope"
    return value, None


def _extract_plan(ctx, source: str) -> tuple[FixtureVariantPlan | None, str]:
    index = ContractIndex.from_context(ctx)
    # Source is useful for validating constants in helper scope.
    index.cut_source = getattr(ctx, "cut_source", "")
    declarations = list(_fixture_declarations(source, index))
    for declaration, fixture in declarations:
        variable = declaration.group(2)
        schema = index.schema(fixture.return_type)
        if schema is None:
            continue
        mutations: list[FixtureMutation] = []
        spans: list[tuple[int, int]] = []
        fixture_variable_types = {
            match.group(2): candidate.return_type
            for match, candidate in declarations
        }
        state_by_property: dict[str, str] = {}
        pattern = re.compile(
            rf"(?m)^\s*{re.escape(variable)}\s*\.\s*(set[A-Z][A-Za-z0-9_$]*)\s*\((.*?)\)\s*;\s*$",
            re.DOTALL,
        )
        for match in pattern.finditer(source):
            setter = match.group(1)
            prop = next((item for item in schema.properties if item.setter == setter), None)
            if prop is None:
                return None, f"unresolved setter {schema.type_name}.{setter}"
            argument, error = _replace_scope_reference(match.group(2), source, index)
            if error:
                return None, error
            normalized_argument = argument or match.group(2).strip()
            prior = state_by_property.get(prop.name)
            if prior is not None and re.sub(r"\s+", "", prior) != re.sub(r"\s+", "", normalized_argument):
                return None, f"contradictory fixture state for {schema.type_name}.{prop.name}"
            state_by_property[prop.name] = normalized_argument
            actual_type = _infer_expression_type(normalized_argument, fixture_variable_types, index)
            compatible, _category = _compatible(prop.resolved_type or prop.type_name, actual_type)
            if not compatible:
                return None, (
                    f"fixture helper type mismatch for {schema.type_name}.{setter}: "
                    f"expected {prop.resolved_type or prop.type_name}, actual {actual_type}"
                )
            enum_schema = index.schema(prop.resolved_type or prop.type_name)
            enum_match = re.fullmatch(r"([A-Za-z_$][\w$]*)\.([A-Z][A-Z0-9_]*)", normalized_argument)
            if (
                enum_schema is not None
                and enum_schema.kind == "enum"
                and enum_match is not None
                and enum_match.group(2) not in enum_schema.enum_constants
            ):
                return None, f"unknown enum constant {normalized_argument}"
            mutations.append(FixtureMutation(
                variable=variable,
                setter=setter,
                argument=normalized_argument,
                property_name=prop.name,
                authoritative_type=prop.resolved_type or prop.type_name,
            ))
            spans.append((match.start(), match.end()))
        if not mutations:
            continue
        signature = _state_signature(fixture.return_type, tuple(mutations))
        method_name = _variant_name(fixture.return_type, signature)
        helper_variable = variable
        lines = [
            f"    private {fixture.return_type} {method_name}() {{",
            f"        {fixture.return_type} {helper_variable} = {fixture.method_name}();",
        ]
        for mutation in mutations:
            lines.append(f"        {helper_variable}.{mutation.setter}({mutation.argument});")
        lines.extend([f"        return {helper_variable};", "    }"])
        rewritten = source
        for start, end in reversed(spans):
            rewritten = rewritten[:start] + rewritten[end:]
        rewritten = (
            rewritten[:declaration.start(3)]
            + method_name
            + rewritten[declaration.end(3):]
        )
        return FixtureVariantPlan(
            application_type=fixture.return_type,
            variable=variable,
            baseline_method=fixture.method_name,
            method_name=method_name,
            normalized_state_signature=signature,
            mutations=tuple(mutations),
            helper_source="\n".join(lines),
            rewritten_test_source=rewritten,
        ), ""
    return None, "no fixture-supported mutation sequence found"


def _existing_variant(ctx, plan: FixtureVariantPlan) -> FixtureSpec | None:
    execution = getattr(ctx, "execution_context", None)
    if execution is None:
        return None
    for fixture in execution.fixtures:
        if getattr(fixture, "state_signature", "") == plan.normalized_state_signature:
            return fixture
    return None


def _publish_variant(ctx, variant: FixtureSpec) -> None:
    execution = getattr(ctx, "execution_context", None)
    if execution is None:
        return
    ctx.execution_context = replace(execution, fixtures=execution.fixtures + (variant,))


def augment_fixture_variant(
    ctx,
    source: str,
    *,
    compile_variant: Callable[[str, str], tuple[bool, tuple[str, ...]]] | None = None,
) -> FixtureAugmentationResult:
    """Perform one bounded fixture-augmentation attempt for one invalid test."""
    with _VARIANT_LOCK:
        plan, reason = _extract_plan(ctx, source)
        if plan is None:
            return FixtureAugmentationResult(source, attempted=False, reason=reason)
        existing = _existing_variant(ctx, plan)
        if existing is not None:
            rewritten = plan.rewritten_test_source.replace(plan.method_name, existing.method_name)
            return FixtureAugmentationResult(
                rewritten,
                variant=existing,
                attempted=True,
                accepted=True,
                actions=({
                    "diagnostic_category": "fixture_variant_reuse",
                    "source_before": source,
                    "source_after": rewritten,
                    "authoritative_contract": plan.normalized_state_signature,
                    "result": "reused",
                },),
            )

        if compile_variant is None:
            return FixtureAugmentationResult(source, attempted=True, reason="transactional fixture compiler unavailable")
        ok, diagnostics = compile_variant(plan.method_name, plan.helper_source)
        if not ok:
            return FixtureAugmentationResult(
                source,
                attempted=True,
                reason="fixture variant compilation failed: " + " | ".join(diagnostics[:4]),
            )
        baseline = next(
            fixture for fixture in ctx.execution_context.fixtures
            if fixture.method_name == plan.baseline_method
        )
        variant = replace(
            baseline,
            fixture_id=f"{baseline.fixture_id}::variant::{hashlib.sha256(plan.normalized_state_signature.encode()).hexdigest()[:12]}",
            method_name=plan.method_name,
            baseline_fixture_id=baseline.fixture_id,
            state_signature=plan.normalized_state_signature,
            scenario_variant=True,
            guaranteed_scalar_state=tuple(
                (mutation.property_name, mutation.argument) for mutation in plan.mutations
            ),
            method_source=plan.helper_source,
            compile_status=FixtureCompileStatus.COMPILED,
            support_status=FixtureSupportStatus.SUPPORTED,
            semantic_valid=True,
            supported=True,
            diagnostics=(),
        )
        _publish_variant(ctx, variant)
        return FixtureAugmentationResult(
            plan.rewritten_test_source,
            variant=variant,
            attempted=True,
            accepted=True,
            actions=({
                "diagnostic_category": "fixture_variant_augmentation",
                "source_before": source,
                "source_after": plan.rewritten_test_source,
                "authoritative_contract": plan.normalized_state_signature,
                "result": "compiled_and_published",
            },),
        )


def insert_fixture_helper(test_class_source: str, helper_source: str) -> str:
    closing = test_class_source.rfind("}")
    if closing < 0:
        raise ValueError("test class closing brace not found")
    return test_class_source[:closing].rstrip() + "\n\n" + helper_source.rstrip() + "\n" + test_class_source[closing:]


__all__ = [
    "FixtureAugmentationResult",
    "FixtureMutation",
    "FixtureVariantPlan",
    "augment_fixture_variant",
    "insert_fixture_helper",
]
