"""Deterministic skeleton construction and preflight compilation."""

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from time import perf_counter

from junitforge.execution.assembly import build_test_skeleton
from junitforge.execution.models import FixtureCompileStatus
from junitforge.timing import event as timing_event


@dataclass(slots=True)
class SkeletonResult:
    source: str
    compiled: bool | None = None
    diagnostics: tuple[str, ...] = ()
    compile_result: object | None = None




def update_fixture_compile_status(ctx, compiled: bool) -> None:
    """Publish skeleton compilation state back into the authoritative catalogue."""
    execution = getattr(ctx, "execution_context", None)
    if execution is None:
        return
    status = FixtureCompileStatus.COMPILED if compiled else FixtureCompileStatus.FAILED
    fixtures = tuple(
        replace(fixture, compile_status=status)
        if fixture.supported and fixture.semantic_valid
        else fixture
        for fixture in execution.fixtures
    )
    ctx.execution_context = replace(execution, fixtures=fixtures)

def generate_skeleton(ctx) -> SkeletonResult:
    return SkeletonResult(source=build_test_skeleton(ctx))


def validate_skeleton_compile(compile_gate, test_path: Path, module) -> SkeletonResult:
    result, errors = compile_gate.check(test_path, module)
    return SkeletonResult(
        source=test_path.read_text(encoding="utf-8"),
        compiled=bool(result.ok),
        diagnostics=tuple(error.render() for error in errors),
        compile_result=result,
    )


def generate_and_validate_skeleton(
    ctx,
    *,
    compile_gate,
    module=None,
    test_path: Path | None = None,
    outcome=None,
) -> SkeletonResult:
    """Build the shared test skeleton and compile it before method LLM calls."""
    result = generate_skeleton(ctx)
    if module is None or test_path is None:
        return result

    test_path.parent.mkdir(parents=True, exist_ok=True)
    test_path.write_text(result.source, encoding="utf-8")
    preflight_started = perf_counter()
    compiled = validate_skeleton_compile(compile_gate, test_path, module)
    timing_event(
        "fixture_skeleton.compile.end",
        elapsed=perf_counter() - preflight_started,
        success=compiled.compiled,
        errors=len(compiled.diagnostics),
    )
    update_fixture_compile_status(ctx, bool(compiled.compiled))
    if not compiled.compiled and outcome is not None:
        outcome.compile_errors = list(compiled.diagnostics[:12])
        outcome.notes.append(
            "fixture skeleton compile failed before method generation: "
            + " | ".join(outcome.compile_errors[:4])
        )
    elif compiled.compiled and outcome is not None:
        outcome.notes.append("fixture skeleton compiled before method generation")
    return compiled
