"""Authoritative generation-time semantic validation for ServiceImpl @Test methods.

The validator is intentionally bounded.  It validates only contracts already
present in the execution context, payload schemas, fixture catalogue, CUT
symbol, and collaborator invocation facts.  It never infers missing Java APIs.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
import re
from typing import Iterable

from junitforge.execution.assembly import (
    normalize_primitive_matchers,
    normalize_simple_assertj_assertions,
)
from junitforge.execution.models import (
    FixtureSpec,
    PayloadProperty,
    PayloadSchema,
    PropertyKind,
)


class SemanticCategory(str, Enum):
    VOID_THEN_RETURN = "resolved_void_then_return"
    NON_VOID_AS_VOID = "resolved_non_void_treated_as_void"
    UNRESOLVED_AS_VOID = "unresolved_method_treated_as_void"
    WRONG_GETTER = "wrong_getter"
    UNKNOWN_METHOD = "unknown_method"
    UNKNOWN_MEMBER = "unknown_member"
    UNKNOWN_SETTER = "unknown_setter"
    UNKNOWN_GETTER = "unknown_getter"
    UNKNOWN_FIELD = "unknown_field"
    UNKNOWN_ENUM_CONSTANT = "unknown_enum_constant"
    INVENTED_APPLICATION_TYPE = "invented_application_type"
    WRONG_NESTED_TYPE = "wrong_nested_application_type"
    COLLECTION_FAMILY = "collection_family_mismatch"
    COLLECTION_ELEMENT = "generic_collection_element_mismatch"
    SCALAR_TYPE = "scalar_type_mismatch"
    UNRESOLVED_COLLABORATOR = "unresolved_collaborator_contract"
    MATCHER_CONSISTENCY = "mockito_matcher_consistency"
    UNAUTHORISED_MOCKITO = "unauthorised_mockito_api"
    PRODUCTION_IDENTIFIER = "production_only_identifier"
    PRIVATE_CUT_IDENTIFIER = "private_cut_identifier"
    FIXTURE_CONSTRUCTION = "fixture_supported_construction"
    FIXTURE_MUTATION = "fixture_supported_mutation"
    FIXTURE_DATA_MOCK = "fixture_supported_data_mock"
    ASSERTION_FRAMEWORK = "unauthorised_assertion_framework"
    ASSERTION_API = "unauthorised_junit_assertion"
    HELPER_SCOPE = "fixture_helper_scope"


@dataclass(slots=True, frozen=True)
class SemanticDiagnostic:
    category: str
    message: str
    expression: str | None = None
    authoritative_contract: str | None = None
    line: int | None = None
    correctable: bool = False

    def render(self) -> str:
        prefix = f"{self.category}: {self.message}"
        if self.authoritative_contract:
            prefix += f" [contract: {self.authoritative_contract}]"
        return prefix


@dataclass(slots=True, frozen=True)
class SemanticValidationResult:
    ok: bool
    diagnostics: tuple[SemanticDiagnostic, ...] = ()
    test_names: tuple[str, ...] = ()

    @property
    def reason(self) -> str:
        return self.diagnostics[0].render() if self.diagnostics else ""


@dataclass(slots=True, frozen=True)
class DeterministicChange:
    sequence: int
    timestamp: str
    diagnostic_category: str
    source_before: str
    source_after: str
    authoritative_contract: str
    result: str = "applied"


@dataclass(slots=True, frozen=True)
class SemanticCorrectionResult:
    source: str
    actions: tuple[dict[str, object], ...] = ()


_STANDARD_TYPES = {
    "String", "BigDecimal", "Date", "LocalDate", "LocalDateTime", "Instant",
    "List", "Set", "Map", "Collection", "Optional", "ArrayList", "HashSet",
    "HashMap", "LinkedHashMap", "LinkedHashSet", "Object", "Class", "UUID",
    "Integer", "Long", "Short", "Byte", "Double", "Float", "Boolean", "Character",
    "int", "long", "short", "byte", "double", "float", "boolean", "char", "void",
}
_ALLOWED_ASSERTIONS = {
    "assertEquals", "assertNotEquals", "assertTrue", "assertFalse", "assertNull",
    "assertNotNull", "assertSame", "assertNotSame", "assertThrows",
    "assertDoesNotThrow", "assertIterableEquals", "assertArrayEquals", "fail",
}
_ALLOWED_MOCKITO = {
    "when", "verify", "times", "never", "atLeast", "atLeastOnce", "atMost",
    "atMostOnce", "only", "doThrow", "doAnswer", "doReturn", "doCallRealMethod",
    "any", "anyString", "anyChar", "anyInt", "anyLong", "anyBoolean", "anyDouble",
    "anyFloat", "anyShort", "anyByte", "eq", "same", "isNull", "notNull",
    "argThat", "contains", "startsWith", "endsWith", "nullable", "mock", "spy",
}
_MATCHER_NAMES = {
    name for name in _ALLOWED_MOCKITO
    if name.startswith("any") or name in {"eq", "same", "isNull", "notNull", "argThat", "nullable"}
}


def _simple(type_name: str | None) -> str:
    text = (type_name or "").strip()
    text = re.sub(r"\?\s*(?:extends|super)\s+", "", text)
    text = text.replace("[]", "")
    if "<" in text:
        text = text.split("<", 1)[0]
    return text.rsplit(".", 1)[-1].strip()


def _generic_arguments(type_name: str | None) -> tuple[str, ...]:
    text = (type_name or "").strip()
    if "<" not in text or ">" not in text:
        return ()
    inner = text[text.find("<") + 1:text.rfind(">")]
    result: list[str] = []
    depth = 0
    start = 0
    for index, char in enumerate(inner):
        if char == "<": depth += 1
        elif char == ">": depth -= 1
        elif char == "," and depth == 0:
            result.append(inner[start:index].strip())
            start = index + 1
    result.append(inner[start:].strip())
    return tuple(value for value in result if value)


def _line(source: str, offset: int) -> int:
    return source.count("\n", 0, offset) + 1


def _split_args(text: str) -> list[str]:
    result: list[str] = []
    depth = 0
    quote: str | None = None
    escaped = False
    start = 0
    for index, char in enumerate(text):
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            continue
        if char in {'"', "'"}:
            quote = char
        elif char in "([{<":
            depth += 1
        elif char in ")]}>":
            depth = max(0, depth - 1)
        elif char == "," and depth == 0:
            result.append(text[start:index].strip())
            start = index + 1
    tail = text[start:].strip()
    if tail or text.strip():
        result.append(tail)
    return result


def _method_calls(source: str) -> Iterable[tuple[str, str, str, int]]:
    pattern = re.compile(r"\b([A-Za-z_$][\w$]*)\s*\.\s*([A-Za-z_$][\w$]*)\s*\(")
    for match in pattern.finditer(source):
        open_index = source.find("(", match.start(), match.end())
        depth = 0
        quote = None
        escaped = False
        close = None
        for index in range(open_index, len(source)):
            char = source[index]
            if quote:
                if escaped: escaped = False
                elif char == "\\": escaped = True
                elif char == quote: quote = None
                continue
            if char in {'"', "'"}: quote = char; continue
            if char == "(": depth += 1
            elif char == ")":
                depth -= 1
                if depth == 0:
                    close = index
                    break
        if close is not None:
            yield match.group(1), match.group(2), source[open_index + 1:close], match.start()


@dataclass(slots=True)
class ContractIndex:
    schemas: dict[str, PayloadSchema] = field(default_factory=dict)
    fixtures_by_method: dict[str, FixtureSpec] = field(default_factory=dict)
    fixtures_by_type: dict[str, list[FixtureSpec]] = field(default_factory=dict)
    collaborator_methods: dict[tuple[str, str, int], object] = field(default_factory=dict)
    collaborator_fields: set[str] = field(default_factory=set)
    private_cut_fields: dict[str, object] = field(default_factory=dict)
    configuration_values: dict[str, str] = field(default_factory=dict)
    production_locals: set[str] = field(default_factory=set)
    cut_source: str = ""

    @classmethod
    def from_context(cls, ctx, method_context=None) -> "ContractIndex":
        result = cls()
        execution = getattr(ctx, "execution_context", None)
        if execution is not None:
            for schema in execution.payload_schemas:
                result.schemas[schema.type_name] = schema
                if schema.fqcn:
                    result.schemas[schema.fqcn] = schema
            for fixture in execution.fixtures:
                result.fixtures_by_method[fixture.method_name] = fixture
                result.fixtures_by_type.setdefault(_simple(fixture.return_type), []).append(fixture)
            for config in execution.configuration_fields:
                if config.test_value is not None:
                    result.configuration_values[config.field_name] = config.test_value
        for field_sig in getattr(ctx.symbol, "fields", ()):
            if "private" in field_sig.modifiers:
                result.private_cut_fields[field_sig.name] = field_sig
        if method_context is not None:
            result.production_locals = {item.name for item in method_context.local_variables}
            for invocation in method_context.dependency_invocations:
                result.collaborator_fields.add(invocation.dependency_field)
                key = (invocation.dependency_field, invocation.contract.method_name, len(invocation.contract.parameter_types))
                result.collaborator_methods[key] = invocation.contract
        return result

    def schema(self, type_name: str | None) -> PayloadSchema | None:
        return self.schemas.get(type_name or "") or self.schemas.get(_simple(type_name))

    def property(self, type_name: str | None, member: str) -> PayloadProperty | None:
        schema = self.schema(type_name)
        if schema is None:
            return None
        for prop in schema.properties:
            if prop.name == member or prop.getter == member or prop.setter == member or prop.builder_method == member:
                return prop
        return None


def _infer_expression_type(expr: str, variables: dict[str, str], index: ContractIndex) -> str | None:
    value = expr.strip()
    if re.fullmatch(r"'.'", value, flags=re.DOTALL): return "char"
    if re.fullmatch(r'"(?:[^"\\]|\\.)*"', value, flags=re.DOTALL): return "String"
    if value in {"true", "false"}: return "boolean"
    if value == "null": return "null"
    if re.fullmatch(r"[-+]?\d+[lL]", value): return "long"
    if re.fullmatch(r"[-+]?\d+", value): return "int"
    if re.fullmatch(r"[-+]?(?:\d+\.\d*|\d*\.\d+)(?:[dD])?", value): return "double"
    if value.startswith("BigDecimal.") or value.startswith("new BigDecimal"):
        return "BigDecimal"
    m = re.match(r"(?:java\.util\.)?(List|Set|Map|Collection)\s*\.\s*of\s*\((.*)\)\s*$", value, re.DOTALL)
    if m:
        args = _split_args(m.group(2))
        element = _infer_expression_type(args[0], variables, index) if args else "Object"
        return f"{m.group(1)}<{element or 'Object'}>"
    m = re.match(r"(?:new\s+)?(?:java\.util\.)?(ArrayList|HashSet|LinkedHashSet|List|Set)\s*(?:<([^>]*)>)?", value)
    if m:
        family = "List" if "List" in m.group(1) else "Set"
        return f"{family}<{(m.group(2) or 'Object').strip()}>"
    m = re.match(r"([A-Za-z_$][\w$]*)\s*\.\s*([A-Z][A-Z0-9_]*)$", value)
    if m and index.schema(m.group(1)):
        return m.group(1)
    m = re.match(r"([A-Za-z_$][\w$]*)\s*\(", value)
    if m and m.group(1) in index.fixtures_by_method:
        return index.fixtures_by_method[m.group(1)].return_type
    return variables.get(value)


def _compatible(expected: str | None, actual: str | None) -> tuple[bool, str | None]:
    if actual in {None, "null"}:
        return True, None
    e_simple, a_simple = _simple(expected), _simple(actual)
    wrappers = {"char": "Character", "int": "Integer", "long": "Long", "double": "Double", "float": "Float", "boolean": "Boolean", "short": "Short", "byte": "Byte"}
    if wrappers.get(e_simple) == a_simple or wrappers.get(a_simple) == e_simple or e_simple == a_simple:
        pass
    elif e_simple in {"List", "Set", "Collection"} and a_simple in {"List", "Set", "Collection"}:
        if e_simple != "Collection" and e_simple != a_simple:
            return False, SemanticCategory.COLLECTION_FAMILY.value
    else:
        return False, SemanticCategory.SCALAR_TYPE.value
    e_args, a_args = _generic_arguments(expected), _generic_arguments(actual)
    if e_args and a_args and _simple(e_args[0]) not in {"Object", "?"} and _simple(e_args[0]) != _simple(a_args[0]):
        return False, SemanticCategory.COLLECTION_ELEMENT.value
    return True, None


def _variable_types(source: str, index: ContractIndex) -> tuple[dict[str, str], dict[str, str]]:
    variables: dict[str, str] = {}
    fixture_vars: dict[str, str] = {}
    declaration = re.compile(
        r"\b([A-Za-z_$][\w$]*(?:\s*<[^;=]+?>)?(?:\[\])?)\s+([A-Za-z_$][\w$]*)\s*=\s*([^;]+);",
        re.DOTALL,
    )
    for match in declaration.finditer(source):
        type_name, variable, initializer = match.group(1).strip(), match.group(2), match.group(3).strip()
        variables[variable] = type_name
        fixture_call = re.match(r"([A-Za-z_$][\w$]*)\s*\(", initializer)
        if fixture_call and fixture_call.group(1) in index.fixtures_by_method:
            fixture_vars[variable] = fixture_call.group(1)
    return variables, fixture_vars


def _matcher_consistent(args: str) -> bool:
    values = _split_args(args)
    if len(values) < 2:
        return True
    uses = [bool(re.search(r"\b(?:" + "|".join(sorted(_MATCHER_NAMES)) + r")\s*\(", value)) for value in values]
    return all(uses) or not any(uses)


def validate_serviceimpl_semantics(ctx, production_method, method_context, source: str) -> SemanticValidationResult:
    index = ContractIndex.from_context(ctx, method_context)
    diagnostics: list[SemanticDiagnostic] = []
    variables, fixture_vars = _variable_types(source, index)

    # Framework/API gates.
    if re.search(r"\b(?:assertThat|MatcherAssert\s*\.\s*assertThat|Truth\s*\.\s*assertThat)\s*\(", source):
        diagnostics.append(SemanticDiagnostic(SemanticCategory.ASSERTION_FRAMEWORK.value, "AssertJ, Hamcrest, or Truth is not authorised"))
    for match in re.finditer(r"\b(assert[A-Za-z0-9_$]+|fail)\s*\(", source):
        if match.group(1) not in _ALLOWED_ASSERTIONS:
            diagnostics.append(SemanticDiagnostic(SemanticCategory.ASSERTION_API.value, f"unsupported JUnit assertion {match.group(1)}", match.group(0), "JUnit Jupiter authorised assertion set", _line(source, match.start())))
    for match in re.finditer(r"\bMockito\s*\.\s*([A-Za-z_$][\w$]*)\s*\(", source):
        method = match.group(1)
        if method not in _ALLOWED_MOCKITO:
            diagnostics.append(SemanticDiagnostic(SemanticCategory.UNAUTHORISED_MOCKITO.value, f"Mockito.{method} is not authorised", match.group(0), "authorised Mockito static API set", _line(source, match.start())))

    for match in re.finditer(r"\b(lenient|mockingDetails|clearInvocations|reset|validateMockitoUsage)\s*\(", source):
        diagnostics.append(SemanticDiagnostic(
            SemanticCategory.UNAUTHORISED_MOCKITO.value,
            f"Mockito API {match.group(1)} is not authorised for generated tests",
            match.group(0),
            "authorised Mockito static API set",
            _line(source, match.start()),
        ))

    # Fixture-only application-object setup.
    for type_name in sorted(index.fixtures_by_type):
        escaped = re.escape(type_name)
        for pattern, message, category in (
            (rf"\bnew\s+{escaped}\s*\(", "direct constructor used for fixture-supported application type", SemanticCategory.FIXTURE_CONSTRUCTION),
            (rf"\b{escaped}\s*\.\s*builder\s*\(", "builder used for fixture-supported application type", SemanticCategory.FIXTURE_CONSTRUCTION),
            (rf"\b(?:mock|spy)\s*\(\s*{escaped}\s*\.\s*class", "mock or spy used as fixture-supported data object", SemanticCategory.FIXTURE_DATA_MOCK),
        ):
            for match in re.finditer(pattern, source):
                diagnostics.append(SemanticDiagnostic(category.value, f"{message}: {type_name}", match.group(0), f"compiled fixture for {type_name}", _line(source, match.start())))
    for variable, fixture_method in fixture_vars.items():
        fixture = index.fixtures_by_method[fixture_method]
        patterns = [
            rf"\b{re.escape(variable)}\s*\.\s*set[A-Z]\w*\s*\(",
            rf"\b{re.escape(variable)}\s*\.\s*[A-Za-z_$][\w$]*\s*=",
            rf"\bReflectionTestUtils\s*\.\s*setField\s*\(\s*{re.escape(variable)}\b",
            rf"\b{re.escape(variable)}\s*\.\s*toBuilder\s*\(",
        ]
        for pattern in patterns:
            for match in re.finditer(pattern, source):
                diagnostics.append(SemanticDiagnostic(SemanticCategory.FIXTURE_MUTATION.value, f"fixture-supported variable {variable} is mutated inside @Test", match.group(0), f"use a compiled {fixture.return_type} fixture variant", _line(source, match.start()), correctable=True))

    # Application members and exact type compatibility.
    for receiver, method_name, args_text, offset in _method_calls(source):
        receiver_type = variables.get(receiver)
        schema = index.schema(receiver_type)
        if schema is not None:
            prop = index.property(receiver_type, method_name)
            if prop is None:
                if method_name in {"equals", "hashCode", "toString", "getClass"}:
                    continue
                alternate = None
                if method_name.startswith("is"):
                    suffix = method_name[2:]
                    alternate = next((item for item in schema.properties if item.getter == "get" + suffix), None)
                elif method_name.startswith("get"):
                    suffix = method_name[3:]
                    alternate = next((item for item in schema.properties if item.getter == "is" + suffix), None)
                if alternate is not None:
                    diagnostics.append(SemanticDiagnostic(
                        SemanticCategory.WRONG_GETTER.value,
                        f"{method_name} is not the authoritative getter for {alternate.name}",
                        method_name,
                        f"{schema.type_name}.{alternate.getter}()",
                        _line(source, offset),
                        correctable=True,
                    ))
                    continue
                if method_name.startswith("set"):
                    category = SemanticCategory.UNKNOWN_SETTER
                elif method_name.startswith(("get", "is")):
                    category = SemanticCategory.UNKNOWN_GETTER
                else:
                    category = SemanticCategory.UNKNOWN_METHOD
                diagnostics.append(SemanticDiagnostic(category.value, f"{schema.type_name}.{method_name} does not exist", f"{receiver}.{method_name}(...)" , f"authoritative members of {schema.type_name}", _line(source, offset)))
                continue
            if method_name.startswith("is") and prop.getter and prop.getter != method_name:
                diagnostics.append(SemanticDiagnostic(SemanticCategory.WRONG_GETTER.value, f"{method_name} is not the authoritative getter for {prop.name}", method_name, f"{schema.type_name}.{prop.getter}()", _line(source, offset), correctable=True))
            if method_name.startswith("set"):
                args = _split_args(args_text)
                if len(args) == 1:
                    actual_type = _infer_expression_type(args[0], variables, index)
                    expected = prop.resolved_type or prop.type_name
                    compatible, category = _compatible(expected, actual_type)
                    if not compatible:
                        expected_schema = index.schema(expected)
                        actual_schema = index.schema(actual_type)
                        effective_category = category or SemanticCategory.SCALAR_TYPE.value
                        if expected_schema is not None and actual_schema is not None and expected_schema is not actual_schema:
                            effective_category = SemanticCategory.WRONG_NESTED_TYPE.value
                        diagnostics.append(SemanticDiagnostic(effective_category, f"{args[0]} has type {actual_type}; expected {expected}", args[0], f"{schema.type_name}.{method_name}({expected})", _line(source, offset), correctable=True))
                    enum_schema = index.schema(expected)
                    enum_match = re.fullmatch(r"([A-Za-z_$][\w$]*)\.([A-Z][A-Z0-9_]*)", args[0].strip())
                    if enum_schema and enum_schema.kind == "enum" and enum_match and enum_match.group(2) not in enum_schema.enum_constants:
                        diagnostics.append(SemanticDiagnostic(SemanticCategory.UNKNOWN_ENUM_CONSTANT.value, f"unknown enum constant {args[0]}", args[0], f"constants: {', '.join(enum_schema.enum_constants)}", _line(source, offset)))

    # Bare field writes on known application variables.
    for match in re.finditer(r"\b([A-Za-z_$][\w$]*)\.([A-Za-z_$][\w$]*)\s*=", source):
        receiver, member = match.group(1), match.group(2)
        schema = index.schema(variables.get(receiver))
        if schema is not None and index.property(variables.get(receiver), member) is None:
            diagnostics.append(SemanticDiagnostic(SemanticCategory.UNKNOWN_FIELD.value, f"unknown field {schema.type_name}.{member}", match.group(0), f"authoritative properties of {schema.type_name}", _line(source, match.start())))

    # Collaborator contracts, void/non-void use, matcher consistency.
    for match in re.finditer(r"(?:Mockito\s*\.\s*)?when\s*\(\s*([A-Za-z_$][\w$]*)\.([A-Za-z_$][\w$]*)\s*\((.*?)\)\s*\)\s*\.\s*thenReturn\s*\(", source, re.DOTALL):
        field, name, args = match.group(1), match.group(2), match.group(3)
        contract = index.collaborator_methods.get((field, name, len(_split_args(args))))
        if contract is None:
            diagnostics.append(SemanticDiagnostic(SemanticCategory.UNRESOLVED_COLLABORATOR.value, f"unresolved collaborator method {field}.{name}/{len(_split_args(args))}", match.group(0), "resolved collaborator contract required", _line(source, match.start())))
        elif contract.is_void:
            diagnostics.append(SemanticDiagnostic(SemanticCategory.VOID_THEN_RETURN.value, f"thenReturn used on resolved void method {field}.{name}", match.group(0), f"void {name}({', '.join(contract.parameter_types)})", _line(source, match.start()), correctable=True))
        if not _matcher_consistent(args):
            diagnostics.append(SemanticDiagnostic(SemanticCategory.MATCHER_CONSISTENCY.value, f"raw arguments and Mockito matchers are mixed in {field}.{name}", args, "all matcher arguments or all raw arguments", _line(source, match.start())))
    for match in re.finditer(r"\bdoNothing\s*\(\s*\)\s*\.\s*when\s*\(\s*([A-Za-z_$][\w$]*)\s*\)\s*\.\s*([A-Za-z_$][\w$]*)\s*\((.*?)\)", source, re.DOTALL):
        field, name, args = match.group(1), match.group(2), match.group(3)
        contract = index.collaborator_methods.get((field, name, len(_split_args(args))))
        if contract is None or not contract.is_resolved:
            diagnostics.append(SemanticDiagnostic(SemanticCategory.UNRESOLVED_AS_VOID.value, f"unresolved method {field}.{name} treated as void", match.group(0), "resolved collaborator contract required", _line(source, match.start())))
        elif contract.is_non_void:
            diagnostics.append(SemanticDiagnostic(SemanticCategory.NON_VOID_AS_VOID.value, f"resolved non-void method {field}.{name} treated as void", match.group(0), f"{contract.return_type} {name}({', '.join(contract.parameter_types)})", _line(source, match.start())))
        if not _matcher_consistent(args):
            diagnostics.append(SemanticDiagnostic(SemanticCategory.MATCHER_CONSISTENCY.value, f"raw arguments and Mockito matchers are mixed in {field}.{name}", args, "all matcher arguments or all raw arguments", _line(source, match.start())))

    # Production-only names. Qualified occurrences are valid; bare references are not.
    declared_names = set(variables)
    for name, field_sig in index.private_cut_fields.items():
        for match in re.finditer(rf"(?<![.\w$]){re.escape(name)}(?![\w$])", source):
            if name in declared_names:
                continue
            diagnostics.append(SemanticDiagnostic(SemanticCategory.PRIVATE_CUT_IDENTIFIER.value, f"private CUT field {name} is unavailable as a bare test variable", name, f"private {field_sig.type} {name}", _line(source, match.start()), correctable=name in index.configuration_values))
    for name in index.production_locals:
        if name in declared_names:
            continue
        for match in re.finditer(rf"(?<![.\w$]){re.escape(name)}(?![\w$])", source):
            diagnostics.append(SemanticDiagnostic(SemanticCategory.PRODUCTION_IDENTIFIER.value, f"production-local variable {name} is unavailable in test scope", name, "production local variables are not test-scope symbols", _line(source, match.start())))

    # Invented application types are rejected only when actively constructed.
    known_types = {_simple(name) for name in index.schemas} | set(index.fixtures_by_type) | _STANDARD_TYPES
    for match in re.finditer(r"\bnew\s+([A-Z][A-Za-z0-9_$]*)\s*\(", source):
        type_name = match.group(1)
        if type_name not in known_types and not type_name.endswith(("Exception", "Error")):
            diagnostics.append(SemanticDiagnostic(SemanticCategory.INVENTED_APPLICATION_TYPE.value, f"unresolved or invented application type {type_name}", match.group(0), "verified application/standard type catalogue", _line(source, match.start())))

    # Deterministic order and deduplication.
    unique: list[SemanticDiagnostic] = []
    seen: set[tuple[str, str, int | None]] = set()
    for diagnostic in diagnostics:
        key = (diagnostic.category, diagnostic.message, diagnostic.line)
        if key not in seen:
            seen.add(key)
            unique.append(diagnostic)
    return SemanticValidationResult(not unique, tuple(unique))


def _record_change(actions: list[dict[str, object]], category: str, before: str, after: str, contract: str) -> None:
    if before == after:
        return
    change = DeterministicChange(
        sequence=len(actions) + 1,
        timestamp=datetime.now(timezone.utc).isoformat(),
        diagnostic_category=category,
        source_before=before,
        source_after=after,
        authoritative_contract=contract,
    )
    actions.append({
        "sequence": change.sequence,
        "timestamp": change.timestamp,
        "diagnostic_category": change.diagnostic_category,
        "source_before": change.source_before,
        "source_after": change.source_after,
        "authoritative_contract": change.authoritative_contract,
        "result": change.result,
    })


def deterministically_correct_serviceimpl(ctx, production_method, method_context, source: str) -> SemanticCorrectionResult:
    """Apply only source-backed, unambiguous corrections."""
    index = ContractIndex.from_context(ctx, method_context)
    corrected = source
    actions: list[dict[str, object]] = []

    for category, transform, contract in (
        (SemanticCategory.UNAUTHORISED_MOCKITO.value, lambda value: re.sub(r"\bMockito\s*\.\s*when\s*\(", "when(", value), "authorised static Mockito.when"),
        (SemanticCategory.UNAUTHORISED_MOCKITO.value, lambda value: re.sub(r"\bMockito\s*\.\s*any\s*\(", "any(", value), "authorised static Mockito.any"),
        ("primitive_matcher", normalize_primitive_matchers, "primitive-compatible Mockito matcher"),
        (SemanticCategory.ASSERTION_FRAMEWORK.value, normalize_simple_assertj_assertions, "JUnit Jupiter assertion API"),
    ):
        before = corrected
        corrected = transform(corrected)
        _record_change(actions, category, before, corrected, contract)

    # Remove complete normal stubbing statements for resolved void methods.
    for match in list(re.finditer(r"(?m)^\s*(?:Mockito\s*\.\s*)?when\s*\(\s*([A-Za-z_$][\w$]*)\.([A-Za-z_$][\w$]*)\s*\((.*?)\)\s*\)\s*\.\s*thenReturn\s*\([^;]*\)\s*;\s*$", corrected, re.DOTALL))[::-1]:
        field, name, args = match.group(1), match.group(2), match.group(3)
        contract = index.collaborator_methods.get((field, name, len(_split_args(args))))
        if contract is not None and contract.is_void:
            before = corrected
            corrected = corrected[:match.start()] + corrected[match.end():]
            _record_change(actions, SemanticCategory.VOID_THEN_RETURN.value, before, corrected, f"void {name}({', '.join(contract.parameter_types)})")

    variables, _fixture_vars = _variable_types(corrected, index)
    # Correct authoritative getter names and setter literal/family types.
    for variable, type_name in list(variables.items()):
        schema = index.schema(type_name)
        if schema is None:
            continue
        for prop in schema.properties:
            if prop.getter and prop.getter.startswith("get"):
                wrong = "is" + prop.getter[3:]
                before = corrected
                corrected = re.sub(rf"\b{re.escape(variable)}\s*\.\s*{re.escape(wrong)}\s*\(", f"{variable}.{prop.getter}(", corrected)
                _record_change(actions, SemanticCategory.WRONG_GETTER.value, before, corrected, f"{schema.type_name}.{prop.getter}()")
            if not prop.setter:
                continue
            expected = prop.resolved_type or prop.type_name
            setter_pattern = re.compile(rf"\b{re.escape(variable)}\s*\.\s*{re.escape(prop.setter)}\s*\(\s*(.*?)\s*\)\s*;", re.DOTALL)
            for match in list(setter_pattern.finditer(corrected))[::-1]:
                argument = match.group(1).strip()
                replacement = None
                category = SemanticCategory.SCALAR_TYPE.value
                if _simple(expected) in {"char", "Character"} and re.fullmatch(r'"([^"\\])"', argument):
                    replacement = "'" + re.fullmatch(r'"([^"\\])"', argument).group(1) + "'"
                elif _simple(expected) == "BigDecimal" and re.fullmatch(r"[-+]?(?:\d+\.\d*|\d*\.\d+|\d+)", argument):
                    replacement = f"BigDecimal.valueOf({argument})"
                elif _simple(expected) == "Set" and re.match(r"(?:java\.util\.)?List\s*\.\s*of\s*\(", argument):
                    replacement = re.sub(r"^(?:java\.util\.)?List", "Set", argument, count=1)
                    category = SemanticCategory.COLLECTION_FAMILY.value
                else:
                    enum_schema = index.schema(expected)
                    enum_match = re.fullmatch(r"([A-Za-z_$][\w$]*)\.([A-Z][A-Z0-9_]*)", argument)
                    if (
                        enum_schema is not None
                        and enum_schema.kind == "enum"
                        and enum_match is not None
                        and enum_match.group(2) not in enum_schema.enum_constants
                        and len(enum_schema.enum_constants) == 1
                    ):
                        replacement = f"{enum_match.group(1)}.{enum_schema.enum_constants[0]}"
                        category = SemanticCategory.UNKNOWN_ENUM_CONSTANT.value
                if replacement:
                    before = corrected
                    corrected = corrected[:match.start(1)] + replacement + corrected[match.end(1):]
                    _record_change(actions, category, before, corrected, f"{schema.type_name}.{prop.setter}({expected})")

    # Replace private configuration identifiers only when a verified test value exists.
    for name, value in index.configuration_values.items():
        before = corrected
        corrected = re.sub(rf"(?<![.\w$]){re.escape(name)}(?![\w$])", value, corrected)
        field = index.private_cut_fields.get(name)
        contract = f"verified configuration {name}={value}" + (f" ({field.type})" if field else "")
        _record_change(actions, SemanticCategory.PRIVATE_CUT_IDENTIFIER.value, before, corrected, contract)

    # Remove an unknown setter only when its property is absent from the selected source path.
    variables, _ = _variable_types(corrected, index)
    selected_source = getattr(method_context, "method_source", "") or ""
    for variable, type_name in variables.items():
        schema = index.schema(type_name)
        if schema is None:
            continue
        known = {prop.setter for prop in schema.properties if prop.setter}
        for match in list(re.finditer(rf"(?m)^\s*{re.escape(variable)}\s*\.\s*(set[A-Z]\w*)\s*\([^;]*\)\s*;\s*$", corrected))[::-1]:
            setter = match.group(1)
            property_name = setter[3:4].lower() + setter[4:]
            if setter not in known and not re.search(rf"\b(?:get|is|set)?{re.escape(setter[3:])}\b|\b{re.escape(property_name)}\b", selected_source):
                before = corrected
                corrected = corrected[:match.start()] + corrected[match.end():]
                _record_change(actions, SemanticCategory.UNKNOWN_SETTER.value, before, corrected, f"{schema.type_name} has no {setter}; property is unrelated to selected path")

    return SemanticCorrectionResult(corrected, tuple(actions))


__all__ = [
    "ContractIndex",
    "DeterministicChange",
    "SemanticCategory",
    "SemanticCorrectionResult",
    "SemanticDiagnostic",
    "SemanticValidationResult",
    "deterministically_correct_serviceimpl",
    "validate_serviceimpl_semantics",
]
