"""Generated Java response extraction compatibility layer."""

from junitforge.execution.assembly import (
    extract_test_method_block,
    extract_test_methods,
    test_method_names,
)


def extract_generated_tests(source: str):
    return extract_test_methods(source)


__all__ = [
    "extract_generated_tests",
    "extract_test_method_block",
    "extract_test_methods",
    "test_method_names",
]
