"""Authoritative generation and repair counter refresh."""

from __future__ import annotations

import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get
from junitforge.registry import history_action_startswith

log = get("junitforge.loop")


def _refresh_generation_counters(outcome: TargetOutcome) -> None:
    """Recompute authoritative method/test recovery counters from test-level records."""
    records = outcome.method_results or []
    outcome.fully_generated_methods = sum(
        record.final_status == MethodDisposition.GENERATED.value for record in records
    )
    outcome.partially_generated_methods = sum(
        record.final_status == MethodDisposition.PARTIALLY_GENERATED.value for record in records
    )
    outcome.rejected_methods = sum(
        record.final_status == MethodDisposition.REJECTED.value for record in records
    )
    outcome.retained_tests = sum(record.tests_retained for record in records)
    outcome.rejected_tests = sum(record.tests_rejected for record in records)
    outcome.fixture_substitutions = sum(
        history_action_startswith(action, "fixture_substitution:")
        for record in records
        for test in record.tests
        for action in test.deterministic_repair_history
    )
    outcome.unnecessary_stubs_removed = sum(
        history_action_startswith(action, "unnecessary_return_stub_removed:")
        for record in records
        for test in record.tests
        for action in test.deterministic_repair_history
    )
    outcome.return_type_mismatches_corrected = sum(
        history_action_startswith(action, "return_type_corrected:") or history_action_startswith(action, "void_return_stub_removed:")
        for record in records
        for test in record.tests
        for action in test.deterministic_repair_history
    )
    outcome.invalid_checked_exception_scenarios_removed = sum(
        test.final_disposition == TestDisposition.REJECTED.value
        and any(
            focused_validation_category(reason) == "INVALID_CHECKED_EXCEPTION_STUBBING"
            for reason in test.validation_diagnostics
        )
        for record in records
        for test in record.tests
    )
    outcome.unknown_member_tests_repaired = sum(
        any(history_action_startswith(action, "unknown_member_") for action in test.deterministic_repair_history)
        for record in records
        for test in record.tests
    )
    outcome.silent_method_omissions = max(
        0, outcome.selected_production_methods - len(records)
    )
