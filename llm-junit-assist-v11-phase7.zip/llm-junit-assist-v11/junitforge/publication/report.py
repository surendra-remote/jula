"""Compatibility facade over the existing v7.3.3 report implementation."""

from junitforge.report import *  # noqa: F401,F403
