"""Final source restoration, removal, and failing-source snapshot publication."""

from __future__ import annotations

import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get

log = get("junitforge.loop")



class PublicationMixin:
    @staticmethod
    def _select_publishable_source_state(outcome: TargetOutcome) -> str:
        """Return the strongest source state supported by recorded evidence.

        Zero-valued runtime counters are not evidence that tests executed.
        Coverage acceptance requires a fresh coverage result and a green full
        runtime snapshot; runtime-green requires an authoritative green full run.
        """
        green = outcome.runtime_last_green_full_run
        runtime_verified = bool(
            green is not None
            and green.tests_run > 0
            and green.maven_execution_success
            and green.tests_green
        )
        if runtime_verified and outcome.coverage_current and outcome.line_pct is not None:
            return "coverage-accepted"
        if runtime_verified:
            return "runtime-green"
        return "compiling"

    @staticmethod
    def _restore_or_remove(test_path: Path, original: str | None) -> None:
        try:
            if original is not None:
                test_path.write_text(original, encoding="utf-8")
            elif test_path.exists():
                test_path.unlink()
        except OSError:
            pass

    @staticmethod
    def _capture_failed_test_snapshot(test_path: Path, outcome: TargetOutcome) -> None:
        """Persist the rejected/non-compiling generated test for inspection.

        The main generated test is restored or removed immediately after a
        compile failure so the Java module is not left broken. This snapshot is
        deliberately written beside the generated test with a .failing suffix so
        it is easy to inspect but is not compiled by Maven/Gradle as a test
        source.
        """
        try:
            if not test_path.exists():
                log.warning(
                    "[COMPILE_REPAIR] snapshot.skipped | test=%s | reason=file_missing",
                    test_path,
                )
                return
            snapshot_path = test_path.with_name(test_path.name + ".failing")
            snapshot_path.write_text(test_path.read_text(encoding="utf-8"), encoding="utf-8")
            outcome.notes.append(f"saved failing generated test snapshot: {snapshot_path}")
            log.error(
                "[COMPILE_REPAIR] snapshot.saved | source=%s | snapshot=%s | bytes=%d",
                test_path,
                snapshot_path,
                snapshot_path.stat().st_size,
            )
        except OSError as exc:
            outcome.notes.append(f"could not save failing test snapshot: {exc}")
            log.exception(
                "[COMPILE_REPAIR] snapshot.failed | test=%s | error=%s",
                test_path,
                exc,
            )
