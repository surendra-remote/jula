"""Compile sequencing, focused repair, candidate acceptance, and Maven recovery."""

from __future__ import annotations

import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.audit.console import stage as console_stage
from junitforge.audit.recorder import sha256_text
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    CompileState,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get

log = get("junitforge.loop")
from junitforge.generation.response_extractor import extract_generated_tests

from junitforge.compilation.candidate_validator import (
    _compile_candidate_is_strict_progress,
    complete_test_class_response_error,
)
from junitforge.compilation.diagnostic_mapper import (
    _select_method_repair_owner,
    map_compile_diagnostics,
)
from junitforge.compilation.provider_response import (
    identical_rejected_response,
    provider_metadata,
    request_hash as focused_request_hash,
)
from junitforge.compilation.response_normalizer import normalize_focused_test_response
from junitforge.generation.payloads import payload_builder_for_context
from junitforge.pipeline.result import sync_test_registry_sources
from junitforge.registry import (
    RegistryStore,
    fixture_method_names_from_context,
    recalculate_registry_ranges,
    source_hash,
)
from junitforge.runtime.state import _mark_retained_compile_state
from junitforge.generation.validation import (
    repair_validation_failure_deterministically,
    validate_generated_test,
    validation_diagnostics,
)


def _audit_compile_errors(errors, source: str = ""):
    lines = source.splitlines()
    out = []
    for error in errors or ():
        line = getattr(error, "line", None)
        detail = list(getattr(error, "detail", ()) or ())
        expected = next((item.split(":", 1)[1].strip() for item in detail if str(item).startswith("required:")), None)
        actual = next((item.split(":", 1)[1].strip() for item in detail if str(item).startswith("found:")), None)
        out.append({
            "file": str(getattr(error, "file", "") or ""),
            "line": line,
            "column": getattr(error, "col", None),
            "message": getattr(error, "message", str(error)),
            "source_line": lines[line - 1] if isinstance(line, int) and 0 < line <= len(lines) else None,
            "diagnostic_category": getattr(error, "diagnostic_category", "compiler_error") or "compiler_error",
            "expected_type": expected,
            "actual_type": actual,
            "detail_lines": detail,
            "raw_compiler_text": getattr(error, "raw", "") or "",
        })
    return out


class CompilationRepairMixin:
    def _compile_with_repair(self, ctx: GenerationContext, test_path: Path,
                             module: ModuleInfo, outcome: TargetOutcome) -> str | None:
        """Compile once after assembly; repair only the owning method block when possible."""
        execution = ctx.execution_context
        target_kind = execution.target_kind.value if execution is not None else ""
        serviceimpl = target_kind == "service-impl"
        methodwise = target_kind in {"controller", "service-impl"}
        source = test_path.read_text(encoding="utf-8")
        recalculate_registry_ranges(
            outcome, source,
            fixture_method_names=fixture_method_names_from_context(ctx),
            persist=True,
        )
        started = perf_counter()
        result, errors = self._compile_candidate(test_path, module)
        elapsed = perf_counter() - started
        audit_errors = _audit_compile_errors(errors, source)
        self.audit.write_json(ctx.symbol.name, "08-compile/command.json", {
            "command": getattr(result, "cmd", []),
            "working_directory": str(module.root),
            "selected_test_class": ctx.test_class_name,
            "build_tool": "ant" if self.compile_gate.__class__.__name__.lower().startswith("ant") else "maven",
            "offline": self.cfg.offline,
            "elapsed_seconds": elapsed,
        })
        self.audit.write_json(ctx.symbol.name, "08-compile/compiler-errors.json", {
            "errors": audit_errors,
            "error_count": len(audit_errors),
            "truncated": False,
        })
        self.audit.write_text(ctx.symbol.name, "08-compile/stdout.log", getattr(result, "stdout", "") or "")
        self.audit.write_text(ctx.symbol.name, "08-compile/stderr.log", getattr(result, "stderr", "") or "")
        self.audit.write_json(ctx.symbol.name, "08-compile/result.json", {
            "success": result.ok,
            "exit_code": result.return_code,
            "error_count": len(errors),
            "source_hash": sha256_text(source),
            "test_count": len(test_method_names(source)),
            "elapsed_seconds": elapsed,
        })
        outcome.compile_history.append({
            "attempt_number": len(outcome.compile_history) + 1,
            "stage": "initial_class_compile",
            "test_id": None,
            "candidate_hash": source_hash(source),
            "diagnostics": _audit_compile_errors(errors, source),
            "validation_result": "NOT_APPLICABLE",
            "compilation_result": "PASSED" if result.ok else "FAILED",
            "decision": "COMMIT" if result.ok else "ROUTE_DIAGNOSTICS",
        })
        if result.ok:
            compile_store = RegistryStore(outcome)
            for method_record in outcome.method_results:
                for test_record in method_record.tests:
                    if test_record.final_disposition != TestDisposition.RETAINED.value:
                        continue
                    compile_store.transition_compile_state(
                        test_record,
                        CompileState.PASSED,
                        attempt={
                            "action": "compile_attempt",
                            "stage": "initial_compile",
                            "success": True,
                            "diagnostic_count": 0,
                        },
                    )
            sync_test_registry_sources(outcome, source, compile_state="PASSED", accepted=True)
            return source

        ownership = map_compile_diagnostics(outcome, errors)
        self._persist_diagnostic_buckets(outcome, ownership)
        compile_store = RegistryStore(outcome)
        for test_id, mapped in ownership.by_test.items():
            compile_store.transition_compile_state(
                test_id,
                CompileState.FAILED,
                diagnostics=[item.to_dict() for item in mapped],
                attempt={
                    "attempt_number": 1,
                    "action": "compile_attempt",
                    "stage": "initial_class_compile",
                    "test_id": test_id,
                    "candidate_hash": source_hash(source),
                    "diagnostics": [item.to_dict() for item in mapped],
                    "validation_result": "NOT_APPLICABLE",
                    "compilation_result": "FAILED",
                    "decision": "ROUTE_TO_FOCUSED_REPAIR",
                },
            )


        console_stage("COMPILE", "failed | errors=%d | audit=08-compile/compiler-errors.json", len(errors), level="warning")

        if errors and all(error.file is None and error.line is None for error in errors):
            outcome.compile_errors = [error.render() for error in errors][:4]
            outcome.notes.append("non-repairable compile error (toolchain)")
            log.error(
                "[COMPILE_REPAIR] stop.non_repairable_toolchain_error | test=%s | errors=%d",
                test_path.name,
                len(errors),
            )
            return None

        if serviceimpl:
            log.debug(
                "[COMPILE_REPAIR] route.registry_focused_test | test=%s | initial_errors=%d | complete_class_attempts=0",
                test_path.name,
                len(errors),
            )
            return self._compile_registry_focused_repair(
                ctx, test_path, module, outcome, errors
            )

        if methodwise:
            log.debug(
                "[COMPILE_REPAIR] route.methodwise | test=%s | initial_errors=%d",
                test_path.name,
                len(errors),
            )
            return self._compile_methodwise_repair(ctx, test_path, module, outcome, errors)

        log.debug(
            "[COMPILE_REPAIR] route.classwide | test=%s | initial_errors=%d",
            test_path.name,
            len(errors),
        )
        current = test_path.read_text(encoding="utf-8")
        for attempt in range(self.cfg.max_compile_repairs):
            outcome.notes.append(f"compile repair {attempt + 1}: {len(errors)} error(s)")
            log.debug(
                "[COMPILE_REPAIR] classwide.attempt.start | attempt=%d/%d | errors_to_llm=%d",
                attempt + 1,
                self.cfg.max_compile_repairs,
                len(errors),
            )
            kb_hints = self.kb.hints_for([error.message for error in errors]) if self.kb else None
            log.debug(
                "[COMPILE_REPAIR] classwide.prompt.build | attempt=%d | kb_hints=%s | source_chars=%d",
                attempt + 1,
                bool(kb_hints),
                len(current),
            )
            builder = payload_builder_for_context(ctx)
            messages = builder.build_compile_repair_payload(ctx, current, errors, kb_hints, mode="classwide")
            log.debug(
                "[COMPILE_REPAIR] classwide.llm.start | attempt=%d/%d | diagnostics=%d",
                attempt + 1,
                self.cfg.max_compile_repairs,
                len(errors),
            )
            raw = self._chat(messages, self.cfg.temperature_repair, self.cfg.max_tokens_repair, outcome)
            candidate = inject_reusable_fixtures(raw or "", ctx)
            res = finalize_java(
                candidate, test_package=ctx.test_package, test_class_name=ctx.test_class_name,
                template=ctx.template, cut_symbol=ctx.symbol, collaborators=ctx.collaborators,
                source_imports=ctx.source_imports)
            if not res.ok or not res.code:
                log.debug(
                    "[COMPILE_REPAIR] classwide.finalize.rejected | attempt=%d/%d | reason=%s",
                    attempt + 1,
                    self.cfg.max_compile_repairs,
                    res.reason or "unknown",
                )
                continue
            current = res.code
            test_path.write_text(current, encoding="utf-8")
            log.debug(
                "[COMPILE_REPAIR] classwide.recompile.start | attempt=%d/%d | test=%s",
                attempt + 1,
                self.cfg.max_compile_repairs,
                test_path.name,
            )
            result, errors = self._compile_candidate(test_path, module)
            if result.ok:
                log.debug(
                    "[COMPILE_REPAIR] classwide.recompile.success | attempt=%d/%d | test=%s",
                    attempt + 1,
                    self.cfg.max_compile_repairs,
                    test_path.name,
                )
                return current
            log.debug(
                "[COMPILE_REPAIR] classwide.recompile.failed | attempt=%d/%d | remaining_errors=%d",
                attempt + 1,
                self.cfg.max_compile_repairs,
                len(errors),
            )
        outcome.compile_errors = [error.render() for error in errors][:12]
        log.error(
            "[COMPILE_REPAIR] exhausted | mode=classwide | test=%s | remaining_errors=%d | saved_to_outcome=%d",
            test_path.name,
            len(errors),
            len(outcome.compile_errors),
        )
        return None

    @staticmethod
    def _persist_diagnostic_buckets(outcome: TargetOutcome, ownership) -> None:
        outcome.fixture_compile_diagnostics = [item.to_dict() for item in ownership.fixture]
        outcome.skeleton_compile_diagnostics = [item.to_dict() for item in ownership.skeleton]
        outcome.import_class_compile_diagnostics = [item.to_dict() for item in ownership.import_class]
        outcome.assembly_compile_diagnostics = [item.to_dict() for item in ownership.assembly]
        outcome.unmapped_compile_diagnostics = [item.to_dict() for item in ownership.unmapped]
        RegistryStore(outcome).persist()

    @staticmethod
    def _production_method_and_context(ctx: GenerationContext, owner_method_id: str):
        methods = {
            f"{method.name}({','.join(type_name for type_name, _ in method.params)})": method
            for method in (ctx.symbol.methods or [])
        }
        contexts = {
            item.method_id: item
            for item in (ctx.execution_context.methods if ctx.execution_context else ())
        }
        return methods.get(owner_method_id), contexts.get(owner_method_id)

    @staticmethod
    def _replace_exact_test_source(class_source: str, test_name: str, replacement: str) -> str | None:
        before = test_method_for_name(class_source, test_name)
        if before is None:
            return None
        updated = replace_test_method(class_source, test_name, replacement)
        after = test_method_for_name(updated, test_name)
        if after is None or after.source.strip() != replacement.strip():
            return None
        if set(test_method_names(updated)) != set(test_method_names(class_source)):
            return None
        return updated

    @staticmethod
    def _isolated_test_class(
        class_source: str,
        *,
        selected_test_id: str,
        unresolved_test_ids: set[str],
        outcome: TargetOutcome,
    ) -> str:
        isolated = class_source
        for method_record in outcome.method_results:
            for test_record in method_record.tests:
                if test_record.test_id == selected_test_id:
                    continue
                if test_record.test_id in unresolved_test_ids:
                    isolated = remove_test_method(isolated, test_record.test_name)
        return isolated

    def _compile_focused_candidate_once(
        self,
        *,
        ctx: GenerationContext,
        test_path: Path,
        module: ModuleInfo,
        outcome: TargetOutcome,
        selected_test: TestCaseRecord,
        full_candidate_source: str,
        unresolved_test_ids: set[str],
        stage: str,
        validation_result: str,
        request_metadata: dict[str, object] | None = None,
    ):
        isolated = self._isolated_test_class(
            full_candidate_source,
            selected_test_id=selected_test.test_id,
            unresolved_test_ids=unresolved_test_ids,
            outcome=outcome,
        )
        fixture_names = fixture_method_names_from_context(ctx)
        recalculate_registry_ranges(
            outcome,
            isolated,
            fixture_method_names=fixture_names,
            persist=True,
        )
        test_path.write_text(isolated, encoding="utf-8")
        started = perf_counter()
        result, errors = self._compile_candidate(test_path, module)
        elapsed = perf_counter() - started
        attempt = {
            "attempt_number": len(outcome.compile_history) + 1,
            "stage": stage,
            "test_id": selected_test.test_id,
            "candidate_hash": source_hash(selected_test.candidate_source),
            "diagnostics": _audit_compile_errors(errors, isolated),
            "validation_result": validation_result,
            "compilation_result": "PASSED" if result.ok else "FAILED",
            "decision": "COMMIT" if result.ok else "ROLLBACK",
            "elapsed_seconds": elapsed,
        }
        if request_metadata:
            attempt["request_response_metadata"] = request_metadata
        outcome.compile_history.append(attempt)
        self.audit.write_json(
            ctx.symbol.name,
            f"09-compile-repair/{selected_test.test_name}/{stage}-compile.json",
            attempt,
        )
        return result, list(errors), attempt

    def _deterministic_focused_candidate(
        self,
        ctx: GenerationContext,
        test_record: TestCaseRecord,
        diagnostics,
    ) -> tuple[str | None, list[object], str]:
        production_method, method_context = self._production_method_and_context(
            ctx, test_record.owner_method_id
        )
        if production_method is None or method_context is None:
            return None, [], "owner production method context unavailable"
        current_test = test_record.latest_accepted_source or test_record.generated_source
        compiler_repair = deterministically_repair_compile_diagnostics(
            ctx,
            production_method,
            method_context,
            current_test,
            diagnostics,
        )
        correction = repair_validation_failure_deterministically(
            ctx,
            production_method,
            method_context,
            compiler_repair.source,
        )
        candidate = correction.source
        actions = list(compiler_repair.actions) + list(correction.actions)
        if candidate.strip() == current_test.strip():
            return None, actions, "authoritative deterministic repair made no source change"
        validation = validate_generated_test(
            ctx,
            production_method,
            method_context,
            candidate,
            existing_names=set(),
        )
        if not validation.ok or tuple(validation.test_names) != (test_record.test_name,):
            reason = validation.reason or "deterministic candidate changed test identity"
            return None, actions + validation_diagnostics(validation), reason
        return candidate, actions, "VALID"

    def _focused_llm_response(
        self,
        *,
        ctx: GenerationContext,
        outcome: TargetOutcome,
        test_record: TestCaseRecord,
        diagnostics,
    ):
        production_method, method_context = self._production_method_and_context(
            ctx, test_record.owner_method_id
        )
        if production_method is None or method_context is None:
            return None, None, "owner production method context unavailable"
        prior_focused_attempts = [
            entry for entry in test_record.llm_repair_history
            if isinstance(entry, dict)
            and entry.get("action") == "focused_compile_repair_response"
        ]
        if prior_focused_attempts:
            return None, None, "FOCUSED_LLM_ATTEMPT_LIMIT_REACHED"
        current_test = test_record.latest_accepted_source or test_record.generated_source
        builder = payload_builder_for_context(ctx)
        messages = builder.build_compile_repair_payload(
            ctx=ctx,
            method=production_method,
            current_test=current_test,
            test_name=test_record.test_name,
            test_id=test_record.test_id,
            errors=list(diagnostics),
            source_start_line=test_record.source_start_line,
            mode="individual",
        )
        digest = focused_request_hash(
            messages,
            temperature=self.cfg.temperature_repair,
            max_tokens=self.cfg.max_tokens_repair,
        )
        outcome.focused_compile_repair_attempts += 1
        response = self._chat_response(
            messages,
            self.cfg.temperature_repair,
            self.cfg.max_tokens_repair,
            outcome,
        )
        raw = getattr(response, "message", None) if response is not None else None
        normalization = normalize_focused_test_response(
            raw,
            expected_test_name=test_record.test_name,
        )
        metadata = provider_metadata(
            response,
            request_digest=digest,
            probable_truncation=normalization.probable_truncation,
            normalization_result=normalization.normalization_result,
            rejection_reason=normalization.rejection_reason,
        )
        duplicate_reason = identical_rejected_response(
            test_record.llm_repair_history,
            request_digest=metadata.request_hash,
            response_digest=metadata.response_hash,
        )
        if duplicate_reason is not None:
            metadata.rejection_reason = "IDENTICAL_REJECTED_RESPONSE"
            return None, metadata, "IDENTICAL_REJECTED_RESPONSE"
        if not normalization.accepted:
            return None, metadata, normalization.rejection_reason or "focused response rejected"
        validation = validate_generated_test(
            ctx,
            production_method,
            method_context,
            normalization.source,
            existing_names=set(),
        )
        if not validation.ok or tuple(validation.test_names) != (test_record.test_name,):
            reason = validation.reason or "focused response changed test identity"
            metadata.rejection_reason = reason
            return None, metadata, reason
        return normalization.source, metadata, "VALID"

    def _commit_focused_candidate(
        self,
        *,
        ctx: GenerationContext,
        outcome: TargetOutcome,
        test_record: TestCaseRecord,
        full_source: str,
        repair_kind: str,
        compile_attempt: dict[str, object],
    ) -> None:
        fixture_names = fixture_method_names_from_context(ctx)
        recalculate_registry_ranges(
            outcome,
            full_source,
            fixture_method_names=fixture_names,
            persist=True,
        )
        store = RegistryStore(outcome)
        store.transition_compile_state(
            test_record,
            CompileState.REPAIRED_PENDING_COMPILE,
            attempt=compile_attempt,
        )
        store.commit_candidate(
            test_record,
            source_start_line=test_record.source_start_line,
            source_end_line=test_record.source_end_line,
        )
        store.transition_compile_state(
            test_record,
            CompileState.REPAIRED_AND_PASSED,
        )
        store.append_history(
            test_record,
            "deterministic_repair_history" if repair_kind == "deterministic" else "llm_repair_history",
            {"action": f"{repair_kind}_compile_repair_commit", "status": "accepted"},
        )

    def _reject_and_remove_compile_test(
        self,
        *,
        ctx: GenerationContext,
        outcome: TargetOutcome,
        test_record: TestCaseRecord,
        source: str,
        reason: str,
    ) -> str:
        store = RegistryStore(outcome)
        if test_record.candidate_source:
            store.discard_candidate(test_record)
        store.reject(test_record, reason)
        updated = remove_test_method(source, test_record.test_name)
        recalculate_registry_ranges(
            outcome,
            updated,
            fixture_method_names=fixture_method_names_from_context(ctx),
            persist=True,
        )
        store.remove(test_record, reason)
        return updated

    def _repair_one_registry_test(
        self,
        *,
        ctx: GenerationContext,
        test_path: Path,
        module: ModuleInfo,
        outcome: TargetOutcome,
        current: str,
        test_record: TestCaseRecord,
        diagnostics,
        unresolved_test_ids: set[str],
    ) -> tuple[str, bool]:
        store = RegistryStore(outcome)
        diagnostic_dicts = [
            item.to_dict() if hasattr(item, "to_dict") else _audit_compile_errors([item], current)[0]
            for item in diagnostics
        ]
        if test_record.compile_state == CompileState.NOT_RUN.value:
            store.transition_compile_state(
                test_record,
                CompileState.FAILED,
                diagnostics=diagnostic_dicts,
            )
        store.transition_compile_state(
            test_record,
            CompileState.DETERMINISTIC_REPAIR_PENDING,
            diagnostics=diagnostic_dicts,
        )
        deterministic_source, actions, validation_state = self._deterministic_focused_candidate(
            ctx,
            test_record,
            [item.diagnostic if hasattr(item, "diagnostic") else item for item in diagnostics],
        )
        for action in actions:
            store.append_history(test_record, "deterministic_repair_history", action)
        if deterministic_source is not None:
            store.set_candidate(test_record, deterministic_source)
            full_candidate = self._replace_exact_test_source(
                current, test_record.test_name, deterministic_source
            )
            if full_candidate is not None:
                result, candidate_errors, attempt = self._compile_focused_candidate_once(
                    ctx=ctx,
                    test_path=test_path,
                    module=module,
                    outcome=outcome,
                    selected_test=test_record,
                    full_candidate_source=full_candidate,
                    unresolved_test_ids=unresolved_test_ids,
                    stage="deterministic_candidate",
                    validation_result=validation_state,
                )
                if result.ok:
                    self._commit_focused_candidate(
                        ctx=ctx,
                        outcome=outcome,
                        test_record=test_record,
                        full_source=full_candidate,
                        repair_kind="deterministic",
                        compile_attempt=attempt,
                    )
                    test_path.write_text(full_candidate, encoding="utf-8")
                    return full_candidate, True
                store.rollback_candidate(
                    test_record,
                    failed_attempt=attempt,
                    history_field="compile_attempts",
                )
                recalculate_registry_ranges(
                    outcome,
                    current,
                    fixture_method_names=fixture_method_names_from_context(ctx),
                    persist=True,
                )
                test_path.write_text(current, encoding="utf-8")
            else:
                store.rollback_candidate(
                    test_record,
                    failed_attempt={
                        "stage": "deterministic_candidate",
                        "validation_result": "class replacement failed",
                        "decision": "ROLLBACK",
                    },
                )
        else:
            store.append_history(
                test_record,
                "deterministic_repair_history",
                {"action": "deterministic_compile_repair_rejected", "reason": validation_state},
            )

        store.transition_compile_state(
            test_record,
            CompileState.LLM_REPAIR_PENDING,
            diagnostics=diagnostic_dicts,
        )
        llm_source, metadata, llm_state = self._focused_llm_response(
            ctx=ctx,
            outcome=outcome,
            test_record=test_record,
            diagnostics=[item.diagnostic if hasattr(item, "diagnostic") else item for item in diagnostics],
        )
        metadata_dict = metadata.to_dict() if metadata is not None else {
            "response_state": "ERROR",
            "rejection_reason": llm_state,
        }
        store.append_history(
            test_record,
            "llm_repair_history",
            {
                "action": "focused_compile_repair_response",
                "status": "candidate" if llm_source is not None else "rejected",
                "provider_metadata": metadata_dict,
                "rejection_reason": None if llm_source is not None else llm_state,
            },
        )
        if llm_source is not None:
            store.set_candidate(test_record, llm_source)
            full_candidate = self._replace_exact_test_source(
                current, test_record.test_name, llm_source
            )
            if full_candidate is not None:
                result, candidate_errors, attempt = self._compile_focused_candidate_once(
                    ctx=ctx,
                    test_path=test_path,
                    module=module,
                    outcome=outcome,
                    selected_test=test_record,
                    full_candidate_source=full_candidate,
                    unresolved_test_ids=unresolved_test_ids,
                    stage="llm_candidate",
                    validation_result=llm_state,
                    request_metadata=metadata_dict,
                )
                if result.ok:
                    self._commit_focused_candidate(
                        ctx=ctx,
                        outcome=outcome,
                        test_record=test_record,
                        full_source=full_candidate,
                        repair_kind="llm",
                        compile_attempt=attempt,
                    )
                    test_path.write_text(full_candidate, encoding="utf-8")
                    return full_candidate, True
                store.rollback_candidate(
                    test_record,
                    failed_attempt=attempt,
                    history_field="compile_attempts",
                )
                recalculate_registry_ranges(
                    outcome,
                    current,
                    fixture_method_names=fixture_method_names_from_context(ctx),
                    persist=True,
                )
                test_path.write_text(current, encoding="utf-8")
            else:
                store.rollback_candidate(
                    test_record,
                    failed_attempt={
                        "stage": "llm_candidate",
                        "validation_result": "class replacement failed",
                        "decision": "ROLLBACK",
                        "request_response_metadata": metadata_dict,
                    },
                )

        reason = llm_state or "focused compile repair exhausted"
        updated = self._reject_and_remove_compile_test(
            ctx=ctx,
            outcome=outcome,
            test_record=test_record,
            source=current,
            reason=reason,
        )
        test_path.write_text(updated, encoding="utf-8")
        return updated, False

    def _compile_registry_focused_repair(
        self,
        ctx: GenerationContext,
        test_path: Path,
        module: ModuleInfo,
        outcome: TargetOutcome,
        errors,
    ) -> str | None:
        """Phase 5 ServiceImpl repair: one registry-owned test per transaction."""
        outcome.complete_class_serviceimpl_llm_repair_attempts = 0
        current = test_path.read_text(encoding="utf-8")
        fixture_names = fixture_method_names_from_context(ctx)
        processed: set[str] = set()
        current_errors = list(errors)

        while True:
            recalculate_registry_ranges(
                outcome,
                current,
                fixture_method_names=fixture_names,
                persist=True,
            )
            ownership = map_compile_diagnostics(outcome, current_errors)
            self._persist_diagnostic_buckets(outcome, ownership)
            if ownership.assembly:
                outcome.notes.append("assembly-level compile diagnostics are not eligible for test-level repair")
                break
            pending = [test_id for test_id in ownership.by_test if test_id not in processed]
            unresolved = set(ownership.by_test)
            for test_id in pending:
                processed.add(test_id)
                test_record = RegistryStore(outcome).find(test_id)
                current, _accepted = self._repair_one_registry_test(
                    ctx=ctx,
                    test_path=test_path,
                    module=module,
                    outcome=outcome,
                    current=current,
                    test_record=test_record,
                    diagnostics=ownership.by_test[test_id],
                    unresolved_test_ids=unresolved,
                )
                unresolved.discard(test_id)

            recalculate_registry_ranges(
                outcome,
                current,
                fixture_method_names=fixture_names,
                persist=True,
            )
            test_path.write_text(current, encoding="utf-8")
            started = perf_counter()
            result, final_errors = self._compile_candidate(test_path, module)
            elapsed = perf_counter() - started
            final_attempt = {
                "attempt_number": len(outcome.compile_history) + 1,
                "stage": "reassembled_class_compile",
                "test_id": None,
                "candidate_hash": source_hash(current),
                "diagnostics": _audit_compile_errors(final_errors, current),
                "validation_result": "RANGES_RECALCULATED",
                "compilation_result": "PASSED" if result.ok else "FAILED",
                "decision": "COMMIT" if result.ok else "RECLASSIFY",
                "elapsed_seconds": elapsed,
            }
            outcome.compile_history.append(final_attempt)
            if result.ok:
                sync_test_registry_sources(
                    outcome,
                    current,
                    compile_state=CompileState.PASSED.value,
                    accepted=True,
                )
                recalculate_registry_ranges(
                    outcome,
                    current,
                    fixture_method_names=fixture_names,
                    persist=True,
                )
                return current

            current_errors = list(final_errors)
            new_ownership = map_compile_diagnostics(outcome, current_errors)
            self._persist_diagnostic_buckets(outcome, new_ownership)
            new_tests = [test_id for test_id in new_ownership.by_test if test_id not in processed]
            if new_tests:
                continue
            break

        test_path.write_text(current, encoding="utf-8")
        failure_store = RegistryStore(outcome)
        for method_record in outcome.method_results:
            for test_record in method_record.tests:
                if test_record.candidate_source:
                    failure_store.discard_candidate(test_record)
        outcome.compile_errors = [error.render() for error in current_errors]
        return None

    def _disabled_complete_class_serviceimpl_repair(self, *args, **kwargs):
        """Phase 5 invariant: complete-class ServiceImpl LLM compile repair is disabled."""
        raise RuntimeError("complete-class ServiceImpl LLM compile repair is disabled")

    def _compile_methodwise_repair(
        self,
        ctx: GenerationContext,
        test_path: Path,
        module: ModuleInfo,
        outcome: TargetOutcome,
        errors,
    ) -> str | None:
        current = test_path.read_text(encoding="utf-8")
        blocked_owners: set[str] = set()
        log.debug(
            "[METHOD_COMPILE_REPAIR] start | target=%s | test=%s | initial_errors=%d | max_repairs=%d",
            ctx.symbol.fqcn, test_path.name, len(errors), self.cfg.max_compile_repairs,
        )
        for attempt in range(self.cfg.max_compile_repairs):
            baseline_current = current
            baseline_errors = list(errors)
            mapped_before = [(error, owner_method_id_for_line(current, error.line)) for error in errors]
            unmapped = [error for error, owner in mapped_before if owner is None]
            previous_total = len(errors)

            # Header/import/fixture diagnostics have no method owner and require
            # their own bounded class-surface repair path. They must not be
            # silently discarded while method blocks are repaired.
            if unmapped:
                log.debug(
                    "[METHOD_COMPILE_REPAIR] header.route | attempt=%d/%d | unmapped_errors=%d",
                    attempt + 1, self.cfg.max_compile_repairs, len(unmapped),
                )
                repaired_header = self._repair_methodwise_header_errors(
                    ctx, current, unmapped, outcome,
                    label=f"class header/import/fixture repair {attempt + 1}",
                )
                if repaired_header is not None and repaired_header != current:
                    test_path.write_text(repaired_header, encoding="utf-8")
                    result, header_errors = self._compile_candidate(test_path, module)
                    if result.ok:
                        _mark_retained_compile_state(outcome, "PASSED")
                        sync_test_registry_sources(outcome, repaired_header, compile_state="PASSED", accepted=True)
                        return repaired_header
                    if _compile_candidate_is_strict_progress(
                        baseline_current,
                        baseline_errors,
                        repaired_header,
                        header_errors,
                    ):
                        current = repaired_header
                        errors = header_errors
                        log.debug(
                            "[METHOD_COMPILE_REPAIR] header.recompile.failed_but_improved | "
                            "attempt=%d/%d | remaining_errors=%d",
                            attempt + 1,
                            self.cfg.max_compile_repairs,
                            len(errors),
                        )
                        continue
                    test_path.write_text(baseline_current, encoding="utf-8")
                    current = baseline_current
                    errors = baseline_errors
                    outcome.notes.append(
                        f"class header/import/fixture repair {attempt + 1} rolled back: "
                        f"errors {len(baseline_errors)}->{len(header_errors)}"
                    )
                    log.debug(
                        "[METHOD_COMPILE_REPAIR] header.candidate.rollback | attempt=%d/%d | "
                        "before=%d | after=%d",
                        attempt + 1,
                        self.cfg.max_compile_repairs,
                        len(baseline_errors),
                        len(header_errors),
                    )

            deterministic = self._repair_compile_diagnostics_deterministically(
                ctx,
                current,
                errors,
                outcome,
                label=f"deterministic compile repair {attempt + 1}",
            )
            if deterministic is not None and deterministic != current:
                structure_error = test_class_structure_error(
                    deterministic, ctx.test_class_name
                )
                if structure_error:
                    outcome.notes.append(
                        f"deterministic compile repair {attempt + 1} rolled back: {structure_error}"
                    )
                else:
                    test_path.write_text(deterministic, encoding="utf-8")
                    result, deterministic_errors = self._compile_candidate(test_path, module)
                    if result.ok:
                        self._commit_deterministic_compile_actions(outcome, "PASSED")
                        log.debug(
                            "[METHOD_COMPILE_REPAIR] deterministic.recompile.success | "
                            "attempt=%d/%d | test=%s",
                            attempt + 1,
                            self.cfg.max_compile_repairs,
                            test_path.name,
                        )
                        _mark_retained_compile_state(outcome, "PASSED")
                        sync_test_registry_sources(outcome, deterministic, compile_state="PASSED", accepted=True)
                        return deterministic
                    deterministic_progress = _compile_candidate_is_strict_progress(
                        baseline_current,
                        baseline_errors,
                        deterministic,
                        deterministic_errors,
                    )
                    log.debug(
                        "[METHOD_COMPILE_REPAIR] deterministic.progress | attempt=%d/%d | "
                        "total_before=%d | total_after=%d | accepted=%s",
                        attempt + 1,
                        self.cfg.max_compile_repairs,
                        len(baseline_errors),
                        len(deterministic_errors),
                        deterministic_progress,
                    )
                    if deterministic_progress:
                        self._commit_deterministic_compile_actions(
                            outcome, "DETERMINISTIC_REPAIRED_PENDING_COMPILE"
                        )
                        current = deterministic
                        errors = deterministic_errors
                        log.debug(
                            "[METHOD_COMPILE_REPAIR] deterministic.recompile.failed_but_improved | "
                            "attempt=%d/%d | remaining_errors=%d",
                            attempt + 1,
                            self.cfg.max_compile_repairs,
                            len(errors),
                        )
                        continue
                test_path.write_text(baseline_current, encoding="utf-8")
                current = baseline_current
                errors = baseline_errors

            log.debug(
                "[METHOD_COMPILE_REPAIR] attempt.start | attempt=%d/%d | current_errors=%d | blocked_owners=%s",
                attempt + 1, self.cfg.max_compile_repairs, len(errors), sorted(blocked_owners),
            )
            repaired = self._repair_methodwise_error_batch(
                ctx, current, errors, outcome,
                label=f"method compile repair {attempt + 1}",
                excluded_owners=blocked_owners,
            )
            selected_owner = getattr(self, "_last_methodwise_repair_owner", None)
            selected_test = getattr(self, "_last_methodwise_repair_test", None)
            source_changed = bool(getattr(self, "_last_methodwise_repair_changed", False))
            before_owner_errors = [
                error for error, owner in mapped_before if owner == selected_owner
            ]
            if repaired is None:
                if selected_owner and selected_owner not in blocked_owners:
                    blocked_owners.add(selected_owner)
                    outcome.notes.append(
                        f"compile repair candidate rejected [{selected_owner}]; "
                        "selecting a different failing owner next"
                    )
                    log.debug(
                        "[METHOD_COMPILE_REPAIR] attempt.rejected | attempt=%d/%d | "
                        "owner=%s | rollback=true",
                        attempt + 1,
                        self.cfg.max_compile_repairs,
                        selected_owner,
                    )
                    test_path.write_text(baseline_current, encoding="utf-8")
                    current = baseline_current
                    errors = baseline_errors
                    continue
                log.debug(
                    "[METHOD_COMPILE_REPAIR] attempt.stopped | attempt=%d/%d | no_repaired_class=true",
                    attempt + 1, self.cfg.max_compile_repairs,
                )
                break
            structure_error = test_class_structure_error(repaired, ctx.test_class_name)
            if structure_error:
                if selected_owner:
                    blocked_owners.add(selected_owner)
                outcome.notes.append(
                    f"compile repair rolled back [{selected_owner}/{selected_test}]: {structure_error}"
                )
                log.debug(
                    "[METHOD_COMPILE_REPAIR] structure.rollback | attempt=%d/%d | owner=%s | "
                    "test=%s | reason=%s",
                    attempt + 1,
                    self.cfg.max_compile_repairs,
                    selected_owner,
                    selected_test,
                    structure_error,
                )
                test_path.write_text(baseline_current, encoding="utf-8")
                current = baseline_current
                errors = baseline_errors
                continue
            test_path.write_text(repaired, encoding="utf-8")
            log.debug(
                "[METHOD_COMPILE_REPAIR] recompile.start | attempt=%d/%d | test=%s | owner=%s",
                attempt + 1, self.cfg.max_compile_repairs, test_path.name, selected_owner,
            )
            result, candidate_errors = self._compile_candidate(test_path, module)
            if result.ok:
                self._commit_methodwise_llm_repair(outcome, "PASSED")
                log.debug(
                    "[METHOD_COMPILE_REPAIR] recompile.success | attempt=%d/%d | test=%s",
                    attempt + 1, self.cfg.max_compile_repairs, test_path.name,
                )
                _mark_retained_compile_state(outcome, "PASSED")
                sync_test_registry_sources(outcome, repaired, compile_state="PASSED", accepted=True)
                return repaired

            mapped_after = [(error, owner_method_id_for_line(repaired, error.line)) for error in candidate_errors]
            after_owner_errors = [error for error, owner in mapped_after if owner == selected_owner]
            before_test_errors = [
                error for error in baseline_errors
                if test_method_name_for_line(baseline_current, error.line) == selected_test
            ]
            after_test_errors = [
                error for error in candidate_errors
                if test_method_name_for_line(repaired, error.line) == selected_test
            ]
            materially_improved = (
                source_changed
                and len(after_test_errors) < len(before_test_errors)
                and _compile_candidate_is_strict_progress(
                    baseline_current,
                    baseline_errors,
                    repaired,
                    candidate_errors,
                    selected_owner=selected_owner,
                )
            )
            log.debug(
                "[METHOD_COMPILE_REPAIR] progress | owner=%s | source_changed=%s | "
                "test_errors_before=%d | test_errors_after=%d | owner_errors_before=%d | "
                "owner_errors_after=%d | total_before=%d | total_after=%d | materially_improved=%s",
                selected_owner, source_changed, len(before_test_errors), len(after_test_errors),
                len(before_owner_errors), len(after_owner_errors), previous_total, len(candidate_errors),
                materially_improved,
            )
            if not materially_improved:
                if selected_owner:
                    blocked_owners.add(selected_owner)
                outcome.notes.append(
                    f"compile repair rolled back [{selected_owner}/{selected_test}]: "
                    f"errors {len(baseline_errors)}->{len(candidate_errors)}, "
                    f"owner {len(before_owner_errors)}->{len(after_owner_errors)}"
                )
                test_path.write_text(baseline_current, encoding="utf-8")
                current = baseline_current
                errors = baseline_errors
                log.debug(
                    "[METHOD_COMPILE_REPAIR] candidate.rollback | attempt=%d/%d | owner=%s | "
                    "test=%s | total_before=%d | total_after=%d",
                    attempt + 1,
                    self.cfg.max_compile_repairs,
                    selected_owner,
                    selected_test,
                    len(baseline_errors),
                    len(candidate_errors),
                )
                continue
            current = repaired
            errors = candidate_errors
            self._commit_methodwise_llm_repair(
                outcome, "REPAIRED_PENDING_COMPILE"
            )
            log.debug(
                "[METHOD_COMPILE_REPAIR] recompile.failed | attempt=%d/%d | remaining_errors=%d",
                attempt + 1, self.cfg.max_compile_repairs, len(errors),
            )

        salvaged = self._reject_irreparable_compile_tests(
            ctx, current, test_path, module, outcome, errors
        )
        if salvaged is not None:
            return salvaged
        outcome.compile_errors = [error.render() for error in errors][:12]
        log.error(
            "[METHOD_COMPILE_REPAIR] exhausted | test=%s | remaining_errors=%d | saved_to_outcome=%d",
            test_path.name, len(errors), len(outcome.compile_errors),
        )
        return None

    def _repair_methodwise_header_errors(
        self,
        ctx: GenerationContext,
        current: str,
        errors,
        outcome: TargetOutcome,
        *,
        label: str,
    ) -> str | None:
        if not errors or self.llm is None or not getattr(ctx, "symbol", None):
            return None
        outcome.notes.append(f"{label}: {len(errors)} unmapped error(s)")
        builder = payload_builder_for_context(ctx)
        messages = builder.build_compile_repair_payload(ctx, current, list(errors), None, mode="classwide")
        raw = self._chat(messages, self.cfg.temperature_repair, self.cfg.max_tokens_repair, outcome)
        candidate = inject_reusable_fixtures(raw or "", ctx)
        finalized = finalize_java(
            candidate, test_package=ctx.test_package, test_class_name=ctx.test_class_name,
            template=ctx.template, cut_symbol=ctx.symbol, collaborators=ctx.collaborators,
            source_imports=ctx.source_imports,
        )
        if not finalized.ok or not finalized.code:
            outcome.notes.append(f"{label} rejected: {finalized.reason}")
            return None
        before_tests = {test.name: test.source.strip() for test in extract_generated_tests(current)}
        after_tests = {test.name: test.source.strip() for test in extract_generated_tests(finalized.code)}
        if before_tests != after_tests:
            missing = sorted(set(before_tests) - set(after_tests))
            outcome.tests_lost_during_compile_repair += len(missing)
            outcome.notes.append(
                f"{label} rejected: header/import repair changed test methods; missing={missing}"
            )
            return None
        structure_error = test_class_structure_error(finalized.code, ctx.test_class_name)
        if structure_error:
            outcome.notes.append(f"{label} rejected: {structure_error}")
            return None
        return finalized.code

    def _repair_methodwise_error_batch(
        self,
        ctx: GenerationContext,
        current: str,
        errors,
        outcome: TargetOutcome,
        *,
        label: str,
        excluded_owners: set[str] | None = None,
    ) -> str | None:
        """Repair only one generated block owning authoritative compiler errors."""
        self._last_methodwise_repair_owner = None
        self._last_methodwise_repair_test = None
        self._last_methodwise_repair_changed = False
        self._last_methodwise_repair_record = None
        excluded_owners = excluded_owners or set()
        mapped_errors = [
            (error, owner_method_id_for_line(current, error.line))
            for error in errors
        ]
        for index, (error, owner) in enumerate(mapped_errors, start=1):
            log.debug(
                "[METHOD_COMPILE_REPAIR] diagnostic.map | label=%s | diagnostic=%d/%d | "
                "line=%s | owner=%s | message=%s",
                label,
                index,
                len(mapped_errors),
                error.line if error.line is not None else "n/a",
                owner or "<outside-generated-method-block>",
                error.message,
            )

        owners = [owner for _, owner in mapped_errors if owner]
        if not owners:
            # The failing line is OUTSIDE any generated method block -- almost always
            # a header issue (missing import, or a type invented in a body that has no
            # import). Name it loudly instead of dying silently: list the exact
            # compiler errors so the cause is visible in the report, and flag the
            # likely invented-type case for the schema/import work.
            rendered = [e.render() for e in errors][:8]
            outcome.notes.append(
                f"{label} stopped: compile error outside any generated method block "
                f"(header/import). Errors: " + " | ".join(rendered)
            )
            log.error(
                "[METHOD_COMPILE_REPAIR] stop.unmapped | label=%s | errors=%d | reason=header_or_import",
                label,
                len(errors),
            )
            for e in errors:
                msg = (e.render() or "").lower()
                if "cannot find symbol" in msg or "cannot be resolved" in msg:
                    outcome.notes.append(
                        f"{label} likely unimported or invented type at "
                        f"line {e.line}: {e.render()}"
                    )
            return None

        owner, owner_counts, unmapped_count = _select_method_repair_owner(
            current, errors, excluded_owners
        )
        if owner is None:
            outcome.notes.append(f"{label} stopped: all failing method owners made no progress")
            log.error(
                "[METHOD_COMPILE_REPAIR] stop.no_eligible_owner | label=%s | owner_counts=%s | excluded=%s",
                label, dict(owner_counts), sorted(excluded_owners),
            )
            return None
        self._last_methodwise_repair_owner = owner
        log.debug(
            "[METHOD_COMPILE_REPAIR] owner.select | label=%s | selected=%s | owner_counts=%s | "
            "unmapped_errors=%d",
            label,
            owner,
            dict(owner_counts),
            unmapped_count,
        )
        method_by_id = {
            f"{method.name}({','.join(type_name for type_name, _ in method.params)})": method
            for method in (ctx.symbol.methods or [])
        }
        context_by_id = {
            method.method_id: method
            for method in (ctx.execution_context.methods if ctx.execution_context else ())
        }
        production_method = method_by_id.get(owner)
        method_context = context_by_id.get(owner)
        block = method_block_for_id(current, owner)
        if production_method is None or method_context is None or block is None:
            outcome.notes.append(f"{label} stopped: context missing for {owner}")
            log.error(
                "[METHOD_COMPILE_REPAIR] stop.context_missing | label=%s | owner=%s | "
                "production_method=%s | method_context=%s | block=%s",
                label,
                owner,
                production_method is not None,
                method_context is not None,
                block is not None,
            )
            return None

        owner_errors = [
            error for error, mapped_owner in mapped_errors
            if mapped_owner == owner
        ] or list(errors)
        test_error_groups: dict[str, list] = defaultdict(list)
        for error in owner_errors:
            test_name = test_method_name_for_line(current, error.line)
            if test_name:
                test_error_groups[test_name].append(error)
        if not test_error_groups:
            outcome.notes.append(
                f"{label} stopped [{owner}]: owner diagnostics could not be mapped to an individual test"
            )
            log.error(
                "[METHOD_COMPILE_REPAIR] stop.test_unmapped | label=%s | owner=%s | errors=%d",
                label, owner, len(owner_errors),
            )
            return None

        selected_test, selected_errors = sorted(
            test_error_groups.items(), key=lambda item: (-len(item[1]), item[0])
        )[0]
        self._last_methodwise_repair_test = selected_test
        extracted_test = test_method_for_name(block, selected_test)
        if extracted_test is None:
            outcome.notes.append(f"{label} stopped [{owner}/{selected_test}]: test source missing")
            return None
        test_source = extracted_test.source

        outcome.notes.append(
            f"{label} [{owner}/{selected_test}]: {len(selected_errors)} error(s)"
        )
        log.debug(
            "[METHOD_COMPILE_REPAIR] llm.scope | label=%s | selected_owner=%s | selected_test=%s | "
            "errors_sent=%d | owner_compile_errors=%d | sibling_tests_preserved=%d | test_chars=%d",
            label,
            owner,
            selected_test,
            len(selected_errors),
            len(owner_errors),
            max(0, len(test_method_names(block)) - 1),
            len(test_source),
        )
        for index, error in enumerate(selected_errors, start=1):
            log.error(
                "[METHOD_COMPILE_REPAIR] llm.diagnostic %d/%d | owner=%s | test=%s | %s",
                index,
                len(selected_errors),
                owner,
                selected_test,
                error.render().replace("\n", " | "),
            )
        builder = payload_builder_for_context(ctx)
        messages = builder.build_compile_repair_payload(
            ctx=ctx,
            method=production_method,
            current_test=test_source,
            test_name=selected_test,
            errors=selected_errors,
            mode="individual",
        )
        raw = self._chat(
            messages,
            self.cfg.temperature_repair,
            self.cfg.max_tokens_repair,
            outcome,
        )
        extracted = extract_generated_tests(raw or "")
        if len(extracted) != 1 or extracted[0].name != selected_test:
            outcome.notes.append(
                f"{label} rejected [{owner}/{selected_test}]: repair must return the exact individual test"
            )
            log.debug(
                "[METHOD_COMPILE_REPAIR] identity.rejected | label=%s | owner=%s | test=%s | returned=%s",
                label, owner, selected_test, [test.name for test in extracted],
            )
            return None
        replacement = normalize_writable_map_mutations(extracted[0].source)
        deterministic = deterministically_repair_test(
            ctx, production_method, method_context, replacement
        )
        replacement = deterministic.source
        existing_names = set(test_method_names(current)) - {selected_test}
        validation = validate_method_block(
            ctx,
            production_method,
            method_context,
            replacement,
            existing_names,
        )
        if not validation.ok or tuple(validation.test_names) != (selected_test,):
            reason = validation.reason if not validation.ok else "test identity changed"
            outcome.notes.append(f"{label} rejected [{owner}/{selected_test}]: {reason}")
            log.debug(
                "[METHOD_COMPILE_REPAIR] validation.rejected | label=%s | owner=%s | test=%s | reason=%s",
                label, owner, selected_test, reason,
            )
            return None

        updated_block = replace_test_method(block, selected_test, replacement)
        if updated_block is None:
            outcome.notes.append(
                f"{label} rejected [{owner}/{selected_test}]: individual replacement failed"
            )
            return None
        if set(test_method_names(updated_block)) != set(test_method_names(block)):
            outcome.notes.append(
                f"{label} rejected [{owner}/{selected_test}]: sibling test identity changed"
            )
            return None
        candidate = replace_method_block(current, owner, updated_block)
        finalized = finalize_java(
            candidate,
            test_package=ctx.test_package,
            test_class_name=ctx.test_class_name,
            template=ctx.template,
            cut_symbol=ctx.symbol,
            collaborators=ctx.collaborators,
            source_imports=ctx.source_imports,
        )
        if not finalized.ok or not finalized.code:
            outcome.notes.append(f"{label} rejected [{owner}/{selected_test}]: {finalized.reason}")
            log.debug(
                "[METHOD_COMPILE_REPAIR] finalize.rejected | label=%s | owner=%s | test=%s | reason=%s",
                label, owner, selected_test, finalized.reason or "unknown",
            )
            return None
        structure_error = test_class_structure_error(finalized.code, ctx.test_class_name)
        if structure_error:
            outcome.notes.append(
                f"{label} rejected [{owner}/{selected_test}]: {structure_error}"
            )
            log.debug(
                "[METHOD_COMPILE_REPAIR] finalize.structure_rejected | label=%s | "
                "owner=%s | test=%s | reason=%s",
                label,
                owner,
                selected_test,
                structure_error,
            )
            return None
        if set(test_method_names(finalized.code)) != set(test_method_names(current)):
            outcome.tests_lost_during_compile_repair += max(
                0, len(test_method_names(current)) - len(test_method_names(finalized.code))
            )
            outcome.notes.append(
                f"{label} rejected [{owner}/{selected_test}]: finalization changed test identity"
            )
            return None
        before_sources = {
            test.name: test.source.strip() for test in extract_generated_tests(current)
        }
        after_sources = {
            test.name: test.source.strip() for test in extract_generated_tests(finalized.code)
        }
        changed_siblings = sorted(
            name
            for name, source in before_sources.items()
            if name != selected_test and after_sources.get(name) != source
        )
        if changed_siblings:
            outcome.notes.append(
                f"{label} rejected [{owner}/{selected_test}]: sibling source changed: "
                + ", ".join(changed_siblings)
            )
            log.debug(
                "[METHOD_COMPILE_REPAIR] sibling_source.rejected | label=%s | owner=%s | "
                "test=%s | changed_siblings=%s",
                label,
                owner,
                selected_test,
                changed_siblings,
            )
            return None
        self._last_methodwise_repair_changed = replacement.strip() != test_source.strip()
        self._last_methodwise_repair_record = (
            owner,
            selected_test,
            replacement,
            tuple(deterministic.actions),
            label,
        )
        log.debug(
            "[METHOD_COMPILE_REPAIR] finalize.accepted | label=%s | owner=%s | test=%s | "
            "class_chars=%d | test_changed=%s",
            label, owner, selected_test, len(finalized.code), self._last_methodwise_repair_changed,
        )
        return finalized.code

    def _commit_methodwise_llm_repair(self, outcome: TargetOutcome, state: str) -> None:
        pending = getattr(self, "_last_methodwise_repair_record", None)
        if not pending:
            return
        owner, selected_test, replacement, deterministic_actions, label = pending
        store = RegistryStore(outcome)
        for record in outcome.method_results:
            if record.method_id != owner:
                continue
            for test in record.tests:
                if test.test_name != selected_test:
                    continue
                store.set_candidate(test, replacement)
                for action in deterministic_actions:
                    store.append_history(test, "deterministic_repair_history", action)
                store.append_history(
                    test,
                    "llm_repair_history",
                    {"action": "compile_repair", "label": label, "status": "accepted"},
                )
                target_state = state
                if state == CompileState.PASSED.value and test.compile_state != CompileState.NOT_RUN.value:
                    target_state = CompileState.REPAIRED_AND_PASSED.value
                store.transition_compile_state(test, target_state)

    def _recover_maven_compile(self, ctx, module, test_path, run, outcome):
        """Repair authoritative Maven compile failures without regenerating other methods."""
        target_kind = (
            ctx.execution_context.target_kind.value
            if ctx.execution_context is not None
            else ""
        )
        serviceimpl = target_kind == "service-impl"
        methodwise = target_kind in {"controller", "service-impl"}
        for attempt in range(self.cfg.max_compile_repairs):
            if run.ok:
                return run
            own = self._own_maven_errors(run.log_tail, test_path)
            if not own:
                return run  # not our compile error (sibling/env) -> genuinely unmeasured

            if serviceimpl:
                repaired = self._compile_registry_focused_repair(
                    ctx, test_path, module, outcome, own
                )
                if repaired is None:
                    return run
                test_path.write_text(repaired, encoding="utf-8")
            elif methodwise:
                current = test_path.read_text(encoding="utf-8")
                repaired = self._repair_methodwise_error_batch(
                    ctx,
                    current,
                    own,
                    outcome,
                    label=f"maven method compile repair {attempt + 1}",
                )
                if repaired is None:
                    return run
                test_path.write_text(repaired, encoding="utf-8")
            else:
                outcome.notes.append(f"maven compile repair: {len(own)} error(s)")
                kb_hints = self.kb.hints_for([e.message for e in own]) if self.kb else None
                builder = payload_builder_for_context(ctx)
                messages = builder.build_compile_repair_payload(
                    ctx,
                    test_path.read_text(encoding="utf-8"),
                    own,
                    kb_hints,
                    mode="classwide",
                )
                raw = self._chat(
                    messages,
                    self.cfg.temperature_repair,
                    self.cfg.max_tokens_repair,
                    outcome,
                )
                candidate = inject_reusable_fixtures(raw or "", ctx)
                res = finalize_java(
                    candidate,
                    test_package=ctx.test_package,
                    test_class_name=ctx.test_class_name,
                    template=ctx.template,
                    cut_symbol=ctx.symbol,
                    collaborators=ctx.collaborators,
                    source_imports=ctx.source_imports,
                )
                if not res.ok or not res.code:
                    return run
                test_path.write_text(res.code, encoding="utf-8")

            run = self._measure_coverage(self.coverage_runner, 
                module,
                test_classes=[self._test_fqcn(ctx)],
            )
        return run
