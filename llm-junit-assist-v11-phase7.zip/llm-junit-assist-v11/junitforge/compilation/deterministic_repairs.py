"""Deterministic compiler-diagnostic repairs and action recording."""

from __future__ import annotations

import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    CompileState,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get
from junitforge.registry import RegistryStore

log = get("junitforge.loop")
from junitforge.generation.response_extractor import extract_generated_tests



class DeterministicRepairsMixin:
    def _repair_compile_diagnostics_deterministically(
        self,
        ctx: GenerationContext,
        current: str,
        errors,
        outcome: TargetOutcome,
        *,
        label: str,
    ) -> str | None:
        """Apply compiler-driven source-backed repairs to every affected test."""
        self._last_deterministic_compile_actions = {}
        method_by_id = {
            f"{method.name}({','.join(type_name for type_name, _ in method.params)})": method
            for method in (ctx.symbol.methods or [])
        }
        context_by_id = {
            method.method_id: method
            for method in (ctx.execution_context.methods if ctx.execution_context else ())
        }
        grouped: dict[tuple[str, str], list] = defaultdict(list)
        for error in errors:
            owner = owner_method_id_for_line(current, error.line)
            test_name = test_method_name_for_line(current, error.line)
            if owner and test_name:
                grouped[(owner, test_name)].append(error)
        if not grouped:
            return None

        candidate = current
        changed_tests: set[str] = set()
        actions_by_test: dict[tuple[str, str], tuple[str, ...]] = {}
        for (owner, test_name), selected_errors in sorted(grouped.items()):
            production_method = method_by_id.get(owner)
            method_context = context_by_id.get(owner)
            block = method_block_for_id(candidate, owner)
            if production_method is None or method_context is None or block is None:
                continue
            extracted = test_method_for_name(block, test_name)
            if extracted is None:
                continue
            compiler_repair = deterministically_repair_compile_diagnostics(
                ctx,
                production_method,
                method_context,
                extracted.source,
                selected_errors,
            )
            if not compiler_repair.changed:
                continue
            focused = deterministically_repair_test(
                ctx,
                production_method,
                method_context,
                compiler_repair.source,
            )
            replacement = focused.source
            existing_names = set(test_method_names(candidate)) - {test_name}
            validation = validate_method_block(
                ctx,
                production_method,
                method_context,
                replacement,
                existing_names,
            )
            if not validation.ok or tuple(validation.test_names) != (test_name,):
                log.debug(
                    "[METHOD_COMPILE_REPAIR] deterministic.rejected | label=%s | owner=%s | "
                    "test=%s | reason=%s",
                    label,
                    owner,
                    test_name,
                    validation.reason if not validation.ok else "test identity changed",
                )
                continue
            updated_block = replace_test_method(block, test_name, replacement)
            candidate = replace_method_block(candidate, owner, updated_block)
            changed_tests.add(test_name)
            actions_by_test[(owner, test_name)] = (
                tuple(compiler_repair.actions) + tuple(focused.actions)
            )
            log.debug(
                "[METHOD_COMPILE_REPAIR] deterministic.applied | label=%s | owner=%s | "
                "test=%s | actions=%s",
                label,
                owner,
                test_name,
                list(actions_by_test[(owner, test_name)]),
            )

        if not changed_tests:
            return None
        finalized = finalize_java(
            candidate,
            test_package=ctx.test_package,
            test_class_name=ctx.test_class_name,
            template=ctx.template,
            cut_symbol=ctx.symbol,
            collaborators=ctx.collaborators,
            source_imports=ctx.source_imports,
        )
        if not finalized.ok or not finalized.code:
            outcome.notes.append(f"{label} rejected: {finalized.reason}")
            return None
        structure_error = test_class_structure_error(finalized.code, ctx.test_class_name)
        if structure_error:
            outcome.notes.append(f"{label} rejected: {structure_error}")
            log.debug(
                "[METHOD_COMPILE_REPAIR] deterministic.structure_rejected | label=%s | reason=%s",
                label,
                structure_error,
            )
            return None

        before_tests = {test.name: test.source.strip() for test in extract_generated_tests(current)}
        after_tests = {test.name: test.source.strip() for test in extract_generated_tests(finalized.code)}
        if set(before_tests) != set(after_tests):
            outcome.notes.append(f"{label} rejected: deterministic repair changed test identity")
            return None
        modified = {name for name in before_tests if before_tests[name] != after_tests[name]}
        if not modified <= changed_tests:
            outcome.notes.append(
                f"{label} rejected: deterministic repair modified unaffected tests: "
                + ", ".join(sorted(modified - changed_tests))
            )
            return None
        self._last_deterministic_compile_actions = {
            key: (actions, after_tests.get(key[1], ""))
            for key, actions in actions_by_test.items()
        }
        return finalized.code

    def _commit_deterministic_compile_actions(self, outcome: TargetOutcome, state: str) -> None:
        pending = getattr(self, "_last_deterministic_compile_actions", {}) or {}
        store = RegistryStore(outcome)
        for record in outcome.method_results:
            for test in record.tests:
                value = pending.get((record.method_id, test.test_name))
                if not value:
                    continue
                actions, source = value
                if source:
                    store.set_candidate(test, source)
                for action in actions:
                    store.append_history(test, "deterministic_repair_history", action)
                target_state = state
                if state == CompileState.PASSED.value and test.compile_state != CompileState.NOT_RUN.value:
                    target_state = CompileState.REPAIRED_AND_PASSED.value
                store.transition_compile_state(test, target_state)
