"""CompileGate execution boundary used by generation and repair stages."""

from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors


def compile_candidate(compile_gate: CompileGate, test_path, module):
    return compile_gate.check(test_path, module)


class CompilerMixin:
    def _compile_candidate(self, test_path, module):
        return compile_candidate(self.compile_gate, test_path, module)


__all__ = [
    "CompileGate",
    "CompilerMixin",
    "compile_candidate",
    "parse_maven_compiler_errors",
]
