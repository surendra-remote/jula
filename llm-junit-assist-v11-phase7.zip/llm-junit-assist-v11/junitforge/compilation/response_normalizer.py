"""Strict normalization for focused one-test LLM compile-repair responses."""

from __future__ import annotations

from dataclasses import dataclass
import re

from junitforge.execution.assembly import extract_test_methods


@dataclass(slots=True, frozen=True)
class FocusedResponseNormalization:
    accepted: bool
    source: str = ""
    normalization_result: str = "REJECTED"
    rejection_reason: str | None = None
    probable_truncation: bool = False
    outer_fence_removed: bool = False


def _balanced_braces(source: str) -> bool:
    depth = 0
    quote: str | None = None
    escaped = False
    line_comment = False
    block_comment = False
    index = 0
    while index < len(source):
        char = source[index]
        nxt = source[index + 1] if index + 1 < len(source) else ""
        if line_comment:
            if char == "\n":
                line_comment = False
            index += 1
            continue
        if block_comment:
            if char == "*" and nxt == "/":
                block_comment = False
                index += 2
                continue
            index += 1
            continue
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            index += 1
            continue
        if char == "/" and nxt == "/":
            line_comment = True
            index += 2
            continue
        if char == "/" and nxt == "*":
            block_comment = True
            index += 2
            continue
        if char in {'"', "'"}:
            quote = char
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth < 0:
                return False
        index += 1
    return depth == 0 and quote is None and not block_comment


def normalize_focused_test_response(
    response: str | None,
    *,
    expected_test_name: str,
) -> FocusedResponseNormalization:
    raw = response or ""
    if not raw.strip():
        return FocusedResponseNormalization(False, rejection_reason="empty provider response")

    fence_count = raw.count("```")
    source = raw.strip()
    fence_removed = False
    if fence_count:
        if fence_count == 1:
            fence = re.search(r"(?m)^[ \t]*```(?P<label>[A-Za-z0-9_-]*)[ \t]*$", raw)
            before = raw[: fence.start()].strip() if fence else ""
            after = raw[fence.end():].strip() if fence else ""
            label = (fence.group("label") if fence else "").lower()
            opening = bool(label) or (not before and bool(after))
            if before and not after and not label:
                opening = False
            reason = "unmatched opening Markdown fence; probable truncation" if opening else "unmatched closing Markdown fence"
            return FocusedResponseNormalization(
                False,
                rejection_reason=reason,
                probable_truncation=opening,
            )
        if fence_count != 2:
            return FocusedResponseNormalization(False, rejection_reason="multiple or nested Markdown fences")
        match = re.fullmatch(
            r"\s*```(?:java)?[ \t]*\r?\n(?P<body>.*?)\r?\n```\s*",
            raw,
            flags=re.DOTALL | re.IGNORECASE,
        )
        if match is None:
            return FocusedResponseNormalization(False, rejection_reason="prose outside the single outer Markdown fence")
        source = match.group("body").strip()
        fence_removed = True

    if "```" in source:
        return FocusedResponseNormalization(False, rejection_reason="nested Markdown fence")
    if re.search(r"(?m)^\s*(?:package|import)\b", source):
        return FocusedResponseNormalization(False, rejection_reason="focused response contains package or imports")
    if re.search(r"\b(?:class|interface|enum|record)\s+[A-Za-z_$][\w$]*", source):
        return FocusedResponseNormalization(False, rejection_reason="focused response contains a type declaration")
    if not _balanced_braces(source):
        return FocusedResponseNormalization(
            False,
            rejection_reason="unbalanced Java braces; probable truncation",
            probable_truncation=True,
        )

    methods = extract_test_methods(source)
    if not methods:
        probable = "@Test" in source
        return FocusedResponseNormalization(
            False,
            rejection_reason="truncated Java; no complete @Test method" if probable else "no complete @Test method",
            probable_truncation=probable,
        )
    if len(methods) != 1:
        return FocusedResponseNormalization(False, rejection_reason="focused response contains multiple @Test methods")
    method = methods[0]
    if method.name != expected_test_name:
        return FocusedResponseNormalization(
            False,
            rejection_reason=f"wrong test identity: expected {expected_test_name}, got {method.name}",
        )
    if method.source.strip() != source.strip():
        return FocusedResponseNormalization(False, rejection_reason="prose or additional Java exists outside the @Test method")
    return FocusedResponseNormalization(
        True,
        source=method.source.strip(),
        normalization_result="OUTER_FENCE_REMOVED" if fence_removed else "RAW_JAVA_ACCEPTED",
        outer_fence_removed=fence_removed,
    )


__all__ = ["FocusedResponseNormalization", "normalize_focused_test_response"]
