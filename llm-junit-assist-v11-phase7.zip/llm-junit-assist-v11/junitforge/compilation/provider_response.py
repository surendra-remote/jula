"""Provider-response metadata and deterministic request/response hashing."""

from __future__ import annotations

from dataclasses import dataclass, asdict
import hashlib
import json
from typing import Any


def _canonical_json(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)


def request_hash(messages: list[dict], *, temperature: float, max_tokens: int) -> str:
    payload = {
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    return hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()


def response_hash(response_text: str | None) -> str:
    normalized = (response_text or "").replace("\r\n", "\n").replace("\r", "\n")
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


@dataclass(slots=True)
class FocusedProviderMetadata:
    response_state: str
    finish_reason: str | None
    input_token_count: int
    output_token_count: int
    response_size: int
    request_hash: str
    response_hash: str
    truncation_state: str
    normalization_result: str | None = None
    rejection_reason: str | None = None
    raw_provider_response: object | None = None

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def provider_metadata(
    response: object | None,
    *,
    request_digest: str,
    probable_truncation: bool = False,
    normalization_result: str | None = None,
    rejection_reason: str | None = None,
) -> FocusedProviderMetadata:
    message = getattr(response, "message", None) if response is not None else None
    usage = getattr(response, "usage", None) if response is not None else None
    finish_reason = getattr(response, "finish_reason", None) if response is not None else None
    raw = getattr(response, "raw", None) if response is not None else None
    if finish_reason is None and isinstance(raw, dict):
        choices = raw.get("choices") or []
        if choices and isinstance(choices[0], dict):
            finish_reason = choices[0].get("finish_reason")
    response_state = getattr(response, "response_state", None) if response is not None else None
    if response_state is None and isinstance(raw, dict):
        response_state = raw.get("status") or raw.get("state")
    if response_state is None:
        response_state = "ERROR" if response is None else ("COMPLETED" if message is not None else "EMPTY")
    provider_truncated = str(finish_reason or "").lower() in {
        "length", "max_tokens", "token_limit", "truncated",
    }
    truncation_state = "PROBABLE_TRUNCATION" if probable_truncation else (
        "PROVIDER_TOKEN_LIMIT" if provider_truncated else "NOT_TRUNCATED"
    )
    return FocusedProviderMetadata(
        response_state=str(response_state),
        finish_reason=str(finish_reason) if finish_reason is not None else None,
        input_token_count=int(getattr(usage, "prompt_tokens", 0) or 0),
        output_token_count=int(getattr(usage, "completion_tokens", 0) or 0),
        response_size=len((message or "").encode("utf-8")),
        request_hash=request_digest,
        response_hash=response_hash(message),
        truncation_state=truncation_state,
        normalization_result=normalization_result,
        rejection_reason=rejection_reason,
        raw_provider_response=raw,
    )


def identical_rejected_response(history: list[object], *, request_digest: str, response_digest: str) -> str | None:
    for entry in history:
        if not isinstance(entry, dict):
            continue
        metadata = entry.get("provider_metadata") if isinstance(entry.get("provider_metadata"), dict) else entry
        if (
            metadata.get("request_hash") == request_digest
            and metadata.get("response_hash") == response_digest
            and (metadata.get("rejection_reason") or entry.get("status") in {"rejected", "IDENTICAL_REJECTED_RESPONSE"})
        ):
            return str(metadata.get("rejection_reason") or entry.get("rejection_reason") or "previously rejected")
    return None


__all__ = [
    "FocusedProviderMetadata",
    "identical_rejected_response",
    "provider_metadata",
    "request_hash",
    "response_hash",
]
