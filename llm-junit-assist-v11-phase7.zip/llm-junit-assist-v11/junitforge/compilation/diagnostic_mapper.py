"""Registry-driven compiler diagnostic ownership and classification.

A compiler line is mapped to a test only when it falls inside that test's
recalculated inclusive range. No nearest-test or name-prefix fallback is used.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass, field
from enum import Enum
import re
from typing import Iterable

from junitforge.models import CompileError, TargetOutcome


class DiagnosticScope(str, Enum):
    TEST = "test"
    FIXTURE = "fixture"
    SKELETON = "skeleton"
    IMPORT_CLASS = "import_class"
    ASSEMBLY = "assembly"
    UNMAPPED = "unmapped"


@dataclass(slots=True, frozen=True)
class MappedCompileDiagnostic:
    diagnostic: CompileError
    scope: str
    test_id: str | None = None
    owner_method_id: str | None = None
    test_name: str | None = None
    range_name: str | None = None

    def to_dict(self) -> dict[str, object]:
        error = self.diagnostic
        return {
            "file": str(error.file) if error.file is not None else None,
            "line": error.line,
            "column": error.col,
            "message": error.message,
            "detail_lines": list(error.detail),
            "diagnostic_category": error.diagnostic_category or diagnostic_category(error.message),
            "raw_compiler_text": error.raw,
            "scope": self.scope,
            "test_id": self.test_id,
            "owner_method_id": self.owner_method_id,
            "test_name": self.test_name,
            "range_name": self.range_name,
        }


@dataclass(slots=True)
class DiagnosticOwnership:
    by_test: dict[str, list[MappedCompileDiagnostic]] = field(default_factory=dict)
    fixture: list[MappedCompileDiagnostic] = field(default_factory=list)
    skeleton: list[MappedCompileDiagnostic] = field(default_factory=list)
    import_class: list[MappedCompileDiagnostic] = field(default_factory=list)
    assembly: list[MappedCompileDiagnostic] = field(default_factory=list)
    unmapped: list[MappedCompileDiagnostic] = field(default_factory=list)

    @property
    def test_diagnostic_count(self) -> int:
        return sum(len(values) for values in self.by_test.values())

    def all_mapped(self) -> tuple[MappedCompileDiagnostic, ...]:
        values: list[MappedCompileDiagnostic] = []
        for group in self.by_test.values():
            values.extend(group)
        values.extend(self.fixture)
        values.extend(self.skeleton)
        values.extend(self.import_class)
        values.extend(self.assembly)
        values.extend(self.unmapped)
        return tuple(values)


def diagnostic_category(message: str | None) -> str:
    value = (message or "").lower()
    categories = (
        ("cannot find symbol", "cannot_find_symbol"),
        ("incompatible types", "incompatible_types"),
        ("method cannot be applied", "method_not_applicable"),
        ("no suitable method", "method_not_applicable"),
        ("reference to", "ambiguous_reference"),
        ("is ambiguous", "ambiguous_reference"),
        ("has private access", "access_violation"),
        ("cannot be accessed", "access_violation"),
        ("unreported exception", "checked_exception"),
        ("exception", "exception_contract"),
        ("reached end of file while parsing", "assembly_structure"),
        ("class, interface, enum, or record expected", "assembly_structure"),
        ("illegal start of", "assembly_structure"),
        ("';' expected", "syntax"),
        ("not a statement", "syntax"),
    )
    for token, category in categories:
        if token in value:
            return category
    return "compiler_error"


def _in_range(line: int | None, item: dict[str, object]) -> bool:
    if line is None:
        return False
    start = item.get("start_line")
    end = item.get("end_line")
    return isinstance(start, int) and isinstance(end, int) and start <= line <= end


def _assembly_diagnostic(error: CompileError, outcome: TargetOutcome) -> bool:
    if diagnostic_category(error.message) == "assembly_structure":
        return True
    return any(_in_range(error.line, item) for item in outcome.assembly_source_ranges)


def map_compile_diagnostics(
    outcome: TargetOutcome,
    diagnostics: Iterable[CompileError],
) -> DiagnosticOwnership:
    """Classify every diagnostic using exact persisted ranges."""
    ownership = DiagnosticOwnership(by_test=defaultdict(list))
    tests = [
        test
        for method in outcome.method_results
        for test in method.tests
    ]
    for error in diagnostics:
        if not error.diagnostic_category or error.diagnostic_category == "compiler_error":
            error.diagnostic_category = diagnostic_category(error.message)

        if _assembly_diagnostic(error, outcome):
            ownership.assembly.append(
                MappedCompileDiagnostic(error, DiagnosticScope.ASSEMBLY.value, range_name="class_structure")
            )
            continue

        matched_test = next(
            (
                test
                for test in tests
                if error.line is not None
                and test.source_start_line is not None
                and test.source_end_line is not None
                and test.source_start_line <= error.line <= test.source_end_line
            ),
            None,
        )
        if matched_test is not None:
            mapped = MappedCompileDiagnostic(
                error,
                DiagnosticScope.TEST.value,
                test_id=matched_test.test_id,
                owner_method_id=matched_test.owner_method_id,
                test_name=matched_test.test_name,
            )
            ownership.by_test[matched_test.test_id].append(mapped)
            continue

        fixture = next((item for item in outcome.fixture_source_ranges if _in_range(error.line, item)), None)
        if fixture is not None:
            ownership.fixture.append(
                MappedCompileDiagnostic(
                    error,
                    DiagnosticScope.FIXTURE.value,
                    range_name=str(fixture.get("name") or "fixture"),
                )
            )
            continue

        skeleton = next((item for item in outcome.skeleton_source_ranges if _in_range(error.line, item)), None)
        if skeleton is not None:
            ownership.skeleton.append(
                MappedCompileDiagnostic(
                    error,
                    DiagnosticScope.SKELETON.value,
                    range_name=str(skeleton.get("name") or "skeleton"),
                )
            )
            continue

        class_range = next((item for item in outcome.import_class_source_ranges if _in_range(error.line, item)), None)
        if class_range is not None:
            ownership.import_class.append(
                MappedCompileDiagnostic(
                    error,
                    DiagnosticScope.IMPORT_CLASS.value,
                    range_name=str(class_range.get("name") or "imports_and_class_header"),
                )
            )
            continue

        ownership.unmapped.append(MappedCompileDiagnostic(error, DiagnosticScope.UNMAPPED.value))

    ownership.by_test = dict(ownership.by_test)
    return ownership


def group_errors_by_test(
    outcome: TargetOutcome,
    diagnostics: Iterable[CompileError],
) -> dict[str, list[CompileError]]:
    ownership = map_compile_diagnostics(outcome, diagnostics)
    return {
        test_id: [item.diagnostic for item in values]
        for test_id, values in ownership.by_test.items()
    }


def _select_method_repair_owner(
    suite: str,
    errors: Iterable[CompileError],
    excluded_owners: set[str] | None = None,
) -> tuple[str | None, Counter, int]:
    """Legacy owner selector retained for controller compatibility."""
    from junitforge.execution.assembly import owner_method_id_for_line

    excluded = excluded_owners or set()
    mapped = [(error, owner_method_id_for_line(suite, error.line)) for error in errors]
    owner_counts = Counter(owner for _, owner in mapped if owner)
    eligible = Counter({owner: count for owner, count in owner_counts.items() if owner not in excluded})
    selected = eligible.most_common(1)[0][0] if eligible else None
    unmapped = sum(1 for _, owner in mapped if owner is None)
    return selected, owner_counts, unmapped


__all__ = [
    "DiagnosticOwnership",
    "DiagnosticScope",
    "MappedCompileDiagnostic",
    "diagnostic_category",
    "group_errors_by_test",
    "map_compile_diagnostics",
    "_select_method_repair_owner",
]
