"""Compile repair candidate acceptance gates."""

from __future__ import annotations

import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get

log = get("junitforge.loop")


def _compile_candidate_is_strict_progress(
    before_source: str,
    before_errors,
    after_source: str,
    after_errors,
    *,
    selected_owner: str | None = None,
) -> bool:
    """Accept a failing compile candidate only when it strictly improves safely.

    A changed diagnostic signature is not progress.  The candidate must reduce
    the total compiler-error count, must not increase any unaffected owner's
    error count, and must not introduce additional unmapped/header errors.
    """
    if len(after_errors) >= len(before_errors):
        return False
    before_mapped = [
        (error, owner_method_id_for_line(before_source, error.line))
        for error in before_errors
    ]
    after_mapped = [
        (error, owner_method_id_for_line(after_source, error.line))
        for error in after_errors
    ]
    before_counts = Counter(owner for _, owner in before_mapped if owner)
    after_counts = Counter(owner for _, owner in after_mapped if owner)
    before_unmapped = sum(1 for _, owner in before_mapped if owner is None)
    after_unmapped = sum(1 for _, owner in after_mapped if owner is None)
    if after_unmapped > before_unmapped:
        return False
    owners = set(before_counts) | set(after_counts)
    for owner in owners:
        if owner == selected_owner:
            continue
        if after_counts.get(owner, 0) > before_counts.get(owner, 0):
            return False
    if selected_owner and after_counts.get(selected_owner, 0) > before_counts.get(selected_owner, 0):
        return False
    return True


def complete_test_class_response_error(
    response: str,
    *,
    expected_class_name: str,
    baseline_source: str,
) -> str | None:
    """Require a raw complete-class compile-repair response before finalization."""
    raw = response or ""
    if "```" in raw:
        return "compile repair response contains Markdown fences"
    structure_error = test_class_structure_error(raw, expected_class_name)
    if structure_error:
        return structure_error
    expected_package = re.search(r"(?m)^\s*package\s+([\w.]+)\s*;", baseline_source or "")
    actual_package = re.search(r"(?m)^\s*package\s+([\w.]+)\s*;", raw)
    if expected_package:
        if actual_package is None or actual_package.group(1) != expected_package.group(1):
            return "compile repair response changed or omitted the test package"
    elif actual_package is not None:
        return "compile repair response introduced an unexpected package"
    if len(re.findall(rf"\bclass\s+{re.escape(expected_class_name)}\b", raw)) != 1:
        return "compile repair response must contain exactly one expected test class"
    return None
