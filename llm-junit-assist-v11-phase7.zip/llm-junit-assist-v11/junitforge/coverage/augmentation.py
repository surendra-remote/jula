"""Coverage-gap augmentation for class-wide and method-wise targets."""

from __future__ import annotations

import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get

log = get("junitforge.loop")

from junitforge.generation.payloads import payload_builder_for_context


class CoverageAugmentationMixin:
    def _augment(self, ctx, test_path, symbol, cc, outcome) -> bool:
        execution = ctx.execution_context
        if execution is not None and execution.target_kind.value == "service-impl":
            outcome.notes.append("ServiceImpl coverage augmentation disabled in v10.2")
            return False
        if execution is not None and execution.target_kind.value == "controller":
            return self._augment_methodwise(ctx, test_path, cc, outcome)

        existing = test_path.read_text(encoding="utf-8")
        ranges = collapse_ranges(cc.uncovered_lines())
        if not ranges and not cc.uncovered_branches():
            return False
        excerpt = slice_uncovered(ctx.cut_source, ranges)
        branch_hints = self._branch_hints(ctx.cut_source, cc.uncovered_branches())
        builder = payload_builder_for_context(ctx)
        messages = builder.build_coverage_augmentation_payload(ctx, existing, excerpt, branch_hints, mode="classwide")
        raw = self._chat(messages, self.cfg.temperature_gen, self.cfg.max_tokens_aug, outcome)
        candidate = inject_reusable_fixtures(raw or "", ctx)
        res = finalize_java(
            candidate, test_package=ctx.test_package, test_class_name=ctx.test_class_name,
            template=ctx.template, cut_symbol=ctx.symbol, collaborators=ctx.collaborators,
            source_imports=ctx.source_imports)
        if not res.ok or not res.code:
            outcome.notes.append(f"augmentation rejected: {res.reason}")
            return False
        test_path.write_text(res.code, encoding="utf-8")
        return True

    def _augment_methodwise(self, ctx, test_path, cc, outcome) -> bool:
        current = test_path.read_text(encoding="utf-8")
        uncovered = set(cc.uncovered_lines())
        candidates = []
        for method_context in ctx.execution_context.methods:
            if not method_context.source_range:
                continue
            start, end = method_context.source_range
            covered_lines = sorted(line for line in uncovered if start <= line <= end)
            if covered_lines:
                candidates.append((len(covered_lines), method_context, covered_lines))
        if not candidates:
            outcome.notes.append("method-wise augmentation skipped: uncovered lines not mapped to a production method")
            return False

        _, method_context, method_lines = max(candidates, key=lambda item: item[0])
        method = next(
            (
                candidate for candidate in (ctx.symbol.methods or [])
                if f"{candidate.name}({','.join(type_name for type_name, _ in candidate.params)})"
                == method_context.method_id
            ),
            None,
        )
        existing_block = method_block_for_id(current, method_context.method_id)
        if method is None or existing_block is None:
            outcome.notes.append(
                f"method-wise augmentation skipped: generated block missing for {method_context.method_id}"
            )
            return False

        ranges = collapse_ranges(method_lines)
        excerpt = slice_uncovered(ctx.cut_source, ranges)
        if not excerpt.strip():
            excerpt = method_context.method_source
        branch_hints = self._branch_hints(ctx.cut_source, cc.uncovered_branches())
        builder = payload_builder_for_context(ctx)
        messages = builder.build_coverage_augmentation_payload(
            ctx,
            method,
            existing_block,
            excerpt,
            branch_hints,
            mode="method",
        )
        raw = self._chat(messages, self.cfg.temperature_gen, self.cfg.max_tokens_aug, outcome)
        new_block = normalize_writable_map_mutations(extract_test_method_block(raw or ""))
        validation = validate_method_block(
            ctx,
            method,
            method_context,
            new_block,
            set(test_method_names(current)),
        )
        if not validation.ok:
            outcome.notes.append(
                f"method augmentation rejected [{method_context.method_id}]: {validation.reason}"
            )
            return False

        combined = existing_block.rstrip() + "\n\n" + new_block.strip()
        candidate = replace_method_block(current, method_context.method_id, combined)
        res = finalize_java(
            candidate,
            test_package=ctx.test_package,
            test_class_name=ctx.test_class_name,
            template=ctx.template,
            cut_symbol=ctx.symbol,
            collaborators=ctx.collaborators,
            source_imports=ctx.source_imports,
        )
        if not res.ok or not res.code:
            outcome.notes.append(
                f"method augmentation rejected [{method_context.method_id}]: {res.reason}"
            )
            return False
        test_path.write_text(res.code, encoding="utf-8")
        outcome.notes.append(
            f"method augmented [{method_context.method_id}]: {len(validation.test_names)} new test(s)"
        )
        return True

    @staticmethod
    def _branch_hints(source: str, branch_lines: list[int]) -> list[str]:
        lines = source.splitlines()
        hints: list[str] = []
        for nr in branch_lines[:12]:
            if 1 <= nr <= len(lines):
                hints.append(f"line {nr}: {lines[nr - 1].strip()}  (some branches untaken)")
        return hints
