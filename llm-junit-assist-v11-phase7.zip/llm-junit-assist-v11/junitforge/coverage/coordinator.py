"""Coverage measurement, runtime gate, augmentation loop, and no-progress stopping."""

from __future__ import annotations

import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.audit.console import stage as console_stage
from junitforge.audit.recorder import sha256_text
from junitforge.runtime.result_parser import _map_runtime_failure_owner, runtime_diagnostic
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get

log = get("junitforge.loop")



class CoverageCoordinatorMixin:
    def _serviceimpl_runtime_and_coverage(
        self,
        ctx: GenerationContext,
        module: ModuleInfo,
        test_path: Path,
        symbol: ClassSymbol,
        outcome: TargetOutcome,
    ) -> None:
        """Run ServiceImpl runtime repair first, then measure/report coverage once."""
        runner = self.coverage_runner
        assert runner is not None
        test_fqcn = self._test_fqcn(ctx)
        runtime_supported = callable(getattr(runner, "run_tests", None))
        coverage_run = None
        current_source = test_path.read_text(encoding="utf-8") if test_path.exists() else ""

        def signal_int(value) -> int:
            return value if isinstance(value, int) else 0

        if runtime_supported:
            console_stage("RUNTIME", "%s started", ctx.test_class_name)
            runtime_started = perf_counter()
            runtime = self._run_tests(
                runner,
                module,
                [test_fqcn],
                label=f"serviceimpl-runtime-{ctx.symbol.name}",
                timeout_sec=self.cfg.runtime_repair_timeout_seconds,
            )
            runtime_elapsed = perf_counter() - runtime_started
            self._record_runtime_test_result(outcome, runtime, scope="full")
            passed = max(0, signal_int(runtime.signals.tests_run) - signal_int(runtime.signals.tests_failed) - signal_int(runtime.signals.tests_errors) - signal_int(runtime.signals.tests_skipped))
            console_stage(
                "RUNTIME",
                "tests=%d | passed=%d | failures=%d | errors=%d | skipped=%d",
                runtime.signals.tests_run,
                passed,
                runtime.signals.tests_failed,
                runtime.signals.tests_errors,
                runtime.signals.tests_skipped,
            )
            for failure in runtime.failures:
                console_stage(
                    "RUNTIME",
                    "failed_test=%s | type=%s",
                    failure.test_method,
                    failure.exception_type or failure.category,
                    level="warning",
                )
            self.audit.write_json(symbol.name, "10-runtime/full-run.json", {
                "command": getattr(runner, "last_command", []),
                "working_directory": getattr(runner, "last_working_directory", None),
                "test_class": test_fqcn,
                "tests_run": runtime.signals.tests_run,
                "passed": passed,
                "failures": runtime.signals.tests_failed,
                "errors": runtime.signals.tests_errors,
                "skipped": runtime.signals.tests_skipped,
                "executed_test_names": runtime.executed_test_names,
                "source_hash": sha256_text(current_source),
                "surefire_report_paths": runtime.report_paths,
                "elapsed_seconds": runtime_elapsed,
                "return_code": runtime.return_code,
            })
            mapped_failures = []
            for failure in runtime.failures:
                owner, mapping_method, mapping_confidence = _map_runtime_failure_owner(
                    current_source, failure, outcome
                )
                mapped_failures.append({
                    "test_name": failure.test_method,
                    "production_method_owner": owner,
                    "runtime_status": failure.status,
                    **runtime_diagnostic(failure),
                    "mapping_method": mapping_method,
                    "mapping_confidence": mapping_confidence,
                })
            self.audit.write_json(symbol.name, "10-runtime/failures.json", {
                "failures": mapped_failures,
                "failure_count": len(mapped_failures),
            })
            self.audit.write_json(symbol.name, "10-runtime/registry-after.json", outcome.method_results)
            if outcome.runtime_initial_full_run is None:
                outcome.runtime_initial_full_run = outcome.runtime_last_full_run
                outcome.runtime_failures_initial = runtime.signals.tests_failed
                outcome.runtime_errors_initial = runtime.signals.tests_errors
                outcome.runtime_failure_categories_initial = dict(
                    Counter(failure.category for failure in runtime.failures)
                )
            if not runtime.tests_green:
                repaired = self._runtime_failure_repair_loop(ctx, test_path, module, runtime, outcome)
                if repaired is None or not repaired.tests_green:
                    outcome.status = outcome.status if outcome.status in {"runtime_failed", "repair_exhausted"} else "runtime_failed"
                    return
                coverage_run = repaired

        console_stage("COVERAGE", "started | target=%s", symbol.name)
        if coverage_run is None or not getattr(coverage_run, "measured", False):
            coverage_run = self._measure_coverage(runner, module, test_classes=[test_fqcn])
            self._record_coverage_runtime_result(outcome, coverage_run, initial=not runtime_supported)

        self.audit.write_json(symbol.name, "12-coverage/run.json", {
            "command": getattr(runner, "last_command", []),
            "working_directory": getattr(runner, "last_working_directory", None),
            "test_class": test_fqcn,
            "exit_code": coverage_run.return_code,
            "source_hash": coverage_run.coverage_source_sha256,
            "test_source_hash": coverage_run.test_source_sha256,
            "elapsed_seconds": getattr(runner, "last_elapsed_seconds", None),
            "jacoco_execution_data_path": coverage_run.selected_exec_path or coverage_run.expected_exec_path,
            "jacoco_xml_path": coverage_run.xml_path,
            "note": coverage_run.note,
        })
        self.audit.write_text(symbol.name, "12-coverage/stdout.log", getattr(runner, "last_stdout", ""))
        self.audit.write_text(symbol.name, "12-coverage/stderr.log", getattr(runner, "last_stderr", ""))
        exec_path = coverage_run.selected_exec_path or coverage_run.expected_exec_path
        xml_path = coverage_run.xml_path
        self.audit.write_json(symbol.name, "12-coverage/freshness.json", {
            "execution_data_exists": bool(exec_path and Path(exec_path).exists()),
            "execution_data_size": Path(exec_path).stat().st_size if exec_path and Path(exec_path).exists() else 0,
            "xml_exists": bool(xml_path and Path(xml_path).exists()),
            "xml_size": Path(xml_path).stat().st_size if xml_path and Path(xml_path).exists() else 0,
            "source_hash": coverage_run.coverage_source_sha256,
            "test_source_hash": coverage_run.test_source_sha256,
            "target_class_matched": None,
            "freshness_accepted": coverage_run.coverage_current,
            "reason": coverage_run.reason or coverage_run.note,
        })

        if not coverage_run.tests_green:
            outcome.status = "runtime_failed"
            outcome.notes.append("coverage skipped: ServiceImpl runtime suite is not green")
            console_stage("COVERAGE", "unmeasured | reason=runtime suite is not green", level="warning")
            return
        if not coverage_run.ok or not coverage_run.measured or coverage_run.xml_path is None:
            outcome.status = "coverage_unmeasured"
            outcome.notes.append(coverage_run.note)
            console_stage("COVERAGE", "unmeasured | reason=%s", coverage_run.reason or coverage_run.note, level="warning")
            return
        if not coverage_run.coverage_current:
            outcome.status = "coverage_unmeasured"
            outcome.notes.append("coverage rejected because JaCoCo data is stale or source-unmatched")
            console_stage("COVERAGE", "rejected | reason=coverage data does not match current source hash", level="warning")
            return

        coverage = self._class_cov(coverage_run.xml_path, module, symbol)
        if coverage is None:
            outcome.status = "coverage_unmeasured"
            outcome.notes.append("selected ServiceImpl class absent from JaCoCo coverage")
            console_stage("COVERAGE", "unmeasured | reason=target class absent from JaCoCo XML", level="warning")
            return

        method_covered = sum(1 for method in coverage.methods if method.covered_instr > 0)
        method_missed = max(0, len(coverage.methods) - method_covered)
        outcome.instruction_covered = coverage.covered_instr
        outcome.instruction_missed = coverage.missed_instr
        outcome.instruction_pct = round(coverage.instr_pct, 2)
        outcome.line_covered = coverage.covered_line
        outcome.line_missed = coverage.missed_line
        outcome.line_pct = round(coverage.line_pct, 2)
        outcome.branch_covered = coverage.covered_branch
        outcome.branch_missed = coverage.missed_branch
        outcome.branch_pct = round(coverage.branch_pct, 2)
        outcome.method_covered = method_covered
        outcome.method_missed = method_missed
        outcome.method_pct = round(coverage.method_pct, 2)
        outcome.uncovered_lines = coverage.uncovered_lines()
        outcome.uncovered_branches = coverage.uncovered_branches()
        outcome.partially_covered_branch_lines = coverage.partially_covered_branch_lines()
        outcome.jacoco_xml_path = str(coverage_run.xml_path)
        outcome.jacoco_exec_path = str(exec_path) if exec_path else None
        outcome.rounds = 0
        line_target = ctx.template.line_target
        branch_target = ctx.template.branch_target
        outcome.status = "threshold_met" if coverage.line_pct >= line_target and coverage.branch_pct >= branch_target else "below_threshold"
        console_stage(
            "COVERAGE",
            "instruction=%.2f%% | line=%.2f%% | branch=%.2f%% | method=%.2f%%",
            coverage.instr_pct,
            coverage.line_pct,
            coverage.branch_pct,
            coverage.method_pct,
        )
        console_stage(
            "COVERAGE",
            "uncovered_lines=%d | partial_branch_lines=%d",
            len(outcome.uncovered_lines),
            len(outcome.partially_covered_branch_lines),
        )
        self.audit.write_json(symbol.name, "12-coverage/parsed.json", {
            "instruction_covered": coverage.covered_instr,
            "instruction_missed": coverage.missed_instr,
            "instruction_percentage": coverage.instr_pct,
            "line_covered": coverage.covered_line,
            "line_missed": coverage.missed_line,
            "line_percentage": coverage.line_pct,
            "branch_covered": coverage.covered_branch,
            "branch_missed": coverage.missed_branch,
            "branch_percentage": coverage.branch_pct,
            "method_covered": method_covered,
            "method_missed": method_missed,
            "method_percentage": coverage.method_pct,
            "uncovered_lines": outcome.uncovered_lines,
            "partially_covered_branch_lines": outcome.partially_covered_branch_lines,
            "coverage_status": outcome.status,
            "target_class_matched": True,
        })
        outcome.notes.append(
            "coverage measured without augmentation: "
            f"instruction={outcome.instruction_pct}%; line={outcome.line_pct}%; "
            f"branch={outcome.branch_pct}%; method={outcome.method_pct}%"
        )

    def _coverage_loop(self, ctx: GenerationContext, module: ModuleInfo, test_path: Path,
                       symbol: ClassSymbol, last_good: str, outcome: TargetOutcome,
                       original: str | None = None) -> None:
        runner = self.coverage_runner
        assert runner is not None
        if (
            ctx.execution_context is not None
            and ctx.execution_context.target_kind.value == "service-impl"
        ):
            self._serviceimpl_runtime_and_coverage(
                ctx, module, test_path, symbol, outcome
            )
            return
        tline, tbranch = ctx.template.line_target, ctx.template.branch_target

        run = self._measure_coverage(runner, module, test_classes=[self._test_fqcn(ctx)])
        # The coverage run's Maven test-compile is the AUTHORITATIVE compile check
        # (the fast javac gate can over-accept). If it fails on our test file, repair
        # from those errors and re-measure.
        # run = self._recover_maven_compile(ctx, module, test_path, run, outcome)
        # if not run.ok or not run.measured or run.xml_path is None:
        #     own = self._own_maven_errors(run.log_tail, test_path)
        #     if own:
        #         self._restore_or_remove(test_path, original)
        #         outcome.compile_errors = [e.render() for e in own][:12]
        #         outcome.status = "compile_failed"
        #         outcome.notes.append("failed Maven test-compile during coverage; reverted")
        run = self._recover_maven_compile(ctx, module, test_path, run, outcome)
        if not run.ok or not run.measured or run.xml_path is None:
            own = self._own_maven_errors(run.log_tail, test_path)
            if own:
                outcome.compile_errors = [e.render() for e in own][:12]
                self._capture_failed_test_snapshot(test_path, outcome)
                self._restore_or_remove(test_path, original)
                outcome.status = "compile_failed"
                outcome.notes.append("failed Maven test-compile during coverage; reverted")
                self._log_compile_failure(outcome, symbol.name, test_path)
            else:
                reason = self._build_failure_reason(run.log_tail)
                coverage_detail = run.note
                if coverage_detail.startswith("coverage unmeasured:"):
                    outcome.status = f"compiled ({coverage_detail})"
                else:
                    outcome.status = f"compiled (coverage unmeasured: {coverage_detail})"
                outcome.notes.append(coverage_detail)
                if getattr(run, "log_path", None):
                    outcome.notes.append(f"coverage log: {run.log_path}")
                if reason:
                    outcome.notes.append("build failure: " + reason)
            return

        self._record_coverage_runtime_result(outcome, run, initial=True)
        runtime_gate_supported = callable(getattr(runner, "run_tests", None))
        log.debug(
            "[RUNTIME_GATE] result | tests_run=%d | failures=%d | errors=%d | "
            "tests_green=%s | coverage_measured=%s | coverage_current=%s | "
            "gate_supported=%s | action=%s",
            run.signals.tests_run,
            run.signals.tests_failed,
            run.signals.tests_errors,
            run.tests_green,
            run.measured,
            run.coverage_current,
            runtime_gate_supported,
            "coverage" if (run.tests_green or not runtime_gate_supported) else "runtime_repair",
        )
        if runtime_gate_supported and not run.tests_green:
            outcome.status = "coverage_measured_tests_failed"
            repaired_run = self._runtime_failure_repair_loop(
                ctx,
                test_path,
                module,
                run,
                outcome,
            )
            if repaired_run is None or not repaired_run.tests_green:
                if outcome.status == "coverage_measured_tests_failed":
                    outcome.status = "runtime_failed"
                log.debug(
                    "[COVERAGE_GATE] rejected | reason=tests_not_green | tests_run=%d | "
                    "failures=%d | errors=%d | status=%s",
                    outcome.runtime_tests_run,
                    outcome.runtime_failures_final,
                    outcome.runtime_errors_final,
                    outcome.status,
                )
                return
            run = repaired_run

        if runtime_gate_supported and not run.coverage_current:
            outcome.status = "coverage_unmeasured"
            outcome.notes.append("coverage rejected because the generated test source changed")
            log.debug("[COVERAGE_GATE] rejected | reason=stale_coverage")
            return
        log.debug(
            "[COVERAGE_GATE] accepted | tests_green=true | coverage_measured=%s | "
            "coverage_current=%s | xml=%s",
            run.measured,
            run.coverage_current,
            run.xml_path,
        )

        cc = self._class_cov(run.xml_path, module, symbol)
        prev_covered = -1
        no_progress = 0
        for rnd in range(self.cfg.max_coverage_rounds):
            if cc is None:
                outcome.status = "compiled (class absent from coverage)"
                return
            outcome.rounds = rnd
            outcome.line_pct = round(cc.line_pct, 1)
            outcome.branch_pct = round(cc.branch_pct, 1)
            outcome.uncovered_lines = cc.uncovered_lines()
            outcome.uncovered_branches = cc.uncovered_branches()

            if cc.line_pct >= tline and cc.branch_pct >= tbranch:
                outcome.status = "threshold_met"
                return
            if cc.covered_instr <= prev_covered:
                no_progress += 1
                if no_progress >= 2:
                    outcome.status = "stalled"
                    outcome.notes.append("no coverage progress for 2 rounds")
                    return
            else:
                no_progress = 0
            prev_covered = cc.covered_instr

            # augment
            augmented = self._augment(ctx, test_path, symbol, cc, outcome)
            if not augmented:
                break
            good = self._compile_with_repair(ctx, test_path, module, outcome)
            if good is None:
                # revert to last compiling snapshot - never ship broken
                test_path.write_text(last_good, encoding="utf-8")
                outcome.notes.append("augmentation broke compile; reverted to last good")
                break
            last_good = good
            run = self._measure_coverage(runner, module, test_classes=[self._test_fqcn(ctx)])
            self._record_coverage_runtime_result(outcome, run, initial=False)
            if runtime_gate_supported and run.ok and run.measured and not run.tests_green:
                outcome.status = "coverage_measured_tests_failed"
                repaired_run = self._runtime_failure_repair_loop(
                    ctx,
                    test_path,
                    module,
                    run,
                    outcome,
                )
                if repaired_run is None:
                    outcome.notes.append("coverage augmentation produced runtime failures")
                    break
                run = repaired_run
                last_good = test_path.read_text(encoding="utf-8")
            if (
                not run.ok
                or not run.measured
                or (runtime_gate_supported and not run.tests_green)
                or (runtime_gate_supported and not run.coverage_current)
            ):
                outcome.notes.append(f"re-measure failed: {run.note}")
                if run.signals.tests_executed and not run.tests_green:
                    outcome.status = "runtime_failed"
                elif not run.coverage_current:
                    outcome.status = "coverage_unmeasured"
                break
            cc = self._class_cov(run.xml_path, module, symbol)

        # Loop ended without meeting the target (exhausted rounds / broke out).
        if outcome.status in {"pending", "coverage_measured_tests_failed"}:
            outcome.status = "below_threshold"
