"""Coverage model compatibility exports."""

from junitforge.coverage_run import CoverageRunResult, RuntimeTestRunResult

__all__ = ["CoverageRunResult", "RuntimeTestRunResult"]
