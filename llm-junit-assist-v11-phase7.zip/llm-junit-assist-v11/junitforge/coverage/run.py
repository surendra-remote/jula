"""Coverage runner compatibility and Maven failure interpretation."""

from __future__ import annotations

import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get

log = get("junitforge.loop")



def measure_coverage(runner: CoverageRunner, module, *, test_classes):
    return runner.measure(module, test_classes=test_classes)


class CoverageRunMixin:
    def _measure_coverage(self, runner: CoverageRunner, module, *, test_classes):
        return measure_coverage(runner, module, test_classes=test_classes)

    @staticmethod
    def _build_failure_reason(log_tail: str) -> str | None:
        """Pull a concise reason out of a Maven build-failure log tail."""
        if not log_tail:
            return None
        m = re.search(r"Failed to execute goal\s+([\w.\-]+:[\w.\-]+:[\w.\-]+:[\w.\-]+)", log_tail)
        plugin = m.group(1) if m else None
        if "COMPILATION ERROR" in log_tail:
            em = re.search(r"\[ERROR\]\s+(/[^\n]+\.java:\[\d+,\d+\][^\n]+)", log_tail)
            detail = em.group(1).strip() if em else "a sibling test failed to compile"
            return f"sibling test-compile failed ({detail[:120]})"
        return f"plugin {plugin}" if plugin else None


__all__ = ["CoverageRunMixin", "CoverageRunner", "CoverageRunResult", "RuntimeTestRunResult", "SurefireFailure", "measure_coverage"]
