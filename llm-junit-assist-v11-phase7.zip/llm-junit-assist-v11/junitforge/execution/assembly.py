"""Deterministic Controller/ServiceImpl test-class assembly.

The LLM generates only @Test methods for one production method.  Python owns the
class wrapper, imports, mocks, standalone MockMvc setup, method markers, and
incremental validation.
"""

from __future__ import annotations

import re
import textwrap
from dataclasses import dataclass

from junitforge.execution.models import MethodExecutionContext, PropertyKind
from junitforge.models import GenerationContext, MethodSig

_BEGIN = "// JUNITFORGE_METHOD_BEGIN: "
_END = "// JUNITFORGE_METHOD_END: "


@dataclass(slots=True, frozen=True)
class MethodBlockValidation:
    ok: bool
    reason: str = ""
    test_names: tuple[str, ...] = ()
    # Advisory findings. NOT grounds for rejection: the execution analyzer is an
    # approximation of Java, so an "unobserved" call may be perfectly valid code
    # the analyzer failed to extract. javac is the authority (DEC-Q072).
    warnings: tuple[str, ...] = ()
    diagnostics: tuple[object, ...] = ()




def _mutated_wildcard_map_variables(block: str) -> tuple[str, ...]:
    wildcard_map_vars = set(re.findall(
        r"\b(?:java\.util\.)?Map\s*<\s*[^>]*\?[^>]*>\s+([A-Za-z_$][\w$]*)\b",
        block,
    ))
    return tuple(sorted(
        variable for variable in wildcard_map_vars
        if re.search(
            rf"\b{re.escape(variable)}\s*\.\s*(?:put|putAll|replace|replaceAll|compute|computeIfAbsent|computeIfPresent|merge)\s*\(",
            block,
        )
    ))




_ASSERTJ_PREFIX = r"(?:org\.assertj\.core\.api\.Assertions|AssertionsForClassTypes|Assertions)\.assertThat|assertThat"


def normalize_primitive_matchers(block: str) -> str:
    """Use Mockito's primitive-specific matcher methods."""
    normalized = block
    mapping = {
        "char": "anyChar()", "Character": "anyChar()",
        "byte": "anyByte()", "Byte": "anyByte()",
        "short": "anyShort()", "Short": "anyShort()",
        "int": "anyInt()", "Integer": "anyInt()",
        "long": "anyLong()", "Long": "anyLong()",
        "float": "anyFloat()", "Float": "anyFloat()",
        "double": "anyDouble()", "Double": "anyDouble()",
        "boolean": "anyBoolean()", "Boolean": "anyBoolean()",
    }
    for type_name, matcher in mapping.items():
        normalized = re.sub(
            rf"\bany\s*\(\s*{re.escape(type_name)}\s*\.\s*class\s*\)",
            matcher,
            normalized,
        )
    return normalized


def _matching_parenthesis(source: str, open_index: int) -> int | None:
    depth = 0
    quote: str | None = None
    escaped = False
    for index in range(open_index, len(source)):
        char = source[index]
        if quote is not None:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            continue
        if char in {'"', "'"}:
            quote = char
            continue
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                return index
    return None


def normalize_simple_assertj_assertions(block: str) -> str:
    """Convert only a single supported AssertJ link to JUnit Jupiter.

    Balanced-parenthesis parsing prevents complex chains such as
    ``assertThat(x).extracting(...).isEqualTo(...)`` from being partially or
    incorrectly normalized.
    """
    supported_binary = {
        "isEqualTo": lambda actual, expected: f"assertEquals({expected}, {actual});",
        "isNotEqualTo": lambda actual, expected: f"assertNotEquals({expected}, {actual});",
        "hasSize": lambda actual, expected: f"assertEquals({expected}, {actual}.size());",
    }
    supported_unary = {
        "isNull": lambda actual: f"assertNull({actual});",
        "isNotNull": lambda actual: f"assertNotNull({actual});",
        "isTrue": lambda actual: f"assertTrue({actual});",
        "isFalse": lambda actual: f"assertFalse({actual});",
        "isEmpty": lambda actual: f"assertTrue({actual}.isEmpty());",
        "isNotEmpty": lambda actual: f"assertFalse({actual}.isEmpty());",
    }
    pattern = re.compile(rf"(?:{_ASSERTJ_PREFIX})\s*\(")
    normalized = block
    search_from = 0
    while True:
        match = pattern.search(normalized, search_from)
        if match is None:
            break
        open_assert = normalized.find("(", match.start(), match.end())
        close_assert = _matching_parenthesis(normalized, open_assert)
        if close_assert is None:
            break
        cursor = close_assert + 1
        while cursor < len(normalized) and normalized[cursor].isspace():
            cursor += 1
        if cursor >= len(normalized) or normalized[cursor] != ".":
            search_from = close_assert + 1
            continue
        cursor += 1
        method_match = re.match(r"([A-Za-z_$][\w$]*)", normalized[cursor:])
        if method_match is None:
            search_from = close_assert + 1
            continue
        chain = method_match.group(1)
        cursor += len(chain)
        while cursor < len(normalized) and normalized[cursor].isspace():
            cursor += 1
        if cursor >= len(normalized) or normalized[cursor] != "(":
            search_from = close_assert + 1
            continue
        close_chain = _matching_parenthesis(normalized, cursor)
        if close_chain is None:
            break
        after = close_chain + 1
        while after < len(normalized) and normalized[after].isspace():
            after += 1
        # Exactly one assertion link is safe. A further dot means a complex
        # AssertJ chain and must remain for structural rejection/repair.
        if after >= len(normalized) or normalized[after] != ";":
            search_from = close_assert + 1
            continue
        actual = normalized[open_assert + 1:close_assert].strip()
        argument = normalized[cursor + 1:close_chain].strip()
        replacement: str | None = None
        if chain in supported_binary and argument:
            replacement = supported_binary[chain](actual, argument)
        elif chain in supported_unary and not argument:
            replacement = supported_unary[chain](actual)
        if replacement is None:
            search_from = after + 1
            continue
        normalized = normalized[:match.start()] + replacement + normalized[after + 1:]
        search_from = match.start() + len(replacement)
    return normalized


def normalize_writable_map_mutations(block: str) -> str:
    """Deterministically make mutated dynamic-map locals writable.

    LLMs frequently mirror production declarations such as ``Map<?, ?>`` and
    then attempt a branch mutation with ``put``. Java rejects non-null inserts
    through wildcard capture. For variables that are actually mutated, rewrite
    only the local declaration and its leading Map cast to ``Map<String,Object>``.
    Dynamic map fixtures are String-keyed by construction, so this is a verified
    code-generation normalization rather than repository fact inference.
    """
    normalized = normalize_primitive_matchers(normalize_simple_assertj_assertions(block))
    for variable in _mutated_wildcard_map_variables(normalized):
        declaration = re.compile(
            rf"(?P<qual>java\.util\.)?Map\s*<\s*[^>]*\?[^>]*>\s+"
            rf"{re.escape(variable)}\s*=\s*(?P<initializer>.*?);",
            flags=re.DOTALL,
        )

        def replace_declaration(match: re.Match[str]) -> str:
            qualifier = match.group("qual") or ""
            initializer = match.group("initializer")
            initializer = re.sub(
                r"^\s*\(\s*(?:java\.util\.)?Map(?:\s*<[^>]*>)?\s*\)",
                "(Map<String, Object>)",
                initializer,
                count=1,
                flags=re.DOTALL,
            )
            return (
                f"{qualifier}Map<String, Object> {variable} ="
                f"{initializer};"
            )

        normalized = declaration.sub(replace_declaration, normalized, count=1)
    return normalized


def cut_variable_name(class_name: str) -> str:
    if not class_name:
        return "classUnderTest"
    if len(class_name) >= 2 and class_name[:2].isupper():
        return class_name[0].lower() + class_name[1:]
    return class_name[0].lower() + class_name[1:]


def _format_import(value: str) -> str | None:
    text = (value or "").strip().rstrip(";")
    if not text:
        return None
    if text.startswith("import "):
        return text + ";"
    if text.startswith("static "):
        return "import " + text + ";"
    return "import " + text + ";"


def _class_package(fqcn: str) -> str:
    return fqcn.rsplit(".", 1)[0] if "." in fqcn else ""


def _imports(ctx: GenerationContext) -> list[str]:
    imports: set[str] = set()
    for value in ctx.template.required_imports or []:
        rendered = _format_import(value)
        if rendered:
            imports.add(rendered)
    for value in ctx.source_imports or []:
        rendered = _format_import(value)
        if rendered:
            imports.add(rendered)

    cut_package = _class_package(ctx.symbol.fqcn)
    if cut_package and cut_package != ctx.test_package:
        imports.add(f"import {ctx.symbol.fqcn};")

    execution = ctx.execution_context
    if execution is not None:
        for dependency in execution.dependencies:
            if dependency.fqcn and _class_package(dependency.fqcn) != ctx.test_package:
                imports.add(f"import {dependency.fqcn};")
        simple_counts: dict[str, int] = {}
        for schema in execution.payload_schemas:
            simple_counts[schema.type_name] = simple_counts.get(schema.type_name, 0) + 1
        for schema in execution.payload_schemas:
            # Two application classes with the same simple name cannot both be
            # imported.  Their fixture methods use FQCNs instead.
            if simple_counts.get(schema.type_name, 0) > 1:
                continue
            if schema.fqcn and _class_package(schema.fqcn) != ctx.test_package:
                imports.add(f"import {schema.fqcn};")
        for fixture in execution.fixtures:
            if not fixture.supported:
                continue
            for value in fixture.imports:
                rendered = _format_import(value)
                if rendered:
                    imports.add(rendered)

    # JDK staples the generated tests routinely use for fixtures/collections and
    # were previously left unimported (Collections/BigDecimal/Map/HashMap/List...).
    imports.update({
        "import java.util.List;",
        "import java.util.ArrayList;",
        "import java.util.Map;",
        "import java.util.HashMap;",
        "import java.util.LinkedHashMap;",
        "import java.util.LinkedHashSet;",
        "import java.util.Collections;",
        "import java.util.Optional;",
        "import java.math.BigDecimal;",
        "import java.math.BigInteger;",
    })

    # Nested payload/property types (e.g. CustomerParam, StatusEnum, TravelPremiumEntry)
    # are fields INSIDE a schema, not top-level schemas, so the schema.fqcn loop above
    # misses them and the generated body references a type with no import.
    #
    # The CUT compiles, so ITS import list is correct and complete by definition. Any
    # application type the test could legitimately use is a type the CUT already imports.
    # So re-emit ALL of the CUT's non-JDK imports -- no package guessing. Unused imports
    # are harmless (Java allows them; they do not fail compilation), whereas a missing
    # one is a hard compile error. Bias to over-import.
    for value in ctx.source_imports or []:
        rendered = _format_import(value)
        if not rendered:
            continue
        body = rendered[len("import "):].lstrip()
        if body.startswith("static "):
            body = body[len("static "):]
        # Skip java.*/javax.* (already covered by the JDK staples above and by
        # wildcard-safe defaults); keep everything else (the application types).
        if body.startswith(("java.", "javax.")):
            continue
        imports.add(rendered)

    # Stable method-level tests always need these even if the template omitted one.
    imports.update({
        "import org.junit.jupiter.api.Test;",
        "import org.junit.jupiter.api.extension.ExtendWith;",
        "import org.mockito.InjectMocks;",
        "import org.mockito.Mock;",
        "import org.mockito.junit.jupiter.MockitoExtension;",
        "import static org.junit.jupiter.api.Assertions.*;",
        "import static org.mockito.Mockito.*;",
    })
    has_injectable_configuration = bool(
        execution is not None
        and any(
            not field.static and field.test_value is not None
            for field in execution.configuration_fields
        )
    )
    if execution is not None and execution.target_kind.value == "controller":
        imports.update({
            "import org.junit.jupiter.api.BeforeEach;",
            "import org.springframework.test.web.servlet.MockMvc;",
            "import org.springframework.test.web.servlet.setup.MockMvcBuilders;",
            "import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;",
            "import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;",
        })
    if has_injectable_configuration:
        imports.update({
            "import org.junit.jupiter.api.BeforeEach;",
            "import org.springframework.test.util.ReflectionTestUtils;",
        })
    return sorted(imports, key=lambda item: (item.startswith("import static "), item))


def _fixture_closure(ctx: GenerationContext):
    execution = ctx.execution_context
    if execution is None:
        return ()
    by_id = {fixture.fixture_id: fixture for fixture in execution.fixtures if fixture.supported}
    roots = {
        fixture_id
        for method in execution.methods
        for fixture_id in method.required_fixture_ids
        if fixture_id in by_id
    }
    if not roots:
        roots = set(by_id)
    selected: set[str] = set()
    stack = list(roots)
    while stack:
        fixture_id = stack.pop()
        if fixture_id in selected or fixture_id not in by_id:
            continue
        selected.add(fixture_id)
        stack.extend(by_id[fixture_id].dependent_fixture_ids)
    return tuple(fixture for fixture in execution.fixtures if fixture.fixture_id in selected and fixture.supported)


def _inject_import_lines(code: str, import_lines: set[str]) -> str:
    if not import_lines:
        return code
    normalized_existing = {
        line.strip().rstrip(";")
        for line in code.splitlines()
        if line.strip().startswith("import ")
    }
    missing = sorted(
        line for line in import_lines
        if line.strip().rstrip(";") not in normalized_existing
    )
    if not missing:
        return code
    package_match = re.search(r"(?m)^\s*package\s+[^;]+;\s*", code)
    insertion = "\n".join(missing) + "\n"
    if package_match:
        return code[:package_match.end()] + "\n" + insertion + code[package_match.end():]
    return insertion + code


def inject_reusable_fixtures(code: str, ctx: GenerationContext) -> str:
    """Insert deterministic recursive fixture helpers into class-wide LLM output.

    Controller/ServiceImpl skeletons already contain these helpers. Utility,
    validator, mapper and other structured-input classes use the legacy
    whole-class generation path, so their final Java file must receive the same
    verified helpers before finalization/compilation.
    """
    execution = ctx.execution_context
    if execution is None or execution.target_kind.methodwise_generation:
        return code
    fixtures = _fixture_closure(ctx)
    if not fixtures:
        return code

    import_lines: set[str] = set()
    package_name = ctx.test_package or ""
    simple_counts: dict[str, int] = {}
    for schema in execution.payload_schemas:
        simple_counts[schema.type_name] = simple_counts.get(schema.type_name, 0) + 1
    for schema in execution.payload_schemas:
        if (
            schema.fqcn
            and simple_counts.get(schema.type_name, 0) == 1
            and _class_package(schema.fqcn) != package_name
        ):
            import_lines.add(f"import {schema.fqcn};")
    for fixture in fixtures:
        for value in fixture.imports:
            rendered = _format_import(value)
            if rendered:
                import_lines.add(rendered)

    out = _inject_import_lines(code, import_lines)
    def has_fixture_declaration(method_name: str) -> bool:
        return bool(re.search(
            rf"(?m)^\s*(?:public|protected|private)?\s*(?:static\s+)?"
            rf"[A-Za-z_$][\w$<>,.? \[\]]*\s+{re.escape(method_name)}\s*\(",
            out,
        ))

    missing_sources = [
        fixture.method_source.strip()
        for fixture in fixtures
        if fixture.method_source.strip() and not has_fixture_declaration(fixture.method_name)
    ]
    if not missing_sources:
        return out
    closing = out.rfind("}")
    if closing < 0:
        return out
    block = "\n\n    // Reusable parser-derived fixtures. Tests mutate only branch-specific fields.\n\n"
    block += "\n\n".join(missing_sources) + "\n"
    return out[:closing].rstrip() + block + out[closing:]


def build_test_skeleton(ctx: GenerationContext) -> str:
    execution = ctx.execution_context
    if execution is None or execution.target_kind.value not in {"controller", "service-impl"}:
        raise ValueError("method-wise skeleton is only valid for Controller/ServiceImpl")

    lines = [f"package {ctx.test_package};", ""]
    lines.extend(_imports(ctx))
    lines.extend(["", "@ExtendWith(MockitoExtension.class)", f"class {ctx.test_class_name} {{", ""])

    seen_fields: set[str] = set()
    for dependency in execution.dependencies:
        field_name = dependency.field_name or dependency.parameter_name
        if not field_name or field_name in seen_fields or not dependency.mockable:
            continue
        seen_fields.add(field_name)
        lines.extend([
            "    @Mock",
            f"    private {dependency.declared_type} {field_name};",
            "",
        ])

    cut_var = cut_variable_name(ctx.symbol.name)
    lines.extend([
        "    @InjectMocks",
        f"    private {ctx.symbol.name} {cut_var};",
        "",
    ])

    injectable_configuration = [
        field for field in execution.configuration_fields
        if not field.static and field.test_value is not None
    ]

    if execution.target_kind.value == "controller":
        lines.extend([
            "    private MockMvc mockMvc;",
            "",
        ])

    if execution.target_kind.value == "controller" or injectable_configuration:
        lines.extend([
            "    @BeforeEach",
            "    void setUp() {",
        ])
        for field in injectable_configuration:
            lines.append(
                f'        ReflectionTestUtils.setField({cut_var}, "{field.field_name}", {field.test_value});'
            )
        if execution.target_kind.value == "controller":
            lines.append(f"        mockMvc = MockMvcBuilders.standaloneSetup({cut_var}).build();")
        lines.extend([
            "    }",
            "",
        ])

    fixture_sources = [
        fixture.method_source.strip()
        for fixture in execution.fixtures
        if fixture.supported and fixture.method_source.strip()
    ]
    if fixture_sources:
        lines.append("    // Reusable parser-derived fixtures. Tests must mutate only target-branch fields.")
        lines.append("")
        for source in fixture_sources:
            lines.extend(source.splitlines())
            lines.append("")

    lines.append("}")
    return "\n".join(lines) + "\n"


def _strip_fences(raw: str) -> str:
    text = (raw or "").strip()
    fenced = re.search(r"```(?:java)?\s*(.*?)```", text, flags=re.DOTALL | re.IGNORECASE)
    return fenced.group(1).strip() if fenced else text


def _matching_brace(text: str, open_index: int) -> int | None:
    depth = 0
    quote: str | None = None
    escaped = False
    line_comment = False
    block_comment = False
    index = open_index
    while index < len(text):
        char = text[index]
        nxt = text[index + 1] if index + 1 < len(text) else ""
        if line_comment:
            if char == "\n":
                line_comment = False
            index += 1
            continue
        if block_comment:
            if char == "*" and nxt == "/":
                block_comment = False
                index += 2
                continue
            index += 1
            continue
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            index += 1
            continue
        if char == "/" and nxt == "/":
            line_comment = True
            index += 2
            continue
        if char == "/" and nxt == "*":
            block_comment = True
            index += 2
            continue
        if char in {'"', "'"}:
            quote = char
            index += 1
            continue
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return index
        index += 1
    return None


def extract_test_method_block(raw: str) -> str:
    """Extract only @Test methods; class wrappers, imports, and fields are discarded."""
    text = _strip_fences(raw)
    methods: list[str] = []
    cursor = 0
    while True:
        match = re.search(r"(?m)^[ \t]*@Test\b", text[cursor:])
        if not match:
            break
        annotation_start = cursor + match.start()
        open_brace = text.find("{", annotation_start)
        if open_brace < 0:
            break
        close_brace = _matching_brace(text, open_brace)
        if close_brace is None:
            break
        method_text = text[annotation_start:close_brace + 1].strip()
        methods.append(method_text)
        cursor = close_brace + 1
    return "\n\n".join(methods).strip()


def test_method_names(code: str) -> tuple[str, ...]:
    names = re.findall(
        r"@Test(?:\s*\([^)]*\))?\s+(?:public\s+|protected\s+|private\s+)?"
        r"(?:static\s+)?void\s+([A-Za-z_$][\w$]*)\s*\(",
        code or "",
        flags=re.MULTILINE,
    )
    return tuple(names)


@dataclass(slots=True, frozen=True)
class ExtractedTestMethod:
    name: str
    source: str
    start_offset: int
    end_offset: int
    start_line: int
    end_line: int
    scenario_id: str | None = None


@dataclass(slots=True, frozen=True)
class FocusedTestRepairResult:
    source: str
    changed: bool
    actions: tuple[str, ...] = ()
    unresolved_reason: str | None = None


@dataclass(slots=True, frozen=True)
class NormalReturnStub:
    field: str
    method_name: str
    statement_start: int
    statement_end: int
    expression_start: int
    expression_end: int
    expression: str
    style: str


def extract_test_methods(raw: str) -> tuple[ExtractedTestMethod, ...]:
    """Extract every @Test method with stable source and line identity."""
    text = _strip_fences(raw or "")
    methods: list[ExtractedTestMethod] = []
    cursor = 0
    while True:
        match = re.search(r"(?m)^[ \t]*@Test\b", text[cursor:])
        if match is None:
            break
        start = cursor + match.start()
        open_brace = text.find("{", start)
        if open_brace < 0:
            break
        close_brace = _matching_brace(text, open_brace)
        if close_brace is None:
            break
        source = text[start:close_brace + 1].strip()
        names = test_method_names(source)
        name = names[0] if names else f"<unidentified-{len(methods) + 1}>"
        scenario_match = re.search(
            r"(?im)\b(?:SCENARIO(?:_ID)?|scenarioId)\s*[:=]\s*([A-Za-z0-9_.:-]+)",
            source,
        )
        start_line = text.count("\n", 0, start) + 1
        end_line = text.count("\n", 0, close_brace + 1) + 1
        methods.append(
            ExtractedTestMethod(
                name=name,
                source=source,
                start_offset=start,
                end_offset=close_brace + 1,
                start_line=start_line,
                end_line=end_line,
                scenario_id=scenario_match.group(1) if scenario_match else None,
            )
        )
        cursor = close_brace + 1
    return tuple(methods)


def join_test_methods(methods: tuple[ExtractedTestMethod, ...] | list[ExtractedTestMethod] | list[str]) -> str:
    values: list[str] = []
    for method in methods:
        values.append(method.source.strip() if isinstance(method, ExtractedTestMethod) else str(method).strip())
    return "\n\n".join(value for value in values if value).strip()


def test_method_for_name(code: str, test_name: str) -> ExtractedTestMethod | None:
    return next((method for method in extract_test_methods(code) if method.name == test_name), None)


def test_method_name_for_line(code: str, line_number: int | None) -> str | None:
    if line_number is None:
        return None
    for method in extract_test_methods(code):
        if method.start_line <= line_number <= method.end_line:
            return method.name
    return None


def test_class_structure_error(code: str, test_class_name: str) -> str | None:
    """Return a focused structural error for a malformed generated test class.

    ``finalize_java`` deliberately tolerates lightweight-parser failures because
    Java 17 syntax can exceed ``javalang``.  Compile-repair candidates need a
    stricter invariant: every ``@Test`` must remain a direct member of the
    selected test class.  This catches an extra class-closing brace introduced
    by an LLM repair before the candidate can replace the last good snapshot.
    """
    text = _strip_fences(code or "")
    declaration = re.search(
        rf"\bclass\s+{re.escape(test_class_name)}\b",
        text,
    )
    if declaration is None:
        return f"test class declaration not found: {test_class_name}"
    class_open = text.find("{", declaration.end())
    if class_open < 0:
        return f"test class opening brace not found: {test_class_name}"
    class_close = _matching_brace(text, class_open)
    if class_close is None:
        return f"test class closing brace is unbalanced: {test_class_name}"

    markers = tuple(re.finditer(r"(?m)^[ \t]*@Test\b", text))
    methods = extract_test_methods(text)
    if len(markers) != len(methods):
        return (
            "not every @Test annotation forms one balanced test method: "
            f"annotations={len(markers)}, extracted={len(methods)}"
        )
    if tuple(method.name for method in methods) != test_method_names(text):
        return "test method extraction and identity parsing disagree"

    for method in methods:
        if not (class_open < method.start_offset < method.end_offset <= class_close):
            return f"test method is outside the test class body: {method.name}"
        depth = _brace_depth_at(text, class_open, method.start_offset)
        if depth != 1:
            return (
                f"test method is not a direct class member: {method.name} "
                f"(brace_depth={depth})"
            )

    for marker in markers:
        if not (class_open < marker.start() < class_close):
            return "@Test annotation appears outside the test class body"
    return None


def _brace_depth_at(text: str, class_open: int, target: int) -> int:
    """Lexically count braces from the class opening brace to ``target``."""
    depth = 1
    quote: str | None = None
    escaped = False
    line_comment = False
    block_comment = False
    index = class_open + 1
    while index < min(target, len(text)):
        char = text[index]
        nxt = text[index + 1] if index + 1 < len(text) else ""
        if line_comment:
            if char == "\n":
                line_comment = False
            index += 1
            continue
        if block_comment:
            if char == "*" and nxt == "/":
                block_comment = False
                index += 2
                continue
            index += 1
            continue
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            index += 1
            continue
        if char == "/" and nxt == "/":
            line_comment = True
            index += 2
            continue
        if char == "/" and nxt == "*":
            block_comment = True
            index += 2
            continue
        if char in {'"', "'"}:
            quote = char
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
        index += 1
    return depth


def replace_test_method(code: str, test_name: str, replacement: str) -> str:
    method = test_method_for_name(code, test_name)
    if method is None:
        raise ValueError(f"test method not found: {test_name}")
    replacement_methods = extract_test_methods(replacement)
    if len(replacement_methods) != 1:
        raise ValueError("replacement must contain exactly one @Test method")
    if replacement_methods[0].name != test_name:
        raise ValueError(
            f"replacement changed test identity: expected {test_name}, got {replacement_methods[0].name}"
        )
    return code[:method.start_offset] + replacement_methods[0].source + code[method.end_offset:]


def remove_test_method(code: str, test_name: str) -> str:
    method = test_method_for_name(code, test_name)
    if method is None:
        return code
    start = method.start_offset
    end = method.end_offset
    while start > 0 and code[start - 1] in " \t":
        start -= 1
    while end < len(code) and code[end] in " \t":
        end += 1
    if end < len(code) and code[end] == "\n":
        end += 1
    return code[:start] + code[end:]


def focused_validation_category(reason: str) -> str:
    lower = (reason or "").lower()
    if "fixture-supported schema type" in lower or "direct construction" in lower:
        return "MANUAL_FIXTURE_CONSTRUCTION"
    if "unnecessary return stubbing" in lower:
        return "UNNECESSARY_RETURN_STUBBING"
    if "return type mismatch" in lower or "void and cannot be used" in lower:
        return "MOCKITO_RETURN_TYPE_MISMATCH"
    if "checked-exception stubbing" in lower:
        return "INVALID_CHECKED_EXCEPTION_STUBBING"
    if "unknown member" in lower:
        return "UNKNOWN_MEMBER"
    if "stubs or verifies the class under test" in lower:
        return "CLASS_UNDER_TEST_STUBBING"
    return "OTHER_VALIDATION"


def _simple_generic_arguments(rendered: str | None) -> tuple[str, ...]:
    text = (rendered or "").strip()
    if "<" not in text or not text.endswith(">"):
        return ()
    body = text[text.find("<") + 1:-1]
    parts: list[str] = []
    depth = 0
    start = 0
    for index, char in enumerate(body):
        if char == "<":
            depth += 1
        elif char == ">":
            depth = max(0, depth - 1)
        elif char == "," and depth == 0:
            parts.append(body[start:index].strip())
            start = index + 1
    tail = body[start:].strip()
    if tail:
        parts.append(tail)
    return tuple(parts)


def _fixture_candidates(
    ctx: GenerationContext,
    method_context: MethodExecutionContext,
    declared_type: str,
) -> tuple:
    execution = ctx.execution_context
    if execution is None:
        return ()
    target = _simple_type(declared_type)
    schemas = {
        _simple_type(schema.type_name): schema
        for schema in execution.payload_schemas
    }
    schemas.update({
        _simple_type(schema.type_name): schema
        for schema in method_context.payload_schemas
    })

    exact = []
    assignable = []
    for fixture in execution.fixtures:
        if not fixture.supported:
            continue
        actual = _simple_type(fixture.return_type)
        if actual == target:
            exact.append(fixture)
            continue
        schema = schemas.get(actual)
        parents: set[str] = set()
        visited: set[str] = set()
        while schema is not None and _simple_type(schema.type_name) not in visited:
            visited.add(_simple_type(schema.type_name))
            if schema.superclass:
                parents.add(_simple_type(schema.superclass))
            parents.update(_simple_type(value) for value in schema.interfaces)
            if target in parents:
                break
            schema = schemas.get(_simple_type(schema.superclass)) if schema.superclass else None
        if target in parents:
            assignable.append(fixture)
    return tuple(exact + assignable)


def _replace_fixture_supported_construction(
    ctx: GenerationContext,
    method_context: MethodExecutionContext,
    source: str,
) -> tuple[str, list[str]]:
    repaired = source
    actions: list[str] = []
    execution = ctx.execution_context
    if execution is None:
        return repaired, actions

    target_types = sorted(
        {
            _simple_type(fixture.return_type)
            for fixture in execution.fixtures
            if fixture.supported
        }
        | {
            _simple_type(schema.type_name)
            for schema in method_context.payload_schemas
            if schema.fixture_method_name
        },
        key=len,
        reverse=True,
    )
    for declared_type in target_types:
        candidates = _fixture_candidates(ctx, method_context, declared_type)
        if not candidates:
            continue
        helper = candidates[0].method_name
        type_pattern = rf"(?:[A-Za-z_$][\w$]*\.)*{re.escape(declared_type)}"
        variable_prefix = (
            rf"(?P<prefix>\b(?:final\s+)?{type_pattern}\s+"
            rf"(?P<var>[A-Za-z_$][\w$]*)\s*=\s*)"
        )
        initializers = (
            rf"new\s+{type_pattern}\s*\([^;]*?\)",
            rf"{type_pattern}\s*\.\s*(?:builder|newBuilder)\s*\(\s*\).*?\.build\s*\(\s*\)",
            rf"(?:Mockito\.)?mock\s*\(\s*{type_pattern}\s*\.\s*class\s*\)",
            rf"(?:Mockito\.)?spy\s*\(\s*new\s+{type_pattern}\s*\([^;]*?\)\s*\)",
        )
        for initializer in initializers:
            pattern = re.compile(variable_prefix + rf"(?P<init>{initializer})\s*;", flags=re.DOTALL)
            while True:
                match = pattern.search(repaired)
                if match is None:
                    break
                replacement = f"{match.group('prefix')}{helper}();"
                repaired = repaired[:match.start()] + replacement + repaired[match.end():]
                actions.append(
                    f"fixture_substitution:{declared_type}:{match.group('var')}->{helper}()"
                )
    return repaired, actions


def _statement_start(source: str, index: int) -> int:
    start = source.rfind("\n", 0, index) + 1
    while start < index and source[start] in " \t":
        start += 1
    return start


def _normal_return_stubs(source: str) -> tuple[NormalReturnStub, ...]:
    stubs: list[NormalReturnStub] = []
    pattern = re.compile(r"\b(?P<style>when|given)\s*\(")
    cursor = 0
    while True:
        match = pattern.search(source, cursor)
        if match is None:
            break
        open_outer = source.find("(", match.start(), match.end())
        close_outer = _matching_parenthesis(source, open_outer)
        if close_outer is None:
            break
        invocation = source[open_outer + 1:close_outer].strip()
        invocation_match = re.match(
            r"(?P<field>[A-Za-z_$][\w$]*)\s*\.\s*"
            r"(?P<method>[A-Za-z_$][\w$]*)\s*\(",
            invocation,
            flags=re.DOTALL,
        )
        if invocation_match is None:
            cursor = close_outer + 1
            continue
        tail = source[close_outer + 1:]
        chain_match = re.match(
            r"\s*\.\s*(?P<return>thenReturn|willReturn)\s*\(",
            tail,
            flags=re.DOTALL,
        )
        if chain_match is None:
            cursor = close_outer + 1
            continue
        open_return = close_outer + 1 + chain_match.end() - 1
        close_return = _matching_parenthesis(source, open_return)
        if close_return is None:
            cursor = close_outer + 1
            continue
        end = close_return + 1
        while end < len(source) and source[end].isspace() and source[end] != "\n":
            end += 1
        if end >= len(source) or source[end] != ";":
            cursor = close_return + 1
            continue
        statement_start = _statement_start(source, match.start())
        statement_end = end + 1
        if statement_end < len(source) and source[statement_end] == "\n":
            statement_end += 1
        stubs.append(
            NormalReturnStub(
                field=invocation_match.group("field"),
                method_name=invocation_match.group("method"),
                statement_start=statement_start,
                statement_end=statement_end,
                expression_start=open_return + 1,
                expression_end=close_return,
                expression=source[open_return + 1:close_return].strip(),
                style=chain_match.group("return"),
            )
        )
        cursor = statement_end
    return tuple(stubs)


def _contracts_by_call(method_context: MethodExecutionContext) -> dict[tuple[str, str], list]:
    contracts: dict[tuple[str, str], list] = {}
    for invocation in method_context.dependency_invocations:
        contracts.setdefault((invocation.dependency_field, invocation.method_name), []).append(invocation)
    return contracts


def _remove_unused_return_stubs(
    method_context: MethodExecutionContext,
    source: str,
) -> tuple[str, list[str]]:
    repaired = source
    actions: list[str] = []
    contracts = _contracts_by_call(method_context)
    for stub in reversed(_normal_return_stubs(repaired)):
        invocations = contracts.get((stub.field, stub.method_name), ())
        if not invocations:
            continue
        if all(inv.contract.is_void for inv in invocations):
            repaired = repaired[:stub.statement_start] + repaired[stub.statement_end:]
            actions.append(f"void_return_stub_removed:{stub.field}.{stub.method_name}")
            continue
        if (
            all(inv.contract.is_non_void for inv in invocations)
            and all(inv.return_flow_is_resolved for inv in invocations)
            and all(not _invocation_return_is_consumed(invocation) for invocation in invocations)
        ):
            repaired = repaired[:stub.statement_start] + repaired[stub.statement_end:]
            actions.append(f"unnecessary_return_stub_removed:{stub.field}.{stub.method_name}")
    return repaired, actions


def _declared_variable_types_for_expression(
    ctx: GenerationContext,
    production_method: MethodSig,
    method_context: MethodExecutionContext,
    source: str,
) -> dict[str, str]:
    return _infer_block_variable_types(ctx, production_method, method_context, source)


def _fixture_expression_for_type(
    ctx: GenerationContext,
    method_context: MethodExecutionContext,
    rendered_type: str,
) -> str | None:
    candidates = _fixture_candidates(ctx, method_context, rendered_type)
    return f"{candidates[0].method_name}()" if candidates else None


def _expression_type(
    ctx: GenerationContext,
    production_method: MethodSig,
    method_context: MethodExecutionContext,
    source: str,
    expression: str,
) -> str | None:
    expr = expression.strip()
    if not expr:
        return None
    if expr == "null":
        return "null"
    if re.fullmatch(r"true|false", expr):
        return "boolean"
    if re.fullmatch(r"[-+]?\d+[lL]", expr):
        return "long"
    if re.fullmatch(r"[-+]?\d+", expr):
        return "int"
    if re.fullmatch(r"[-+]?(?:\d+\.\d*|\d*\.\d+)[fF]", expr):
        return "float"
    if re.fullmatch(r"[-+]?(?:\d+\.\d*|\d*\.\d+)(?:[dD])?", expr):
        return "double"
    if re.fullmatch(r"'(?:\\.|[^'\\])'", expr):
        return "char"
    if re.fullmatch(r'"(?:\\.|[^"\\])*"', expr):
        return "String"
    if re.match(r"(?:java\.util\.)?Optional\s*\.", expr):
        return "Optional"
    if re.match(r"(?:java\.util\.)?(?:List|Arrays|Collections)\s*\.", expr):
        if "singleton" in expr and "singletonList" not in expr:
            return "Set"
        return "List"
    if re.match(r"(?:java\.util\.)?Set\s*\.", expr):
        return "Set"
    if re.match(r"new\s+(?:java\.util\.)?(?:ArrayList|LinkedList)", expr):
        return "List"
    if re.match(r"new\s+(?:java\.util\.)?(?:HashSet|LinkedHashSet|TreeSet)", expr):
        return "Set"
    if re.match(r"new\s+(?:java\.util\.)?(?:HashMap|LinkedHashMap|TreeMap)", expr):
        return "Map"
    helper_match = re.fullmatch(r"([A-Za-z_$][\w$]*)\s*\(\s*\)", expr)
    if helper_match and ctx.execution_context is not None:
        for fixture in ctx.execution_context.fixtures:
            if fixture.supported and fixture.method_name == helper_match.group(1):
                return _simple_type(fixture.return_type)
    variable_types = _declared_variable_types_for_expression(
        ctx, production_method, method_context, source
    )
    if expr in variable_types:
        return variable_types[expr]
    creation = re.match(r"new\s+([A-Za-z_$][\w$.]*)", expr)
    if creation:
        return _simple_type(creation.group(1))
    return None


def _primitive_compatible(expected: str, actual: str) -> bool:
    pairs = {
        "boolean": {"boolean", "Boolean"},
        "Boolean": {"boolean", "Boolean"},
        "byte": {"byte", "Byte", "int"},
        "Byte": {"byte", "Byte", "int"},
        "short": {"short", "Short", "byte", "Byte", "int"},
        "Short": {"short", "Short", "byte", "Byte", "int"},
        "int": {"int", "Integer", "byte", "Byte", "short", "Short"},
        "Integer": {"int", "Integer", "byte", "Byte", "short", "Short"},
        "long": {"long", "Long", "int", "Integer"},
        "Long": {"long", "Long", "int", "Integer"},
        "float": {"float", "Float", "int", "Integer", "long", "Long"},
        "Float": {"float", "Float", "int", "Integer", "long", "Long"},
        "double": {"double", "Double", "float", "Float", "int", "Integer", "long", "Long"},
        "Double": {"double", "Double", "float", "Float", "int", "Integer", "long", "Long"},
        "char": {"char", "Character"},
        "Character": {"char", "Character"},
    }
    return actual in pairs.get(expected, set())


def _return_expression_assignable(expected_rendered: str, actual: str | None) -> bool:
    expected = _simple_type(expected_rendered)
    if actual is None:
        return False
    if actual == "null":
        return expected not in {"boolean", "byte", "short", "int", "long", "float", "double", "char"}
    if _primitive_compatible(expected, actual):
        return True
    if expected == actual:
        return True
    if expected in {"Collection", "Iterable"} and actual in {"List", "Set", "Collection"}:
        return True
    if expected == "List" and actual == "List":
        return True
    if expected == "Set" and actual == "Set":
        return True
    if expected == "Map" and actual == "Map":
        return True
    if expected == "Optional" and actual == "Optional":
        return True
    return False


def _branch_specific_boolean(test_name: str, source: str) -> str:
    lower = f"{test_name} {source}".lower()
    false_tokens = ("false", "invalid", "failure", "disabled", "not_", "notwhen", "rejected")
    return "false" if any(token in lower for token in false_tokens) else "true"


def _compatible_return_expression(
    ctx: GenerationContext,
    production_method: MethodSig,
    method_context: MethodExecutionContext,
    expected_rendered: str,
    test_name: str,
    source: str,
) -> str | None:
    expected = _simple_type(expected_rendered)
    if expected in {"int", "Integer", "byte", "Byte", "short", "Short"}:
        return "1"
    if expected in {"long", "Long"}:
        return "1L"
    if expected in {"float", "Float"}:
        return "1.0f"
    if expected in {"double", "Double"}:
        return "1.0d"
    if expected in {"boolean", "Boolean"}:
        return _branch_specific_boolean(test_name, source)
    if expected in {"char", "Character"}:
        return "'Y'"
    if expected == "String":
        return '"value"'
    args = _simple_generic_arguments(expected_rendered)
    lower = f"{test_name} {source}".lower()
    wants_empty = any(token in lower for token in ("empty", "missing", "absent", "notfound", "not_found"))
    if expected == "Optional":
        if wants_empty or not args:
            return "Optional.empty()"
        inner = _fixture_expression_for_type(ctx, method_context, args[0])
        return f"Optional.of({inner})" if inner else "Optional.empty()"
    if expected in {"List", "Collection", "Iterable"}:
        if wants_empty or not args:
            return "Collections.emptyList()"
        inner = _fixture_expression_for_type(ctx, method_context, args[0])
        return f"List.of({inner})" if inner else "Collections.emptyList()"
    if expected == "Set":
        if wants_empty or not args:
            return "Collections.emptySet()"
        inner = _fixture_expression_for_type(ctx, method_context, args[0])
        return f"Set.of({inner})" if inner else "Collections.emptySet()"
    if expected == "Map":
        return "new HashMap<>()"
    return _fixture_expression_for_type(ctx, method_context, expected_rendered)


def _repair_return_type_mismatches(
    ctx: GenerationContext,
    production_method: MethodSig,
    method_context: MethodExecutionContext,
    source: str,
    test_name: str,
) -> tuple[str, list[str]]:
    repaired = source
    actions: list[str] = []
    contracts = _contracts_by_call(method_context)
    # Work right-to-left because replacements change offsets.
    for stub in reversed(_normal_return_stubs(repaired)):
        invocations = contracts.get((stub.field, stub.method_name), ())
        if not invocations:
            continue
        if any(not invocation.contract.is_resolved for invocation in invocations):
            continue
        return_types = tuple(dict.fromkeys(invocation.contract.return_type for invocation in invocations))
        if all(invocation.contract.is_void for invocation in invocations):
            repaired = repaired[:stub.statement_start] + repaired[stub.statement_end:]
            actions.append(f"void_return_stub_removed:{stub.field}.{stub.method_name}")
            continue
        expected_rendered = next((value for value in return_types if value and value != "void"), None)
        if expected_rendered is None:
            continue
        actual = _expression_type(
            ctx, production_method, method_context, repaired, stub.expression
        )
        if _return_expression_assignable(expected_rendered, actual):
            continue
        replacement = _compatible_return_expression(
            ctx,
            production_method,
            method_context,
            expected_rendered,
            test_name,
            repaired,
        )
        if replacement is None:
            continue
        repaired = (
            repaired[:stub.expression_start]
            + replacement
            + repaired[stub.expression_end:]
        )
        actions.append(
            f"return_type_corrected:{stub.field}.{stub.method_name}:{stub.expression}->{replacement}"
        )
    return repaired, actions


def _known_checked_exception_types() -> set[str]:
    return {
        "Exception",
        "Throwable",
        "InterruptedException",
        "IOException",
        "FileNotFoundException",
        "SQLException",
        "ParseException",
        "ExecutionException",
        "TimeoutException",
        "CloneNotSupportedException",
        "ReflectiveOperationException",
        "ClassNotFoundException",
    }


def _source_supported_unchecked_exceptions(method_context: MethodExecutionContext) -> tuple[str, ...]:
    source = method_context.method_source or ""
    candidates = set(
        re.findall(
            r"\b(?:catch\s*\(\s*|throw\s+new\s+)"
            r"([A-Za-z_$][\w$.]*(?:RuntimeException|IllegalArgumentException|IllegalStateException|"
            r"UnsupportedOperationException|NoSuchElementException))",
            source,
        )
    )
    for invocation in method_context.dependency_invocations:
        for declared in invocation.contract.throws:
            simple = _simple_type(declared)
            if simple.endswith("RuntimeException") or simple in {
                "IllegalArgumentException",
                "IllegalStateException",
                "UnsupportedOperationException",
                "NoSuchElementException",
            }:
                candidates.add(simple)
    return tuple(sorted(_simple_type(value) for value in candidates))


def _repair_illegal_checked_exception_stubs(
    method_context: MethodExecutionContext,
    source: str,
) -> tuple[str, list[str]]:
    repaired = source
    actions: list[str] = []
    checked = _known_checked_exception_types()
    supported_unchecked = _source_supported_unchecked_exceptions(method_context)
    for invocation in method_context.dependency_invocations:
        field = invocation.dependency_field
        method = invocation.method_name
        declared = {_simple_type(value) for value in invocation.contract.throws}
        patterns = (
            re.compile(
                rf"((?:when|given)\s*\(\s*{re.escape(field)}\s*\.\s*"
                rf"{re.escape(method)}\s*\(.*?\)\s*\)\s*\.\s*"
                rf"(?:thenThrow|willThrow)\s*\(\s*new\s+)([\w.]+)",
                flags=re.DOTALL,
            ),
            re.compile(
                rf"(doThrow\s*\(\s*new\s+)([\w.]+)(.*?\)\s*\.\s*when\s*\(\s*"
                rf"{re.escape(field)}\s*\)\s*\.\s*{re.escape(method)}\s*\()",
                flags=re.DOTALL,
            ),
        )
        for pattern in patterns:
            while True:
                match = pattern.search(repaired)
                if match is None:
                    break
                exception_type = _simple_type(match.group(2))
                if exception_type not in checked or exception_type in declared:
                    break
                if not supported_unchecked:
                    break
                replacement = supported_unchecked[0]
                repaired = (
                    repaired[:match.start(2)]
                    + replacement
                    + repaired[match.end(2):]
                )
                actions.append(
                    f"checked_exception_replaced:{field}.{method}:{exception_type}->{replacement}"
                )
    return repaired, actions


def _member_property_key(member: str) -> str:
    for prefix in ("get", "set", "is"):
        if member.startswith(prefix) and len(member) > len(prefix):
            return member[len(prefix):].lower()
    return member.lower()


def _statement_range_containing(source: str, index: int) -> tuple[int, int] | None:
    start = source.rfind(";", 0, index) + 1
    brace = source.rfind("{", 0, index)
    if brace > start:
        start = brace + 1
    end = source.find(";", index)
    if end < 0:
        return None
    while start < len(source) and source[start] in " \t\n\r":
        start += 1
    return start, end + 1


def _meaningful_oracle_count(source: str) -> int:
    return len(re.findall(
        r"\b(?:assert[A-Z][A-Za-z0-9_$]*|verify|verifyNoInteractions|verifyNoMoreInteractions)\s*\(",
        source,
    ))


def _repair_unknown_members(
    ctx: GenerationContext,
    production_method: MethodSig,
    method_context: MethodExecutionContext,
    source: str,
) -> tuple[str, list[str]]:
    repaired = source
    actions: list[str] = []
    schemas = _schema_contracts(method_context)
    variables = _infer_block_variable_types(ctx, production_method, method_context, repaired)

    changed = True
    while changed:
        changed = False
        for variable, type_name in list(variables.items()):
            schema = schemas.get(type_name)
            if schema is None:
                continue
            allowed = set(_OBJECT_METHODS)
            for prop in schema.properties:
                allowed.update(
                    value
                    for value in (prop.getter, prop.setter, prop.builder_method)
                    if value
                )
            calls = list(re.finditer(
                rf"\b{re.escape(variable)}\s*\.\s*([A-Za-z_$][\w$]*)\s*\(",
                repaired,
            ))
            for match in calls:
                member = match.group(1)
                if member in allowed:
                    continue

                same_property = [
                    candidate
                    for candidate in allowed
                    if _member_property_key(candidate) == _member_property_key(member)
                ]
                if len(same_property) == 1:
                    replacement = same_property[0]
                    member_start = match.start(1)
                    repaired = repaired[:member_start] + replacement + repaired[match.end(1):]
                    actions.append(
                        f"unknown_member_corrected:{type_name}.{member}->{replacement}"
                    )
                    changed = True
                    break

                receiver_candidates: list[str] = []
                for other_variable, other_type in variables.items():
                    if other_variable == variable:
                        continue
                    other_schema = schemas.get(other_type)
                    if other_schema is None:
                        continue
                    other_allowed = set(_OBJECT_METHODS)
                    for prop in other_schema.properties:
                        other_allowed.update(
                            value
                            for value in (prop.getter, prop.setter, prop.builder_method)
                            if value
                        )
                    if member in other_allowed:
                        receiver_candidates.append(other_variable)
                if len(receiver_candidates) == 1:
                    replacement_receiver = receiver_candidates[0]
                    repaired = (
                        repaired[:match.start()]
                        + re.sub(
                            rf"^\b{re.escape(variable)}\b",
                            replacement_receiver,
                            repaired[match.start():match.end()],
                            count=1,
                        )
                        + repaired[match.end():]
                    )
                    actions.append(
                        f"unknown_member_receiver_corrected:{variable}.{member}->{replacement_receiver}.{member}"
                    )
                    changed = True
                    break

                statement_range = _statement_range_containing(repaired, match.start())
                if statement_range is not None:
                    statement = repaired[statement_range[0]:statement_range[1]]
                    if re.search(r"\bassert[A-Z][A-Za-z0-9_$]*\s*\(", statement):
                        candidate = repaired[:statement_range[0]] + repaired[statement_range[1]:]
                        if _meaningful_oracle_count(candidate) > 0:
                            repaired = candidate
                            actions.append(
                                f"unknown_member_assertion_removed:{variable}.{member}"
                            )
                            changed = True
                            break
            if changed:
                variables = _infer_block_variable_types(
                    ctx, production_method, method_context, repaired
                )
                break
    return repaired, actions


def deterministically_repair_compile_diagnostics(
    ctx: GenerationContext,
    production_method: MethodSig,
    method_context: MethodExecutionContext,
    test_source: str,
    errors,
) -> FocusedTestRepairResult:
    """Repair high-confidence javac diagnostics for one individual test.

    These repairs are driven by compiler facts plus verified method/schema/
    collaborator contracts.  They run before any compile-repair LLM call so a
    repeated source-backed mistake can be fixed across all affected tests in a
    single deterministic pass.
    """
    repaired = test_source
    actions: list[str] = []
    rendered_errors = [error.render() for error in errors]

    # 1. Wrong JavaBean accessor on a verified schema return type.  javac gives
    # the exact receiver type; the schema catalog supplies the only legal
    # getter/setter/builder member for the same property key.
    schemas = _schema_contracts(method_context)
    for rendered in rendered_errors:
        method_match = re.search(
            r"symbol:\s*method\s+([A-Za-z_$][\w$]*)\s*\([^\n]*\)",
            rendered,
        )
        location_match = re.search(
            r"location:\s*class\s+([A-Za-z_$][\w$]*)",
            rendered,
        )
        if not method_match or not location_match:
            continue
        bad_member = method_match.group(1)
        receiver_type = _simple_type(location_match.group(1))

        # Common chained-setter hallucination:
        # product.getResultPremium().setResultPremium(value)
        # where getResultPremium() already returns BigDecimal.  Collapsing the
        # duplicate property hop is source-preserving and unambiguous.
        if bad_member.startswith("set") and len(bad_member) > 3:
            property_suffix = bad_member[3:]
            collapse = re.compile(
                rf"\.\s*(?:get|is){re.escape(property_suffix)}\s*\(\s*\)\s*"
                rf"\.\s*{re.escape(bad_member)}\s*\("
            )
            collapsed, count = collapse.subn(f".{bad_member}(", repaired)
            if count:
                repaired = collapsed
                actions.append(
                    f"compile_chained_setter_collapsed:{receiver_type}.{bad_member}:{count}"
                )
                continue

        schema = schemas.get(receiver_type)
        if schema is None:
            continue
        candidates: list[str] = []
        bad_key = _member_property_key(bad_member)
        for prop in schema.properties:
            if bad_member.startswith(("get", "is")):
                member_candidates = (prop.getter,)
            elif bad_member.startswith("set"):
                member_candidates = (prop.setter, prop.builder_method)
            else:
                member_candidates = (prop.getter, prop.setter, prop.builder_method)
            for candidate in member_candidates:
                if candidate and _member_property_key(candidate) == bad_key:
                    candidates.append(candidate)
        unique = sorted(set(candidates))
        if len(unique) != 1 or unique[0] == bad_member:
            continue
        replacement = unique[0]
        repaired, count = re.subn(
            rf"\.\s*{re.escape(bad_member)}\s*\(",
            f".{replacement}(",
            repaired,
        )
        if count:
            actions.append(
                f"compile_unknown_member_corrected:{receiver_type}.{bad_member}->{replacement}:{count}"
            )

    # 2. Unknown receiver variable for a verified collaborator method.  Replace
    # it only when the method contract resolves to exactly one injected field.
    declared = _declared_test_identifiers(repaired)
    dependency_fields = {
        dependency.field_name or dependency.parameter_name
        for dependency in (ctx.execution_context.dependencies if ctx.execution_context else ())
        if dependency.field_name or dependency.parameter_name
    }
    unknown_variables: set[str] = set()
    for rendered in rendered_errors:
        variable_match = re.search(
            r"symbol:\s*variable\s+([A-Za-z_$][\w$]*)",
            rendered,
        )
        if variable_match:
            unknown_variables.add(variable_match.group(1))
    for variable in sorted(unknown_variables):
        if variable in declared or variable in dependency_fields:
            continue
        called_methods = set(re.findall(
            rf"\b{re.escape(variable)}\s*\.\s*([A-Za-z_$][\w$]*)\s*\(",
            repaired,
        ))
        replacement_fields: set[str] = set()
        for method_name in called_methods:
            matches = {
                invocation.dependency_field
                for invocation in method_context.dependency_invocations
                if invocation.method_name == method_name
            }
            if len(matches) == 1:
                replacement_fields.update(matches)
        if len(replacement_fields) == 1:
            replacement_field = next(iter(replacement_fields))
            repaired, count = re.subn(
                rf"\b{re.escape(variable)}\b(?=\s*\.)",
                replacement_field,
                repaired,
            )
            if count:
                actions.append(
                    f"compile_collaborator_receiver_corrected:{variable}->{replacement_field}:{count}"
                )

    # 3. Missing local argument used to invoke the selected CUT method.  Infer
    # the type only from the verified production-method parameter position.
    declared = _declared_test_identifiers(repaired)
    for variable in sorted(unknown_variables):
        if variable in declared or re.search(rf"\b{re.escape(variable)}\s*\.", repaired):
            continue
        inferred_type = _infer_missing_cut_argument_type(
            ctx, production_method, repaired, variable
        )
        if inferred_type is None:
            continue
        expression = _deterministic_local_value(
            ctx, method_context, inferred_type, variable
        )
        if expression is None:
            continue
        inserted = _insert_local_after_test_open(
            repaired, f"{inferred_type} {variable} = {expression};"
        )
        if inserted != repaired:
            repaired = inserted
            declared.add(variable)
            actions.append(
                f"compile_missing_local_declared:{inferred_type} {variable}"
            )

    return FocusedTestRepairResult(
        source=repaired.strip(),
        changed=repaired.strip() != test_source.strip(),
        actions=tuple(actions),
    )


def _infer_missing_cut_argument_type(
    ctx: GenerationContext,
    production_method: MethodSig,
    source: str,
    variable: str,
) -> str | None:
    cut_var = cut_variable_name(ctx.symbol.name)
    call = re.search(
        rf"\b{re.escape(cut_var)}\s*\.\s*{re.escape(production_method.name)}\s*\((.*?)\)",
        source,
        flags=re.DOTALL,
    )
    if call is None:
        return None
    arguments = [part.strip() for part in _split_top_level_arguments(call.group(1))]
    positions = [index for index, value in enumerate(arguments) if value == variable]
    if len(positions) != 1:
        return None
    position = positions[0]
    if position >= len(production_method.params):
        return None
    return production_method.params[position][0]


def _split_top_level_arguments(arguments: str) -> tuple[str, ...]:
    parts: list[str] = []
    start = 0
    paren = bracket = brace = angle = 0
    quote: str | None = None
    escaped = False
    for index, char in enumerate(arguments):
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            continue
        if char in {'"', "'"}:
            quote = char
        elif char == "(":
            paren += 1
        elif char == ")":
            paren = max(0, paren - 1)
        elif char == "[":
            bracket += 1
        elif char == "]":
            bracket = max(0, bracket - 1)
        elif char == "{":
            brace += 1
        elif char == "}":
            brace = max(0, brace - 1)
        elif char == "<":
            angle += 1
        elif char == ">":
            angle = max(0, angle - 1)
        elif char == "," and paren == bracket == brace == angle == 0:
            parts.append(arguments[start:index])
            start = index + 1
    parts.append(arguments[start:])
    return tuple(parts)


def _deterministic_local_value(
    ctx: GenerationContext,
    method_context: MethodExecutionContext,
    rendered_type: str,
    variable: str,
) -> str | None:
    simple = _simple_type(rendered_type)
    if simple == "String":
        return f'"{variable}"'
    if simple in {"char", "Character"}:
        return "'A'"
    if simple in {"boolean", "Boolean"}:
        return "false"
    if simple in {"byte", "Byte", "short", "Short", "int", "Integer"}:
        return "1"
    if simple in {"long", "Long"}:
        return "1L"
    if simple in {"float", "Float"}:
        return "1.0f"
    if simple in {"double", "Double"}:
        return "1.0d"
    fixture = _fixture_expression_for_type(ctx, method_context, rendered_type)
    return fixture


def _insert_local_after_test_open(source: str, declaration: str) -> str:
    methods = extract_test_methods(source)
    if len(methods) != 1:
        return source
    method_source = methods[0].source
    open_brace = method_source.find("{")
    if open_brace < 0:
        return source
    line_start = method_source.rfind("\n", 0, open_brace) + 1
    base_indent = re.match(r"[ \t]*", method_source[line_start:open_brace]).group(0)
    insertion = f"\n{base_indent}    {declaration}"
    repaired_method = method_source[:open_brace + 1] + insertion + method_source[open_brace + 1:]
    return replace_test_method(source, methods[0].name, repaired_method)


def deterministically_repair_test(
    ctx: GenerationContext,
    production_method: MethodSig,
    method_context: MethodExecutionContext,
    test_source: str,
) -> FocusedTestRepairResult:
    """Apply only source-backed v7.3 repairs to one @Test method."""
    methods = extract_test_methods(test_source)
    test_name = methods[0].name if len(methods) == 1 else "<unknown>"
    repaired = normalize_writable_map_mutations(test_source)
    actions: list[str] = []

    for repair in (
        lambda value: _replace_fixture_supported_construction(ctx, method_context, value),
        lambda value: _remove_unused_return_stubs(method_context, value),
        lambda value: _repair_return_type_mismatches(
            ctx, production_method, method_context, value, test_name
        ),
        lambda value: _repair_illegal_checked_exception_stubs(method_context, value),
        lambda value: _repair_unknown_members(
            ctx, production_method, method_context, value
        ),
    ):
        repaired, new_actions = repair(repaired)
        actions.extend(new_actions)

    return FocusedTestRepairResult(
        source=repaired.strip(),
        changed=repaired.strip() != test_source.strip(),
        actions=tuple(actions),
    )


def _has_collaborator_stub(block: str, field: str, method_name: str) -> bool:
    """Return whether the generated suite stubs one exact collaborator call.

    Supports standard Mockito and BDDMockito forms. This is intentionally a
    suite-level check: branch-specific tests may omit downstream stubs when an
    earlier collaborator throws, but a required unconditional collaborator must
    not be absent from the complete generated method suite.
    """
    field_re = re.escape(field)
    method_re = re.escape(method_name)
    patterns = (
        rf"\b(?:when|given)\s*\(\s*{field_re}\s*\.\s*{method_re}\s*\(",
        rf"\b(?:doReturn|doThrow|doAnswer|doNothing)\s*\([^;]*?\)\s*\.\s*when\s*\(\s*{field_re}\s*\)\s*\.\s*{method_re}\s*\(",
        rf"\b(?:willReturn|willThrow|willAnswer|willDoNothing)\s*\([^;]*?\)\s*\.\s*given\s*\(\s*{field_re}\s*\)\s*\.\s*{method_re}\s*\(",
    )
    return any(re.search(pattern, block, flags=re.DOTALL) for pattern in patterns)


def _invocation_return_is_consumed(invocation) -> bool:
    if not getattr(invocation, "return_flow_is_resolved", True):
        return False
    if bool(getattr(invocation, "return_value_consumed", False)):
        return True
    kind = getattr(getattr(invocation, "consumption_kind", None), "value", None) or str(
        getattr(invocation, "consumption_kind", "")
    )
    if kind == "assignment-without-subsequent-read":
        return False
    return bool(getattr(invocation, "assigned_to", None)) and kind in {"", "ignored-expression-statement"}


def _missing_required_collaborator_stubs(
    method_context: MethodExecutionContext,
    block: str,
) -> tuple[str, ...]:
    """Find source-proven unconditional non-void calls omitted by the suite.

    These calls execute on every normal traversal of the selected public path.
    Accepting a suite that omits all stubbing for them produces null/default mock
    returns and is the exact failure seen for ``aesEncUtils.encode`` and
    ``iQuotationClient.getQuotationByRefNoTransType`` inside ``getQuotation``.
    """
    required: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for invocation in method_context.dependency_invocations:
        contract = invocation.contract
        if (
            invocation.branch_id is not None
            or not contract.is_non_void
            or not invocation.return_flow_is_resolved
            or not _invocation_return_is_consumed(invocation)
        ):
            continue
        key = (invocation.dependency_field, invocation.method_name)
        if key in seen:
            continue
        seen.add(key)
        required.append(key)
    return tuple(
        f"{field}.{method_name}"
        for field, method_name in required
        if not _has_collaborator_stub(block, field, method_name)
    )


_APPLICATION_TYPE_SUFFIXES = (
    "Entity", "Dto", "DTO", "Request", "Response", "Resource", "Model",
    "Payload", "Param", "Command", "Event", "Repository", "Service", "Client", "Type",
)
_JAVA_ALLOWED_TYPES = {
    "String", "Object", "Boolean", "Byte", "Short", "Integer", "Long", "Float", "Double",
    "Character", "BigDecimal", "BigInteger", "Date", "LocalDate", "LocalDateTime", "Instant",
    "List", "Set", "Map", "Collection", "Iterable", "ArrayList", "HashSet", "LinkedHashSet",
    "HashMap", "LinkedHashMap", "Optional", "Collections", "Arrays", "Stream", "ResponseEntity",
    "RuntimeException", "Exception", "Throwable", "Class", "UUID", "File", "TreeSet",
}
_OBJECT_METHODS = {"equals", "hashCode", "toString", "getClass", "clone", "canEqual"}


def _simple_type(rendered: str | None) -> str:
    text = (rendered or "").strip().replace("...", "").replace("[]", "")
    if "<" in text:
        text = text.split("<", 1)[0]
    return text.rsplit(".", 1)[-1].strip()


def _fixture_contracts(ctx: GenerationContext, method_context: MethodExecutionContext):
    execution = ctx.execution_context
    if execution is None:
        return {}, {}, set()
    fixtures = {
        fixture.fixture_id: fixture
        for fixture in execution.fixtures
        if fixture.supported
    }
    by_type = {_simple_type(f.return_type): f for f in fixtures.values()}
    by_method = {f.method_name: f for f in fixtures.values()}
    return by_type, by_method, set(by_type)


def _schema_contracts(method_context: MethodExecutionContext):
    by_type = {_simple_type(schema.type_name): schema for schema in method_context.payload_schemas}
    for schema in method_context.payload_schemas:
        if schema.fqcn:
            by_type.setdefault(_simple_type(schema.fqcn), schema)
    return by_type


def _known_application_types(ctx: GenerationContext, method_context: MethodExecutionContext) -> set[str]:
    known = {_simple_type(ctx.symbol.name), _simple_type(ctx.symbol.fqcn)}
    known.update(_simple_type(schema.type_name) for schema in method_context.payload_schemas)
    known.update(_simple_type(schema.fqcn) for schema in method_context.payload_schemas if schema.fqcn)
    if ctx.execution_context:
        known.update(_simple_type(dep.declared_type) for dep in ctx.execution_context.dependencies)
        known.update(_simple_type(f.return_type) for f in ctx.execution_context.fixtures if f.supported)
    for invocation in method_context.dependency_invocations:
        known.add(_simple_type(invocation.contract.return_type))
        known.update(_simple_type(value) for value in invocation.contract.parameter_types)
    for value in ctx.source_imports or []:
        body = value.strip().replace("import ", "").replace("static ", "").rstrip(";")
        if not body.endswith(".*"):
            known.add(_simple_type(body))
    known.update(_JAVA_ALLOWED_TYPES)
    return {value for value in known if value}


def _infer_block_variable_types(
    ctx: GenerationContext,
    production_method: MethodSig,
    method_context: MethodExecutionContext,
    block: str,
) -> dict[str, str]:
    _, fixture_by_method, _ = _fixture_contracts(ctx, method_context)
    variables: dict[str, str] = {}
    declaration = re.compile(
        r"\b([A-Z][A-Za-z0-9_$.]*(?:\s*<[^;=]+>)?(?:\[\])?)\s+([A-Za-z_$][\w$]*)\s*="
    )
    for type_name, variable in declaration.findall(block):
        variables[variable] = _simple_type(type_name)
    for variable, helper in re.findall(
        r"\b([A-Za-z_$][\w$]*)\s*=\s*([A-Za-z_$][\w$]*)\s*\(\s*\)", block
    ):
        fixture = fixture_by_method.get(helper)
        if fixture:
            variables[variable] = _simple_type(fixture.return_type)
    cut_var = cut_variable_name(ctx.symbol.name)
    return_type = _simple_type(production_method.return_type)
    if return_type:
        for variable in re.findall(
            rf"\b(?:var|[A-Z][A-Za-z0-9_$.<>?, ]*)\s+([A-Za-z_$][\w$]*)\s*=\s*{re.escape(cut_var)}\s*\.\s*{re.escape(production_method.name)}\s*\(",
            block,
        ):
            variables.setdefault(variable, return_type)
    return variables


def _direct_schema_construction_error(
    ctx: GenerationContext,
    method_context: MethodExecutionContext,
    block: str,
) -> str | None:
    by_type, _, fixture_types = _fixture_contracts(ctx, method_context)
    for type_name in sorted(fixture_types, key=len, reverse=True):
        fixture = by_type[type_name]
        patterns = (
            rf"\bnew\s+{re.escape(type_name)}\s*\(",
            rf"\b{re.escape(type_name)}\s*\.\s*(?:builder|newBuilder)\s*\(",
            rf"\bmock\s*\(\s*{re.escape(type_name)}\s*\.\s*class\s*\)",
            rf"\bspy\s*\(\s*new\s+{re.escape(type_name)}\s*\(",
        )
        if any(re.search(pattern, block) for pattern in patterns):
            return (
                f"direct construction of fixture-supported schema type {type_name} is forbidden; "
                f"use {fixture.method_name}()"
            )
    return None


def _unknown_application_type_error(
    ctx: GenerationContext,
    method_context: MethodExecutionContext,
    block: str,
) -> str | None:
    known = _known_application_types(ctx, method_context)
    candidates: set[str] = set()
    patterns = (
        r"\bnew\s+([A-Z][A-Za-z0-9_$]*)\s*[<(]",
        r"\b(?:any|mock)\s*\(\s*([A-Z][A-Za-z0-9_$]*)\s*\.\s*class",
        r"\b([A-Z][A-Za-z0-9_$]*)\s+[a-zA-Z_$][\w$]*\s*=",
        r"\b([A-Z][A-Za-z0-9_$]*)\s*\.\s*[A-Z][A-Z0-9_]*\b",
    )
    for pattern in patterns:
        candidates.update(re.findall(pattern, block))
    for candidate in sorted(candidates):
        if candidate in known or not candidate.endswith(_APPLICATION_TYPE_SUFFIXES):
            continue
        return (
            f"unknown application type {candidate}; application class names must come from verified Java declarations "
            "and must never be inferred from repository, collaborator, method, or variable names"
        )
    return None


def _strip_java_literals_and_comments(block: str) -> str:
    text = re.sub(r"/\*.*?\*/", " ", block, flags=re.DOTALL)
    text = re.sub(r"//[^\n]*", " ", text)
    text = re.sub(r'"(?:\\.|[^"\\])*"', '""', text)
    text = re.sub(r"'(?:\\.|[^'\\])*'", "''", text)
    return text


def _unknown_constant_error(
    ctx: GenerationContext,
    method_context: MethodExecutionContext,
    block: str,
) -> str | None:
    # A wildcard static import prevents complete enumeration; defer those cases
    # to javac rather than rejecting a potentially valid constant.
    imports = [value.strip().replace("import ", "").rstrip(";") for value in (ctx.source_imports or [])]
    if any(value.startswith("static ") and value.endswith(".*") for value in imports):
        return None
    allowed = {
        field.name for field in (ctx.symbol.fields or [])
        if "static" in field.modifiers and "final" in field.modifiers
    }
    for schema in method_context.payload_schemas:
        allowed.update(schema.enum_constants)
        for prop in schema.properties:
            allowed.update(prop.enum_constants)
    for value in imports:
        if value.startswith("static ") and not value.endswith(".*"):
            allowed.add(value.rsplit(".", 1)[-1])
    # Exclude qualified constants; enum validation handles Type.CONSTANT.
    scrubbed = _strip_java_literals_and_comments(block)
    tokens = set(re.findall(r"(?<![.@\w$])([A-Z][A-Z0-9_]{2,})(?![\w$])", scrubbed))
    harmless = {"NULL", "TRUE", "FALSE", "TODO", "UTF_8"}
    unknown = sorted(tokens - allowed - harmless)
    if unknown:
        return (
            f"unknown unqualified application constant(s): {', '.join(unknown)}; "
            "use only constants verified from the target source or exact static imports"
        )
    return None


def _schema_member_or_type_error(
    ctx: GenerationContext,
    production_method: MethodSig,
    method_context: MethodExecutionContext,
    block: str,
) -> str | None:
    schemas = _schema_contracts(method_context)
    variables = _infer_block_variable_types(ctx, production_method, method_context, block)
    for variable, type_name in variables.items():
        schema = schemas.get(type_name)
        if schema is None:
            continue
        allowed = set(_OBJECT_METHODS)
        properties_by_setter = {}
        for prop in schema.properties:
            if prop.getter:
                allowed.add(prop.getter)
            if prop.setter:
                allowed.add(prop.setter)
                properties_by_setter[prop.setter] = prop
            if prop.builder_method:
                allowed.add(prop.builder_method)
        observed = set(re.findall(rf"\b{re.escape(variable)}\s*\.\s*([A-Za-z_$][\w$]*)\s*\(", block))
        invalid = sorted(observed - allowed)
        if invalid:
            return (
                f"unknown member(s) on verified type {type_name}: {', '.join(invalid)}; "
                f"verified alternatives: {', '.join(sorted(allowed)) or 'none'}"
            )
        for setter, argument in re.findall(
            rf"\b{re.escape(variable)}\s*\.\s*(set[A-Za-z0-9_$]+)\s*\(\s*([^;\n]*?)\s*\)\s*;",
            block,
        ):
            prop = properties_by_setter.get(setter)
            if prop is None:
                continue
            arg = argument.strip()
            expected = _simple_type(prop.resolved_type or prop.type_name)
            if prop.kind == PropertyKind.ENUM:
                if re.fullmatch(r"'.*'|\".*\"", arg):
                    return f"{type_name}.{setter} requires enum {expected}, not character/string literal {arg}"
                enum_match = re.fullmatch(r"([A-Z][\w$]*)\.([A-Z][A-Z0-9_]*)", arg)
                if enum_match:
                    enum_type, constant = enum_match.groups()
                    if enum_type != expected or (prop.enum_constants and constant not in prop.enum_constants):
                        return f"invalid enum value {arg} for {type_name}.{setter}; allowed: {', '.join(prop.enum_constants)}"
            if prop.kind == PropertyKind.SET and re.search(r"\b(?:List\.of|Arrays\.asList|Collections\.singletonList|new\s+ArrayList)\b", arg):
                return f"{type_name}.{setter} requires Set<{prop.element_type or '?'}>, not a List expression"
            if prop.kind == PropertyKind.LIST and re.search(r"\b(?:Set\.of|Collections\.singleton|new\s+(?:HashSet|LinkedHashSet))\b", arg):
                return f"{type_name}.{setter} requires List<{prop.element_type or '?'}>, not a Set expression"
            if expected in {"Date", "LocalDate", "LocalDateTime", "Instant"} and re.fullmatch(r'".*"', arg):
                return f"{type_name}.{setter} requires {expected}, not String"
            if expected in {"Character", "char"} and re.fullmatch(r'".*"', arg):
                return f"{type_name}.{setter} requires {expected}, not String"
    # Type-qualified enum constants can be checked even without a local variable.
    enum_schemas = {schema.type_name: schema for schema in method_context.payload_schemas if schema.enum_constants}
    for enum_type, constant in re.findall(r"\b([A-Z][\w$]*)\.([A-Z][A-Z0-9_]*)\b", block):
        schema = enum_schemas.get(enum_type)
        if schema and constant not in schema.enum_constants:
            return f"unknown enum constant {enum_type}.{constant}; allowed: {', '.join(schema.enum_constants)}"
    return None


def _mockito_contract_error(ctx: GenerationContext, method_context: MethodExecutionContext, block: str) -> str | None:
    contracts: dict[tuple[str, str], list] = {}
    for invocation in method_context.dependency_invocations:
        contracts.setdefault((invocation.dependency_field, invocation.method_name), []).append(invocation)
    _, fixture_by_method, _ = _fixture_contracts(ctx, method_context)
    for (field, method_name), invocations in contracts.items():
        return_types = {inv.contract.return_type for inv in invocations if inv.contract.return_type is not None}
        is_void = bool(invocations) and all(inv.contract.is_void for inv in invocations)
        is_non_void = bool(invocations) and all(inv.contract.is_non_void for inv in invocations)
        when_pattern = rf"\b(?:when|given)\s*\(\s*{re.escape(field)}\s*\.\s*{re.escape(method_name)}\s*\("
        do_nothing_pattern = rf"\bdoNothing\s*\(\s*\)\s*\.\s*when\s*\(\s*{re.escape(field)}\s*\)\s*\.\s*{re.escape(method_name)}\s*\("
        has_when = re.search(when_pattern, block, flags=re.DOTALL) is not None
        has_return_stub = re.search(
            when_pattern + r".*?\)\s*\.\s*(?:thenReturn|willReturn)\s*\(",
            block,
            flags=re.DOTALL,
        ) is not None
        has_do_nothing = re.search(do_nothing_pattern, block, flags=re.DOTALL) is not None
        unresolved_contract = any(not inv.contract.is_resolved for inv in invocations)
        unresolved_flow = any(not inv.return_flow_is_resolved for inv in invocations)
        unresolved_required = any(
            inv.branch_id is None
            and (not inv.contract.is_resolved or not inv.return_flow_is_resolved)
            and (inv.return_value_consumed or not inv.return_flow_is_resolved)
            for inv in invocations
        )
        if unresolved_contract or unresolved_flow:
            if has_when or has_do_nothing or unresolved_required:
                return (
                    f"UNRESOLVED_COLLABORATOR_CONTRACT: {field}.{method_name}; "
                    "do not infer void/non-void behavior or create speculative stubbing"
                )
            continue
        if is_void and has_when:
            return f"invalid Mockito stubbing: {field}.{method_name} is void and cannot be used in when(...).thenReturn(...)"
        if is_non_void and has_do_nothing:
            return f"invalid Mockito stubbing: {field}.{method_name} is non-void; doNothing() is not applicable"
        if is_non_void and has_when:
            pattern = re.compile(
                rf"(?:when|given)\s*\(\s*{re.escape(field)}\s*\.\s*{re.escape(method_name)}\s*\(.*?\)\s*\)"
                rf"\s*\.\s*(?:thenReturn|willReturn)\s*\(\s*([A-Za-z_$][\w$]*)\s*\(\s*\)\s*\)",
                flags=re.DOTALL,
            )
            for helper_name in pattern.findall(block):
                fixture = fixture_by_method.get(helper_name)
                if fixture:
                    expected = {_simple_type(value) for value in return_types if value}
                    actual = _simple_type(fixture.return_type)
                    if expected and actual not in expected:
                        return (
                            f"Mockito return type mismatch for {field}.{method_name}: expected "
                            f"{', '.join(sorted(expected))}, fixture {helper_name}() returns {actual}"
                        )
        proven_ignored = all(
            inv.return_flow_is_resolved and not _invocation_return_is_consumed(inv)
            for inv in invocations
        )
        if is_non_void and proven_ignored and has_return_stub:
            return (
                f"unnecessary return stubbing for {field}.{method_name}: the ServiceImpl ignores this invocation result; "
                "generate no normal stub and optionally verify the interaction"
            )
    if re.search(r"\.thenReturn\s*\(\s*\)", block):
        return "invalid Mockito stubbing: thenReturn() requires a value"
    return None


def _invalid_checked_exception_stub_error(
    method_context: MethodExecutionContext,
    block: str,
) -> str | None:
    """Reject high-confidence illegal checked exceptions before Surefire."""
    known_checked = {
        "Exception",
        "Throwable",
        "InterruptedException",
        "IOException",
        "FileNotFoundException",
        "SQLException",
        "ParseException",
        "ExecutionException",
        "TimeoutException",
        "CloneNotSupportedException",
        "ReflectiveOperationException",
        "ClassNotFoundException",
    }
    for invocation in method_context.dependency_invocations:
        field = invocation.dependency_field
        method_name = invocation.method_name
        declared = {_simple_type(value) for value in invocation.contract.throws}
        patterns = (
            re.compile(
                rf"(?:when|given)\s*\(\s*{re.escape(field)}\s*\.\s*"
                rf"{re.escape(method_name)}\s*\(.*?\)\s*\)\s*\.\s*"
                rf"(?:thenThrow|willThrow)\s*\(\s*new\s+([\w.]+)",
                flags=re.DOTALL,
            ),
            re.compile(
                rf"doThrow\s*\(\s*new\s+([\w.]+).*?\)\s*\.\s*when\s*\(\s*"
                rf"{re.escape(field)}\s*\)\s*\.\s*{re.escape(method_name)}\s*\(",
                flags=re.DOTALL,
            ),
        )
        for pattern in patterns:
            for exception_type in pattern.findall(block):
                simple = _simple_type(exception_type)
                if simple in known_checked and simple not in declared:
                    declared_text = ", ".join(sorted(declared)) or "(none)"
                    return (
                        f"invalid Mockito checked-exception stubbing for {field}.{method_name}: "
                        f"{simple} is not declared by the collaborator method; declared throws: "
                        f"{declared_text}. Use a declared checked exception, a source-proven "
                        "unchecked exception, or remove the impossible scenario."
                    )
    return None




def _mask_java_literals_and_comments(source: str) -> str:
    """Mask comments and string/char literals while preserving offsets."""
    pattern = re.compile(
        r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',
        flags=re.DOTALL,
    )
    return pattern.sub(lambda match: " " * len(match.group(0)), source)


def _unsupported_assertion_error(block: str) -> str | None:
    if re.search(r"\b(?:org\.assertj\.core\.api\.Assertions\s*\.|AssertionsForClassTypes\s*\.|Assertions\s*\.)?assertThat\s*\(", block):
        return (
            "Unsupported assertion framework: AssertJ assertThat(...). "
            "Use JUnit Jupiter assertions already provided by the deterministic skeleton."
        )
    if re.search(r"\bMatcherAssert\s*\.\s*assertThat\s*\(", block):
        return "Unsupported assertion framework: Hamcrest. Use JUnit Jupiter assertions."
    if re.search(r"\b(?:Truth|com\.google\.common\.truth\.Truth)\s*\.\s*assertThat\s*\(", block):
        return "Unsupported assertion framework: Google Truth. Use JUnit Jupiter assertions."
    return None


def _declared_test_identifiers(block: str) -> set[str]:
    masked = _mask_java_literals_and_comments(block)
    names = set(re.findall(
        r"\b(?:final\s+)?[A-Za-z_$][\w$]*(?:\s*<[^;(){}]+>)?(?:\[\])?\s+"
        r"([A-Za-z_$][\w$]*)\s*(?==|;|,|\))",
        masked,
    ))
    names.update(re.findall(r"\b([A-Za-z_$][\w$]*)\s*->", masked))
    names.update(
        name
        for group in re.findall(r"\(([^()]*)\)\s*->", masked)
        for name in re.findall(r"\b([A-Za-z_$][\w$]*)\b", group)
    )
    return names


def _production_scope_identifier_error(
    ctx: GenerationContext,
    method_context: MethodExecutionContext,
    block: str,
) -> str | None:
    """Reject CUT fields copied as unqualified test-method identifiers."""
    masked = _mask_java_literals_and_comments(block)
    declared = _declared_test_identifiers(block)
    dependency_fields = {
        dependency.field_name or dependency.parameter_name
        for dependency in (ctx.execution_context.dependencies if ctx.execution_context else ())
        if dependency.field_name or dependency.parameter_name
    }
    config_by_name = {
        field.field_name: field
        for field in (ctx.execution_context.configuration_fields if ctx.execution_context else ())
    }
    for field in ctx.symbol.fields or ():
        name = field.name
        if name in declared or name in dependency_fields:
            continue
        cut_var = cut_variable_name(ctx.symbol.name)
        direct_cut_access = re.search(
            rf"\b{re.escape(cut_var)}\s*\.\s*{re.escape(name)}(?![\w$])",
            masked,
        ) is not None
        unqualified_access = re.search(
            rf"(?<![.\w$]){re.escape(name)}(?![\w$])",
            masked,
        ) is not None
        if not direct_cut_access and not unqualified_access:
            continue
        if "static" in (field.modifiers or set()) and "final" in (field.modifiers or set()):
            continue
        config = config_by_name.get(name)
        exact = config.test_value if config is not None else None
        alternative = (
            f" Use the deterministic test-side value {exact} only when exact forwarding is required;"
            if exact else ""
        )
        primitive = _simple_type(field.type)
        matcher = {
            "char": "anyChar()", "Character": "anyChar()",
            "byte": "anyByte()", "Byte": "anyByte()",
            "short": "anyShort()", "Short": "anyShort()",
            "int": "anyInt()", "Integer": "anyInt()",
            "long": "anyLong()", "Long": "anyLong()",
            "float": "anyFloat()", "Float": "anyFloat()",
            "double": "anyDouble()", "Double": "anyDouble()",
            "boolean": "anyBoolean()", "Boolean": "anyBoolean()",
        }.get(primitive, f"any({primitive}.class)")
        visibility = "private " if "private" in (field.modifiers or set()) else ""
        return (
            f"Identifier `{name}` is not available in generated test scope; it is a {visibility}CUT field."
            f"{alternative} Use {matcher} when the argument is scenario-irrelevant."
        )
    return None

def validate_method_block(
    ctx: GenerationContext,
    production_method: MethodSig,
    method_context: MethodExecutionContext,
    block: str,
    existing_names: set[str],
) -> MethodBlockValidation:
    if not block.strip() or "@Test" not in block:
        return MethodBlockValidation(False, "no @Test methods returned")
    if re.search(r"(?m)^\s*(package|import)\b|\bclass\s+\w+", block):
        return MethodBlockValidation(False, "method response contains package/import/class wrapper")

    names = test_method_names(block)
    if not names:
        return MethodBlockValidation(False, "unable to identify generated test method names")
    duplicates = set(names) & existing_names
    if duplicates:
        return MethodBlockValidation(False, f"duplicate test method names: {', '.join(sorted(duplicates))}")
    if len(names) != len(set(names)):
        return MethodBlockValidation(False, "duplicate test names within method response")

    cut_var = cut_variable_name(ctx.symbol.name)
    called_cut_methods = set(re.findall(rf"\b{re.escape(cut_var)}\s*\.\s*([A-Za-z_$][\w$]*)\s*\(", block))
    # A test may legitimately name OTHER public methods of the CUT -- especially a
    # "funnel" class with one public entry point that delegates to sibling public
    # methods. Only reject a call to a method that is actually PRIVATE (calling a
    # private method directly is a real violation). Public sibling calls are
    # advisory; javac and the runtime arbitrate.
    public_cut_methods = {
        m.name for m in (ctx.symbol.methods or []) if getattr(m, "is_public", False)
    }
    other_calls = called_cut_methods - {production_method.name}
    # A call to another method on the CUT is NOT terminal. For a funnel class
    # (one public entry delegating to helpers) the model naturally references the
    # helpers. If a call is genuinely to a private method, javac rejects that one
    # line and repair fixes it -- far better than dropping the whole suite and
    # generating nothing. So: advisory, never terminal. javac arbitrates.
    private_other_calls = sorted(m for m in other_calls if m not in public_cut_methods)
    advisory_cut_calls = sorted(other_calls & public_cut_methods)
    if (
        ctx.execution_context is not None
        and ctx.execution_context.target_kind.value == "service-impl"
        and production_method.name not in called_cut_methods
    ):
        return MethodBlockValidation(False, "ServiceImpl tests do not call the selected CUT method")
    if re.search(rf"\b(?:when|verify)\s*\(\s*{re.escape(cut_var)}\b", block) or re.search(
        rf"\.when\s*\(\s*{re.escape(cut_var)}\b", block
    ):
        return MethodBlockValidation(False, "response stubs or verifies the class under test")

    for deterministic_error in (
        _unsupported_assertion_error(block),
        _production_scope_identifier_error(ctx, method_context, block),
        _direct_schema_construction_error(ctx, method_context, block),
        _unknown_application_type_error(ctx, method_context, block),
        _unknown_constant_error(ctx, method_context, block),
        _schema_member_or_type_error(ctx, production_method, method_context, block),
        _invalid_checked_exception_stub_error(method_context, block),
        _mockito_contract_error(ctx, method_context, block),
    ):
        if deterministic_error:
            return MethodBlockValidation(False, deterministic_error)

    missing_stubs = _missing_required_collaborator_stubs(method_context, block)
    if missing_stubs:
        return MethodBlockValidation(
            False,
            "response omits required collaborator stubs across the selected public/helper path: "
            + ", ".join(missing_stubs),
        )

    # Map<?, ?> is readable but cannot be mutated because neither key nor value
    # has a writable captured type. Catch this before javac creates a .failing
    # file and route the block through the bounded structural repair.
    mutated_wildcard_maps = list(_mutated_wildcard_map_variables(block))
    if mutated_wildcard_maps:
        return MethodBlockValidation(
            False,
            "response mutates wildcard Map<?, ?> variable(s): "
            + ", ".join(mutated_wildcard_maps)
            + "; use Map<String, Object> (with an explicit checked/unchecked cast from the verified fixture) before mutation",
        )

    # ------------------------------------------------------------------
    # ADVISORY ONLY.  Previously this rejected the block outright, which meant a
    # single analyzer extraction gap (chained call, lambda, stream, ternary)
    # silently destroyed a whole method's tests with no repair path.  The
    # analyzer under-approximates Java; it must not outrank javac.
    # ------------------------------------------------------------------
    warnings: list[str] = []
    allowed_calls: dict[str, set[str]] = {}
    for invocation in method_context.dependency_invocations:
        allowed_calls.setdefault(invocation.dependency_field, set()).add(invocation.method_name)
    for dependency in ctx.execution_context.dependencies if ctx.execution_context else ():
        field = dependency.field_name or dependency.parameter_name
        if not field:
            continue
        observed = set(re.findall(rf"\b{re.escape(field)}\s*\.\s*([A-Za-z_$][\w$]*)\s*\(", block))
        invalid = observed - allowed_calls.get(field, set())
        if invalid:
            warnings.append(
                f"unobserved collaborator calls on {field}: {', '.join(sorted(invalid))} "
                f"(advisory; deferred to javac)"
            )

    # Duplicate private helpers across concurrently generated blocks would be a
    # real compile error, so this one IS terminal.
    helpers = set(re.findall(r"(?m)^\s*private\s+[\w<>\[\],.\s]+\s+(\w+)\s*\(", block))
    if helpers:
        return MethodBlockValidation(
            False,
            f"response defines private helper methods: {', '.join(sorted(helpers))}; "
            f"call existing fixture builders instead",
        )

    if advisory_cut_calls:
        warnings.append(
            "response also calls sibling public CUT methods: "
            + ", ".join(advisory_cut_calls) + " (advisory; funnel class)"
        )
    if private_other_calls:
        warnings.append(
            "response references non-public CUT methods: "
            + ", ".join(private_other_calls)
            + " (advisory; if truly private, javac will flag the direct call and "
            "repair will route it through the public method)"
        )

    return MethodBlockValidation(True, test_names=names, warnings=tuple(warnings))


def insert_method_block(suite: str, method_id: str, block: str) -> str:
    marker = f"{_BEGIN}{method_id}\n"
    end_marker = f"{_END}{method_id}\n"
    indented = "\n".join("    " + line if line.strip() else "" for line in block.splitlines())
    insertion = f"    {marker}{indented}\n    {end_marker}"
    close = suite.rfind("}")
    if close < 0:
        raise ValueError("test skeleton has no closing class brace")
    prefix = suite[:close].rstrip()
    return prefix + "\n\n" + insertion.rstrip() + "\n}\n"


def method_block_for_id(suite: str, method_id: str) -> str | None:
    pattern = re.compile(
        rf"(?ms)^\s*{re.escape(_BEGIN + method_id)}\s*$\n(.*?)^\s*{re.escape(_END + method_id)}\s*$"
    )
    match = pattern.search(suite)
    return match.group(1) if match else None


def replace_method_block(suite: str, method_id: str, block: str) -> str:
    pattern = re.compile(
        rf"(?ms)^\s*{re.escape(_BEGIN + method_id)}\s*$\n.*?^\s*{re.escape(_END + method_id)}\s*$"
    )
    # ``method_block_for_id`` returns the block with its existing class-member
    # indentation.  Dedent before re-indenting so every repair is idempotent;
    # otherwise each attempt shifts all sibling tests four spaces to the right
    # and makes source-preservation checks report false sibling changes.
    normalized = textwrap.dedent(block).strip("\n")
    indented = "\n".join("    " + line if line.strip() else "" for line in normalized.splitlines())
    replacement = f"    {_BEGIN}{method_id}\n{indented}\n    {_END}{method_id}"
    updated, count = pattern.subn(replacement, suite, count=1)
    if count != 1:
        raise ValueError(f"method block not found: {method_id}")
    return updated


def owner_method_id_for_line(suite: str, line_number: int | None) -> str | None:
    if line_number is None:
        return None
    current: str | None = None
    for index, line in enumerate(suite.splitlines(), start=1):
        stripped = line.strip()
        if stripped.startswith(_BEGIN):
            current = stripped[len(_BEGIN):].strip()
        elif stripped.startswith(_END):
            current = None
        if index == line_number:
            return current
    return None


def owner_method_id_for_test_name(suite: str, test_name: str | None) -> str | None:
    """Resolve a generated JUnit method to its deterministic production owner."""
    if not test_name:
        return None
    current: str | None = None
    annotation_seen = False
    method_pattern = re.compile(
        r"\b(?:public\s+|protected\s+|private\s+)?(?:final\s+)?void\s+"
        + re.escape(test_name)
        + r"\s*\("
    )
    for line in suite.splitlines():
        stripped = line.strip()
        if stripped.startswith(_BEGIN):
            current = stripped[len(_BEGIN):].strip()
            annotation_seen = False
            continue
        if stripped.startswith(_END):
            current = None
            annotation_seen = False
            continue
        if current is None:
            continue
        if stripped.startswith("@Test"):
            if method_pattern.search(line):
                return current
            annotation_seen = True
            continue
        if annotation_seen and method_pattern.search(line):
            return current
        if annotation_seen and stripped and not stripped.startswith("@"):
            # The declaration may span annotations but not arbitrary statements.
            annotation_seen = False
    return None