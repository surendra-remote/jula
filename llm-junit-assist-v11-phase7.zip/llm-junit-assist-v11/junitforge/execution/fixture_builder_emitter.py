"""Deterministic reusable Java fixture emission.

The emitter consumes the authoritative parser-built schema catalogue.  It emits
bounded baseline graphs, records every guaranteed relationship, and fails closed
when a required child or collection element cannot be constructed safely.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, replace
from typing import Iterable

from junitforge.execution.models import (
    ConstructionKind,
    FixtureCompileStatus,
    FixtureCycleDecision,
    FixtureSpec,
    FixtureSupportStatus,
    MapEntrySchema,
    MapSchema,
    PayloadProperty,
    PayloadSchema,
    PropertyKind,
    ResolutionStatus,
)


def _simple(type_name: str | None) -> str:
    text = (type_name or "Object").strip().replace("...", "")
    return text.rsplit(".", 1)[-1]


def _raw_simple(type_name: str | None) -> str:
    return _simple((type_name or "Object").split("<", 1)[0].replace("[]", ""))


def _safe_identifier(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_$]", "", value)
    if not cleaned:
        return "Fixture"
    return cleaned if cleaned[0].isalpha() or cleaned[0] in "_$" else f"T{cleaned}"


def _variable(value: str) -> str:
    cleaned = _safe_identifier(value)
    return cleaned[:1].lower() + cleaned[1:]


@dataclass(slots=True)
class EmittedFixtures:
    helpers: list[str] = field(default_factory=list)
    fixtures: list[FixtureSpec] = field(default_factory=list)
    imports: set[str] = field(default_factory=set)
    diagnostics: list[str] = field(default_factory=list)
    back_edges: list[tuple[str, str]] = field(default_factory=list)


@dataclass(slots=True)
class _ValuePlan:
    expression: str | None
    prelude: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    dependency_relationships: list[tuple[str, str]] = field(default_factory=list)
    scalar_guarantees: list[tuple[str, str]] = field(default_factory=list)
    relationship_guarantees: list[str] = field(default_factory=list)
    identity_guarantees: list[str] = field(default_factory=list)
    blockers: list[str] = field(default_factory=list)


class FixtureBuilderEmitter:
    def __init__(self, schemas: Iterable[PayloadSchema], map_schemas: Iterable[MapSchema] = ()):
        self.schemas = list(schemas)
        self.map_schemas = list(map_schemas)
        self.by_id: dict[str, PayloadSchema] = {}
        self.by_name: dict[str, PayloadSchema] = {}
        self._schema_position: dict[str, int] = {}
        for index, schema in enumerate(self.schemas):
            sid = schema.fqcn or schema.type_name
            self.by_id[sid] = schema
            self.by_name.setdefault(schema.type_name, schema)
            if schema.fqcn:
                self.by_name.setdefault(schema.fqcn, schema)
            self._schema_position[sid] = index
        self.map_by_id = {m.schema_id: m for m in self.map_schemas}
        self.imports: set[str] = set()
        self.diagnostics: list[str] = []
        self.back_edges: list[tuple[str, str]] = []
        self._method_name: dict[str, str] = {}
        self._used_names: set[str] = set()
        self._duplicate_simple = {
            name for name in {s.type_name for s in self.schemas}
            if sum(1 for s in self.schemas if s.type_name == name and s.fqcn) > 1
        }
        self._emitted_specs: dict[str, FixtureSpec] = {}
        self._cycle_decisions: dict[str, list[FixtureCycleDecision]] = {}
        self._omitted_cycle_edges: set[tuple[str, str]] = set()
        self._plan_cycle_edges()

    def emit_all(self) -> EmittedFixtures:
        # Assign names before source emission so every dependency call is stable.
        for schema in sorted(self.schemas, key=lambda item: (item.fqcn or item.type_name)):
            if schema.kind != "enum":
                self._schema_method_name(schema)
        for schema in sorted(self.map_schemas, key=lambda item: item.schema_id):
            self._map_method_name(schema)

        fixtures: list[FixtureSpec] = []
        emitted: set[str] = set()

        def visit_schema(schema_id: str, stack: tuple[str, ...] = ()) -> None:
            schema = self.by_id.get(schema_id) or self.by_name.get(schema_id) or self.by_name.get(_simple(schema_id))
            if schema is None:
                return
            sid = schema.fqcn or schema.type_name
            if sid in emitted or sid in stack:
                return
            for prop in schema.properties:
                for ref in prop.nested_schema_refs:
                    child = self._child(ref)
                    if child and child.kind != "enum" and (sid, prop.name) not in self._omitted_cycle_edges:
                        visit_schema(child.fqcn or child.type_name, (*stack, sid))
            spec = self._emit_schema(schema)
            emitted.add(sid)
            self._emitted_specs[sid] = spec
            fixtures.append(spec)

        for schema in sorted(
            self.schemas,
            key=lambda item: (item.depth, self._schema_position.get(item.fqcn or item.type_name, 0)),
        ):
            if schema.kind != "enum":
                visit_schema(schema.fqcn or schema.type_name)

        emitted_maps: set[str] = set()

        def visit_map(schema_id: str, stack: tuple[str, ...] = ()) -> None:
            if schema_id in emitted_maps or schema_id in stack:
                return
            schema = self.map_by_id.get(schema_id)
            if schema is None:
                return
            for entry in schema.entries:
                if entry.nested_schema_id:
                    visit_map(entry.nested_schema_id, (*stack, schema_id))
                if entry.collection_element_schema_id:
                    visit_map(entry.collection_element_schema_id, (*stack, schema_id))
            spec = self._emit_map(schema)
            emitted_maps.add(schema_id)
            self._emitted_specs[schema_id] = spec
            fixtures.append(spec)

        for schema in self.map_schemas:
            visit_map(schema.schema_id)

        fixtures, semantic_diagnostics = self._semantic_validate(fixtures)
        fixtures = self._with_transitive_dependencies(fixtures)
        helpers = [
            fixture.method_source
            for fixture in fixtures
            if fixture.supported and fixture.semantic_valid and fixture.method_source
        ]
        self.diagnostics.extend(semantic_diagnostics)
        return EmittedFixtures(
            helpers=helpers,
            fixtures=fixtures,
            imports=set(self.imports),
            diagnostics=list(dict.fromkeys(self.diagnostics)),
            back_edges=list(self.back_edges),
        )

    def _schema_method_name(self, schema: PayloadSchema) -> str:
        sid = schema.fqcn or schema.type_name
        if sid in self._method_name:
            return self._method_name[sid]
        base = schema.fixture_method_name or f"valid{_safe_identifier(schema.type_name)}"
        if schema.type_name in self._duplicate_simple and schema.package_name:
            base += _safe_identifier(schema.package_name.rsplit(".", 1)[-1])
        name = self._unique_method_name(base)
        self._method_name[sid] = name
        return name

    def _map_method_name(self, schema: MapSchema) -> str:
        if schema.schema_id in self._method_name:
            return self._method_name[schema.schema_id]
        base = schema.fixture_method_name or f"valid{_safe_identifier(schema.semantic_name)}"
        name = self._unique_method_name(base)
        self._method_name[schema.schema_id] = name
        return name

    def _unique_method_name(self, base: str) -> str:
        name = base
        suffix = 2
        while name in self._used_names:
            name = f"{base}{suffix}"
            suffix += 1
        self._used_names.add(name)
        return name

    def _type_ref(self, schema: PayloadSchema) -> str:
        if schema.type_name in self._duplicate_simple and schema.fqcn:
            return schema.fqcn
        return schema.type_name

    def _child(self, ref: str | None) -> PayloadSchema | None:
        if not ref:
            return None
        return self.by_id.get(ref) or self.by_name.get(ref) or self.by_name.get(_simple(ref))

    def _plan_cycle_edges(self) -> None:
        visited: set[str] = set()
        active: list[str] = []

        def walk(schema: PayloadSchema) -> None:
            sid = schema.fqcn or schema.type_name
            if sid in visited:
                return
            visited.add(sid)
            active.append(sid)
            for prop in schema.properties:
                if not prop.nested_schema_refs:
                    continue
                child = self._child(prop.nested_schema_refs[0])
                if child is None or child.kind == "enum":
                    continue
                child_id = child.fqcn or child.type_name
                path = f"{schema.type_name}.{prop.name}"
                if child_id in active:
                    decision = FixtureCycleDecision(
                        owner_fixture_id=sid,
                        property_name=prop.name,
                        relationship_path=path,
                        target_fixture_id=child_id,
                        action="omit-reverse-edge",
                        reason="edge returns to an object already in the active fixture path",
                    )
                    self._cycle_decisions.setdefault(sid, []).append(decision)
                    self._omitted_cycle_edges.add((sid, prop.name))
                    self.back_edges.append((sid, prop.name))
                    self.diagnostics.append(f"cycle reverse edge omitted: {path} -> {child_id}")
                    continue
                if self._path_exists(child_id, sid):
                    self._cycle_decisions.setdefault(sid, []).append(FixtureCycleDecision(
                        owner_fixture_id=sid,
                        property_name=prop.name,
                        relationship_path=path,
                        target_fixture_id=child_id,
                        action="preserve-forward-edge",
                        reason="minimum safe forward graph retains this edge; the returning edge is omitted",
                    ))
                walk(child)
            active.pop()

        for schema in sorted(
            self.schemas,
            key=lambda item: (item.depth, self._schema_position.get(item.fqcn or item.type_name, 0)),
        ):
            if schema.kind != "enum":
                walk(schema)

    def _path_exists(self, start_id: str, target_id: str, seen: set[str] | None = None) -> bool:
        if start_id == target_id:
            return True
        seen = set() if seen is None else seen
        if start_id in seen:
            return False
        seen.add(start_id)
        schema = self._child(start_id)
        if schema is None:
            return False
        sid = schema.fqcn or schema.type_name
        for prop in schema.properties:
            for ref in prop.nested_schema_refs:
                child = self._child(ref)
                child_id = (child.fqcn or child.type_name) if child else ref
                if child_id == target_id or self._path_exists(child_id, target_id, seen):
                    return True
        return False

    def _emit_schema(self, schema: PayloadSchema) -> FixtureSpec:
        sid = schema.fqcn or schema.type_name
        method_name = self._schema_method_name(schema)
        type_ref = self._type_ref(schema)
        diagnostics = list(schema.diagnostics)
        cycle_decisions = tuple(self._cycle_decisions.get(sid, ()))
        omitted_edges = tuple(
            decision.relationship_path
            for decision in cycle_decisions
            if decision.action == "omit-reverse-edge"
        )
        if schema.resolution_status != ResolutionStatus.RESOLVED:
            diagnostics.append("schema unresolved")
        if schema.kind == "enum" or schema.construction_kind == ConstructionKind.ENUM:
            return self._unsupported_fixture(
                sid, method_name, type_ref, sid,
                ("enum schemas use constants, not fixture methods",),
                cycle_decisions=cycle_decisions,
                omitted_edges=omitted_edges,
            )
        if schema.construction_kind == ConstructionKind.UNSUPPORTED or schema.resolution_status != ResolutionStatus.RESOLVED:
            diagnostics.append(f"unsupported construction kind for {type_ref}")
            return self._unsupported_fixture(
                sid, method_name, type_ref, sid, tuple(diagnostics),
                cycle_decisions=cycle_decisions,
                omitted_edges=omitted_edges,
            )

        dependencies: list[str] = []
        dependency_relationships: list[tuple[str, str]] = []
        required_paths: list[str] = []
        minimum_sizes: list[tuple[str, int]] = []
        scalar_guarantees: list[tuple[str, str]] = []
        relationship_guarantees: list[str] = []
        identity_guarantees: list[str] = []
        blockers: list[str] = []
        prop_values: dict[str, str] = {}
        prelude_by_property: dict[str, list[str]] = {}

        for prop in schema.properties:
            plan = self._value_plan(schema, prop)
            dependencies.extend(plan.dependencies)
            dependency_relationships.extend(plan.dependency_relationships)
            scalar_guarantees.extend(plan.scalar_guarantees)
            relationship_guarantees.extend(plan.relationship_guarantees)
            identity_guarantees.extend(plan.identity_guarantees)
            blockers.extend(plan.blockers)
            if prop.baseline_required and prop.kind in {
                PropertyKind.OBJECT, PropertyKind.LIST, PropertyKind.SET, PropertyKind.COLLECTION,
                PropertyKind.MAP, PropertyKind.OPTIONAL, PropertyKind.ARRAY, PropertyKind.PAGE,
                PropertyKind.RESPONSE_ENTITY, PropertyKind.WRAPPER,
            }:
                required_paths.append(prop.name)
            if prop.kind in {
                PropertyKind.LIST, PropertyKind.SET, PropertyKind.COLLECTION,
                PropertyKind.PAGE, PropertyKind.ARRAY,
            } and prop.name in plan.relationship_guarantees:
                minimum_sizes.append((prop.name, max(1, prop.minimum_size)))
            elif prop.minimum_size > 0:
                minimum_sizes.append((prop.name, prop.minimum_size))
            if plan.expression is not None:
                prop_values[prop.name] = plan.expression
                prelude_by_property[prop.name] = plan.prelude

        writable_names = {
            prop.name
            for prop in schema.properties
            if prop.setter or prop.builder_method or prop.field_public or prop.constructor_index is not None
        }
        for prop in schema.properties:
            if prop.baseline_required and prop.name not in writable_names and prop.name not in {
                name for _, name in schema.constructor_parameters
            } and (sid, prop.name) not in self._omitted_cycle_edges:
                blockers.append(f"required property is not writable: {schema.type_name}.{prop.name}")

        if blockers:
            diagnostics.extend(blockers)
            return FixtureSpec(
                fixture_id=sid,
                method_name=method_name,
                return_type=type_ref,
                schema_id=sid,
                dependent_fixture_ids=tuple(dict.fromkeys(dependencies)),
                dependency_relationship_paths=tuple(dict.fromkeys(dependency_relationships)),
                required_relationship_paths=tuple(dict.fromkeys(required_paths)),
                minimum_collection_sizes=tuple(dict.fromkeys(minimum_sizes)),
                cycle_decisions=cycle_decisions,
                omitted_edges=omitted_edges,
                support_status=FixtureSupportStatus.PARTIAL,
                compile_status=FixtureCompileStatus.NOT_COMPILED,
                semantic_valid=False,
                blocking_reasons=tuple(dict.fromkeys(blockers)),
                imports=tuple(sorted(self.imports)),
                method_source="",
                supported=False,
                diagnostics=tuple(dict.fromkeys(diagnostics)),
            )

        var = _variable(schema.type_name)
        lines = [f"    private {type_ref} {method_name}() {{"]
        for prop in schema.properties:
            lines.extend(prelude_by_property.get(prop.name, ()))

        if schema.construction_kind == ConstructionKind.BUILDER:
            lines.append(f"        {type_ref} {var} = {type_ref}.builder()")
            builder_count = 0
            for prop in schema.properties:
                value = prop_values.get(prop.name)
                if value is None or not prop.builder_method:
                    continue
                lines.append(f"                .{prop.builder_method}({value})")
                builder_count += 1
            lines.append("                .build();")
            for prop in schema.properties:
                value = prop_values.get(prop.name)
                if value is not None and prop.setter and not prop.builder_method:
                    lines.append(f"        {var}.{prop.setter}({value});")
            if builder_count == 0:
                diagnostics.append("builder detected but no verified builder properties")
        elif schema.construction_kind in {ConstructionKind.CONSTRUCTOR, ConstructionKind.RECORD}:
            values: list[str] = []
            for ptype, pname in schema.constructor_parameters:
                value = prop_values.get(pname)
                if value is None:
                    value = self._scalar_literal(schema.type_name, pname, ptype, ())
                values.append(value)
            lines.append(f"        {type_ref} {var} = new {type_ref}({', '.join(values)});")
            if schema.construction_kind == ConstructionKind.CONSTRUCTOR:
                ctor_names = {name for _, name in schema.constructor_parameters}
                for prop in schema.properties:
                    value = prop_values.get(prop.name)
                    if value is None or prop.name in ctor_names:
                        continue
                    if prop.setter:
                        lines.append(f"        {var}.{prop.setter}({value});")
                    elif prop.field_public:
                        lines.append(f"        {var}.{prop.name} = {value};")
        else:
            lines.append(f"        {type_ref} {var} = new {type_ref}();")
            for prop in schema.properties:
                value = prop_values.get(prop.name)
                if value is None:
                    continue
                if prop.setter:
                    lines.append(f"        {var}.{prop.setter}({value});")
                elif prop.field_public:
                    lines.append(f"        {var}.{prop.name} = {value};")
                elif prop.constructor_index is None:
                    diagnostics.append(f"unwritable property omitted: {schema.type_name}.{prop.name}")
        lines.extend((f"        return {var};", "    }"))
        return FixtureSpec(
            fixture_id=sid,
            method_name=method_name,
            return_type=type_ref,
            schema_id=sid,
            dependent_fixture_ids=tuple(dict.fromkeys(dependencies)),
            dependency_relationship_paths=tuple(dict.fromkeys(dependency_relationships)),
            required_relationship_paths=tuple(dict.fromkeys(required_paths)),
            minimum_collection_sizes=tuple(dict.fromkeys(minimum_sizes)),
            guaranteed_scalar_state=tuple(dict.fromkeys(scalar_guarantees)),
            guaranteed_relationships=tuple(dict.fromkeys(relationship_guarantees)),
            identity_guarantees=tuple(dict.fromkeys(identity_guarantees)),
            cycle_decisions=cycle_decisions,
            omitted_edges=omitted_edges,
            support_status=FixtureSupportStatus.SUPPORTED,
            compile_status=FixtureCompileStatus.NOT_COMPILED,
            semantic_valid=True,
            imports=tuple(sorted(self.imports)),
            method_source="\n".join(lines),
            supported=True,
            diagnostics=tuple(dict.fromkeys(diagnostics)),
        )

    def _unsupported_fixture(
        self,
        fixture_id: str,
        method_name: str,
        return_type: str,
        schema_id: str,
        diagnostics: tuple[str, ...],
        *,
        cycle_decisions: tuple[FixtureCycleDecision, ...] = (),
        omitted_edges: tuple[str, ...] = (),
    ) -> FixtureSpec:
        return FixtureSpec(
            fixture_id=fixture_id,
            method_name=method_name,
            return_type=return_type,
            schema_id=schema_id,
            cycle_decisions=cycle_decisions,
            omitted_edges=omitted_edges,
            support_status=FixtureSupportStatus.UNSUPPORTED,
            compile_status=FixtureCompileStatus.NOT_COMPILED,
            semantic_valid=False,
            blocking_reasons=diagnostics,
            supported=False,
            diagnostics=diagnostics,
        )

    def _value_plan(self, owner: PayloadSchema, prop: PayloadProperty) -> _ValuePlan:
        owner_id = owner.fqcn or owner.type_name
        required = prop.baseline_required or prop.minimum_size > 0
        if (owner_id, prop.name) in self._omitted_cycle_edges:
            plan = _ValuePlan(expression=None)
            if required:
                plan.blockers.append(
                    f"required cycle reverse edge omitted: {owner.type_name}.{prop.name}"
                )
            return plan

        child = self._child(prop.nested_schema_refs[0]) if prop.nested_schema_refs else None
        child_id = (child.fqcn or child.type_name) if child else None
        child_spec = self._emitted_specs.get(child_id or "")
        plan = _ValuePlan(expression=None)

        if prop.baseline_value:
            plan.expression = prop.baseline_value
        elif (
            prop.default_initializer
            and prop.default_initializer.strip() != "null"
            and self._safe_initializer(prop.default_initializer)
        ):
            plan.expression = prop.default_initializer
        elif prop.kind == PropertyKind.ENUM:
            constants = prop.enum_constants or (child.enum_constants if child else ())
            if constants:
                type_ref = self._type_ref(child) if child else _raw_simple(prop.type_name)
                plan.expression = f"{type_ref}.{constants[0]}"
        elif prop.kind == PropertyKind.OBJECT:
            if child and child.kind == "enum" and child.enum_constants:
                plan.expression = f"{self._type_ref(child)}.{child.enum_constants[0]}"
            elif child and child_spec and child_spec.supported and child_spec.semantic_valid:
                plan.expression = f"{child_spec.method_name}()"
                plan.dependencies.append(child_id or "")
                plan.dependency_relationships.append((prop.name, child_id or ""))
                plan.relationship_guarantees.append(prop.name)
                plan.identity_guarantees.append(
                    f"{prop.name} is the exact instance returned by {child_spec.method_name}()"
                )
            else:
                plan.expression = self._scalar_literal(owner.type_name, prop.name, prop.type_name, prop.enum_constants)
        elif prop.kind in {PropertyKind.PRIMITIVE, PropertyKind.SCALAR, PropertyKind.TEMPORAL}:
            plan.expression = self._scalar_literal(owner.type_name, prop.name, prop.type_name, prop.enum_constants)
        elif prop.kind in {PropertyKind.LIST, PropertyKind.COLLECTION, PropertyKind.SET, PropertyKind.PAGE, PropertyKind.ARRAY}:
            plan = self._collection_plan(owner, prop, child, child_spec)
        elif prop.kind == PropertyKind.MAP:
            self.imports.add("java.util.LinkedHashMap")
            plan.expression = "new LinkedHashMap<>()"
            if required:
                plan.blockers.append(
                    f"required map has no authoritative entry schema: {owner.type_name}.{prop.name}"
                )
        elif prop.kind == PropertyKind.OPTIONAL:
            self.imports.add("java.util.Optional")
            wrapped = self._wrapped_value_plan(owner, prop, child, child_spec)
            plan = wrapped
            has_value = wrapped.expression is not None and not self._is_empty_or_null(wrapped.expression)
            plan.expression = "Optional.empty()" if not has_value else f"Optional.of({wrapped.expression})"
        elif prop.kind == PropertyKind.RESPONSE_ENTITY:
            self.imports.add("org.springframework.http.ResponseEntity")
            wrapped = self._wrapped_value_plan(owner, prop, child, child_spec)
            plan = wrapped
            has_value = wrapped.expression is not None and not self._is_empty_or_null(wrapped.expression)
            plan.expression = "ResponseEntity.ok().build()" if not has_value else f"ResponseEntity.ok({wrapped.expression})"
        elif prop.kind == PropertyKind.WRAPPER:
            wrapped = self._wrapped_value_plan(owner, prop, child, child_spec)
            plan = wrapped
            raw = _raw_simple(prop.type_name)
            has_value = wrapped.expression is not None and not self._is_empty_or_null(wrapped.expression)
            if raw == "CompletableFuture":
                self.imports.add("java.util.concurrent.CompletableFuture")
                plan.expression = (
                    "CompletableFuture.completedFuture(null)"
                    if not has_value else f"CompletableFuture.completedFuture({wrapped.expression})"
                )
            elif raw == "Mono":
                plan.expression = "Mono.empty()" if not has_value else f"Mono.just({wrapped.expression})"
            elif raw == "Flux":
                plan.expression = "Flux.empty()" if not has_value else f"Flux.just({wrapped.expression})"

        if prop.kind in {PropertyKind.PRIMITIVE, PropertyKind.SCALAR, PropertyKind.TEMPORAL, PropertyKind.ENUM}:
            if plan.expression is not None and plan.expression != "null":
                plan.scalar_guarantees.append((prop.name, plan.expression))
        elif plan.expression is not None and not self._is_empty_or_null(plan.expression):
            if prop.name not in plan.relationship_guarantees:
                plan.relationship_guarantees.append(prop.name)

        if required:
            if plan.expression is None or self._is_empty_or_null(plan.expression):
                plan.blockers.append(
                    f"required baseline value unresolved: {owner.type_name}.{prop.name} ({prop.type_name})"
                )
            if child_id and (child_spec is None or not child_spec.supported or not child_spec.semantic_valid):
                plan.blockers.append(
                    f"required child fixture unsupported: {owner.type_name}.{prop.name} -> {child_id}"
                )
        return plan

    def _collection_plan(
        self,
        owner: PayloadSchema,
        prop: PayloadProperty,
        child: PayloadSchema | None,
        child_spec: FixtureSpec | None,
    ) -> _ValuePlan:
        plan = _ValuePlan(expression=None)
        count = max(1, prop.minimum_size)
        element_values: list[str] = []
        if child and child.kind == "enum" and child.enum_constants:
            if prop.kind == PropertyKind.SET and count > len(child.enum_constants):
                plan.blockers.append(
                    f"cannot guarantee {count} unique enum set elements for {owner.type_name}.{prop.name}"
                )
            element_values = [
                f"{self._type_ref(child)}.{child.enum_constants[min(index, len(child.enum_constants) - 1)]}"
                for index in range(count)
            ]
        elif child and child_spec and child_spec.supported and child_spec.semantic_valid:
            if prop.kind == PropertyKind.SET and count > 1:
                plan.blockers.append(
                    f"cannot guarantee unique object equality for required set {owner.type_name}.{prop.name}"
                )
            for index in range(count):
                local = _variable(prop.name) + ("Element" if count == 1 else f"Element{index + 1}")
                plan.prelude.append(f"        {self._type_ref(child)} {local} = {child_spec.method_name}();")
                element_values.append(local)
                plan.identity_guarantees.append(
                    f"{prop.name}[{index}] is the exact {local} instance returned by {child_spec.method_name}()"
                )
            child_id = child.fqcn or child.type_name
            plan.dependencies.append(child_id)
            plan.dependency_relationships.append((prop.name, child_id))
        else:
            element_type = prop.element_type or prop.array_component_type
            if element_type:
                for index in range(count):
                    element_values.append(
                        self._scalar_literal_for_index(owner.type_name, prop.name, element_type, prop.enum_constants, index)
                    )

        if any(value == "null" for value in element_values) or not element_values:
            if prop.baseline_required or prop.minimum_size > 0:
                plan.blockers.append(
                    f"required collection element unresolved: {owner.type_name}.{prop.name} ({prop.type_name})"
                )
            element_values = []

        if prop.kind in {PropertyKind.LIST, PropertyKind.COLLECTION}:
            self.imports.update({"java.util.ArrayList", "java.util.List"})
            plan.expression = (
                "new ArrayList<>()" if not element_values
                else f"new ArrayList<>(List.of({', '.join(element_values)}))"
            )
        elif prop.kind == PropertyKind.SET:
            self.imports.update({"java.util.LinkedHashSet", "java.util.List"})
            plan.expression = (
                "new LinkedHashSet<>()" if not element_values
                else f"new LinkedHashSet<>(List.of({', '.join(element_values)}))"
            )
        elif prop.kind == PropertyKind.PAGE:
            self.imports.update({"java.util.ArrayList", "java.util.List", "org.springframework.data.domain.PageImpl"})
            plan.expression = (
                "new PageImpl<>(new ArrayList<>())" if not element_values
                else f"new PageImpl<>(new ArrayList<>(List.of({', '.join(element_values)})))"
            )
        elif prop.kind == PropertyKind.ARRAY:
            component = _raw_simple(prop.array_component_type or prop.element_type or "Object")
            plan.expression = (
                f"new {component}[0]" if not element_values
                else f"new {component}[] {{{', '.join(element_values)}}}"
            )
        if element_values:
            plan.relationship_guarantees.append(prop.name)
        return plan

    def _wrapped_value_plan(
        self,
        owner: PayloadSchema,
        prop: PayloadProperty,
        child: PayloadSchema | None,
        child_spec: FixtureSpec | None,
    ) -> _ValuePlan:
        plan = _ValuePlan(expression=None)
        if child and child.kind == "enum" and child.enum_constants:
            plan.expression = f"{self._type_ref(child)}.{child.enum_constants[0]}"
        elif child and child_spec and child_spec.supported and child_spec.semantic_valid:
            local = _variable(prop.name) + "Value"
            plan.prelude.append(f"        {self._type_ref(child)} {local} = {child_spec.method_name}();")
            plan.expression = local
            child_id = child.fqcn or child.type_name
            plan.dependencies.append(child_id)
            plan.dependency_relationships.append((prop.name, child_id))
            plan.relationship_guarantees.append(prop.name)
            plan.identity_guarantees.append(
                f"{prop.name} wraps the exact {local} instance returned by {child_spec.method_name}()"
            )
        elif prop.wrapped_type:
            plan.expression = self._scalar_literal(owner.type_name, prop.name, prop.wrapped_type, prop.enum_constants)
        return plan

    @staticmethod
    def _is_empty_or_null(expression: str) -> bool:
        text = expression.replace(" ", "")
        return text in {
            "null", "Optional.empty()", "Mono.empty()", "Flux.empty()",
            "ResponseEntity.ok().build()", "CompletableFuture.completedFuture(null)",
            "newArrayList<>()", "newLinkedHashSet<>()", "newLinkedHashMap<>()",
        } or text.endswith("[0]") or "newPageImpl<>(newArrayList<>())" in text

    @staticmethod
    def _safe_initializer(value: str) -> bool:
        text = value.strip()
        return bool(re.fullmatch(r"(?:true|false|null|-?\d+(?:\.\d+)?[fFdDlL]?|'(?:\\.|[^'])'|\"(?:\\.|[^\"])*\")", text))

    def _scalar_literal_for_index(
        self,
        owner: str,
        field_name: str,
        java_type: str,
        enum_constants: tuple[str, ...],
        index: int,
    ) -> str:
        if index == 0:
            return self._scalar_literal(owner, field_name, java_type, enum_constants)
        simple = _raw_simple(java_type)
        if simple == "String":
            return f'"{field_name}-value-{index + 1}"'
        if simple in {"byte", "Byte"}:
            return f"(byte) {index + 1}"
        if simple in {"short", "Short"}:
            return f"(short) {index + 1}"
        if simple in {"int", "Integer"}:
            return str(index + 1)
        if simple in {"long", "Long"}:
            return f"{index + 1}L"
        if simple in {"float", "Float"}:
            return f"{index + 1}.0f"
        if simple in {"double", "Double"}:
            return f"{index + 1}.0d"
        if enum_constants and index < len(enum_constants):
            return f"{simple}.{enum_constants[index]}"
        return self._scalar_literal(owner, field_name, java_type, enum_constants)

    def _scalar_literal(self, owner: str, field_name: str, java_type: str, enum_constants: tuple[str, ...]) -> str:
        simple = _raw_simple(java_type)
        lowered = field_name.lower()
        if enum_constants:
            return f"{simple}.{enum_constants[0]}"
        if simple in {"boolean", "Boolean"}:
            return "false"
        if simple in {"byte", "Byte"}:
            return "(byte) 1"
        if simple in {"short", "Short"}:
            return "(short) 1"
        if simple in {"int", "Integer"}:
            return "1"
        if simple in {"long", "Long"}:
            return "1L"
        if simple in {"float", "Float"}:
            return "1.0f"
        if simple in {"double", "Double"}:
            return "1.0d"
        if simple in {"char", "Character"}:
            return "'A'"
        if simple == "BigDecimal":
            self.imports.add("java.math.BigDecimal")
            return 'new BigDecimal("100.00")'
        if simple == "BigInteger":
            self.imports.add("java.math.BigInteger")
            return "BigInteger.ONE"
        if simple == "UUID":
            self.imports.add("java.util.UUID")
            return 'UUID.fromString("00000000-0000-0000-0000-000000000001")'
        if simple == "LocalDate":
            self.imports.add("java.time.LocalDate")
            return "LocalDate.of(2020, 1, 1)"
        if simple == "LocalDateTime":
            self.imports.add("java.time.LocalDateTime")
            return "LocalDateTime.of(2020, 1, 1, 0, 0)"
        if simple == "LocalTime":
            self.imports.add("java.time.LocalTime")
            return "LocalTime.NOON"
        if simple == "Instant":
            self.imports.add("java.time.Instant")
            return "Instant.EPOCH"
        if simple == "Date":
            self.imports.add("java.util.Date")
            return "new Date(0L)"
        if simple == "String":
            if "email" in lowered:
                value = "test@example.com"
            elif any(x in lowered for x in ("dob", "birthdate", "birth_date")):
                value = "1990-01-01"
            elif "date" in lowered or lowered.endswith("from") or lowered.endswith("to"):
                value = "2020-01-01"
            elif "gender" in lowered:
                value = "M"
            elif "country" in lowered or "nationality" in lowered:
                value = "SG"
            elif "postal" in lowered or "zipcode" in lowered:
                value = "123456"
            elif any(x in lowered for x in ("phone", "mobile", "contactvalue")):
                value = "91234567"
            elif "url" in lowered:
                value = "https://example.test"
            elif "name" in lowered:
                value = "Test Name"
            elif "code" in lowered or "ref" in lowered:
                value = "CODE1"
            elif lowered.endswith("no") or lowered.endswith("number"):
                value = "NO123"
            elif lowered.endswith("id"):
                value = "ID123"
            elif "type" in lowered:
                value = "TYPE1"
            else:
                value = f"{field_name}-value"
            return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'
        self.diagnostics.append(f"no deterministic scalar value for {owner}.{field_name}: {java_type}")
        return "null"

    def _emit_map(self, schema: MapSchema) -> FixtureSpec:
        method_name = self._map_method_name(schema)
        dependencies: list[str] = []
        dependency_relationships: list[tuple[str, str]] = []
        blockers: list[str] = []
        scalar_guarantees: list[tuple[str, str]] = []
        relationship_guarantees: list[str] = []
        minimum_sizes: list[tuple[str, int]] = []
        identity_guarantees: list[str] = []
        self.imports.update({"java.util.Map", "java.util.LinkedHashMap", "java.util.ArrayList", "java.util.List"})
        lines = [
            f"    private Map<String, Object> {method_name}() {{",
            "        Map<String, Object> value = new LinkedHashMap<>();",
        ]
        for entry in schema.entries:
            expression, entry_dependencies, entry_blockers = self._map_entry_expr(entry)
            dependencies.extend(entry_dependencies)
            for dependency_id in entry_dependencies:
                dependency_relationships.append((entry.key_literal, dependency_id))
            blockers.extend(entry_blockers)
            lines.append(f'        value.put("{entry.key_literal}", {expression});')
            if entry.nested_schema_id or entry.collection_element_schema_id:
                relationship_guarantees.append(entry.key_literal)
                identity_guarantees.append(
                    f'map key "{entry.key_literal}" contains the exact object returned by its dependent fixture'
                )
            else:
                scalar_guarantees.append((entry.key_literal, expression))
            if entry.collection_element_schema_id:
                minimum_sizes.append((entry.key_literal, 1))
        lines.extend(("        return value;", "    }"))
        if schema.resolution_status != ResolutionStatus.RESOLVED:
            blockers.append("map schema is not fully resolved")
        if any(entry.required for entry in schema.entries) and not schema.entries:
            blockers.append("map schema has no verified literal keys")
        if blockers:
            return FixtureSpec(
                fixture_id=schema.schema_id,
                method_name=method_name,
                return_type="Map<String, Object>",
                schema_id=schema.schema_id,
                dependent_fixture_ids=tuple(dict.fromkeys(dependencies)),
                dependency_relationship_paths=tuple(dict.fromkeys(dependency_relationships)),
                support_status=FixtureSupportStatus.PARTIAL,
                compile_status=FixtureCompileStatus.NOT_COMPILED,
                semantic_valid=False,
                blocking_reasons=tuple(dict.fromkeys(blockers)),
                imports=tuple(sorted(self.imports)),
                method_source="",
                supported=False,
                diagnostics=tuple(dict.fromkeys(blockers)),
            )
        return FixtureSpec(
            fixture_id=schema.schema_id,
            method_name=method_name,
            return_type="Map<String, Object>",
            schema_id=schema.schema_id,
            dependent_fixture_ids=tuple(dict.fromkeys(dependencies)),
            dependency_relationship_paths=tuple(dict.fromkeys(dependency_relationships)),
            required_relationship_paths=tuple(dict.fromkeys(relationship_guarantees)),
            minimum_collection_sizes=tuple(dict.fromkeys(minimum_sizes)),
            guaranteed_scalar_state=tuple(dict.fromkeys(scalar_guarantees)),
            guaranteed_relationships=tuple(dict.fromkeys(relationship_guarantees)),
            identity_guarantees=tuple(dict.fromkeys(identity_guarantees)),
            support_status=FixtureSupportStatus.SUPPORTED,
            compile_status=FixtureCompileStatus.NOT_COMPILED,
            semantic_valid=True,
            imports=tuple(sorted(self.imports)),
            method_source="\n".join(lines),
            supported=True,
            diagnostics=() if schema.entries else ("map schema has no verified literal keys",),
        )

    def _map_entry_expr(self, entry: MapEntrySchema) -> tuple[str, list[str], list[str]]:
        if entry.baseline_value:
            return entry.baseline_value, [], []
        if entry.nested_schema_id:
            child = self._emitted_specs.get(entry.nested_schema_id)
            if child and child.supported and child.semantic_valid:
                return f"{child.method_name}()", [entry.nested_schema_id], []
            return "null", [entry.nested_schema_id], [f"required nested map fixture unsupported: {entry.nested_schema_id}"]
        if entry.collection_element_schema_id:
            child = self._emitted_specs.get(entry.collection_element_schema_id)
            if child and child.supported and child.semantic_valid:
                return f"new ArrayList<>(List.of({child.method_name}()))", [entry.collection_element_schema_id], []
            return "new ArrayList<>()", [entry.collection_element_schema_id], [
                f"required map collection element fixture unsupported: {entry.collection_element_schema_id}"
            ]
        runtime = entry.runtime_type or "String"
        if entry.kind in {PropertyKind.LIST, PropertyKind.SET, PropertyKind.COLLECTION}:
            if entry.required:
                return "new ArrayList<>()", [], [f"required map collection element type unresolved: {entry.key_literal}"]
            return "new ArrayList<>()", [], []
        if entry.kind == PropertyKind.MAP:
            if entry.required:
                return "new LinkedHashMap<>()", [], [f"required nested map schema unresolved: {entry.key_literal}"]
            return "new LinkedHashMap<>()", [], []
        value = self._scalar_literal("Map", entry.key_literal, runtime, ())
        blockers = [f"required map value unresolved: {entry.key_literal}"] if entry.required and value == "null" else []
        return value, [], blockers

    def _with_transitive_dependencies(self, fixtures: list[FixtureSpec]) -> list[FixtureSpec]:
        by_id = {fixture.fixture_id: fixture for fixture in fixtures}

        def closure(fixture_id: str, seen: set[str] | None = None) -> tuple[str, ...]:
            seen = set() if seen is None else seen
            if fixture_id in seen:
                return ()
            seen.add(fixture_id)
            out: list[str] = []
            fixture = by_id.get(fixture_id)
            for child_id in fixture.dependent_fixture_ids if fixture else ():
                if child_id not in out:
                    out.append(child_id)
                for transitive in closure(child_id, set(seen)):
                    if transitive not in out:
                        out.append(transitive)
            return tuple(out)

        enriched: list[FixtureSpec] = []
        for fixture in fixtures:
            scalar_state = list(fixture.guaranteed_scalar_state)
            relationships = list(fixture.guaranteed_relationships)
            required_paths = list(fixture.required_relationship_paths)
            minimum_sizes = list(fixture.minimum_collection_sizes)
            identity = list(fixture.identity_guarantees)
            collection_paths = {path for path, _minimum in fixture.minimum_collection_sizes}
            for path, child_id in fixture.dependency_relationship_paths:
                child = by_id.get(child_id)
                if child is None or not child.supported or not child.semantic_valid:
                    continue
                prefix = path + ("[]" if path in collection_paths else "")
                for child_path, value in child.guaranteed_scalar_state:
                    item = (f"{prefix}.{child_path}", value)
                    if item not in scalar_state:
                        scalar_state.append(item)
                for child_path in child.guaranteed_relationships:
                    item = f"{prefix}.{child_path}"
                    if item not in relationships:
                        relationships.append(item)
                for child_path in child.required_relationship_paths:
                    item = f"{prefix}.{child_path}"
                    if item not in required_paths:
                        required_paths.append(item)
                for child_path, minimum in child.minimum_collection_sizes:
                    item = (f"{prefix}.{child_path}", minimum)
                    if item not in minimum_sizes:
                        minimum_sizes.append(item)
                for guarantee in child.identity_guarantees:
                    item = f"through {prefix}: {guarantee}"
                    if item not in identity:
                        identity.append(item)
            enriched.append(replace(
                fixture,
                transitive_fixture_ids=closure(fixture.fixture_id),
                required_relationship_paths=tuple(required_paths),
                minimum_collection_sizes=tuple(minimum_sizes),
                guaranteed_scalar_state=tuple(scalar_state),
                guaranteed_relationships=tuple(relationships),
                identity_guarantees=tuple(identity),
            ))
        return enriched

    def _semantic_validate(self, fixtures: list[FixtureSpec]) -> tuple[list[FixtureSpec], list[str]]:
        diagnostics: list[str] = []
        by_id = {fixture.fixture_id: fixture for fixture in fixtures}
        validated: list[FixtureSpec] = []
        for fixture in fixtures:
            errors: list[str] = []
            if fixture.supported:
                declaration = re.search(
                    rf"\b{re.escape(fixture.method_name)}\s*\(\s*\)\s*\{{",
                    fixture.method_source,
                )
                if not fixture.method_source or declaration is None:
                    errors.append("fixture source does not declare the catalogue method name")
                for dependency_id in fixture.dependent_fixture_ids:
                    dependency = by_id.get(dependency_id)
                    if dependency is None:
                        errors.append(f"catalogue dependency missing: {dependency_id}")
                    elif not dependency.supported or not dependency.semantic_valid:
                        errors.append(f"catalogue dependency is not supported: {dependency_id}")
                    elif f"{dependency.method_name}()" not in fixture.method_source:
                        errors.append(f"catalogue dependency call absent from source: {dependency.method_name}()")
                for path, expression in fixture.guaranteed_scalar_state:
                    if expression not in fixture.method_source:
                        errors.append(f"scalar guarantee absent from source: {path}={expression}")
                for omitted in fixture.omitted_edges:
                    prop_name = omitted.rsplit(".", 1)[-1]
                    if re.search(rf"\bset{re.escape(prop_name[:1].upper() + prop_name[1:])}\s*\(", fixture.method_source):
                        errors.append(f"omitted cycle edge appears in source: {omitted}")
            if errors:
                diagnostics.extend(f"{fixture.fixture_id}: {error}" for error in errors)
                validated.append(replace(
                    fixture,
                    support_status=FixtureSupportStatus.PARTIAL,
                    compile_status=FixtureCompileStatus.NOT_COMPILED,
                    semantic_valid=False,
                    blocking_reasons=tuple(dict.fromkeys((*fixture.blocking_reasons, *errors))),
                    guaranteed_scalar_state=(),
                    guaranteed_relationships=(),
                    identity_guarantees=(),
                    supported=False,
                    diagnostics=tuple(dict.fromkeys((*fixture.diagnostics, *errors))),
                ))
            else:
                validated.append(fixture)
        return validated, diagnostics


def emit_fixture_catalog(
    schemas: Iterable[PayloadSchema],
    map_schemas: Iterable[MapSchema] = (),
) -> EmittedFixtures:
    return FixtureBuilderEmitter(schemas, map_schemas).emit_all()
