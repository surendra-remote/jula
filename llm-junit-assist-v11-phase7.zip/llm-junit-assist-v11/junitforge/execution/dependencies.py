"""Exact dependency references and invoked method contracts.

Unlike the compatibility collaborator resolver, this module preserves the
injection-point name.  It is used only for Controller and ServiceImpl context.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from collections.abc import Callable, Iterable

from junitforge.execution.models import (
    DependencyMethodContract,
    DependencyRef,
    InvocationArgument,
    ResolutionStatus,
)
from junitforge.models import ClassSymbol, JavaSourceFile, MethodSig

LookupFn = Callable[[str], ClassSymbol | None]

_VALUE_TYPES = {
    "void", "boolean", "byte", "short", "int", "long", "float", "double", "char",
    "Boolean", "Byte", "Short", "Integer", "Long", "Float", "Double", "Character",
    "String", "Object", "BigDecimal", "BigInteger", "UUID", "Date", "LocalDate",
    "LocalDateTime", "ZonedDateTime", "OffsetDateTime", "Instant", "Duration",
    "List", "Set", "Map", "Collection", "Iterable", "Iterator", "Stream",
    "Optional", "Page", "Slice", "ResponseEntity", "HttpHeaders", "HttpStatus",
    "CompletableFuture", "Logger", "Class",
}
_PAYLOAD_SUFFIXES = (
    "Dto", "DTO", "Request", "Response", "Model", "Entity", "Payload",
    "Command", "Event", "Vo", "VO",
)
_SPRING_DATA_SUPERS = {
    "Repository",
    "CrudRepository",
    "ListCrudRepository",
    "PagingAndSortingRepository",
    "ListPagingAndSortingRepository",
    "JpaRepository",
}
_APPROVED_INHERITED_METHODS = {
    "save",
    "saveAndFlush",
    "saveAll",
    "findById",
    "findAll",
    "count",
    "existsById",
    "delete",
    "deleteById",
    "flush",
}
_LIST_RETURNING_REPOSITORIES = {
    "JpaRepository",
    "ListCrudRepository",
    "ListPagingAndSortingRepository",
}
_JPA_REPOSITORIES = {"JpaRepository"}


def simple_type_name(rendered: str | None) -> str:
    text = (rendered or "").strip().replace("...", "").replace("[]", "")
    if "<" in text:
        text = text.split("<", 1)[0]
    return text.rsplit(".", 1)[-1].strip()


def normalized_type(rendered: str | None) -> str:
    return re.sub(r"\s+", "", (rendered or "").replace("java.lang.", ""))


def _annotation_names(values: Iterable[str]) -> set[str]:
    return {str(v).split(".")[-1].lstrip("@").lower() for v in values}


def _is_payload_or_value(simple: str, sym: ClassSymbol | None) -> bool:
    if not simple or simple in _VALUE_TYPES or simple.endswith(_PAYLOAD_SUFFIXES):
        return True
    if sym is None:
        return False
    annos = _annotation_names(sym.annotations or [])
    if annos & {"entity", "embeddable", "mappedsuperclass"}:
        return True
    component_annos = {"service", "component", "repository", "controller", "restcontroller"}
    lombok_pojo_annos = {"data", "getter", "setter", "value", "builder", "superbuilder"}
    if annos & lombok_pojo_annos and not annos & component_annos:
        return True
    return sym.name.endswith(_PAYLOAD_SUFFIXES)


def _resolve_type(simple: str, lookup: LookupFn) -> tuple[ClassSymbol | None, ResolutionStatus]:
    sym = lookup(simple)
    if sym is None:
        return None, ResolutionStatus.EXTERNAL
    return sym, ResolutionStatus.RESOLVED


def _eligible_constructors(symbol: ClassSymbol) -> tuple[list[MethodSig], list[str]]:
    constructors = [c for c in (symbol.constructors or []) if "private" not in c.modifiers]
    if not constructors:
        return [], []
    annotated = [
        c for c in constructors
        if _annotation_names(c.annotations or []) & {"autowired", "inject", "resource"}
    ]
    if len(annotated) == 1:
        return annotated, []
    if len(annotated) > 1:
        return [], ["multiple constructors carry injection annotations"]
    if len(constructors) == 1:
        return constructors, []
    return [], ["multiple non-private constructors and no deterministic injection constructor"]


def resolve_dependency_refs(
    source_file: JavaSourceFile,
    symbol: ClassSymbol,
    lookup: LookupFn,
) -> tuple[list[DependencyRef], list[str]]:
    """Resolve exact dependency injection points without collapsing by type."""
    refs: list[DependencyRef] = []
    diagnostics: list[str] = []
    field_by_name = {f.name: f for f in (symbol.fields or [])}
    fields_by_type: dict[str, list[str]] = {}

    for field in symbol.fields or []:
        if "static" in field.modifiers:
            continue
        annos = _annotation_names(field.annotations or [])
        if "value" in annos:
            continue
        simple = simple_type_name(field.type)
        resolved, status = _resolve_type(simple, lookup)
        if _is_payload_or_value(simple, resolved):
            continue
        fields_by_type.setdefault(simple, []).append(field.name)
        refs.append(
            DependencyRef(
                field_name=field.name,
                parameter_name=None,
                declared_type=field.type,
                simple_type=simple,
                fqcn=resolved.fqcn if resolved else None,
                origin="field",
                resolution_status=status,
            )
        )

    constructors, ctor_diagnostics = _eligible_constructors(symbol)
    diagnostics.extend(ctor_diagnostics)
    existing_fields = {(r.field_name, r.simple_type) for r in refs}

    for ctor in constructors:
        for ptype, pname in ctor.params:
            simple = simple_type_name(ptype)
            resolved, status = _resolve_type(simple, lookup)
            if _is_payload_or_value(simple, resolved):
                continue

            mapped_field: str | None = None
            if pname in field_by_name and simple_type_name(field_by_name[pname].type) == simple:
                mapped_field = pname
            else:
                same_type_fields = fields_by_type.get(simple, [])
                if len(same_type_fields) == 1:
                    mapped_field = same_type_fields[0]

            if mapped_field is not None and (mapped_field, simple) in existing_fields:
                # Preserve constructor parameter identity on the existing field ref.
                refs = [
                    DependencyRef(
                        field_name=r.field_name,
                        parameter_name=pname if r.field_name == mapped_field and r.simple_type == simple else r.parameter_name,
                        declared_type=r.declared_type,
                        simple_type=r.simple_type,
                        fqcn=r.fqcn,
                        origin="field+ctor-param" if r.field_name == mapped_field and r.simple_type == simple else r.origin,
                        resolution_status=r.resolution_status,
                        mockable=r.mockable,
                        diagnostics=r.diagnostics,
                    )
                    for r in refs
                ]
                continue

            refs.append(
                DependencyRef(
                    field_name=mapped_field or pname,
                    parameter_name=pname,
                    declared_type=ptype,
                    simple_type=simple,
                    fqcn=resolved.fqcn if resolved else None,
                    origin="ctor-param",
                    resolution_status=status,
                    diagnostics=("constructor parameter could not be mapped to a declared field",) if mapped_field is None else (),
                )
            )

    # Deduplicate only the same injection point, never all instances of a type.
    unique: dict[tuple[str | None, str | None, str], DependencyRef] = {}
    for ref in refs:
        unique[(ref.field_name, ref.parameter_name, ref.declared_type)] = ref
    return list(unique.values()), diagnostics


def _is_mockable_instance_method(method: MethodSig, owner_kind: str) -> bool:
    if method.is_constructor or method.is_static or "private" in method.modifiers:
        return False
    if owner_kind == "interface":
        return True
    return method.is_public


@dataclass(slots=True, frozen=True)
class RepositoryGenericBinding:
    entity_type: str | None
    id_type: str | None
    base_interface: str | None
    resolution_status: ResolutionStatus
    inheritance_path: tuple[str, ...] = ()
    diagnostics: tuple[str, ...] = ()


def _argument_types_match(method: MethodSig, args: tuple[InvocationArgument, ...]) -> bool:
    if len(method.params) != len(args):
        return False
    for (ptype, _), arg in zip(method.params, args):
        if not arg.inferred_type:
            continue
        left = simple_type_name(ptype)
        right = simple_type_name(arg.inferred_type)
        if left == right:
            continue
        primitive_pairs = {
            ("int", "Integer"), ("Integer", "int"),
            ("long", "Long"), ("Long", "long"),
            ("boolean", "Boolean"), ("Boolean", "boolean"),
            ("double", "Double"), ("Double", "double"),
            ("float", "Float"), ("Float", "float"),
            ("char", "Character"), ("Character", "char"),
            ("short", "Short"), ("Short", "short"),
            ("byte", "Byte"), ("Byte", "byte"),
        }
        if (left, right) not in primitive_pairs:
            return False
    return True


def _split_generic_arguments(rendered: str) -> tuple[str, ...]:
    text = (rendered or "").strip()
    if "<" not in text or not text.endswith(">"):
        return ()
    body = text[text.find("<") + 1:-1]
    parts: list[str] = []
    depth = 0
    start = 0
    for index, char in enumerate(body):
        if char == "<":
            depth += 1
        elif char == ">":
            depth = max(0, depth - 1)
        elif char == "," and depth == 0:
            parts.append(body[start:index].strip())
            start = index + 1
    tail = body[start:].strip()
    if tail:
        parts.append(tail)
    return tuple(parts)


def _type_parameter_name(rendered: str) -> str | None:
    match = re.match(r"\s*([A-Za-z_$][\w$]*)", rendered or "")
    return match.group(1) if match else None


def _type_parameters(sym: ClassSymbol | None) -> tuple[str, ...]:
    if sym is None:
        return ()
    return tuple(
        name for name in (_type_parameter_name(value) for value in (sym.type_parameters or []))
        if name
    )


def _type_declaration(rendered: str) -> tuple[str, tuple[str, ...]]:
    text = (rendered or "").strip()
    return simple_type_name(text), _split_generic_arguments(text)


def _substitute_type_variables(rendered: str | None, bindings: dict[str, str]) -> str | None:
    if rendered is None:
        return None
    result = rendered.strip()
    if not result:
        return None
    for _ in range(max(1, len(bindings) + 1)):
        previous = result
        for variable, concrete in bindings.items():
            if concrete:
                result = re.sub(rf"(?<![\w$]){re.escape(variable)}(?![\w$])", concrete, result)
        if result == previous:
            break
    return result


def _root_type_bindings(dependency: DependencyRef, sym: ClassSymbol | None) -> dict[str, str]:
    parameters = _type_parameters(sym)
    arguments = _split_generic_arguments(dependency.declared_type)
    return {
        parameter: argument
        for parameter, argument in zip(parameters, arguments)
        if argument
    }


def _super_declarations(sym: ClassSymbol) -> tuple[str, ...]:
    declarations: list[str] = []
    if sym.extends:
        declarations.append(sym.extends)
    declarations.extend(sym.implements or [])
    return tuple(value for value in declarations if value)


def _contains_unresolved_type_variable(rendered: str | None, variables: set[str]) -> bool:
    text = (rendered or "").strip()
    if not text or "?" in text:
        return True
    return any(re.search(rf"(?<![\w$]){re.escape(variable)}(?![\w$])", text) for variable in variables)


def resolve_repository_generic_binding(
    dependency: DependencyRef,
    lookup: LookupFn,
) -> RepositoryGenericBinding:
    """Resolve entity/ID bindings through arbitrary custom repository parents.

    The traversal carries generic substitutions across every available interface
    declaration and never guesses an entity or ID from a field/repository name.
    """
    # A collaborator may be declared directly as JpaRepository<Entity, Id> or
    # CrudRepository<Entity, Id>, without an application-specific child
    # interface. The well-known declaration itself is authoritative even when
    # dependency bytecode/source is not available to the source lookup.
    if dependency.simple_type in _SPRING_DATA_SUPERS:
        arguments = _split_generic_arguments(dependency.declared_type)
        entity = arguments[0] if len(arguments) >= 1 else None
        identifier = arguments[1] if len(arguments) >= 2 else None
        obvious_variables = {
            value for value in (entity, identifier)
            if value and re.fullmatch(r"[A-Z][A-Z0-9_$]?", value)
        }
        if (
            entity
            and identifier
            and not _contains_unresolved_type_variable(entity, obvious_variables)
            and not _contains_unresolved_type_variable(identifier, obvious_variables)
        ):
            return RepositoryGenericBinding(
                entity,
                identifier,
                dependency.simple_type,
                ResolutionStatus.RESOLVED,
                (dependency.declared_type,),
            )
        return RepositoryGenericBinding(
            None,
            None,
            dependency.simple_type,
            ResolutionStatus.PARTIAL,
            (dependency.declared_type,),
            (f"direct Spring Data binding incomplete: {dependency.declared_type}",),
        )

    root = lookup(dependency.simple_type)
    if root is None:
        return RepositoryGenericBinding(
            None, None, None, ResolutionStatus.UNRESOLVED,
            diagnostics=(f"repository type unavailable: {dependency.simple_type}",),
        )

    candidates: list[tuple[str, str, str, tuple[str, ...]]] = []
    partial_paths: list[tuple[str, ...]] = []
    diagnostics: list[str] = []
    queue: list[tuple[ClassSymbol, dict[str, str], tuple[str, ...], frozenset[str]]] = [
        (root, _root_type_bindings(dependency, root), (root.fqcn,), frozenset())
    ]
    seen: set[tuple[str, tuple[tuple[str, str], ...]]] = set()

    while queue:
        current, bindings, path, inherited_variables = queue.pop(0)
        state = (current.fqcn, tuple(sorted(bindings.items())))
        if state in seen:
            continue
        seen.add(state)
        current_variables = set(_type_parameters(current)) | set(inherited_variables)

        for declaration in _super_declarations(current):
            base, raw_arguments = _type_declaration(declaration)
            arguments = tuple(
                _substitute_type_variables(argument, bindings) or argument
                for argument in raw_arguments
            )
            next_path = (*path, declaration)
            if base in _SPRING_DATA_SUPERS:
                entity = arguments[0] if len(arguments) >= 1 else None
                identifier = arguments[1] if len(arguments) >= 2 else None
                unresolved = (
                    _contains_unresolved_type_variable(entity, current_variables)
                    or _contains_unresolved_type_variable(identifier, current_variables)
                )
                if unresolved:
                    partial_paths.append(next_path)
                    diagnostics.append(
                        f"Spring Data binding incomplete at {declaration}: "
                        f"entity={entity!r}, id={identifier!r}"
                    )
                else:
                    candidates.append((entity or "", identifier or "", base, next_path))
                continue

            parent = lookup(base)
            if parent is None:
                diagnostics.append(f"repository parent unavailable: {base}")
                partial_paths.append(next_path)
                continue
            parent_parameters = _type_parameters(parent)
            next_bindings = {
                parameter: argument
                for parameter, argument in zip(parent_parameters, arguments)
                if argument
            }
            queue.append((parent, next_bindings, next_path, frozenset(current_variables | set(parent_parameters))))

    unique = {
        (entity, identifier, base): path
        for entity, identifier, base, path in candidates
    }
    if len(unique) == 1:
        (entity, identifier, base), path = next(iter(unique.items()))
        return RepositoryGenericBinding(
            entity, identifier, base, ResolutionStatus.RESOLVED, path, tuple(dict.fromkeys(diagnostics))
        )
    if len(unique) > 1:
        details = "; ".join(f"{base}<{entity}, {identifier}>" for entity, identifier, base in unique)
        diagnostics.append(f"conflicting Spring Data generic bindings: {details}")
        return RepositoryGenericBinding(
            None, None, None, ResolutionStatus.PARTIAL,
            diagnostics=tuple(dict.fromkeys(diagnostics)),
        )
    if partial_paths or any(simple_type_name(value) in _SPRING_DATA_SUPERS for value in _super_declarations(root)):
        return RepositoryGenericBinding(
            None, None, None, ResolutionStatus.PARTIAL,
            inheritance_path=partial_paths[0] if partial_paths else (root.fqcn,),
            diagnostics=tuple(dict.fromkeys(diagnostics)),
        )
    return RepositoryGenericBinding(
        None, None, None, ResolutionStatus.UNRESOLVED,
        diagnostics=tuple(dict.fromkeys(diagnostics or ["no Spring Data repository ancestor resolved"])),
    )


def _repository_contract_types(
    binding: RepositoryGenericBinding,
    method_name: str,
) -> tuple[str | None, tuple[str, ...], tuple[str, ...]]:
    entity = binding.entity_type
    identifier = binding.id_type
    base = binding.base_interface
    diagnostics: list[str] = []
    if binding.resolution_status != ResolutionStatus.RESOLVED or not entity or not identifier or not base:
        return None, (), tuple(binding.diagnostics)

    list_returning = base in _LIST_RETURNING_REPOSITORIES
    jpa = base in _JPA_REPOSITORIES
    if method_name == "save":
        return entity, (entity,), ()
    if method_name == "saveAndFlush":
        if not jpa:
            return None, (), (f"{method_name} is not inherited from {base}",)
        return entity, (entity,), ()
    if method_name == "saveAll":
        return (f"List<{entity}>" if list_returning else f"Iterable<{entity}>"), (f"Iterable<{entity}>",), ()
    if method_name == "findById":
        return f"Optional<{entity}>", (identifier,), ()
    if method_name == "findAll":
        return (f"List<{entity}>" if list_returning else f"Iterable<{entity}>"), (), ()
    if method_name == "count":
        return "long", (), ()
    if method_name == "existsById":
        return "boolean", (identifier,), ()
    if method_name == "delete":
        return "void", (entity,), ()
    if method_name == "deleteById":
        return "void", (identifier,), ()
    if method_name == "flush":
        if not jpa:
            return None, (), (f"{method_name} is not inherited from {base}",)
        return "void", (), ()
    return None, (), (f"unsupported inherited Spring Data method: {method_name}",)


def _inherited_repository_contract(
    dependency: DependencyRef,
    method_name: str,
    lookup: LookupFn,
) -> DependencyMethodContract:
    binding = resolve_repository_generic_binding(dependency, lookup)
    return_type, parameter_types, diagnostics = _repository_contract_types(binding, method_name)
    resolved = return_type is not None and binding.resolution_status == ResolutionStatus.RESOLVED
    status = ResolutionStatus.RESOLVED if resolved else (
        ResolutionStatus.PARTIAL
        if binding.resolution_status == ResolutionStatus.PARTIAL or binding.base_interface is not None
        else ResolutionStatus.UNRESOLVED
    )
    return DependencyMethodContract(
        dependency_field=dependency.field_name or dependency.parameter_name or dependency.simple_type,
        dependency_type=dependency.declared_type,
        method_name=method_name,
        return_type=return_type,
        parameter_types=parameter_types,
        declaring_type=binding.inheritance_path[-1] if binding.inheritance_path else dependency.fqcn,
        inherited_spring_data=resolved,
        resolution_status=status,
        repository_entity_type=binding.entity_type,
        repository_id_type=binding.id_type,
        repository_base_interface=binding.base_interface,
        diagnostics=tuple(dict.fromkeys((*binding.diagnostics, *diagnostics))),
    )


def resolve_method_contract(
    dependency: DependencyRef,
    method_name: str,
    args: tuple[InvocationArgument, ...],
    lookup: LookupFn,
    *,
    return_type_hint: str | None = None,
    declaring_type_hint: str | None = None,
    parameter_type_hints: tuple[str, ...] = (),
) -> DependencyMethodContract:
    """Resolve one actually observed dependency invocation."""
    sym = lookup(dependency.simple_type)
    candidates: list[MethodSig] = []
    if sym is not None:
        candidates = [
            m for m in (sym.methods or [])
            if m.name == method_name
            and m.arity == len(args)
            and _is_mockable_instance_method(m, sym.kind)
        ]

    selected: MethodSig | None = None
    if len(candidates) == 1:
        selected = candidates[0]
    elif len(candidates) > 1:
        matching = [m for m in candidates if _argument_types_match(m, args)]
        if len(matching) == 1:
            selected = matching[0]

    if selected is not None:
        bindings = _root_type_bindings(dependency, sym)
        return_type = _substitute_type_variables(selected.return_type, bindings)
        parameter_types = tuple(
            _substitute_type_variables(type_name, bindings) or type_name
            for type_name, _ in selected.params
        )
        status = ResolutionStatus.RESOLVED if return_type is not None else ResolutionStatus.PARTIAL
        return DependencyMethodContract(
            dependency_field=dependency.field_name or dependency.parameter_name or dependency.simple_type,
            dependency_type=dependency.declared_type,
            method_name=method_name,
            return_type=return_type,
            parameter_types=parameter_types,
            parameter_names=tuple(n for _, n in selected.params),
            throws=tuple(selected.throws or []),
            declaring_type=sym.fqcn if sym else declaring_type_hint,
            inherited_spring_data=False,
            resolution_status=status,
            diagnostics=("declared method return type unresolved",) if return_type is None else (),
        )

    if sym is not None and method_name in _APPROVED_INHERITED_METHODS:
        inherited = _inherited_repository_contract(dependency, method_name, lookup)
        if inherited.resolution_status != ResolutionStatus.UNRESOLVED or inherited.repository_base_interface:
            return inherited

    status = ResolutionStatus.AMBIGUOUS if len(candidates) > 1 else ResolutionStatus.UNRESOLVED
    if return_type_hint or parameter_type_hints or declaring_type_hint:
        status = ResolutionStatus.PARTIAL if status != ResolutionStatus.AMBIGUOUS else status
    observed_parameter_types = (
        parameter_type_hints
        if parameter_type_hints
        else tuple(arg.inferred_type for arg in args if arg.inferred_type)
    )
    if len(observed_parameter_types) != len(args):
        observed_parameter_types = ()
    return DependencyMethodContract(
        dependency_field=dependency.field_name or dependency.parameter_name or dependency.simple_type,
        dependency_type=dependency.declared_type,
        method_name=method_name,
        return_type=return_type_hint,
        parameter_types=observed_parameter_types,
        declaring_type=declaring_type_hint or dependency.fqcn,
        inherited_spring_data=False,
        resolution_status=status,
        diagnostics=(
            "multiple matching collaborator overloads"
            if status == ResolutionStatus.AMBIGUOUS
            else "collaborator method contract unresolved"
        ,),
    )
