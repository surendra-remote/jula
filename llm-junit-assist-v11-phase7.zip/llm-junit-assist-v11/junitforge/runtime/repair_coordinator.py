"""Registry-owned transactional runtime repair.

Phase 6 repairs exactly one failing registry test per transaction.  Runtime
repair never invokes compile-repair orchestration: each candidate is compiled
once through the compile gate, then executed through targeted and complete-class
gates before the Phase 1 registry commit API is allowed to promote it.
"""

from __future__ import annotations

from collections import Counter
from copy import deepcopy
import re
from pathlib import Path
from time import perf_counter

from junitforge.audit.console import stage as console_stage
from junitforge.audit.paths import safe_name
from junitforge.compilation.provider_response import (
    identical_rejected_response,
    provider_metadata,
    request_hash,
)
from junitforge.compilation.response_normalizer import normalize_focused_test_response
from junitforge.coverage_run import (
    CoverageRunResult,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.assembly import (
    normalize_writable_map_mutations,
    owner_method_id_for_test_name,
    replace_test_method,
    test_class_structure_error,
    test_method_for_name,
    test_method_names,
)
from junitforge.generation.payloads import payload_builder_for_context
from junitforge.generation.semantic_validation import validate_serviceimpl_semantics
from junitforge.generation.validation import validate_serviceimpl_structural_test
from junitforge.models import (
    CompileState,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
)
from junitforge.pipeline.result import test_record_by_name
from junitforge.registry import (
    RegistryStore,
    fixture_method_names_from_context,
    recalculate_registry_ranges,
    source_hash,
)
from junitforge.runtime.candidate_validator import (
    validate_runtime_candidate_identity,
    validate_runtime_source_identity,
)
from junitforge.runtime.result_parser import (
    group_runtime_failures_by_test,
    map_runtime_failure_test,
    runtime_diagnostic,
)
from junitforge.vendor.logging_utils import get

log = get("junitforge.loop")


def _runtime_owner_priority(item: tuple[str, list[SurefireFailure]]) -> tuple[int, int, str]:
    identity, failures = item
    errors = sum(1 for failure in failures if (failure.status or "").lower() == "error")
    deterministic = sum(
        1
        for failure in failures
        if failure.category in {
            "INVALID_CHECKED_EXCEPTION_STUB",
            "UNNECESSARY_STUBBING",
            "UNEXPECTED_NULL_POINTER",
        }
    )
    return errors, len(failures) + deterministic, identity


def _targeted_selector(test_fqcn: str, failures: list[SurefireFailure]) -> str:
    names: list[str] = []
    for failure in failures:
        name = (failure.test_method or "").split("(", 1)[0]
        if name and name not in names:
            names.append(name)
    return test_fqcn + ("#" + "+".join(names) if names else "")


def _deterministic_runtime_replacement(
    suite: str,
    owner: str,
    failures: list[SurefireFailure],
) -> tuple[str | None, str | None]:
    """Return one exact repaired test for a high-confidence local stub failure."""
    selected_names = {
        (failure.test_method or "").split("(", 1)[0]
        for failure in failures
        if failure.test_method
    }
    if len(selected_names) != 1:
        return None, None
    selected_name = next(iter(selected_names))
    selected = test_method_for_name(suite, selected_name)
    if selected is None or owner_method_id_for_test_name(suite, selected_name) != owner:
        return None, None

    relative_lines = sorted(
        {
            failure.generated_test_line - selected.start_line + 1
            for failure in failures
            if failure.category == "UNNECESSARY_STUBBING"
            and failure.generated_test_line is not None
            and selected.start_line <= failure.generated_test_line <= selected.end_line
        },
        reverse=True,
    )
    if not relative_lines:
        return None, None

    lines = selected.source.splitlines()
    stub_start = re.compile(
        r"\b(?:lenient\s*\(\s*\)\s*\.)?when\s*\(|"
        r"\bdo(?:Return|Throw|Answer|Nothing)\s*\("
    )
    removed = 0
    for line_number in relative_lines:
        index = line_number - 1
        if index < 0 or index >= len(lines):
            continue
        start = index
        while start >= 0 and index - start <= 8 and not stub_start.search(lines[start]):
            start -= 1
        if start < 0 or index - start > 8:
            continue
        end = start
        while end < len(lines) and end - start <= 16 and ";" not in lines[end]:
            end += 1
        if end >= len(lines) or end - start > 16:
            continue
        statement = "\n".join(lines[start : end + 1])
        if not stub_start.search(statement) or "verify(" in statement:
            continue
        del lines[start : end + 1]
        removed += 1
    if not removed:
        return None, None
    repaired = "\n".join(lines)
    return repaired, f"removed_unused_local_stubs={removed}"


def _compile_diagnostics(errors) -> list[dict[str, object]]:
    result: list[dict[str, object]] = []
    for error in errors or ():
        result.append(
            {
                "file": str(getattr(error, "file", "") or ""),
                "line": getattr(error, "line", None),
                "column": getattr(error, "col", None),
                "message": getattr(error, "message", str(error)),
                "detail": list(getattr(error, "detail", ()) or ()),
                "diagnostic_category": getattr(error, "diagnostic_category", None),
                "raw": getattr(error, "raw", ""),
            }
        )
    return result


def _runtime_result(run: RuntimeTestRunResult | CoverageRunResult | None) -> dict[str, object] | None:
    if run is None:
        return None
    signals = run.signals
    return {
        "maven_execution_success": bool(run.maven_execution_success),
        "tests_run": signals.tests_run,
        "failures": signals.tests_failed,
        "errors": signals.tests_errors,
        "skipped": signals.tests_skipped,
        "tests_green": bool(run.tests_green),
        "executed_test_names": list(run.executed_test_names),
        "failing_test_names": sorted({failure.test_method for failure in run.failures}),
        "note": run.note,
        "log_path": str(run.log_path) if run.log_path else None,
        "report_paths": [str(path) for path in run.report_paths],
    }


def _failure_payload(failure: SurefireFailure) -> dict[str, object]:
    return {
        "executed_test_class": failure.test_class,
        "executed_test_method": (failure.test_method or "").split("(", 1)[0],
        "status": failure.status,
        "category": failure.category,
        "exception_type": failure.exception_type,
        "message": failure.message,
        "stack_trace": failure.stack_trace,
        "production_file": failure.production_file,
        "production_line": failure.production_line,
    }


def _usage_dict(metadata: dict[str, object] | None) -> dict[str, int]:
    metadata = metadata or {}
    return {
        "input_tokens": int(metadata.get("input_token_count", 0) or 0),
        "output_tokens": int(metadata.get("output_token_count", 0) or 0),
        "total_tokens": int(metadata.get("input_token_count", 0) or 0)
        + int(metadata.get("output_token_count", 0) or 0),
    }


def _record_runtime_failure_state(
    outcome: TargetOutcome,
    record: TestCaseRecord,
    failures: list[SurefireFailure],
) -> None:
    diagnostics = [runtime_diagnostic(failure) for failure in failures]
    has_error = any((failure.status or "").lower() == "error" for failure in failures)
    RegistryStore(outcome).set_runtime_state(
        record,
        "ERROR" if has_error else "FAILURE",
        diagnostics=diagnostics,
    )


def _ensure_registry_test(
    outcome: TargetOutcome,
    *,
    suite: str,
    owner: str,
    test_name: str,
) -> TestCaseRecord | None:
    """Backward-compatible migration for direct callers with a pre-registry outcome."""
    existing = test_record_by_name(outcome, test_name)
    if existing is not None:
        return existing
    extracted = test_method_for_name(suite, test_name)
    if extracted is None:
        return None
    method_record = next((item for item in outcome.method_results if item.method_id == owner), None)
    if method_record is None:
        method_record = MethodGenerationRecord(
            method_id=owner,
            final_status=MethodDisposition.PARTIALLY_GENERATED.value,
        )
        RegistryStore(outcome).register_method(method_record)
    record = TestCaseRecord(
        owner_method_id=owner,
        test_name=test_name,
        generated_source=extracted.source,
        latest_accepted_source=extracted.source,
        source_start_line=extracted.start_line,
        source_end_line=extracted.end_line,
        source_hash=source_hash(extracted.source),
        validation_state="VALID",
        compile_state=CompileState.PASSED.value,
        final_disposition=TestDisposition.RETAINED.value,
    )
    RegistryStore(outcome).register_test(method_record, record)
    return record


class RuntimeRepairMixin:
    def _runtime_failure_repair_loop(
        self,
        ctx: GenerationContext,
        test_path: Path,
        module: ModuleInfo,
        initial_run: CoverageRunResult,
        outcome: TargetOutcome,
    ) -> CoverageRunResult | None:
        runner = self.coverage_runner
        assert runner is not None
        current_run: CoverageRunResult | RuntimeTestRunResult = initial_run
        owner_attempts: Counter[str] = Counter()
        blocked_tests: set[str] = set()
        visited_owners: set[str] = set()
        no_progress_rounds = 0
        max_rounds = max(0, self.cfg.max_runtime_repair_rounds)
        test_fqcn = self._test_fqcn(ctx)

        if (
            outcome.runtime_failures_initial == 0
            and outcome.runtime_errors_initial == 0
            and (initial_run.signals.tests_failed or initial_run.signals.tests_errors)
        ):
            outcome.runtime_failures_initial = initial_run.signals.tests_failed
            outcome.runtime_errors_initial = initial_run.signals.tests_errors
            outcome.runtime_failure_categories_initial = dict(
                Counter(failure.category for failure in initial_run.failures)
            )

        for round_no in range(1, max_rounds + 1):
            if current_run.signals.tests_green:
                break
            suite = test_path.read_text(encoding="utf-8")
            failures = list(current_run.failures)
            if not failures and current_run.log_tail:
                failures = list(parse_surefire_failures_from_log(current_run.log_tail, [test_fqcn]))
            if not failures:
                outcome.status = "runtime_failed"
                outcome.notes.append("runtime repair stopped: no structured Surefire failure entries")
                return None

            # Migrate only exact marker-owned tests for legacy direct callers.
            for failure in failures:
                test_name = (failure.test_method or "").split("(", 1)[0]
                if test_record_by_name(outcome, test_name) is None:
                    owner = owner_method_id_for_test_name(suite, test_name)
                    if owner:
                        _ensure_registry_test(outcome, suite=suite, owner=owner, test_name=test_name)

            grouped, unmapped = group_runtime_failures_by_test(
                failures,
                outcome,
                expected_test_class=test_fqcn,
            )
            outcome.remaining_runtime_owners = sorted(
                {RegistryStore(outcome).find(test_id).owner_method_id for test_id in grouped}
            )
            if unmapped:
                outcome.notes.append(
                    f"runtime failures not mapped to stable registry test_id: {len(unmapped)}"
                )
            eligible: list[tuple[str, list[SurefireFailure]]] = []
            for test_id, test_failures in grouped.items():
                if test_id in blocked_tests:
                    continue
                record = RegistryStore(outcome).find(test_id)
                owner = record.owner_method_id
                if owner_attempts[owner] >= self.cfg.max_runtime_repairs_per_owner:
                    continue
                if owner not in visited_owners and len(visited_owners) >= self.cfg.max_runtime_repair_owners:
                    continue
                eligible.append((test_id, test_failures))
            if not eligible:
                outcome.status = "repair_exhausted"
                return None

            test_id, selected_failures = max(eligible, key=_runtime_owner_priority)
            record = RegistryStore(outcome).find(test_id)
            owner = record.owner_method_id
            owner_attempts[owner] += 1
            visited_owners.add(owner)
            outcome.runtime_repair_attempts += 1
            console_stage(
                "RUNTIME_REPAIR",
                "test_id=%s | attempt=%d | diagnostics=%d",
                test_id,
                owner_attempts[owner],
                len(selected_failures),
            )

            accepted, next_run, reason = self._repair_runtime_owner(
                ctx=ctx,
                test_path=test_path,
                module=module,
                owner=owner,
                owner_failures=selected_failures,
                before_run=current_run,
                outcome=outcome,
                test_fqcn=test_fqcn,
                round_no=round_no,
                attempt_no=owner_attempts[owner],
            )
            if accepted and next_run is not None:
                current_run = next_run
                no_progress_rounds = 0
                runner.invalidate_coverage(module)
                outcome.coverage_current = False
                if current_run.signals.tests_green:
                    fresh = self._measure_coverage(runner, module, test_classes=[test_fqcn])
                    self._record_coverage_runtime_result(outcome, fresh, initial=False)
                    if fresh.ok and fresh.measured and fresh.tests_green and fresh.coverage_current:
                        outcome.status = "pending"
                        return fresh
                    current_run = fresh
                continue

            no_progress_rounds += 1
            if reason == "IDENTICAL_REJECTED_RESPONSE":
                blocked_tests.add(test_id)
            if owner_attempts[owner] >= self.cfg.max_runtime_repairs_per_owner:
                blocked_tests.update(
                    item.test_id
                    for method in outcome.method_results
                    for item in method.tests
                    if item.owner_method_id == owner
                )
            if no_progress_rounds >= self.cfg.max_runtime_no_progress_rounds:
                outcome.status = "repair_exhausted"
                return None

        if current_run.signals.tests_green:
            runner.invalidate_coverage(module)
            fresh = self._measure_coverage(runner, module, test_classes=[test_fqcn])
            self._record_coverage_runtime_result(outcome, fresh, initial=False)
            if fresh.ok and fresh.measured and fresh.tests_green and fresh.coverage_current:
                outcome.status = "pending"
                return fresh
        outcome.status = "repair_exhausted" if outcome.runtime_repair_attempts else "runtime_failed"
        return None

    def _repair_runtime_owner(
        self,
        *,
        ctx: GenerationContext,
        test_path: Path,
        module: ModuleInfo,
        owner: str,
        owner_failures: list[SurefireFailure],
        before_run: CoverageRunResult | RuntimeTestRunResult,
        outcome: TargetOutcome,
        test_fqcn: str,
        round_no: int,
        attempt_no: int,
    ) -> tuple[bool, RuntimeTestRunResult | None, str]:
        """Repair one failing registry test transactionally.

        The compatibility method name is retained, but the repair unit is one
        stable ``test_id`` rather than an owner block.
        """
        runner = self.coverage_runner
        assert runner is not None
        prior_class_source = test_path.read_text(encoding="utf-8")

        mapped_records: dict[str, TestCaseRecord] = {}
        for failure in owner_failures:
            record, _mapping, _confidence = map_runtime_failure_test(
                failure,
                outcome,
                expected_test_class=test_fqcn,
            )
            if record is None:
                test_name = (failure.test_method or "").split("(", 1)[0]
                record = _ensure_registry_test(
                    outcome,
                    suite=prior_class_source,
                    owner=owner,
                    test_name=test_name,
                )
            if record is not None:
                mapped_records[record.test_id] = record
        if len(mapped_records) != 1:
            return False, None, "RUNTIME_FAILURE_NOT_OWNED_BY_ONE_REGISTRY_TEST"
        record = next(iter(mapped_records.values()))
        if record.owner_method_id != owner:
            return False, None, "RUNTIME_OWNER_METADATA_MISMATCH"

        production_method = next(
            (
                method
                for method in (ctx.symbol.methods or [])
                if f"{method.name}({','.join(type_name for type_name, _ in method.params)})" == owner
            ),
            None,
        )
        method_context = next(
            (item for item in (ctx.execution_context.methods if ctx.execution_context else ()) if item.method_id == owner),
            None,
        )
        current_test = test_method_for_name(prior_class_source, record.test_name)
        if production_method is None or method_context is None or current_test is None:
            return False, None, "OWNER_CONTEXT_OR_TEST_SOURCE_MISSING"

        _record_runtime_failure_state(outcome, record, owner_failures)
        audit_dir = f"11-runtime-repair/{safe_name(record.test_name)}/attempt-{attempt_no:03d}"
        attempt: dict[str, object] = {
            "attempt_number": attempt_no,
            "round_number": round_no,
            "test_id": record.test_id,
            "owner_method_id": record.owner_method_id,
            "runtime_failure": [_failure_payload(failure) for failure in owner_failures],
            "runtime_diagnostics": [runtime_diagnostic(failure) for failure in owner_failures],
            "request": None,
            "response": None,
            "request_hash": None,
            "response_hash": None,
            "candidate_source": None,
            "candidate_hash": None,
            "structural_validation_result": {"passed": False, "reason": "NOT_RUN"},
            "semantic_validation_result": {"passed": False, "reason": "NOT_RUN"},
            "compile_result": {"passed": False, "status": "NOT_RUN"},
            "compile_diagnostics": [],
            "targeted_execution_result": None,
            "complete_retained_class_execution_result": None,
            "decision": "PENDING",
            "rollback_reason": None,
            "token_counts": {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0},
            "finish_reason": None,
            "response_size": 0,
            "truncation_state": "NOT_APPLICABLE",
            "compile_repair_llm_calls": 0,
        }
        store = RegistryStore(outcome)

        def persist_attempt() -> None:
            self.audit.write_json(ctx.symbol.name, f"{audit_dir}/attempt.json", attempt)

        def rollback(reason: str) -> tuple[bool, None, str]:
            test_path.write_text(prior_class_source, encoding="utf-8")
            attempt["decision"] = "ROLLBACK"
            attempt["status"] = "rejected"
            attempt["rollback_reason"] = reason
            metadata = attempt.get("provider_metadata")
            if isinstance(metadata, dict):
                metadata["rejection_reason"] = reason
            if record.candidate_source:
                store.rollback_candidate(
                    record,
                    failed_attempt=deepcopy(attempt),
                    history_field="runtime_repair_attempts",
                )
            else:
                store.append_history(record, "runtime_repair_attempts", deepcopy(attempt))
            recalculate_registry_ranges(
                outcome,
                prior_class_source,
                fixture_method_names=fixture_method_names_from_context(ctx),
                persist=True,
            )
            outcome.runtime_repair_history.append(
                {"test_id": record.test_id, "attempt": attempt_no, "decision": "ROLLBACK", "reason": reason}
            )
            persist_attempt()
            return False, None, reason

        candidate_test_source, deterministic_action = _deterministic_runtime_replacement(
            prior_class_source,
            owner,
            owner_failures,
        )
        if candidate_test_source is None:
            failing_test = {
                "test_id": record.test_id,
                "owner_method_id": record.owner_method_id,
                "test_name": record.test_name,
                "source": current_test.source,
                "runtime_status": "error"
                if any((failure.status or "").lower() == "error" for failure in owner_failures)
                else "failure",
                "diagnostics": [runtime_diagnostic(failure) for failure in owner_failures],
            }
            messages = payload_builder_for_context(ctx).build_runtime_repair_payload(
                ctx,
                production_method,
                failing_tests=[failing_test],
                test_class_source=prior_class_source,
            )
            digest = request_hash(
                messages,
                temperature=self.cfg.temperature_repair,
                max_tokens=self.cfg.max_tokens_repair,
            )
            attempt["request"] = messages
            attempt["request_hash"] = digest
            self.audit.write_json(ctx.symbol.name, f"{audit_dir}/request.json", messages)
            response = self._chat_response(
                messages,
                self.cfg.temperature_repair,
                self.cfg.max_tokens_repair,
                outcome,
            )
            raw = getattr(response, "message", None) if response is not None else None
            normalization = normalize_focused_test_response(raw, expected_test_name=record.test_name)
            metadata = provider_metadata(
                response,
                request_digest=digest,
                probable_truncation=normalization.probable_truncation,
                normalization_result=normalization.normalization_result,
                rejection_reason=normalization.rejection_reason,
            ).to_dict()
            attempt["response"] = raw
            attempt["response_hash"] = metadata["response_hash"]
            attempt["token_counts"] = _usage_dict(metadata)
            attempt["finish_reason"] = metadata["finish_reason"]
            attempt["response_size"] = metadata["response_size"]
            attempt["truncation_state"] = metadata["truncation_state"]
            attempt["provider_metadata"] = metadata
            self.audit.write_text(ctx.symbol.name, f"{audit_dir}/response.txt", raw or "")

            duplicate_reason = identical_rejected_response(
                record.runtime_repair_attempts,
                request_digest=digest,
                response_digest=str(metadata["response_hash"]),
            )
            if duplicate_reason is not None:
                metadata["rejection_reason"] = "IDENTICAL_REJECTED_RESPONSE"
                return rollback("IDENTICAL_REJECTED_RESPONSE")
            if not normalization.accepted:
                return rollback(normalization.rejection_reason or "RUNTIME_RESPONSE_REJECTED")
            candidate_test_source = normalize_writable_map_mutations(normalization.source)
        else:
            attempt["deterministic_action"] = deterministic_action

        attempt["candidate_source"] = candidate_test_source
        attempt["candidate_hash"] = source_hash(candidate_test_source)
        store.set_candidate(record, candidate_test_source)
        self.audit.write_text(ctx.symbol.name, f"{audit_dir}/candidate-test.java", candidate_test_source)

        structural = validate_serviceimpl_structural_test(
            ctx,
            production_method,
            candidate_test_source,
            existing_names=set(test_method_names(prior_class_source)) - {record.test_name},
        )
        attempt["structural_validation_result"] = {
            "passed": bool(structural.ok),
            "reason": structural.reason,
            "test_names": list(structural.test_names),
        }
        if not structural.ok or tuple(structural.test_names) != (record.test_name,):
            return rollback(structural.reason or "STRUCTURAL_VALIDATION_FAILED")

        semantic = validate_serviceimpl_semantics(
            ctx,
            production_method,
            method_context,
            candidate_test_source,
        )
        attempt["semantic_validation_result"] = {
            "passed": bool(semantic.ok),
            "reason": semantic.reason,
            "diagnostics": [
                {
                    "category": item.category,
                    "message": item.message,
                    "expression": item.expression,
                    "authoritative_contract": item.authoritative_contract,
                    "line": item.line,
                }
                for item in semantic.diagnostics
            ],
        }
        if not semantic.ok:
            return rollback(semantic.reason or "SEMANTIC_VALIDATION_FAILED")

        candidate_class = replace_test_method(
            prior_class_source,
            record.test_name,
            candidate_test_source,
        )
        if candidate_class is None:
            return rollback("TEMPORARY_CLASS_ASSEMBLY_FAILED")
        structure_error = test_class_structure_error(candidate_class, ctx.test_class_name)
        if structure_error:
            attempt["structural_validation_result"] = {
                "passed": False,
                "reason": structure_error,
                "test_names": [record.test_name],
            }
            return rollback("TEMPORARY_CLASS_STRUCTURE_INVALID")
        identity_ok, identity_reason, identity_details = validate_runtime_source_identity(
            before_source=prior_class_source,
            after_source=candidate_class,
            owner=owner,
            selected_test_name=record.test_name,
        )
        if not identity_ok:
            attempt["source_identity_result"] = {
                "passed": False,
                "reason": identity_reason,
                "details": list(identity_details),
            }
            return rollback(identity_reason)
        attempt["source_identity_result"] = {"passed": True, "reason": identity_reason, "details": []}
        self.audit.write_text(ctx.symbol.name, f"{audit_dir}/candidate-class.java", candidate_class)

        recalculate_registry_ranges(
            outcome,
            candidate_class,
            fixture_method_names=fixture_method_names_from_context(ctx),
            persist=True,
        )
        test_path.write_text(candidate_class, encoding="utf-8")
        compile_started = perf_counter()
        compile_result, compile_errors = self._compile_candidate(test_path, module)
        attempt["compile_result"] = {
            "passed": bool(getattr(compile_result, "ok", False)),
            "status": "PASSED" if getattr(compile_result, "ok", False) else "FAILED",
            "return_code": getattr(compile_result, "return_code", None),
            "elapsed_seconds": perf_counter() - compile_started,
            "command": list(getattr(compile_result, "cmd", ()) or ()),
        }
        attempt["compile_diagnostics"] = _compile_diagnostics(compile_errors)
        if not getattr(compile_result, "ok", False):
            record.current_compile_diagnostics = list(attempt["compile_diagnostics"])
            record.compile_diagnostics.append(
                {
                    "stage": "runtime_repair_candidate",
                    "attempt": attempt_no,
                    "diagnostics": list(attempt["compile_diagnostics"]),
                    "decision": "ROLLBACK",
                }
            )
            store.persist()
            return rollback("RUNTIME_CANDIDATE_COMPILE_FAILED")

        targeted_selector = f"{test_fqcn}#{record.test_name}"
        targeted = self._run_tests(
            runner,
            module,
            [targeted_selector],
            label=f"runtime-repair-{round_no}-{record.test_name}-targeted",
            timeout_sec=self.cfg.runtime_repair_timeout_seconds,
        )
        attempt["targeted_execution_result"] = _runtime_result(targeted)
        if (
            not targeted.maven_execution_success
            or targeted.signals.tests_run != 1
            or (targeted.executed_test_names and record.test_name not in set(targeted.executed_test_names))
            or not targeted.tests_green
        ):
            return rollback("TARGETED_EXECUTION_FAILED")

        full = self._run_tests(
            runner,
            module,
            [test_fqcn],
            label=f"runtime-repair-{round_no}-{record.test_name}-full",
            timeout_sec=self.cfg.runtime_repair_timeout_seconds,
        )
        attempt["complete_retained_class_execution_result"] = _runtime_result(full)
        accepted, acceptance_reason, identity_details = validate_runtime_candidate_identity(
            before_source=prior_class_source,
            after_source=candidate_class,
            owner=owner,
            selected_test_names={record.test_name},
            before_run=before_run,
            targeted_run=targeted,
            full_run=full,
            owner_failures_before=owner_failures,
            require_full_green=True,
        )
        if not accepted:
            attempt["runtime_acceptance_details"] = list(identity_details)
            return rollback(acceptance_reason)

        # Commit only now, through the Phase 1 transaction API.
        accepted_test = test_method_for_name(candidate_class, record.test_name)
        if accepted_test is None:
            return rollback("ACCEPTED_TEST_SOURCE_MISSING")
        store.commit_candidate(
            record,
            source_start_line=accepted_test.start_line,
            source_end_line=accepted_test.end_line,
        )
        recalculate_registry_ranges(
            outcome,
            candidate_class,
            fixture_method_names=fixture_method_names_from_context(ctx),
            persist=True,
        )
        self._record_runtime_test_result(outcome, targeted, scope="targeted")
        self._record_runtime_test_result(outcome, full, scope="full")
        attempt["decision"] = "COMMIT"
        attempt["rollback_reason"] = None
        store.append_history(record, "runtime_repair_attempts", deepcopy(attempt))
        outcome.runtime_repair_history.append(
            {"test_id": record.test_id, "attempt": attempt_no, "decision": "COMMIT"}
        )
        persist_attempt()
        console_stage(
            "RUNTIME_REPAIR",
            "test_id=%s | targeted=passed | full_class=passed | committed",
            record.test_id,
        )
        return True, full, "accepted"
