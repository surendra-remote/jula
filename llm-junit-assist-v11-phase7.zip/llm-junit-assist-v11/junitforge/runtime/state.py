"""Runtime snapshots and authoritative per-test registry updates."""

from __future__ import annotations

from collections import Counter
from copy import deepcopy

from junitforge.coverage_run import CoverageRunResult, RuntimeTestRunResult
from junitforge.models import CompileState, RuntimeResultSnapshot, TargetOutcome, TestDisposition
from junitforge.registry import RegistryStore
from junitforge.runtime.result_parser import runtime_diagnostic


class RuntimeStateMixin:
    def _record_coverage_runtime_result(
        self,
        outcome: TargetOutcome,
        run: CoverageRunResult,
        *,
        initial: bool,
    ) -> None:
        signals = run.signals
        snapshot = _runtime_snapshot(run, "full")
        _record_test_runtime_states(outcome, run)
        if initial and outcome.runtime_initial_full_run is None:
            outcome.runtime_initial_full_run = snapshot
            outcome.runtime_failures_initial = signals.tests_failed
            outcome.runtime_errors_initial = signals.tests_errors
            outcome.runtime_failure_categories_initial = dict(
                Counter(f.category for f in run.failures)
            )
        outcome.runtime_last_full_run = snapshot
        if signals.tests_green:
            outcome.runtime_last_green_full_run = snapshot
            outcome.remaining_runtime_owners = []
        outcome.runtime_tests_run = signals.tests_run
        outcome.runtime_failures_final = signals.tests_failed
        outcome.runtime_errors_final = signals.tests_errors
        outcome.runtime_skipped_final = signals.tests_skipped
        outcome.runtime_failure_categories = dict(Counter(f.category for f in run.failures))
        outcome.surefire_report_paths = list(
            dict.fromkeys((*outcome.surefire_report_paths, *(str(path) for path in run.report_paths)))
        )
        if run.log_path:
            outcome.coverage_log_path = str(run.log_path)
        outcome.test_source_sha256 = run.test_source_sha256
        outcome.coverage_source_sha256 = run.coverage_source_sha256
        outcome.coverage_current = run.coverage_current

    def _record_runtime_test_result(
        self,
        outcome: TargetOutcome,
        run: RuntimeTestRunResult,
        *,
        scope: str,
    ) -> None:
        snapshot = _runtime_snapshot(run, scope)
        _record_test_runtime_states(outcome, run)
        if scope == "targeted":
            outcome.runtime_last_targeted_run = snapshot
        else:
            outcome.runtime_last_full_run = snapshot
            outcome.runtime_tests_run = run.signals.tests_run
            outcome.runtime_failures_final = run.signals.tests_failed
            outcome.runtime_errors_final = run.signals.tests_errors
            outcome.runtime_skipped_final = run.signals.tests_skipped
            outcome.runtime_failure_categories = dict(Counter(f.category for f in run.failures))
            if run.signals.tests_green:
                outcome.runtime_last_green_full_run = snapshot
                outcome.remaining_runtime_owners = []
        outcome.surefire_report_paths = list(
            dict.fromkeys((*outcome.surefire_report_paths, *(str(path) for path in run.report_paths)))
        )
        if run.log_path:
            outcome.runtime_log_paths = list(
                dict.fromkeys((*outcome.runtime_log_paths, str(run.log_path)))
            )



_RUNTIME_OUTCOME_FIELDS = (
    "runtime_tests_run",
    "runtime_failures_final",
    "runtime_errors_final",
    "runtime_skipped_final",
    "runtime_failure_categories",
    "runtime_last_targeted_run",
    "runtime_last_full_run",
    "runtime_last_green_full_run",
    "remaining_runtime_owners",
)


def snapshot_runtime_outcome(outcome: TargetOutcome) -> dict[str, object]:
    return {name: deepcopy(getattr(outcome, name)) for name in _RUNTIME_OUTCOME_FIELDS}


def restore_runtime_outcome(outcome: TargetOutcome, snapshot: dict[str, object]) -> None:
    for name, value in snapshot.items():
        setattr(outcome, name, deepcopy(value))


def _runtime_snapshot(
    run: CoverageRunResult | RuntimeTestRunResult,
    scope: str,
) -> RuntimeResultSnapshot:
    return RuntimeResultSnapshot(
        scope=scope,
        tests_run=run.signals.tests_run,
        failures=run.signals.tests_failed,
        errors=run.signals.tests_errors,
        skipped=run.signals.tests_skipped,
        executed_test_names=list(run.executed_test_names),
        failing_test_names=sorted({failure.test_method for failure in run.failures}),
        maven_execution_success=bool(run.maven_execution_success),
        tests_green=run.tests_green,
        note=run.note,
    )


def _mark_retained_compile_state(outcome: TargetOutcome, state: str) -> None:
    store = RegistryStore(outcome)
    for record in outcome.method_results:
        for test in record.tests:
            if test.final_disposition != TestDisposition.RETAINED.value:
                continue
            target = state
            if state == CompileState.PASSED.value and test.compile_state in {
                CompileState.FAILED.value,
                CompileState.DETERMINISTIC_REPAIR_PENDING.value,
                CompileState.LLM_REPAIR_PENDING.value,
                CompileState.REPAIRED_PENDING_COMPILE.value,
                "DETERMINISTIC_REPAIRED_PENDING_COMPILE",
            }:
                target = CompileState.REPAIRED_AND_PASSED.value
            store.transition_compile_state(test, target)


def _record_test_runtime_states(
    outcome: TargetOutcome,
    run: CoverageRunResult | RuntimeTestRunResult,
) -> None:
    """Pair each runtime error/failure with its exact registered test case."""
    failures_by_test: dict[str, list] = {}
    for failure in run.failures:
        normalized_name = (failure.test_method or "").split("(", 1)[0]
        failures_by_test.setdefault(normalized_name, []).append(failure)
    executed = set(run.executed_test_names)
    store = RegistryStore(outcome)
    for method_record in outcome.method_results:
        for test in method_record.tests:
            failures = failures_by_test.get(test.test_name, [])
            if failures:
                has_error = any((failure.status or "").lower() == "error" for failure in failures)
                store.set_runtime_state(
                    test,
                    "ERROR" if has_error else "FAILURE",
                    diagnostics=[runtime_diagnostic(failure) for failure in failures],
                )
            elif test.test_name in executed:
                store.set_runtime_state(test, "PASSED")


__all__ = [
    "RuntimeStateMixin",
    "_mark_retained_compile_state",
    "_record_test_runtime_states",
    "_runtime_snapshot",
    "restore_runtime_outcome",
    "snapshot_runtime_outcome",
]
