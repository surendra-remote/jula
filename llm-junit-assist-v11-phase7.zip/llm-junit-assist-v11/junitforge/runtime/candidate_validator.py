"""Runtime repair identity and acceptance validation."""

from __future__ import annotations

from junitforge.coverage_run import CoverageRunResult, RuntimeTestRunResult, SurefireFailure
from junitforge.execution.assembly import method_block_for_id, test_method_for_name, test_method_names


def validate_runtime_source_identity(
    *,
    before_source: str,
    after_source: str,
    owner: str,
    selected_test_name: str,
) -> tuple[bool, str, tuple[str, ...]]:
    """Verify that a candidate changes only one registry-selected @Test method."""
    before_names = tuple(test_method_names(before_source))
    after_names = tuple(test_method_names(after_source))
    missing = tuple(sorted(set(before_names) - set(after_names)))
    added = tuple(sorted(set(after_names) - set(before_names)))
    if len(before_names) != len(after_names) or missing or added:
        return False, "TEST_IDENTITY_CHANGED", missing + added

    before_owner = tuple(test_method_names(method_block_for_id(before_source, owner) or ""))
    after_owner = tuple(test_method_names(method_block_for_id(after_source, owner) or ""))
    owner_missing = tuple(sorted(set(before_owner) - set(after_owner)))
    owner_added = tuple(sorted(set(after_owner) - set(before_owner)))
    if len(before_owner) != len(after_owner) or owner_missing or owner_added:
        return False, "OWNER_TEST_IDENTITY_CHANGED", owner_missing + owner_added
    if selected_test_name not in after_names:
        return False, "SELECTED_TEST_DISAPPEARED", (selected_test_name,)

    changed_siblings: list[str] = []
    for test_name in before_names:
        if test_name == selected_test_name:
            continue
        before_test = test_method_for_name(before_source, test_name)
        after_test = test_method_for_name(after_source, test_name)
        if before_test is None or after_test is None or before_test.source != after_test.source:
            changed_siblings.append(test_name)
    if changed_siblings:
        return False, "PASSED_TEST_SOURCE_CHANGED", tuple(sorted(changed_siblings))
    return True, "SOURCE_IDENTITY_PRESERVED", ()


def validate_runtime_candidate_identity(
    *,
    before_source: str,
    after_source: str,
    owner: str,
    selected_test_names: set[str],
    before_run: CoverageRunResult | RuntimeTestRunResult,
    targeted_run: RuntimeTestRunResult,
    full_run: RuntimeTestRunResult,
    owner_failures_before: list[SurefireFailure],
    require_full_green: bool = False,
) -> tuple[bool, str, tuple[str, ...]]:
    """Validate source identity and targeted/full runtime acceptance gates."""
    if len(selected_test_names) == 1:
        source_ok, source_reason, source_details = validate_runtime_source_identity(
            before_source=before_source,
            after_source=after_source,
            owner=owner,
            selected_test_name=next(iter(selected_test_names)),
        )
        if not source_ok:
            return False, source_reason, source_details
    else:
        # Compatibility for pre-Phase-6 direct callers; the coordinator never
        # supplies more than one selected test.
        before_names = tuple(test_method_names(before_source))
        after_names = tuple(test_method_names(after_source))
        missing = tuple(sorted(set(before_names) - set(after_names)))
        added = tuple(sorted(set(after_names) - set(before_names)))
        if len(before_names) != len(after_names) or missing or added:
            return False, "TEST_IDENTITY_CHANGED", missing + added
        before_owner = tuple(test_method_names(method_block_for_id(before_source, owner) or ""))
        after_owner = tuple(test_method_names(method_block_for_id(after_source, owner) or ""))
        if set(before_owner) != set(after_owner) or len(before_owner) != len(after_owner):
            return False, "OWNER_TEST_IDENTITY_CHANGED", tuple(sorted(set(before_owner) - set(after_owner)))
        for test_name in before_names:
            if test_name in selected_test_names:
                continue
            before_test = test_method_for_name(before_source, test_name)
            after_test = test_method_for_name(after_source, test_name)
            if before_test is None or after_test is None or before_test.source != after_test.source:
                return False, "PASSED_TEST_SOURCE_CHANGED", (test_name,)

    expected_targeted = len(selected_test_names)
    if targeted_run.signals.tests_run != expected_targeted:
        missing = tuple(sorted(selected_test_names - set(targeted_run.executed_test_names)))
        return False, "TARGETED_TEST_COUNT_MISMATCH", missing
    targeted_executed = set(targeted_run.executed_test_names)
    if targeted_executed and not selected_test_names.issubset(targeted_executed):
        return False, "SELECTED_TEST_NOT_EXECUTED_TARGETED", tuple(
            sorted(selected_test_names - targeted_executed)
        )
    if not targeted_run.maven_execution_success or not targeted_run.signals.tests_executed:
        return False, "TARGETED_EXECUTION_FAILED", tuple(sorted(selected_test_names))
    if require_full_green and not targeted_run.tests_green:
        return False, "TARGETED_TESTS_NOT_GREEN", tuple(
            sorted({failure.test_method for failure in targeted_run.failures})
        )

    before_names = tuple(test_method_names(before_source))
    if full_run.signals.tests_run != before_run.signals.tests_run:
        missing = tuple(sorted(set(before_names) - set(full_run.executed_test_names)))
        return False, "FULL_TEST_COUNT_MISMATCH", missing
    full_executed = set(full_run.executed_test_names)
    if full_executed and not set(before_names).issubset(full_executed):
        return False, "FULL_TEST_IDENTITY_MISMATCH", tuple(sorted(set(before_names) - full_executed))
    if full_executed and not selected_test_names.issubset(full_executed):
        return False, "SELECTED_TEST_NOT_EXECUTED_FULL", tuple(
            sorted(selected_test_names - full_executed)
        )
    if not full_run.maven_execution_success or not full_run.signals.tests_executed:
        return False, "FULL_EXECUTION_FAILED", ()
    if require_full_green and not full_run.tests_green:
        return False, "FULL_SUITE_NOT_GREEN", tuple(
            sorted({failure.test_method for failure in full_run.failures})
        )

    before_failing_names = {failure.test_method for failure in before_run.failures}
    after_failing_names = {failure.test_method for failure in full_run.failures}
    newly_failing = tuple(sorted(after_failing_names - before_failing_names))
    if newly_failing:
        return False, "NEW_FAILING_TEST_INTRODUCED", newly_failing

    selected_still_failing = selected_test_names & after_failing_names
    owner_before_severity = sum(2 if failure.status == "error" else 1 for failure in owner_failures_before)
    owner_after_severity = sum(
        2 if failure.status == "error" else 1
        for failure in full_run.failures
        if failure.test_method in selected_test_names
    )
    if owner_after_severity >= owner_before_severity or selected_still_failing == selected_test_names:
        return False, "OWNER_FAILURE_SEVERITY_NOT_IMPROVED", tuple(sorted(selected_still_failing))
    before_suite_severity = before_run.signals.tests_errors * 2 + before_run.signals.tests_failed
    after_suite_severity = full_run.signals.tests_errors * 2 + full_run.signals.tests_failed
    if after_suite_severity > before_suite_severity:
        return False, "FULL_SUITE_SEVERITY_WORSENED", ()
    return True, "ACCEPTED", ()


__all__ = ["validate_runtime_candidate_identity", "validate_runtime_source_identity"]
