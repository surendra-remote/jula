"""Runtime failure ownership, grouping, and structured repair diagnostics."""

from __future__ import annotations

from collections import defaultdict
import re

from junitforge.coverage_run import SurefireFailure
from junitforge.execution.assembly import (
    owner_method_id_for_line,
    owner_method_id_for_test_name,
)
from junitforge.models import TargetOutcome, TestCaseRecord
from junitforge.pipeline.result import owner_for_test, test_record_by_name


def _normalized_test_method(value: str | None) -> str:
    return (value or "").split("(", 1)[0].strip()


def _normalized_test_class(value: str | None) -> str:
    return (value or "").strip().replace("$", ".")


def map_runtime_failure_test(
    failure: SurefireFailure,
    outcome: TargetOutcome,
    *,
    expected_test_class: str | None = None,
) -> tuple[TestCaseRecord | None, str, str]:
    """Map a runtime failure to one stable registry test identity.

    Runtime identity deliberately excludes source line numbers.  The executed
    class and method are matched against the authoritative registry, whose
    record already carries owner-method metadata and the stable ``test_id``.
    """
    actual_class = _normalized_test_class(failure.test_class)
    expected_class = _normalized_test_class(expected_test_class)
    if expected_class and actual_class:
        if actual_class != expected_class and actual_class.rsplit(".", 1)[-1] != expected_class.rsplit(".", 1)[-1]:
            return None, "executed_test_class_mismatch", "low"

    method_name = _normalized_test_method(failure.test_method)
    if not method_name:
        return None, "executed_test_method_missing", "low"
    record = test_record_by_name(outcome, method_name)
    if record is None:
        return None, "registry_test_missing", "low"
    if record.test_id != f"{record.owner_method_id}::{record.test_name}":
        return None, "registry_identity_invalid", "low"
    return record, "registry_test_id", "high"


def group_runtime_failures_by_test(
    failures: tuple[SurefireFailure, ...] | list[SurefireFailure],
    outcome: TargetOutcome,
    *,
    expected_test_class: str | None = None,
) -> tuple[dict[str, list[SurefireFailure]], list[SurefireFailure]]:
    grouped: dict[str, list[SurefireFailure]] = defaultdict(list)
    unmapped: list[SurefireFailure] = []
    for failure in failures:
        record, _source, confidence = map_runtime_failure_test(
            failure,
            outcome,
            expected_test_class=expected_test_class,
        )
        if record is None or confidence != "high":
            unmapped.append(failure)
            continue
        grouped[record.test_id].append(failure)
    return dict(grouped), unmapped


def _map_runtime_failure_owner(
    suite: str,
    failure: SurefireFailure,
    outcome=None,
) -> tuple[str | None, str, str]:
    """Compatibility owner mapping.

    The Phase 6 runtime-repair coordinator uses ``map_runtime_failure_test``.
    Legacy callers without a registry retain the older bounded fallbacks.
    """
    if outcome is not None:
        owner = owner_for_test(outcome, failure.test_method)
        if owner:
            return owner, "registry", "high"
        return None, "registry_unmapped", "low"
    owner = owner_method_id_for_test_name(suite, failure.test_method)
    if owner:
        return owner, "name_marker", "high"
    owner = owner_method_id_for_line(suite, failure.generated_test_line)
    if owner:
        return owner, "line_compatibility_only", "medium"
    prefix = failure.test_method.split("_", 1)[0].split("when", 1)[0]
    if prefix:
        candidates = []
        for line in suite.splitlines():
            stripped = line.strip()
            if stripped.startswith("// JUNITFORGE_METHOD_BEGIN: "):
                method_id = stripped.split(":", 1)[1].strip()
                method_name = method_id.split("(", 1)[0]
                if method_name == prefix:
                    candidates.append(method_id)
        if len(candidates) == 1:
            return candidates[0], "name_prefix", "medium"
    return None, "unmapped", "low"


def _group_runtime_failures(
    suite: str,
    failures: tuple[SurefireFailure, ...] | list[SurefireFailure],
    outcome=None,
) -> tuple[dict[str, list[SurefireFailure]], list[SurefireFailure]]:
    grouped: dict[str, list[SurefireFailure]] = defaultdict(list)
    unmapped: list[SurefireFailure] = []
    for failure in failures:
        owner, _, confidence = _map_runtime_failure_owner(suite, failure, outcome)
        if owner and confidence != "low":
            grouped[owner].append(failure)
        else:
            unmapped.append(failure)
    return dict(grouped), unmapped


def _expected_actual(message: str) -> tuple[str | None, str | None]:
    text = message or ""
    match = re.search(
        r"expected:\s*(?:<(?P<expected_angle>.*?)>|(?P<expected>\S+))\s*"
        r"(?:but was:|but was)\s*(?:<(?P<actual_angle>.*?)>|(?P<actual>\S+))",
        text,
        flags=re.IGNORECASE | re.DOTALL,
    )
    if not match:
        return None, None
    return (
        match.group("expected_angle") or match.group("expected"),
        match.group("actual_angle") or match.group("actual"),
    )


def runtime_diagnostic(failure: SurefireFailure, *, stack_limit: int = 5000) -> dict[str, object]:
    status = (failure.status or "").lower()
    assertion = (
        status == "failure"
        or "AssertionFailedError" in (failure.exception_type or "")
        or failure.category.startswith("ASSERTION_")
        or failure.category in {
            "EXPECTED_EXCEPTION_NOT_THROWN",
            "WANTED_BUT_NOT_INVOKED",
            "NEVER_WANTED_BUT_INVOKED",
            "MOCK_ARGUMENT_MISMATCH",
        }
    )
    expected, actual = _expected_actual(failure.message)
    return {
        "type": "assertion_failure" if assertion else "runtime_error",
        "exception": failure.exception_type or None,
        "message": failure.message or "",
        "expected": expected,
        "actual": actual,
        "source_line": failure.generated_test_line,
        "stack_trace": (failure.stack_trace or "")[:stack_limit],
        "category": failure.category,
        "executed_test_class": failure.test_class,
        "executed_test_method": _normalized_test_method(failure.test_method),
    }


def _runtime_failure_excerpt(failures: list[SurefireFailure], limit: int = 9000) -> str:
    chunks: list[str] = []
    for failure in failures:
        chunk = "\n".join(
            (
                f"TEST: {failure.test_class}#{failure.test_method}",
                f"STATUS: {failure.status}",
                f"CATEGORY: {failure.category}",
                f"EXCEPTION: {failure.exception_type}",
                f"MESSAGE: {failure.message}",
                f"GENERATED_TEST_LINE: {failure.generated_test_line}",
                f"PRODUCTION_FRAME: {failure.production_file}:{failure.production_line}",
                "STACK TRACE:",
                failure.stack_trace,
            )
        )
        chunks.append(chunk)
        if sum(len(value) for value in chunks) >= limit:
            break
    return "\n\n---\n\n".join(chunks)[:limit]


def _failure_signatures(
    failures: tuple[SurefireFailure, ...] | list[SurefireFailure],
) -> set[str]:
    return {failure.signature for failure in failures}


__all__ = [
    "_failure_signatures",
    "_group_runtime_failures",
    "_map_runtime_failure_owner",
    "_runtime_failure_excerpt",
    "group_runtime_failures_by_test",
    "map_runtime_failure_test",
    "runtime_diagnostic",
]
