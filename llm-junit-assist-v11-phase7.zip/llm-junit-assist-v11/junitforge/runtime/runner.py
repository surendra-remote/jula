"""Targeted and full runtime execution boundary."""

from junitforge.coverage_run import CoverageRunner, RuntimeTestRunResult


def run_tests(runner: CoverageRunner, module, test_classes, **kwargs):
    return runner.run_tests(module, test_classes, **kwargs)


class RuntimeRunnerMixin:
    def _run_tests(self, runner: CoverageRunner, module, test_classes, **kwargs):
        return run_tests(runner, module, test_classes, **kwargs)


__all__ = ["CoverageRunner", "RuntimeRunnerMixin", "RuntimeTestRunResult", "run_tests"]
