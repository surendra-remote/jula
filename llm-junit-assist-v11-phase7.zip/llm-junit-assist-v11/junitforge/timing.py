"""Low-noise timing and optional long-running heartbeat diagnostics.

Normal INFO output is owned by the fixed console-stage logger. Timing events are
DEBUG-only and may also be persisted as JSONL for troubleshooting.
"""
from __future__ import annotations

import json
import threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from time import perf_counter
from typing import Any, Iterator

from junitforge import __version__
from junitforge.vendor.logging_utils import get

log = get("junitforge.timing")
_LOCK = threading.Lock()
_OUTPUT: Path | None = None
_VERSION = __version__


def configure_timing(repo_root: Path | None = None) -> None:
    global _OUTPUT
    if repo_root is not None:
        _OUTPUT = Path(repo_root) / ".junitforge" / "timing-events.jsonl"
        _OUTPUT.parent.mkdir(parents=True, exist_ok=True)
        _OUTPUT.touch(exist_ok=True)
    event("version", version=_VERSION, timing_file=str(_OUTPUT) if _OUTPUT else "disabled")


def now() -> float:
    return perf_counter()


def event(step: str, *, elapsed: float | None = None, **fields: Any) -> None:
    timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    parts = [step]
    if elapsed is not None:
        parts.append(f"elapsed={elapsed:.3f}s")
    parts.extend(f"{key}={value}" for key, value in fields.items())
    log.debug("[TIMING] %s", " | ".join(parts))
    if _OUTPUT is not None:
        payload = {
            "timestamp": timestamp,
            "version": _VERSION,
            "step": step,
            "elapsed_seconds": elapsed,
            **fields,
        }
        try:
            with _LOCK, _OUTPUT.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(payload, default=str, ensure_ascii=False) + "\n")
        except OSError as exc:
            log.debug("timing-file-write-error | error=%s", exc)


@contextmanager
def heartbeat(step: str, *, interval_seconds: float = 90.0, **fields: Any) -> Iterator[None]:
    """Emit DEBUG-only heartbeats after a long-running threshold."""
    started = perf_counter()
    stop = threading.Event()
    interval = max(60.0, float(interval_seconds))

    def run() -> None:
        count = 0
        while not stop.wait(interval):
            count += 1
            log.debug(
                "[HEARTBEAT] stage=%s | elapsed=%.1fs | count=%d | target=%s",
                step,
                perf_counter() - started,
                count,
                fields.get("target", ""),
            )

    thread = threading.Thread(target=run, name=f"junitforge-heartbeat-{step}", daemon=True)
    thread.start()
    try:
        yield
    finally:
        stop.set()
        thread.join(timeout=1.0)
