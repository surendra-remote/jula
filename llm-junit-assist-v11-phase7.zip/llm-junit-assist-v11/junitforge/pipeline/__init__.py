"""Pipeline public exports without eager imports that create stage cycles."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover - import-time typing only
    from .engine import GenerationPipeline
    from .state import PipelineState

__all__ = ["GenerationPipeline", "PipelineState"]


def __getattr__(name: str):
    if name == "GenerationPipeline":
        from .engine import GenerationPipeline

        return GenerationPipeline
    if name == "PipelineState":
        from .state import PipelineState

        return PipelineState
    raise AttributeError(name)
