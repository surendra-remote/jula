"""Stable pipeline stage identifiers."""

from enum import Enum


class PipelineStage(str, Enum):
    TARGET = "target"
    CONTEXT = "context"
    SKELETON = "skeleton"
    GENERATION = "generation"
    VALIDATION = "validation"
    COMPILE = "compile"
    COMPILE_REPAIR = "compile_repair"
    RUNTIME = "runtime"
    RUNTIME_REPAIR = "runtime_repair"
    COVERAGE = "coverage"
    AUGMENTATION = "augmentation"
    PUBLICATION = "publication"
