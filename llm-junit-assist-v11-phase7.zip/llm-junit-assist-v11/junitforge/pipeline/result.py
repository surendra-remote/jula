"""TargetOutcome creation and authoritative generated-test registry helpers."""

from __future__ import annotations

from copy import deepcopy

from junitforge.generation.response_extractor import extract_generated_tests
from junitforge.models import CompileState, TargetOutcome, TestDisposition
from junitforge.registry import RegistryStore, persist_registry


def create_target_outcome(*, fqcn: str, module: str, source_path: str) -> TargetOutcome:
    return TargetOutcome(
        fqcn=fqcn,
        module=module,
        source_path=source_path,
        test_path="",
        classification="",
        testable=True,
    )


def test_registry(outcome: TargetOutcome) -> dict[str, list]:
    """Return the authoritative production-method -> TestCaseRecord registry."""
    return {record.method_id: record.tests for record in outcome.method_results}


def test_record_by_name(outcome: TargetOutcome, test_name: str):
    normalized = (test_name or "").split("(", 1)[0]
    for method_record in outcome.method_results:
        for test_record in method_record.tests:
            if test_record.test_name == test_name or test_record.test_name == normalized:
                return test_record
    return None


def owner_for_test(outcome: TargetOutcome, test_name: str) -> str | None:
    record = test_record_by_name(outcome, test_name)
    return record.owner_method_id if record is not None else None


def _accepted_compile_state(current: str, requested: str) -> str:
    if requested != CompileState.PASSED.value:
        return requested
    if current == CompileState.REPAIRED_AND_PASSED.value:
        return current
    if current in {
        CompileState.FAILED.value,
        CompileState.DETERMINISTIC_REPAIR_PENDING.value,
        CompileState.LLM_REPAIR_PENDING.value,
        CompileState.REPAIRED_PENDING_COMPILE.value,
    }:
        return CompileState.REPAIRED_AND_PASSED.value
    return CompileState.PASSED.value


def sync_test_registry_sources(
    outcome: TargetOutcome,
    source: str,
    *,
    compile_state: str | None = None,
    accepted: bool = False,
) -> None:
    """Synchronize extracted test sources through the central candidate API.

    ``generated_source`` remains the immutable original LLM-produced source.
    Accepted assembly/repair output is promoted only through ``commit_candidate``.
    """
    extracted = {test.name: test for test in extract_generated_tests(source)}
    store = RegistryStore(outcome)
    for method_record in outcome.method_results:
        for test_record in method_record.tests:
            current = extracted.get(test_record.test_name)
            if current is None:
                continue
            if current.source != test_record.latest_accepted_source:
                store.set_candidate(test_record, current.source)
                if accepted:
                    store.commit_candidate(
                        test_record,
                        source_start_line=current.start_line,
                        source_end_line=current.end_line,
                    )
            if compile_state is not None and test_record.final_disposition == TestDisposition.RETAINED.value:
                target_state = _accepted_compile_state(test_record.compile_state, compile_state)
                store.transition_compile_state(test_record, target_state)


def snapshot_test_registry(outcome: TargetOutcome):
    """Capture all per-method/per-test registry state for transactional rollback."""
    return deepcopy(outcome.method_results)


def restore_test_registry(outcome: TargetOutcome, snapshot) -> None:
    """Restore the authoritative registry after a rejected repair candidate."""
    outcome.method_results = deepcopy(snapshot)
    persist_registry(outcome)


def restore_test_registry_source(outcome: TargetOutcome, source: str) -> None:
    sync_test_registry_sources(outcome, source, accepted=True)


__all__ = [
    "create_target_outcome",
    "owner_for_test",
    "restore_test_registry",
    "restore_test_registry_source",
    "snapshot_test_registry",
    "sync_test_registry_sources",
    "test_record_by_name",
    "test_registry",
]
