"""Transactional per-target Java source state."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PipelineState:
    original_source: str | None = None
    current_source: str | None = None
    last_compiling_source: str | None = None
    last_runtime_green_source: str | None = None
    last_coverage_valid_source: str | None = None
    previous_candidate_source: str | None = None

    def record_generated_candidate(self, source: str) -> None:
        self.previous_candidate_source = self.current_source
        self.current_source = source

    def record_compiling_source(self, source: str) -> None:
        self.current_source = source
        self.last_compiling_source = source

    def record_runtime_green_source(self, source: str) -> None:
        self.current_source = source
        self.last_runtime_green_source = source

    def record_coverage_valid_source(self, source: str) -> None:
        self.current_source = source
        self.last_coverage_valid_source = source

    def rollback_to_last_accepted(self) -> str | None:
        accepted = (
            self.last_coverage_valid_source
            or self.last_runtime_green_source
            or self.last_compiling_source
            or self.original_source
        )
        self.current_source = accepted
        return accepted
