"""Authoritative generated-test registry lifecycle and persistence.

The registry stored at ``07-class-assembly/registry.json`` is a persisted view
of ``TargetOutcome.method_results``.  This module never maintains a second
independent registry collection.
"""

from __future__ import annotations

import json
import os
import tempfile
import threading
from dataclasses import fields
from pathlib import Path
from typing import Any, Iterable
import re

from junitforge.audit.serializer import dumps
from junitforge.models import (
    CompileState,
    MethodGenerationRecord,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
)

REGISTRY_RELATIVE_PATH = Path("07-class-assembly/registry.json")
_PERSIST_LOCK = threading.RLock()

_COMPILE_STATE_ALIASES = {
    "DETERMINISTIC_REPAIRED_PENDING_COMPILE": CompileState.REPAIRED_PENDING_COMPILE.value,
}

_ALLOWED_COMPILE_TRANSITIONS: dict[str, set[str]] = {
    CompileState.NOT_RUN.value: {
        CompileState.PASSED.value,
        CompileState.FAILED.value,
        CompileState.REJECTED.value,
        CompileState.REMOVED.value,
    },
    CompileState.PASSED.value: {
        CompileState.FAILED.value,
        CompileState.DETERMINISTIC_REPAIR_PENDING.value,
        CompileState.LLM_REPAIR_PENDING.value,
        CompileState.REPAIRED_PENDING_COMPILE.value,
        CompileState.REPAIRED_AND_PASSED.value,
        CompileState.REJECTED.value,
        CompileState.REMOVED.value,
    },
    CompileState.FAILED.value: {
        CompileState.DETERMINISTIC_REPAIR_PENDING.value,
        CompileState.LLM_REPAIR_PENDING.value,
        CompileState.REPAIRED_PENDING_COMPILE.value,
        CompileState.REPAIRED_AND_PASSED.value,
        CompileState.REJECTED.value,
        CompileState.REMOVED.value,
    },
    CompileState.DETERMINISTIC_REPAIR_PENDING.value: {
        CompileState.REPAIRED_PENDING_COMPILE.value,
        CompileState.LLM_REPAIR_PENDING.value,
        CompileState.REJECTED.value,
        CompileState.REMOVED.value,
    },
    CompileState.LLM_REPAIR_PENDING.value: {
        CompileState.REPAIRED_PENDING_COMPILE.value,
        CompileState.REJECTED.value,
        CompileState.REMOVED.value,
    },
    CompileState.REPAIRED_PENDING_COMPILE.value: {
        CompileState.REPAIRED_AND_PASSED.value,
        CompileState.FAILED.value,
        CompileState.DETERMINISTIC_REPAIR_PENDING.value,
        CompileState.LLM_REPAIR_PENDING.value,
        CompileState.REJECTED.value,
        CompileState.REMOVED.value,
    },
    CompileState.REPAIRED_AND_PASSED.value: {
        CompileState.FAILED.value,
        CompileState.DETERMINISTIC_REPAIR_PENDING.value,
        CompileState.LLM_REPAIR_PENDING.value,
        CompileState.REPAIRED_PENDING_COMPILE.value,
        CompileState.REJECTED.value,
        CompileState.REMOVED.value,
    },
    CompileState.REJECTED.value: {CompileState.REMOVED.value},
    CompileState.REMOVED.value: set(),
}


class InvalidCompileStateTransition(ValueError):
    """Raised when code attempts an impossible compile-state transition."""


class RegistryPersistenceError(OSError):
    """Raised when atomic registry persistence fails."""


def normalize_source(source: str | None) -> str:
    """Return a deterministic representation used only for source hashing."""
    if not source:
        return ""
    normalized = source.replace("\r\n", "\n").replace("\r", "\n")
    lines = [line.rstrip() for line in normalized.split("\n")]
    while lines and not lines[0]:
        lines.pop(0)
    while lines and not lines[-1]:
        lines.pop()
    return "\n".join(lines) + ("\n" if lines else "")


def source_hash(source: str | None) -> str:
    import hashlib

    return hashlib.sha256(normalize_source(source).encode("utf-8")).hexdigest()


def extract_history_action(entry: object) -> str:
    """Extract a comparable action string from structured or legacy history."""
    if isinstance(entry, str):
        return entry
    if isinstance(entry, dict):
        for key in ("action", "type", "event", "name", "stage"):
            value = entry.get(key)
            if value is not None:
                return str(value)
    return ""


def history_action_startswith(entry: object, prefix: str) -> bool:
    return extract_history_action(entry).startswith(prefix)


def _atomic_replace_text(path: Path, text: str) -> None:
    """Write text through a same-directory temporary file and atomic replace."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd: int | None = None
    temp_path: Path | None = None
    try:
        fd, temp_name = tempfile.mkstemp(
            prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent)
        )
        temp_path = Path(temp_name)
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            fd = None
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
        temp_path = None
    except Exception as exc:  # noqa: BLE001
        if fd is not None:
            os.close(fd)
        if temp_path is not None:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass
        raise RegistryPersistenceError(f"unable to persist registry {path}: {exc}") from exc


def atomic_write_registry(path: Path, method_records: Iterable[MethodGenerationRecord]) -> None:
    """Persist the legacy list-shaped registry document.

    Kept for compatibility with Phase 1 callers. ``RegistryStore.persist`` writes
    the enriched document that also contains recalculated class-surface ranges.
    """
    text, _warnings = dumps(list(method_records))
    _atomic_replace_text(Path(path), text)


def atomic_write_registry_document(path: Path, outcome: TargetOutcome) -> None:
    document = {
        "schema_version": 6,
        "method_results": list(outcome.method_results),
        "assembled_source_hash": outcome.registry_source_hash,
        "source_ranges": {
            "fixtures": list(outcome.fixture_source_ranges),
            "skeleton": list(outcome.skeleton_source_ranges),
            "imports_and_class": list(outcome.import_class_source_ranges),
            "assembly": list(outcome.assembly_source_ranges),
        },
    }
    text, _warnings = dumps(document)
    _atomic_replace_text(Path(path), text)


def _coerce_history(value: Any, *, legacy_action: str) -> list[object]:
    if isinstance(value, list):
        return list(value)
    if value in (None, "", 0):
        return []
    if isinstance(value, int):
        return [{"action": legacy_action, "attempt": index + 1} for index in range(value)]
    return [value]


def test_record_from_dict(value: dict[str, Any]) -> TestCaseRecord:
    allowed = {item.name for item in fields(TestCaseRecord)}
    data = {key: item for key, item in value.items() if key in allowed}
    for field_name, legacy_action in (
        ("validation_diagnostics", "legacy_validation_diagnostic"),
        ("compile_diagnostics", "legacy_compile_diagnostic"),
        ("current_compile_diagnostics", "legacy_current_compile_diagnostic"),
        ("compile_attempts", "legacy_compile_attempt"),
        ("deterministic_repair_history", "legacy_deterministic_repair"),
        ("llm_repair_history", "legacy_llm_repair"),
        ("runtime_diagnostics", "legacy_runtime_diagnostic"),
        ("current_runtime_diagnostics", "legacy_current_runtime_diagnostic"),
        ("runtime_repair_attempts", "legacy_runtime_repair_attempt"),
    ):
        data[field_name] = _coerce_history(data.get(field_name), legacy_action=legacy_action)
    record = TestCaseRecord(**data)
    if record.latest_accepted_source and not record.source_hash:
        record.source_hash = source_hash(record.latest_accepted_source)
    record.compile_state = _normalize_compile_state(record.compile_state)
    return record


def method_record_from_dict(value: dict[str, Any]) -> MethodGenerationRecord:
    allowed = {item.name for item in fields(MethodGenerationRecord)}
    data = {key: item for key, item in value.items() if key in allowed and key != "tests"}
    tests = value.get("tests") or []
    data["tests"] = [
        item if isinstance(item, TestCaseRecord) else test_record_from_dict(item)
        for item in tests
        if isinstance(item, (dict, TestCaseRecord))
    ]
    return MethodGenerationRecord(**data)


def load_registry(path: Path) -> list[MethodGenerationRecord]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(payload, dict):
        payload = payload.get("method_results", payload.get("records", []))
    if not isinstance(payload, list):
        raise ValueError("registry root must be a list of method records")
    return [
        item if isinstance(item, MethodGenerationRecord) else method_record_from_dict(item)
        for item in payload
        if isinstance(item, (dict, MethodGenerationRecord))
    ]


def _normalize_compile_state(value: str | CompileState) -> str:
    raw = value.value if isinstance(value, CompileState) else str(value or CompileState.NOT_RUN.value)
    raw = _COMPILE_STATE_ALIASES.get(raw, raw)
    if raw not in _ALLOWED_COMPILE_TRANSITIONS:
        raise ValueError(f"unknown compile state: {raw}")
    return raw



def _line_for_offset(source: str, offset: int) -> int:
    return source.count("\n", 0, max(0, offset)) + 1


def _matching_brace(source: str, opening: int) -> int | None:
    depth = 0
    quote: str | None = None
    escaped = False
    line_comment = False
    block_comment = False
    index = opening
    while index < len(source):
        char = source[index]
        nxt = source[index + 1] if index + 1 < len(source) else ""
        if line_comment:
            if char == "\n":
                line_comment = False
            index += 1
            continue
        if block_comment:
            if char == "*" and nxt == "/":
                block_comment = False
                index += 2
                continue
            index += 1
            continue
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            index += 1
            continue
        if char == "/" and nxt == "/":
            line_comment = True
            index += 2
            continue
        if char == "/" and nxt == "*":
            block_comment = True
            index += 2
            continue
        if char in {'"', "'"}:
            quote = char
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return index
        index += 1
    return None


def _method_ranges(source: str) -> list[dict[str, object]]:
    """Return direct class-member method ranges without using line proximity."""
    result: list[dict[str, object]] = []
    pattern = re.compile(
        r"(?m)^[ \t]*(?P<annotations>(?:@[\w.]+(?:\([^\n]*\))?[ \t]*\n[ \t]*)*)"
        r"(?:(?:public|protected|private|static|final|synchronized|abstract|native|strictfp|default)\s+)*"
        r"(?:<[^>{};]+>\s*)?[\w.$<>?,\[\] \t]+\s+"
        r"(?P<name>[A-Za-z_$][\w$]*)\s*\([^;{}]*\)\s*(?:throws\s+[^\{]+)?\{"
    )
    for match in pattern.finditer(source):
        opening = source.find("{", match.start(), match.end())
        closing = _matching_brace(source, opening) if opening >= 0 else None
        if closing is None:
            continue
        start = match.start()
        result.append({
            "name": match.group("name"),
            "start_line": _line_for_offset(source, start),
            "end_line": _line_for_offset(source, closing),
            "annotations": match.group("annotations") or "",
        })
    return result


def recalculate_registry_ranges(
    outcome: TargetOutcome,
    source: str,
    *,
    fixture_method_names: Iterable[str] = (),
    persist: bool = True,
) -> None:
    """Recalculate test, fixture, skeleton, import/class, and assembly ranges.

    Test ownership remains the stable ``test_id``. Lines are mutable coordinates
    recalculated after every assembly or replacement and are never used as an
    identity key.
    """
    from junitforge.execution.assembly import extract_test_methods, test_class_structure_error

    extracted = {item.name: item for item in extract_test_methods(source)}
    for method in outcome.method_results:
        for record in method.tests:
            current = extracted.get(record.test_name)
            record.source_start_line = current.start_line if current else None
            record.source_end_line = current.end_line if current else None

    fixture_names = set(fixture_method_names)
    method_ranges = _method_ranges(source)
    fixture_ranges: list[dict[str, object]] = []
    skeleton_ranges: list[dict[str, object]] = []
    test_names = set(extracted)
    for item in method_ranges:
        name = str(item["name"])
        if name in test_names:
            continue
        entry = {key: value for key, value in item.items() if key != "annotations"}
        if name in fixture_names:
            fixture_ranges.append(entry)
        else:
            annotations = str(item.get("annotations") or "")
            entry["kind"] = "setup" if re.search(r"@(?:BeforeEach|BeforeAll)\b", annotations) else "member"
            skeleton_ranges.append(entry)

    lines = source.splitlines()
    class_match = re.search(r"\bclass\s+[A-Za-z_$][\w$]*[^\{]*\{", source)
    class_open_line = _line_for_offset(source, source.find("{", class_match.start(), class_match.end())) if class_match else 1
    import_end = 0
    for index, line in enumerate(lines, start=1):
        if re.match(r"\s*(?:package|import)\b", line):
            import_end = index
    import_class_ranges = [{
        "name": "imports_and_class_header",
        "start_line": 1,
        "end_line": max(import_end, class_open_line),
    }]

    structure_error = None
    class_name = Path(outcome.test_path).name.removesuffix(".java") if outcome.test_path else ""
    if class_name:
        structure_error = test_class_structure_error(source, class_name)
    assembly_ranges = []
    if structure_error:
        assembly_ranges.append({
            "name": "malformed_class_structure",
            "start_line": 1,
            "end_line": max(1, len(lines)),
            "reason": structure_error,
        })

    # Persist class fields, constructor/setup fragments, and other non-test
    # class-surface lines as skeleton ranges. Method and test ranges take
    # precedence during diagnostic mapping.
    occupied: set[int] = set()
    for item in fixture_ranges + skeleton_ranges:
        occupied.update(range(int(item["start_line"]), int(item["end_line"]) + 1))
    for item in extracted.values():
        occupied.update(range(item.start_line, item.end_line + 1))
    class_close_line = max(1, len(lines))
    if class_match:
        opening = source.find("{", class_match.start(), class_match.end())
        closing = _matching_brace(source, opening) if opening >= 0 else None
        if closing is not None:
            class_close_line = _line_for_offset(source, closing)
    gap_start: int | None = None
    for line_number in range(class_open_line + 1, class_close_line):
        content = lines[line_number - 1].strip() if line_number <= len(lines) else ""
        eligible = line_number not in occupied and bool(content) and not content.startswith("// JUNITFORGE-")
        if eligible and gap_start is None:
            gap_start = line_number
        if not eligible and gap_start is not None:
            skeleton_ranges.append({
                "name": "class_fields_or_setup",
                "kind": "class_surface",
                "start_line": gap_start,
                "end_line": line_number - 1,
            })
            gap_start = None
    if gap_start is not None:
        skeleton_ranges.append({
            "name": "class_fields_or_setup",
            "kind": "class_surface",
            "start_line": gap_start,
            "end_line": class_close_line - 1,
        })

    outcome.registry_source_hash = source_hash(source)
    outcome.fixture_source_ranges = fixture_ranges
    outcome.skeleton_source_ranges = skeleton_ranges
    outcome.import_class_source_ranges = import_class_ranges
    outcome.assembly_source_ranges = assembly_ranges
    if persist:
        RegistryStore(outcome).persist()


def fixture_method_names_from_context(ctx: object | None) -> tuple[str, ...]:
    execution = getattr(ctx, "execution_context", None)
    return tuple(
        str(getattr(fixture, "method_name", ""))
        for fixture in (getattr(execution, "fixtures", ()) or ())
        if getattr(fixture, "method_name", None)
    )


class RegistryStore:
    """Transactional facade over ``TargetOutcome.method_results``."""

    def __init__(self, outcome: TargetOutcome, path: Path | None = None):
        self.outcome = outcome
        self.path = Path(path or outcome.registry_path) if (path or outcome.registry_path) else None
        if self.path is not None:
            self.outcome.registry_path = str(self.path)

    def persist(self) -> None:
        if self.path is not None:
            with _PERSIST_LOCK:
                atomic_write_registry_document(self.path, self.outcome)

    def find(self, test: str | TestCaseRecord) -> TestCaseRecord:
        if isinstance(test, TestCaseRecord):
            return test
        for method in self.outcome.method_results:
            for record in method.tests:
                if record.test_id == test or record.test_name == test:
                    return record
        raise KeyError(test)

    def register_method(self, method: MethodGenerationRecord) -> None:
        if all(existing is not method for existing in self.outcome.method_results):
            self.outcome.method_results.append(method)
        self.persist()

    def register_test(self, method: MethodGenerationRecord, test: TestCaseRecord) -> None:
        if all(existing is not test for existing in method.tests):
            method.tests.append(test)
        self.persist()

    def set_candidate(
        self,
        test: str | TestCaseRecord,
        source: str,
    ) -> TestCaseRecord:
        record = self.find(test)
        record.candidate_source = source
        self.persist()
        return record

    def commit_candidate(
        self,
        test: str | TestCaseRecord,
        *,
        source_start_line: int | None = None,
        source_end_line: int | None = None,
    ) -> TestCaseRecord:
        record = self.find(test)
        if not record.candidate_source:
            raise ValueError(f"no candidate source exists for {record.test_id}")
        record.previous_accepted_source = record.latest_accepted_source
        record.latest_accepted_source = record.candidate_source
        record.source_hash = source_hash(record.latest_accepted_source)
        if source_start_line is not None:
            record.source_start_line = source_start_line
        if source_end_line is not None:
            record.source_end_line = source_end_line
        record.candidate_source = ""
        self.persist()
        return record

    def discard_candidate(self, test: str | TestCaseRecord) -> TestCaseRecord:
        record = self.find(test)
        record.candidate_source = ""
        self.persist()
        return record

    def rollback_candidate(
        self,
        test: str | TestCaseRecord,
        *,
        failed_attempt: object,
        history_field: str = "compile_attempts",
    ) -> TestCaseRecord:
        record = self.find(test)
        history = getattr(record, history_field, None)
        if not isinstance(history, list):
            raise ValueError(f"{history_field} is not an append-only history field")
        history.append(failed_attempt)
        record.candidate_source = ""
        self.persist()
        return record

    def set_validation_state(
        self,
        test: str | TestCaseRecord,
        state: str,
        *,
        diagnostics: Iterable[object] = (),
    ) -> TestCaseRecord:
        record = self.find(test)
        record.validation_state = state
        record.validation_diagnostics.extend(diagnostics)
        self.persist()
        return record


    def set_disposition(
        self,
        test: str | TestCaseRecord,
        disposition: str,
        *,
        rejection_reason: str | None = None,
    ) -> TestCaseRecord:
        record = self.find(test)
        record.final_disposition = disposition
        if rejection_reason is not None:
            record.final_rejection_reason = rejection_reason
        self.persist()
        return record

    def transition_compile_state(
        self,
        test: str | TestCaseRecord,
        state: str | CompileState,
        *,
        diagnostics: Iterable[object] = (),
        attempt: object | None = None,
    ) -> TestCaseRecord:
        record = self.find(test)
        current = _normalize_compile_state(record.compile_state)
        target = _normalize_compile_state(state)
        if target != current and target not in _ALLOWED_COMPILE_TRANSITIONS[current]:
            raise InvalidCompileStateTransition(f"invalid compile transition: {current} -> {target}")
        diagnostic_list = list(diagnostics)
        record.current_compile_diagnostics = diagnostic_list
        if diagnostic_list:
            record.compile_diagnostics.append(
                {"state": target, "diagnostics": diagnostic_list}
            )
        if attempt is not None:
            record.compile_attempts.append(attempt)
        record.compile_state = target
        self.persist()
        return record

    def append_history(
        self,
        test: str | TestCaseRecord,
        history_field: str,
        entry: object,
    ) -> TestCaseRecord:
        record = self.find(test)
        history = getattr(record, history_field, None)
        if not isinstance(history, list):
            raise ValueError(f"{history_field} is not an append-only history field")
        history.append(entry)
        self.persist()
        return record

    def set_runtime_state(
        self,
        test: str | TestCaseRecord,
        state: str,
        *,
        diagnostics: Iterable[object] = (),
    ) -> TestCaseRecord:
        record = self.find(test)
        record.runtime_state = state
        diagnostic_list = list(diagnostics)
        record.current_runtime_diagnostics = diagnostic_list
        if diagnostic_list:
            record.runtime_diagnostics.extend(diagnostic_list)
        self.persist()
        return record

    def reject(self, test: str | TestCaseRecord, reason: str) -> TestCaseRecord:
        record = self.find(test)
        record.final_disposition = TestDisposition.REJECTED.value
        record.final_rejection_reason = reason
        if record.compile_state != CompileState.REMOVED.value:
            self.transition_compile_state(record, CompileState.REJECTED)
        else:
            self.persist()
        return record

    def remove(self, test: str | TestCaseRecord, reason: str | None = None) -> TestCaseRecord:
        record = self.find(test)
        if reason:
            record.final_rejection_reason = reason
        record.final_disposition = TestDisposition.REJECTED.value
        self.transition_compile_state(record, CompileState.REMOVED)
        return record


def registry_store(outcome: TargetOutcome) -> RegistryStore:
    return RegistryStore(outcome)


def persist_registry(outcome: TargetOutcome) -> None:
    RegistryStore(outcome).persist()


__all__ = [
    "InvalidCompileStateTransition",
    "REGISTRY_RELATIVE_PATH",
    "RegistryPersistenceError",
    "RegistryStore",
    "atomic_write_registry",
    "atomic_write_registry_document",
    "extract_history_action",
    "history_action_startswith",
    "load_registry",
    "method_record_from_dict",
    "normalize_source",
    "recalculate_registry_ranges",
    "fixture_method_names_from_context",
    "persist_registry",
    "registry_store",
    "source_hash",
    "test_record_from_dict",
]
