# RUN COMMANDS

Commands for `llm-junit-assist v7.3.3 — Compile-Repair Rollback and Deterministic Diagnostics Hotfix`.

## 1. Verify installed release

```bash
python -c "import junitforge; print(junitforge.__version__)"
```

Expected:

```text
7.3.3
```

## 2. Python compilation

```bash
cd llm-junit-assist-v7.3.3
python -m compileall -q -f junitforge tests
```

## 3. Focused compile-repair regressions

```bash
python -m unittest discover -s tests -p 'test_v73_generation_recovery.py' -v
```

Expected:

```text
Ran 46 tests
OK
```

## 4. Complete Python suite

```bash
python -m unittest discover -s tests -v
```

Expected:

```text
Ran 160 tests
OK
```

Pytest cross-check:

```bash
python -m pytest -q
```

Expected:

```text
160 passed, 5 warnings
```

## 5. Representative Java fixture compilation

```bash
python -m unittest \
  tests.test_schema_fixture_pipeline.SchemaFixturePipelineTest.test_emitted_fixture_java_compiles_and_is_deep \
  tests.test_schema_fixture_pipeline.SchemaFixturePipelineTest.test_byte_and_short_fixture_values_use_explicit_narrowing_casts \
  -v
```

## 6. Windows-path and runtime-log regressions

```bash
python -m unittest \
  tests.test_compile_error_parsing.WindowsJavacErrorParsingTest \
  tests.test_v73_generation_recovery.ExistingBehaviorRegressionTest.test_35_windows_runtime_log_filename_remains_safe \
  -v
```

## 7. Re-run PaymentServiceImpl without coverage

Windows Command Prompt:

```bat
python -m junitforge --repo-path "C:\Users\xsglfdua\git\gi-qnb-billpayment" --only PaymentServiceImpl.java --limit 1 --overwrite --no-coverage --llm-audit --verbose
```

Expected v7.3.3 log behavior:

```text
[METHOD_COMPILE_REPAIR] deterministic.applied
[METHOD_COMPILE_REPAIR] deterministic.progress
```

When an LLM candidate is structurally invalid or worsens compilation, expect:

```text
[METHOD_COMPILE_REPAIR] structure.rollback
```

or:

```text
[METHOD_COMPILE_REPAIR] candidate.rollback
```

The next attempt must show the pre-candidate error count and must not continue from the damaged 32-error class.

## 8. Re-run with full-suite coverage validation

```bat
python -m junitforge --repo-path "C:\Users\xsglfdua\git\gi-qnb-billpayment" --only PaymentServiceImpl.java --limit 1 --overwrite --coverage --llm-audit --verbose
```

Coverage remains valid only after the complete generated test class compiles and executes with more than zero tests, zero failures, zero errors, matching source hashes, and fresh JaCoCo output.

## 9. CLI smoke check

```bash
python -m junitforge --help
```

## 10. Archive integrity

```bash
unzip -t llm-junit-assist-v7.3.3.zip
unzip -t llm-junit-assist-v7.3.3-changed-files.zip
```

## 11. SHA-256

Linux/macOS:

```bash
sha256sum llm-junit-assist-v7.3.3.zip
sha256sum llm-junit-assist-v7.3.3-changed-files.zip
```

Windows PowerShell:

```powershell
Get-FileHash .\llm-junit-assist-v7.3.3.zip -Algorithm SHA256
Get-FileHash .\llm-junit-assist-v7.3.3-changed-files.zip -Algorithm SHA256
```
