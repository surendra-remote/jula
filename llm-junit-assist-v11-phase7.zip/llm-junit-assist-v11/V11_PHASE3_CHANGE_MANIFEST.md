# llm-junit-assist v11 Phase 3 Change Manifest

## Scope

Phase 3 implements complete, bounded, compiled baseline fixture graphs from the existing authoritative schema catalogue and deterministic fixture emitter. Phase 1 registry/state/history behavior and Phase 2 collaborator/Spring Data contracts remain unchanged. No fixture variants, compile-repair changes, runtime-repair changes, coverage changes, or Phase 4 behavior were added.

## Changed files and responsibilities

| File | Responsibility |
|---|---|
| `junitforge/__init__.py` | Updates package identity to `11.0-phase3` and documents the preserved Phase 1/2 foundation plus Phase 3 fixture scope. |
| `junitforge/timing.py` | Aligns timing/audit version metadata with `11.0-phase3`. |
| `junitforge/execution/models.py` | Extends the existing fixture catalogue with explicit support state, compile state, direct/transitive dependencies, relationship paths, scalar/relationship guarantees, minimum sizes, identity guarantees, blocking reasons, and cycle decisions. |
| `junitforge/execution/payload_schema.py` | Propagates required dereference paths recursively through nested schemas; permits source-required paths beyond the ordinary depth bound; detects indexed, streamed, iterated, mutated, enhanced-loop, and unsafe wrapper access; distinguishes wrapper presence from collection cardinality. |
| `junitforge/execution/fixture_builder_emitter.py` | Reworks the existing deterministic emitter to build bounded child-first fixture graphs, honour minimum collection sizes, emit compatible non-null elements, record dependency and identity guarantees, terminate cycles explicitly, fail closed for unresolved required state, validate catalogue/source agreement, and leave emitted fixtures uncompiled until skeleton validation. |
| `junitforge/execution/renderer.py` | Restricts verified fixture contracts to fully supported, semantically valid, skeleton-compiled fixtures; serializes the expanded authoritative fixture catalogue. |
| `junitforge/generation/skeleton_generator.py` | Feeds the existing skeleton compilation result back into the authoritative fixture catalogue as `compiled` or `failed` before method generation. |
| `junitforge/generation/method_generator.py` | Persists the post-skeleton compiled fixture catalogue before any per-method LLM generation; report-write failure remains non-fatal. |
| `junitforge/generation/payloads/serviceimpl.py` | Emits only method-relevant compiled fixture contracts and only the approved compact facts: method name, application type, guaranteed scalar/nested state, minimum sizes, identity guarantees, support status, and compile status. No fixture source or complete catalogue is sent. |
| `junitforge/prompts/generation.py` | Applies the same supported/semantic/compiled exposure gate to the retained legacy fixture-contract rendering path. |
| `tests/test_v102_logging_audit.py` | Updates the package-version assertion to `11.0-phase3`; existing logging/audit checks are unchanged. |
| `tests/test_v11_phase3_fixture_graphs.py` | Adds 15 focused Phase 3 regressions for nested required graphs, collection cardinality/type/null safety, dependencies, identity, cycle handling, fail-closed unsupported children, wrapper safety, catalogue/source consistency, compile-state exposure, Java compilation, focused payloads, and instruction preservation. |
| `V11_PHASE3_PYTEST_OUTPUT.txt` | Captures the complete pytest result. |
| `V11_PHASE3_COMPILEALL_OUTPUT.txt` | Captures Python bytecode compilation validation. |
| `V11_PHASE3_IMPORT_SMOKE_OUTPUT.txt` | Captures package/version/model/prompt-fingerprint import smoke validation. |
| `V11_PHASE3_JAVA_FIXTURE_COMPILE_OUTPUT.txt` | Captures the synthetic Java fixture-graph `javac` compilation test. |
| `V11_PHASE3_VALIDATION_REPORT.md` | Summarizes implemented behavior, validation results, and explicit unsupported fixture conditions. |
| `V11_PHASE3_MODIFIED_FILES.txt` | Provides the exact machine-readable changed-file list. |

## ServiceImpl general_instructions preservation

- The existing permanent `generation_instruction` structure remains byte-semantically unchanged.
- Permanent clauses replaced: **none**.
- Permanent replacement text: **none**.
- Replacement reasons: **not applicable**.
- Permanent clauses added: **none**; the existing instructions already contain object-identity, fixture-use, dereference-safety, collection-cardinality, and fail-closed path-selection rules.
- The preserved SHA-256 fingerprint remains `929e6c195c2814c1e921d2568cfb2ad0d23974176493d37f42d5c9830fae3f93`.
- Fixture method facts and guarantees are emitted only in the dynamic `fixtures` section for the selected method.
- Complete fixture catalogues, unsupported fixtures, partial fixtures, uncompiled fixtures, and fixture Java source are not placed in permanent instructions or method-generation payloads.

## Explicitly unchanged

- Phase 1 authoritative registry, stable test identity, source lifecycle, state transitions, accepted-source semantics, rollback, and append-only history.
- Phase 2 recursive repository generic resolution, inherited Spring Data contracts, return-flow semantics, collaborator payloads, and stubbing classification.
- Scenario-specific fixture variants.
- Compile-repair and runtime-repair algorithms.
- Coverage execution, parsing, augmentation, and thresholds.
- Unrelated DTO/entity/controller generation behavior.
