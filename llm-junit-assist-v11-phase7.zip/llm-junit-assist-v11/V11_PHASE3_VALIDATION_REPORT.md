# llm-junit-assist v11 Phase 3 Validation Report

## Result

**PASS**

Phase 3 extends the existing schema and fixture pipeline; it does not introduce a second fixture framework. Required baseline object graphs now fail closed unless their source, semantic guarantees, support status, and skeleton compilation state are authoritative.

## Implemented behavior

### Recursive required schema propagation

- `baseline_required` and source-derived dereference requirements propagate through every nested property in the path.
- Explicitly required paths may continue beyond the ordinary configured schema depth while remaining bounded by the existing type limit and cycle controls.
- Indexed collection access records `index + 1` cardinality.
- Streams, parallel streams, `iterator().next()`, enhanced loops, and collection mutation establish non-null/populated baseline requirements.
- Unsafe no-argument wrapper `get()` marks the wrapper value required without incorrectly reporting a collection minimum.

### Complete deterministic baseline graphs

- Required child objects are constructed through their stable deterministic fixture methods.
- Required collections contain at least the authoritative minimum number of compatible, non-null elements.
- Mutable implementations are emitted for baseline lists, sets, and maps where mutation may occur.
- Nested fixture methods are emitted child-first and called by the parent source.
- Scalar, nested relationship, collection-size, and identity guarantees are recorded in the same fixture catalogue entry as the emitted source.

### Dependencies and identity

- Every fixture records direct dependency IDs and relationship paths.
- Transitive dependency IDs and nested guarantees are calculated without recursive loops.
- Identity guarantees identify the exact nested/collection element instance attached to the parent baseline.
- The preserved permanent ServiceImpl rule requires reuse of the same logical instance when it is attached, returned by a collaborator, passed through helpers, persisted, verified, or dereferenced later.

### Cycle handling

- Cycle analysis records `preserve-forward-edge` and `omit-reverse-edge` decisions.
- The first safe forward relationship is retained.
- Only the active-path reverse edge that would recurse is omitted.
- Omitted edges and reasons are present in catalogue diagnostics.
- If production requirements explicitly dereference the omitted reverse edge, the affected fixture becomes partial and its parent fails closed rather than claiming full support.

### Support, semantic, and compile gates

- Fixture support is explicit: `supported`, `partial`, or `unsupported`.
- Fixture compile state is explicit: `not-compiled`, `compiled`, or `failed`.
- New emitted fixture source starts as `not-compiled`.
- Existing skeleton compilation remains authoritative; no independent compiler was added.
- Successful skeleton compilation marks supported semantic fixtures `compiled` before method generation.
- Failed skeleton compilation marks them `failed` and prevents exposure.
- Semantic validation checks stable method declaration, dependency presence/support, dependency calls, scalar guarantees, and omitted cycle edges before exposure.

### Focused prompt integration

For the selected method, the dynamic `fixtures` section contains only relevant exposed fixtures and only:

- fixture method name;
- application type;
- guaranteed scalar state;
- guaranteed nested relationships;
- required/baseline collection minimum sizes;
- identity guarantees;
- support status;
- compiled status.

Unsupported, partial, semantically invalid, failed, uncompiled, unrelated fixtures and fixture Java source are excluded. The permanent ServiceImpl `general_instructions` fingerprint is unchanged and appears once through the existing payload structure.

## Validation commands and results

| Validation | Command | Result |
|---|---|---|
| Complete test suite | `python -m pytest -q` | **258 passed**, 5 pre-existing `TestKind` collection warnings |
| Phase 3 focused regressions | included in complete suite (`tests/test_v11_phase3_fixture_graphs.py`) | **15 passed** |
| Python bytecode compilation | `python -m compileall -q junitforge tests` | **PASS**, exit code 0 |
| Import/version/model smoke | package plus fixture schema/emitter/status/prompt imports | **PASS**, version `11.0-phase3` |
| Prompt-preservation smoke | canonical permanent-instruction SHA-256 | **PASS** |
| Synthetic Java fixture compilation | focused pytest invoking `javac` on emitted nested collection graph | **PASS**, 1 passed |

The complete raw outputs are retained in the four `V11_PHASE3_*_OUTPUT.txt` files.

## Explicit unsupported fixture conditions

A fixture is not exposed when any of these conditions applies:

1. The application schema or required child type cannot be resolved authoritatively.
2. The schema construction mechanism is unsupported or incomplete.
3. The schema is an enum; verified enum constants are used directly instead of emitting an object fixture method.
4. A required property has no verified constructor parameter, builder method, setter, or public field.
5. A required child fixture is missing, partial, unsupported, or semantically invalid.
6. A required collection element type cannot be resolved or produces a null/incompatible value.
7. A required object `Set` needs multiple elements but uniqueness under application equality cannot be guaranteed.
8. A required enum `Set` cardinality exceeds the number of verified distinct enum constants.
9. A required map has no authoritative literal-key/entry schema, or a required nested map value/collection element cannot be built.
10. A required `Optional`, response body, future/reactive wrapper value cannot be constructed without an empty/null payload.
11. A required reverse cycle edge is the edge that must be omitted to prevent recursion.
12. Catalogue dependencies or guaranteed source expressions do not match emitted Java source during semantic validation.
13. The existing skeleton compilation fails; otherwise supported fixtures are marked `failed` and remain unexposed.
14. Existing bounded schema type/depth/cycle resolution cannot establish the required state safely.

In all such cases, the blocking reason remains in fixture diagnostics. A null, empty collection, or missing edge is not emitted while the fixture claims full support.

## Validation boundary

Validation covered the complete Python suite and a synthetic Java `javac` harness. It did not execute a customer Maven/Ant repository, live LLM call, compile repair, runtime repair, coverage augmentation, scenario-specific fixture variants, or Phase 4 behavior.
