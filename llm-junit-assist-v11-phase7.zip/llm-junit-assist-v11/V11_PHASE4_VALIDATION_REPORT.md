# llm-junit-assist v11 Phase 4 Validation Report

## Result

**PASS**

Phase 4 extends the existing ServiceImpl method-generation path with a contract-indexed semantic gate and extends the existing compiled fixture catalogue with scenario variants. Known source-backed semantic defects are rejected or corrected before temporary class assembly. Fixture-supported application objects can no longer be constructed or mutated inside retained `@Test` methods.

## Implemented behavior

### Pre-assembly semantic gate

Every ServiceImpl test first passes the existing structural checks and then the Phase 4 semantic validator. Diagnostics are structured and retained in `validation_diagnostics`; a test with any known semantic violation cannot receive a valid state.

The gate covers:

- exact setter/getter/member/type contracts and Boolean getter conventions;
- collaborator method existence, resolved void/non-void state, unresolved-contract safety, matcher consistency, and authorised Mockito APIs;
- scalar, character, `BigDecimal`, collection-family, generic-element, nested application-type, and enum compatibility;
- private CUT configuration fields and production-local identifiers unavailable in test scope;
- invented application types and unknown fields/properties;
- JUnit Jupiter-only assertions;
- fixture-supported constructors, builders, setters, direct assignment, reflection mutation, mocks/spies as data objects, and manual graph construction.

Normal standard Java values remain legal for arguments, collaborator returns, verifications, and assertions.

### Deterministic correction and history

Only authoritative, unambiguous corrections are applied. Supported corrections include:

- removal of normal `thenReturn(...)` stubbing on resolved void methods;
- authoritative getter correction;
- `Mockito.when(...)`/`Mockito.any(...)` static normalization;
- primitive matcher normalization such as `any(char.class)` to `anyChar()`;
- verified one-character string literal to character literal;
- verified numeric literal to `BigDecimal.valueOf(...)`;
- `List.of(...)` to `Set.of(...)` where the exact setter contract requires `Set`;
- verified private configuration identifier replacement;
- single-authoritative enum correction;
- removal of an unknown setter only when source proves it is unrelated to the selected path;
- supported simple AssertJ normalization to JUnit Jupiter.

Each change appends a structured record containing sequence, UTC timestamp, diagnostic category, complete source before/after, authoritative contract, and result. Prior history is not cleared.

### Fixture-only setup and scenario variants

When a retained test needs state beyond the baseline fixture:

1. the mutation sequence is identified for one fixture-supported variable;
2. its setter contracts and values are validated;
3. helper-scope references are replaced only with verified compiled fixture calls, verified configuration values, or source-proven constants;
4. state is normalized and deduplicated by application type plus state signature;
5. an existing compatible compiled variant is reused when present;
6. otherwise exactly one deterministic variant is generated;
7. that one helper is inserted and compiled transactionally;
8. the catalogue is updated only after successful compilation;
9. the test is rewritten to call the compiled variant directly;
10. semantic validation is rerun.

A failed variant is not published and does not contaminate unrelated variants or tests. Contradictory state, unresolved scope, unknown contracts, unsafe graphs, failed semantic validation, failed helper compilation, or an invalid rewritten test rejects only the owning test/dependants.

### Source lifecycle

- The original LLM method is initialized in `generated_source` once and never overwritten.
- Deterministic correction, fixture substitution, or focused repair is staged in `candidate_source`.
- Generation-time semantic acceptance does not update `latest_accepted_source`.
- `compile_state` remains `NOT_RUN` after semantic validation.
- Candidate promotion remains reserved for the existing compilation acceptance gate and later Phase 5 work.

### Focused generation repair

When deterministic correction and the one fixture-augmentation attempt are insufficient, the generator may send one invalid raw `@Test` method with only its relevant diagnostics and contracts. Exactly one corrected method with the same identity is required. The complete test class is never sent for this generation-time repair. The repaired method is structurally and semantically revalidated once; otherwise it is rejected.

### Prompt composition

The existing permanent ServiceImpl instructions remain authoritative except for the five required smallest-clause replacements. Two missing non-overlapping safeguards were appended once. Method-specific source, collaborator, fixture, type, enum, collection, scalar, constant, scenario, and diagnostic facts remain dynamic and focused.

The approved instruction fingerprint is:

`e0873b732e770b07bfa940ab1f17e5fb3925b5c4b6ec4053add41280ff37cb43`

## Validation commands and results

| Validation | Command | Result |
|---|---|---|
| Complete test suite | `python -m pytest -q` | **299 passed**, 5 pre-existing `TestKind` collection warnings |
| Focused Phase 4 semantic/variant suite | `python -m pytest -q tests/test_v11_phase4_semantic_variants.py` | **41 passed** |
| Synthetic fixture-variant Java compilation | `python -m pytest -q tests/test_v11_phase4_semantic_variants.py::test_synthetic_compiled_fixture_variant_java_source` | **1 passed**, `javac` successful |
| Python bytecode compilation | `python -m compileall -q junitforge tests` | **PASS**, exit code 0 |
| Import/version/API smoke | Phase 4 package and generation API imports | **PASS**, version `11.0-phase4` |
| Prompt fingerprint smoke | `validate_general_instructions_preserved()` | **PASS** |

Raw outputs are retained in the five `V11_PHASE4_*_OUTPUT.txt` files.

## Required test coverage mapping

The focused suite covers all requested areas, including:

- resolved void stubbing, non-void save behavior, and unresolved methods;
- getter/Boolean conventions;
- Mockito qualification and matcher consistency;
- character, integer, `BigDecimal`, string, collection-family, generic-element, enum, setter/getter/member, nested-type, and invented-type defects;
- private CUT and production-local identifiers;
- forbidden assertion frameworks;
- fixture constructors, setters, builders, reflection, mocks/spies, local capture, and constant scope;
- variant deduplication, one bounded augmentation, and transactional isolation;
- generated/candidate/accepted source lifecycle;
- mutation-free accepted tests;
- focused payload selection and permanent/dynamic deduplication;
- minimal instruction replacement and preservation of non-conflicting rules;
- synthetic Java compilation of a generated scenario fixture variant.

## Exact general-instruction replacements

The exact five before/after clauses and reasons are recorded in `V11_PHASE4_CHANGE_MANIFEST.md`. No other permanent clause was removed, reordered, shortened, or broadly rewritten.

## Explicit unsupported semantic cases

Phase 4 fails closed for these cases rather than guessing:

1. Ambiguous Java overload resolution not already resolved by authoritative collaborator/schema contracts.
2. Arbitrary interprocedural value-flow or dynamic runtime-derived fixture state that cannot be represented as a bounded verified setter sequence.
3. Fixture mutations expressed through unsupported fluent APIs, arbitrary lambdas, custom reflection utilities, or unknown factories.
4. Parameterized fixture-helper generation; Phase 4 uses zero-argument compiled variants and rejects unresolved helper-scope values.
5. Automatic semantic/domain naming such as `validMotorPendingGiPolicyEntity` when no such fixture exists; newly generated variants use a deterministic type-plus-state-signature name.
6. Direct-field application-object mutation augmentation; it is detected and rejected rather than converted without an authoritative setter/construction contract.
7. Multiple unrelated fixture-supported objects requiring coordinated new variants in one invalid test; the attempt is intentionally bounded to one owning mutation sequence.
8. Contradictory repeated assignments to one fixture property.
9. Required collection/map/nested graph state that cannot be bounded safely using existing compiled fixture methods and verified contracts.
10. Unknown or ambiguous enum values, constants, members, setters, getters, nested types, or generic element types.
11. Complex AssertJ/Hamcrest/Truth chains without an unambiguous JUnit Jupiter equivalent.
12. A test whose rewritten fixture state no longer demonstrably satisfies the selected source path.
13. Customer-repository-specific compiler behavior not represented by the synthetic Java harness.

## Validation boundary

Validation used the complete Python suite, focused semantic tests, import/compileall checks, and a synthetic Java `javac` harness. It did not invoke a live LLM, run a customer Maven/Ant repository, redesign the compile-repair or runtime-repair loops, run JaCoCo, or implement Phase 5 source-promotion orchestration.
