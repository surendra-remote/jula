# llm-junit-assist v11 Phase 2 Change Manifest

## Scope

Phase 2 implements authoritative collaborator contracts, recursive Spring Data generic binding, inherited Spring Data method contracts, and separate return-consumption metadata. Phase 1 registry, source lifecycle, state, and append-only history behavior remain unchanged. No fixture-graph, fixture-variant, compile-repair, runtime-repair, or Phase 3 work was added.

## Changed files and responsibilities

| File | Responsibility |
|---|---|
| `junitforge/__init__.py` | Updates the package version to `11.0-phase2`. |
| `junitforge/timing.py` | Aligns timing/audit version metadata with `11.0-phase2`. |
| `junitforge/parser/java_symbols.py` | Preserves interface type parameters, generic parent declarations, and multiple interface parents in both javalang and fallback parsing. |
| `junitforge/execution/models.py` | Adds explicit collaborator contract state helpers, repository entity/ID metadata, canonical return-consumption kinds, return-flow resolution status, invocation expressions, and normal-stubbing classification. |
| `junitforge/execution/dependencies.py` | Implements recursive repository generic resolution through custom and intermediate interfaces; resolves exact inherited Spring Data contracts for the approved methods; preserves null unresolved return types and explicit status. |
| `junitforge/execution/analyzer.py` | Separates collaborator contract resolution from return-flow analysis; classifies assigned, dereferenced, branch, Optional, stream, passed-to-call, ignored, and unresolved flows; propagates helper-return consumption interprocedurally. |
| `junitforge/execution/stub_planner.py` | Uses exact resolved void/non-void state and return-flow status; exposes required/optional/unnecessary/forbidden/unresolved normal-stubbing semantics; fails closed on unresolved contracts. |
| `junitforge/execution/assembly.py` | Removes unresolved-as-void fallbacks from deterministic repair and validation; prevents speculative stubbing; emits `UNRESOLVED_COLLABORATOR_CONTRACT` where required. |
| `junitforge/execution/renderer.py` | Adds contract status, return-flow status, consumption kind, invocation expression, and stubbing requirement to diagnostics. |
| `junitforge/generation/payloads/serviceimpl.py` | Emits only reachable method-specific collaborator contracts with exact nullable return types, resolution status, repository bindings, consumption metadata, and stubbing requirement. Adds an immutable Phase 1 instruction fingerprint check. |
| `tests/test_v102_logging_audit.py` | Updates the version assertion to `11.0-phase2`; all original audit assertions remain. |
| `tests/test_v11_phase2_collaborator_contracts.py` | Adds Phase 2 regression coverage for recursive repository inheritance, exact contracts, all requested return-flow states, fail-closed validation, focused payloads, null return preservation, and prompt integrity. |
| `V11_PHASE2_PYTEST_OUTPUT.txt` | Captures the complete pytest result. |
| `V11_PHASE2_COMPILEALL_OUTPUT.txt` | Captures compileall validation. |
| `V11_PHASE2_IMPORT_SMOKE_OUTPUT.txt` | Captures import/version/prompt-fingerprint smoke validation. |
| `V11_PHASE2_VALIDATION_REPORT.md` | Summarizes Phase 2 behavior, validation, and unresolved limitations. |
| `V11_PHASE2_MODIFIED_FILES.txt` | Machine-readable exact changed-file list. |

## ServiceImpl general_instructions preservation

- Phase 1 permanent `generation_instruction` content was not rewritten, shortened, reordered, or removed.
- Permanent clauses replaced: **none**.
- Permanent clauses added: **none**.
- Replacement reasons: **not applicable**.
- Phase 2 collaborator and return-flow facts are emitted only in the dynamic `collaborators` payload section.
- A SHA-256 fingerprint (`929e6c195c2814c1e921d2568cfb2ad0d23974176493d37f42d5c9830fae3f93`) guards the exact Phase 1 permanent instruction structure.

## Explicitly unchanged

- `07-class-assembly/registry.json` authority and Phase 1 registry schema.
- Stable test identity, source snapshots, accepted-source semantics, rollback semantics, and append-only history.
- Fixture graph generation and fixture variants.
- Compile repair and runtime repair algorithms.
- Coverage augmentation behavior.
- Unrelated DTO/entity/controller generation behavior.
