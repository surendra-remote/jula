# llm-junit-assist v11 Phase 1 Change Manifest

Baseline: original uploaded `llm-junit-assist v10.2` source.

## Changed production files

| File | Responsibility |
|---|---|
| `junitforge/__init__.py` | Identifies the project as v11 Phase 1 and describes the registry/state/history scope. |
| `junitforge/models.py` | Adds stable test identity, required source lifecycle fields, append-only evidence fields, explicit compile states, backward-compatible history coercion, and `generated_source` immutability. |
| `junitforge/registry.py` | New authoritative registry lifecycle module. Provides deterministic source hashing, atomic persistence, backward-compatible loading, structured/legacy history parsing, transactional candidate commit/rollback, compile transition validation, and persisted validation/runtime/disposition updates. |
| `junitforge/pipeline/result.py` | Routes assembled and repaired test-source synchronization through the central registry candidate/commit API; persists registry restoration. |
| `junitforge/pipeline/engine.py` | Binds each target outcome to the existing `07-class-assembly/registry.json` path and persists the authoritative registry through `RegistryStore`. |
| `junitforge/generation/method_generator.py` | Pre-registers method/test records and persists candidate creation, validation transitions, diagnostics, repair histories, rejection, and assembly outcomes without overwriting `generated_source`. |
| `junitforge/compilation/deterministic_repairs.py` | Records deterministic compile candidates, actions, and compile states through the registry API. |
| `junitforge/compilation/repair_coordinator.py` | Records initial compile attempts/diagnostics and accepted compile-repair candidates through central registry operations. |
| `junitforge/compilation/salvage.py` | Persists individual compile rejection state and diagnostics without bypassing registry lifecycle functions. |
| `junitforge/runtime/state.py` | Persists per-test runtime state/diagnostics and retained-test compile transitions through `RegistryStore`. |
| `junitforge/runtime/repair_coordinator.py` | Changes per-test runtime repair attempts from a mutable counter to append-only structured attempt/history entries. |
| `junitforge/publication/summary.py` | Uses one shared history-action parser for both structured dictionary and legacy string entries. |

## Changed test files

| File | Responsibility |
|---|---|
| `tests/test_v102_logging_audit.py` | Updates the asserted tool version to `11.0-phase1`. |
| `tests/test_v11_phase1_registry.py` | Adds the 15 required Phase 1 registry, lifecycle, persistence, compatibility, and import-cycle tests. |

## Validation artifacts

| File | Responsibility |
|---|---|
| `V11_PHASE1_PYTEST_OUTPUT.txt` | Complete final pytest output. |
| `V11_PHASE1_COMPILEALL_OUTPUT.txt` | Python compileall result. |
| `V11_PHASE1_IMPORT_SMOKE_OUTPUT.txt` | Main-package import smoke-test result. |
| `V11_PHASE1_VALIDATION_REPORT.md` | Concise final Phase 1 validation report. |
