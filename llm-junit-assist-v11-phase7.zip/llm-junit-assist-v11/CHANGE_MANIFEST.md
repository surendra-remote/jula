# CHANGE MANIFEST

## Release

`llm-junit-assist v7.3.3 — Compile-Repair Rollback and Deterministic Diagnostics Hotfix`

This corrective release is built on v7.3.2. It preserves the v7.3 per-test salvage design and the v7.3.1/v7.3.2 record-boundary fixes while correcting the compile-repair behavior observed in the supplied `PaymentServiceImpl` log.

## Observed failure

The initial generated class had 27 compiler errors distributed across four production-method owners. The first LLM repair targeted one test in `revertPaymentStatusToQuoteAfterCancelPayment(String)`. The candidate was accepted before compilation proved improvement. Its compilation result worsened:

```text
owner_errors_before=10
owner_errors_after=32
total_before=27
total_after=32
diagnostics_changed=True
materially_improved=True
```

The candidate inserted an invalid class boundary, leaving sibling `@Test` methods outside `PaymentServiceImplTest`. Subsequent attempts repaired the already-corrupted source instead of the last valid snapshot.

## Root causes

1. `diagnostics_changed=True` was treated as material progress even when error counts increased.
2. A failed candidate was written into `current` before its compile result was accepted.
3. No rollback restored the previous Java source after a worsening candidate.
4. Test-name preservation checked only names, not whether tests remained direct members of the test class.
5. Sibling test source was not protected from compile-repair finalization changes.
6. `replace_method_block()` reapplied class indentation on every repair, producing indentation drift and false sibling-source changes.
7. Repeated compiler-fact corrections were sent to the LLM instead of being repaired deterministically across all affected tests.

## Corrected behavior

### Strict compile-candidate acceptance

A still-failing compile-repair candidate is retained only when all conditions hold:

- source changed;
- selected test compiler-error count decreased;
- total compiler-error count strictly decreased;
- selected owner error count did not increase;
- no unaffected owner gained compiler errors;
- unmapped/header compiler errors did not increase;
- all tests remain structurally inside the selected test class;
- sibling test names and sibling source remain unchanged.

A changed diagnostic signature by itself is never progress.

### Transactional rollback

Before every header, deterministic, or LLM compile-repair candidate, the engine captures the current source and compiler diagnostics. A rejected or worsening candidate is rolled back on disk and in memory. Later attempts and per-test salvage therefore operate on the last accepted snapshot, not damaged Java.

Repair-history and compile-state metadata are committed only after the candidate compiles or passes the strict improvement gate. Rolled-back candidates do not appear as accepted repairs.

### Test-class structural gate

Compile repair now verifies that:

- the expected test class declaration exists;
- its braces are balanced;
- every `@Test` is extractable as one balanced method;
- every test lies inside the test class body;
- every test is a direct class member rather than outside or nested accidentally.

### Deterministic compiler-diagnostic repairs

Before any LLM compile repair, v7.3.3 processes every affected individual test and applies only source-backed corrections:

1. **Wrong verified accessor**
   - Example: `isPaymentStatus()` on `ProcessPaymentResponseData` becomes the unique verified getter such as `getPaymentStatus()`.

2. **Wrong collaborator receiver**
   - Example: `giBillRepository.findByGiPolicyEntityAndStatus(...)` is changed to the unique injected dependency field that owns the verified method contract.

3. **Duplicated getter/setter chain**
   - Example: `product.getResultPremium().setResultPremium(value)` becomes `product.setResultPremium(value)` when javac proves the intermediate receiver is the value type.

4. **Missing selected-method argument local**
   - Example: an undeclared `quotationNumber` used as the verified `String` parameter to the selected CUT method receives a deterministic local declaration.

The deterministic pass repairs all affected tests in one batch and recompiles before using the LLM.

### Idempotent owner-block assembly

`replace_method_block()` now dedents an extracted owner block before restoring class-member indentation. Repeated repairs no longer shift sibling tests farther right or create false sibling modifications.

## Modified files relative to v7.3.2

| File | Purpose |
|---|---|
| `junitforge/__init__.py` | Updates package metadata and version to `7.3.3`. |
| `junitforge/execution/assembly.py` | Adds test-class structural validation, compiler-driven deterministic repairs, missing-local inference, verified accessor/receiver corrections, chained-setter collapse, and idempotent owner-block indentation. |
| `junitforge/loop.py` | Adds deterministic compile-repair batching, strict progress evaluation, transactional rollback, sibling-source protection, and deferred repair-history commit. |
| `tests/test_v73_generation_recovery.py` | Adds eight regressions for the supplied repair failure and deterministic compiler corrections. |
| `CHANGE_MANIFEST.md` | Documents the root causes, behavior changes, preserved behavior, and inventory. |
| `VALIDATION_REPORT.md` | Records v7.3.3 commands, counts, environment, and limitations. |
| `RUN_COMMANDS.md` | Records validation and enterprise rerun commands. |

## Added files

None.

## Deleted files

None.

## Preserved behavior

- v7.3 per-test validation salvage and partial owner retention.
- v7.3.1 `ExtractedTestMethod.source` boundary correction.
- v7.3.2 owner-level `MethodGenerationRecord.method_id` compile-salvage correction.
- Fixture substitution and scenario-specific overrides.
- Same-class real execution and injected `IService` collaborator treatment.
- Reachable-helper return-consumption propagation.
- Mockito return-type and checked-exception repair rules.
- Unknown-member individual-test isolation.
- Runtime test identity/count protection.
- Full-class authoritative runtime reporting.
- Coverage freshness and source-hash gates.
- Windows-safe runtime-log behavior.
- CLI, Maven, and Ant compatibility.

## Deferred scope

This release does not redesign generation, implement unrestricted compiler-error synthesis, or infer ambiguous application contracts. Enterprise-specific behavior still requires execution against the private repository and its Maven classpath.

---

## Behaviour-preserving loop.py restructuring

Date: 2026-08-05

The v7.3.3 generation engine was structurally refactored without changing its generation, validation, compile-repair, runtime-repair, coverage, augmentation, logging, or audit semantics.

### Main changes

- Reduced `junitforge/loop.py` from 3,176 lines to a 52-line compatibility facade.
- Retained `Engine(...)` and `Engine.run_target(...)` for CLI, tests, and direct callers.
- Moved orchestration into `junitforge/pipeline/`.
- Moved method-wise and class-wide generation into `junitforge/generation/`.
- Extracted the nested `generate_one(...)` function into a named testable method.
- Moved compile diagnostics, deterministic repair, focused repair, candidate validation, and salvage into `junitforge/compilation/`.
- Moved runtime parsing, repair, acceptance, state recording, and execution boundaries into `junitforge/runtime/`.
- Moved coverage coordination and augmentation into `junitforge/coverage/`.
- Moved restoration, failing-source publication, and generation counter refresh into `junitforge/publication/`.
- Added target-specific payload builders for ServiceImpl, controller, DTO/entity, and other Java targets.
- Preserved the original v7.3.3 prompt functions behind stage-specific payload-builder adapters.
- Added `RESTRUCTURING_REPORT.md` with a responsibility and migration record for every original `loop.py` function.

### Compatibility

- Existing CLI construction and execution remain unchanged.
- Existing private `Engine` methods remain callable through inherited mixins.
- Existing top-level `loop.py` helper imports used by tests remain re-exported.
- Existing coverage, report, and summary public modules remain available.
- Existing logger category `junitforge.loop` remains preserved.

No intentional behavioural changes were introduced.
