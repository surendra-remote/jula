# llm-junit-assist v11 Phase 2 Validation Report

## Result

**PASS**

Phase 2 adds deterministic collaborator and Spring Data contract resolution without introducing a parallel framework. Existing Phase 1 behavior remains covered by the complete pre-existing suite.

## Implemented behavior

### Repository generic resolution

- Resolves direct `JpaRepository<Entity, Id>` and `CrudRepository<Entity, Id>` declarations even when external Spring source symbols are unavailable.
- Resolves custom repository interfaces through intermediate generic parents and multiple inheritance levels.
- Carries entity and ID substitutions across inherited type variables.
- Preserves partial/unresolved status when a parent symbol, binding, or generic argument is unavailable or conflicting.

### Inherited Spring Data contracts

Exact contracts are provided for:

- `save`
- `saveAndFlush`
- `saveAll`
- `findById`
- `findAll`
- `count`
- `existsById`
- `delete`
- `deleteById`
- `flush`

JPA/List repository contracts preserve `List<Entity>` returns; `CrudRepository` contracts preserve `Iterable<Entity>` returns. JPA-only methods requested from a Crud-only repository remain null/partial rather than being converted to void.

### Contract and return-flow state

The implementation keeps these states distinct:

1. resolved void;
2. resolved non-void, consumed;
3. resolved non-void, ignored;
4. unresolved/partial contract.

Return-flow metadata is separate from the method contract and records caller method, invocation expression, assignment target, consumption kind, consumption status, and normal-stubbing requirement.

### Interprocedural consumption

The analyzer classifies and propagates:

- ignored results;
- assigned and later read results;
- dereferences;
- branch-tested results;
- values passed to another call;
- values returned from helpers or targets;
- Optional flows;
- stream flows;
- unresolved flows.

Unresolved flow is never reclassified as ignored.

### Payload, validation, and diagnostics

- Method-generation payloads contain only collaborator methods reachable from the selected target/helper closure.
- Null unresolved return types remain JSON `null`.
- Exact contract and flow resolution states are included.
- Normal stubbing is classified as `required`, `optional`, `unnecessary`, `forbidden`, or `unresolved`.
- Semantic validation and assembly no longer infer void from missing return types.
- Required unresolved contracts produce `UNRESOLVED_COLLABORATOR_CONTRACT`.
- Diagnostics expose repository bindings, contract status, flow status, consumption kind, and stubbing semantics.

### Permanent prompt preservation

The Phase 1 ServiceImpl permanent instruction structure is byte-semantically guarded by a canonical JSON SHA-256 fingerprint. No Phase 2 catalogue or method-specific contract data was added to permanent instructions.

## Validation commands and results

| Validation | Command | Result |
|---|---|---|
| Complete test suite | `python -m pytest -q` | **243 passed**, 5 pre-existing collection warnings |
| Python bytecode compilation | `python -m compileall -q junitforge tests` | **PASS** |
| Import smoke | imports of package, parser, execution, payload, and pipeline modules | **PASS** |
| Version smoke | `junitforge.__version__` | `11.0-phase2` |
| Prompt-preservation smoke | Phase 1 instruction fingerprint | **PASS** |
| Forbidden fallback scan | no `contract.return_type or "void"`; no empty/null-as-void predicate | **PASS** |

## Unresolved limitations

1. Recursive custom-parent resolution remains source/symbol dependent. If an intermediate application repository interface cannot be resolved, the contract remains partial or unresolved and fails closed.
2. Return-flow analysis is bounded static source analysis. Reflection, runtime proxies, highly dynamic dispatch, complex aliasing, or unsupported callback shapes may remain unresolved.
3. The inherited contract table is intentionally limited to the methods required by Phase 2. Pageable, Sort, Specification, query-by-example, and custom Spring Data extension methods were not added.
4. Conflicting entity/ID bindings reached through multiple repository inheritance paths remain partial rather than selecting one speculatively.
5. Validation was performed against the Python project suite and synthetic Java source facts. No customer repository, Maven build, live IBM model call, compile repair, runtime repair, or Phase 3 fixture behavior was executed in this phase.
