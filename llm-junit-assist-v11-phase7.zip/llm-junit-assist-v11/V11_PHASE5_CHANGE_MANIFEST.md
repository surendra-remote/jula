# llm-junit-assist v11 Phase 5 Change Manifest

## Scope

Phase 5 replaces ordinary ServiceImpl complete-class LLM compile repair with registry-driven, diagnostic-owned, transactional per-test repair. It preserves the Phase 1 authoritative registry and source lifecycle, Phase 2 collaborator contracts, Phase 3 compiled fixture catalogue, and Phase 4 structural/semantic generation validation. It does not add runtime repair behavior or a parallel registry/compiler/repair framework.

## Changed files and responsibilities

| File | Responsibility |
|---|---|
| `junitforge/__init__.py` | Updates package identity to `11.0-phase5`. |
| `junitforge/timing.py` | Aligns persisted timing-event version metadata with `11.0-phase5`. |
| `junitforge/models.py` | Extends compiler diagnostics with a category and extends `TargetOutcome` with append-only compile history, persisted source hash/ranges, diagnostic buckets, and repair-attempt counters. |
| `junitforge/registry.py` | Persists the enriched authoritative registry document, recalculates exact test/fixture/skeleton/import/class/assembly ranges, persists the assembled-source hash, and adds candidate discard support without creating a second registry. |
| `junitforge/compile_gate.py` | Preserves all parsed compiler errors, detail lines, raw text, columns, and normalized diagnostic categories. |
| `junitforge/compilation/__init__.py` | Exposes the Phase 5 diagnostic mapping, response normalization, hashing, and provider-metadata APIs. |
| `junitforge/compilation/diagnostic_mapper.py` | Implements exact inclusive range ownership by stable `test_id`, grouped test diagnostics, and separate fixture/skeleton/import-class/assembly/unmapped classifications with no nearest-test fallback. |
| `junitforge/compilation/provider_response.py` | Implements canonical request/response hashing, full focused-provider metadata, truncation state, and identical-rejected-response detection. |
| `junitforge/compilation/response_normalizer.py` | Implements strict one-method raw-Java/outer-fence normalization, identity enforcement, prose/type/import/multiple-method rejection, and probable-truncation classification. |
| `junitforge/compilation/repair_coordinator.py` | Recalculates/persists ranges before every compile candidate, routes ServiceImpl diagnostics to one registry-owned test transaction, performs bounded deterministic then one focused LLM repair, compiles each candidate once, commits only after compile success, rolls back failed candidates, removes rejected tests through explicit registry transitions, preserves append-only evidence, and disables complete-class ServiceImpl LLM repair in initial and Maven recovery paths. |
| `junitforge/generation/payloads/serviceimpl.py` | Replaces the obsolete complete-class ServiceImpl compile payload with one focused test payload, dynamically selects only directly relevant diagnostics/contracts/fixtures/constants/configuration/imports/APIs, preserves the baseline instructions once, and adds focused compile-repair rules once. |
| `junitforge/pipeline/engine.py` | Adds a full-provider-response LLM invocation path while retaining the existing text-only compatibility wrapper for unaffected stages. |
| `junitforge/pipeline/result.py` | Preserves `REPAIRED_AND_PASSED` during final accepted-source synchronization instead of attempting an invalid downgrade to `PASSED`. |
| `junitforge/vendor/llm/base.py` | Extends the vendor-neutral LLM response with response state and finish reason while retaining message, usage, tool calls, and raw response. |
| `junitforge/vendor/llm/watsonx.py` | Populates response state and finish reason from the complete Watsonx provider response. |
| `tests/test_loop_restructuring.py` | Replaces obsolete complete-class ServiceImpl payload assertions with focused registry-owned test assertions. |
| `tests/test_v101_serviceimpl_payload_workflow.py` | Updates legacy compile-repair payload regressions to the Phase 5 one-test contract. |
| `tests/test_v102_logging_audit.py` | Updates the version assertion to `11.0-phase5`; stage vocabulary remains unchanged. |
| `tests/test_v73_generation_recovery.py` | Updates legacy ServiceImpl compile-repair tests to use exact focused identity and owner-method context. |
| `tests/test_v11_phase5_focused_compile_repair.py` | Adds 31 Phase 5 regressions covering all required diagnostic, transaction, normalization, metadata, hashing, history, attempt-limit, payload-focus, and instruction-preservation behavior. |
| `V11_PHASE5_PYTEST_OUTPUT.txt` | Captures the complete pytest result. |
| `V11_PHASE5_FOCUSED_REPAIR_OUTPUT.txt` | Captures the complete focused Phase 5 suite. |
| `V11_PHASE5_DIAGNOSTIC_MAPPING_OUTPUT.txt` | Captures synthetic diagnostic parsing/ownership/classification tests. |
| `V11_PHASE5_FOCUSED_INTEGRATION_OUTPUT.txt` | Captures synthetic transactional focused compile-repair integration tests. |
| `V11_PHASE5_COMPILEALL_OUTPUT.txt` | Captures Python bytecode compilation validation. |
| `V11_PHASE5_IMPORT_SMOKE_OUTPUT.txt` | Captures package/version/API/prompt import smoke validation. |
| `V11_PHASE5_COMPLETE_CLASS_REPAIR_EVIDENCE.txt` | Records source and regression evidence that complete-class ServiceImpl LLM repair attempts equal zero. |
| `V11_PHASE5_TEST_RESULTS.txt` | Summarizes all required validation commands and results. |
| `V11_PHASE5_VALIDATION_REPORT.md` | Summarizes implemented behavior, validation evidence, limits, and explicit unverified behavior. |
| `V11_PHASE5_MODIFIED_FILES.txt` | Provides the exact machine-readable changed-file list. |

## ServiceImpl `general_instructions` preservation

The Phase 4 `_GENERATION_INSTRUCTION` object remains byte-for-byte unchanged and retains SHA-256:

`e0873b732e770b07bfa940ab1f17e5fb3925b5c4b6ec4053add41280ff37cb43`

The focused compile payload deep-copies that object exactly once. Only this directly conflicting copied clause is replaced for the focused compile-repair request:

### Replacement 1

**Before**

> `objective.requested_test_kind = normal_success`

**After**

> `objective.requested_test_kind = focused_compile_repair`

**Reason:** a compile-repair request corrects an existing registry-owned test; it is not a new normal-success generation request. The replacement is limited to the copied focused payload and does not mutate the permanent baseline.

## Approved non-duplicate focused additions

The focused payload includes `_COMPILE_REPAIR_INSTRUCTIONS` exactly once. It defines:

- one-attempt limit;
- exact test identity and one-method output;
- grouped-diagnostic scope;
- no sibling, fixture, setup, import, field, or class changes;
- compile-safe Mockito and Java constraints;
- no complete-class output.

Method-specific diagnostics, schema/type contracts, collaborator contracts, fixture contracts, constants, configuration values, imports, and authorised APIs remain in separate dynamic sections. Complete catalogues are not embedded in permanent instructions or focused payloads.

## Limits enforced

- Complete-class ServiceImpl LLM compile-repair attempts: **0**.
- Focused LLM compile-repair attempts per persisted `test_id`: **1**.
- Identical-response retries: **0**.
- Deterministic candidate compilations: **1 per candidate**.
- LLM candidate compilations: **1 per candidate**.
- Test ownership: exact persisted inclusive range only.
- Rejected test removal: explicit `REJECTED -> REMOVED` registry transition only.
