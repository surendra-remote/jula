# llm-junit-assist v11 Final Changed-File Manifest

## Comparison basis and honesty boundary

The final Phase 6 archive retains the Phase 1–6 change manifests that identify changes from the original v10.2 baseline. The original v10.2 source tree itself was **not** included in the Phase 6 archive, so a byte-for-byte final-tree diff against v10.2 is **NOT_VERIFIED**. The complete inventory below is reconstructed from the retained per-phase manifests, then checked against the final source responsibilities.

The Phase 7-to-Phase 6 comparison is exact: the uploaded Phase 6 archive was separately extracted and compared to the final working tree.

## Added production files since v10.2

| File | Responsibility |
|---|---|
| `junitforge/compilation/diagnostic_mapper.py` | Exact diagnostic range ownership, classification and per-test grouping. |
| `junitforge/compilation/provider_response.py` | Provider metadata, request/response hashes and duplicate-response evidence. |
| `junitforge/compilation/response_normalizer.py` | Strict one-method focused provider response normalization. |
| `junitforge/generation/fixture_variants.py` | Scenario-specific fixture variant normalization, bounded transactional compilation and reuse. |
| `junitforge/generation/semantic_validation.py` | Contract-indexed ServiceImpl semantic validation and deterministic source-backed correction. |
| `junitforge/registry.py` | Authoritative atomic registry persistence, immutable source lifecycle, transitions, history and range synchronization. |
| `junitforge/runtime/candidate_validator.py` | Runtime candidate identity, sibling, targeted/full execution and green-suite gates. |
| `junitforge/runtime/result_parser.py` | Stable registry test identity mapping for Surefire failures without line identity. |

## Modified production files since v10.2

| File | Responsibility |
|---|---|
| `junitforge/__init__.py` | Final package identity/version; updated throughout phases and finalized as 11.0.0. |
| `junitforge/cli.py` | Final audit-run status now distinguishes completed runs containing fatal target failures. |
| `junitforge/compilation/__init__.py` | Exports focused compilation ownership/normalization APIs. |
| `junitforge/compilation/deterministic_repairs.py` | Registry-owned deterministic compile candidates and actions. |
| `junitforge/compilation/repair_coordinator.py` | Transactional per-test compile repair; complete-class ServiceImpl repair disabled. |
| `junitforge/compilation/salvage.py` | Explicit rejection/removal and recompilation of remaining registry-owned tests. |
| `junitforge/compile_gate.py` | Complete compiler diagnostic parsing and compile boundary support. |
| `junitforge/execution/analyzer.py` | Interprocedural return-consumption and required schema/fixture context analysis. |
| `junitforge/execution/assembly.py` | Fail-closed semantic/contract assembly handling and registry-owned method blocks. |
| `junitforge/execution/dependencies.py` | Recursive repository generic resolution and exact inherited Spring Data contracts. |
| `junitforge/execution/fixture_builder_emitter.py` | Bounded child-first complete fixture graph emission, dependencies, guarantees and cycle handling. |
| `junitforge/execution/models.py` | Collaborator contracts, return-flow states, schemas, fixtures, guarantees, dependencies and compile/support states. |
| `junitforge/execution/payload_schema.py` | Recursive required-path and collection-minimum propagation. |
| `junitforge/execution/renderer.py` | Expanded contract/schema/fixture diagnostics and focused exposed fixture rendering. |
| `junitforge/execution/stub_planner.py` | Exact resolved/unresolved stubbing requirements without unresolved-as-void fallback. |
| `junitforge/generation/__init__.py` | Exports semantic/fixture-variant generation APIs. |
| `junitforge/generation/method_generator.py` | ServiceImpl method generation, validation/repair staging, registry initialization and fixture catalogue persistence. |
| `junitforge/generation/payloads/serviceimpl.py` | Focused method, generation-repair, compile-repair and runtime-repair payload composition with preserved instructions. |
| `junitforge/generation/skeleton_generator.py` | Skeleton preflight compilation and authoritative fixture compile/exposure state. |
| `junitforge/generation/validation.py` | Integrates structural and semantic generation validation. |
| `junitforge/loop.py` | Backward-compatible facade/exports for refactored Phase 6 runtime ownership. |
| `junitforge/models.py` | Registry test records, source lifecycle, contract/flow metadata, compile/runtime state and provider evidence models. |
| `junitforge/parser/java_symbols.py` | Preserves generic interface declarations/parents required for repository binding. |
| `junitforge/pipeline/engine.py` | Integrated target orchestration, registry binding, focused compile/runtime routes and evidence-based publication state. |
| `junitforge/pipeline/result.py` | Synchronizes accepted/repaired assembled sources through the authoritative registry. |
| `junitforge/prompts/generation.py` | Fixture reuse/identity guidance aligned with authoritative compiled graphs. |
| `junitforge/publication/publisher.py` | Restoration/failure snapshots and evidence-based strongest publishable source-state selection. |
| `junitforge/publication/summary.py` | Structured and legacy repair-history action parsing. |
| `junitforge/report.py` | Authoritative generated/retained/rejected/repaired/removed and repair/fixture-variant counters. |
| `junitforge/runtime/__init__.py` | Exports stable runtime ownership and transactional repair APIs. |
| `junitforge/runtime/repair_coordinator.py` | Single-test runtime transaction with one direct compile and no nested compile repair. |
| `junitforge/runtime/state.py` | Deep-copied authoritative runtime snapshots and per-test state recording. |
| `junitforge/summary.py` | Console summaries recognize compiled/threshold-met/prefixed compiled outcomes as successful. |
| `junitforge/timing.py` | Version-aligned low-noise timing/audit metadata; now uses package version as the single source of truth. |
| `junitforge/vendor/llm/base.py` | Vendor-neutral provider response state and finish-reason fields. |
| `junitforge/vendor/llm/watsonx.py` | Maps Watsonx complete response metadata into the vendor-neutral response. |

## Added test files since v10.2

| File | Responsibility |
|---|---|
| `tests/test_v11_phase1_registry.py` | Added Phase 1 registry/state/history regression suite. |
| `tests/test_v11_phase2_collaborator_contracts.py` | Added Phase 2 collaborator/Spring Data contract and flow suite; later prompt regressions retained. |
| `tests/test_v11_phase3_fixture_graphs.py` | Added Phase 3 fixture graph suite with real javac harness. |
| `tests/test_v11_phase4_semantic_variants.py` | Added Phase 4 semantic/variant suite with real javac variant harness. |
| `tests/test_v11_phase5_focused_compile_repair.py` | Added Phase 5 focused compile-repair suite. |
| `tests/test_v11_phase6_transactional_runtime_repair.py` | Added Phase 6 transactional runtime-repair suite. |
| `tests/test_v11_phase7_integrated_release.py` | Added connected release-gate workflow, prompt, reporting/publication, import and version regressions. |

## Modified pre-existing test files

| File | Responsibility |
|---|---|
| `tests/test_loop_restructuring.py` | Legacy payload expectations aligned with focused ServiceImpl compile repair. |
| `tests/test_v101_serviceimpl_payload_workflow.py` | Legacy ServiceImpl payload/runtime tests aligned with Phase 5/6 focused transactions. |
| `tests/test_v102_logging_audit.py` | Version assertions updated through phases and finalized at 11.0.0. |
| `tests/test_v721_runtime_repair_gate.py` | Legacy runtime gate updated for one direct compile and no nested repair. |
| `tests/test_v73_generation_recovery.py` | Legacy ServiceImpl compile-repair tests updated for exact test identity/owner context. |


## Removed files

**None reported by any Phase 1–6 manifest and none removed by Phase 7.**

## Exact Phase 7 code/test delta from the uploaded Phase 6 archive

### Modified

| File | Phase 7 responsibility |
|---|---|
| `junitforge/__init__.py` | Final version `11.0.0`. |
| `junitforge/timing.py` | Removes stale Phase 5 timing version and uses package version. |
| `junitforge/cli.py` | Records `completed_with_failures` when a fatal target outcome exists. |
| `junitforge/pipeline/engine.py` | Delegates publication qualification to evidence-based source-state selection. |
| `junitforge/publication/publisher.py` | Requires authoritative green full-run evidence before claiming runtime-green/coverage-accepted. |
| `junitforge/report.py` | Reports registry-derived generated/retained/rejected/repaired/removed counts, fixture variants, and compile/runtime repair attempts. |
| `junitforge/summary.py` | Treats compiled/threshold-met and detailed compiled statuses as successful outcomes. |
| `tests/test_v102_logging_audit.py` | Final version assertion. |

### Added

| File | Phase 7 responsibility |
|---|---|
| `tests/test_v11_phase7_integrated_release.py` | Connected synthetic workflow and final integration regressions. |
| `V11_PHASE7_*.txt` / `V11_PHASE7_*.md` | Release evidence, reports, matrix, flow, limitations and manifests. |

### Removed

None.

## Unrelated generator confirmation

No DTO, entity, enum, controller, or other unrelated class-wide generator algorithm was modified for Phase 7. Across v11, generation changes are confined to the existing ServiceImpl method-generation, validation, skeleton-fixture, and prompt paths required by Phases 1–6. `junitforge/prompts/generation.py` changed only to preserve compiled fixture identity/reuse rules; it did not redesign unrelated generators.
