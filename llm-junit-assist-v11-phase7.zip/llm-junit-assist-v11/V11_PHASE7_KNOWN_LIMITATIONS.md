# llm-junit-assist v11 Known Limitations and Unverified Items

## NOT_VERIFIED

1. **Enterprise/customer repository end-to-end run** — no enterprise Java repository was supplied.
2. **Real Maven execution** — Maven was not installed in the validation environment.
3. **Real Surefire/JaCoCo runtime-repair cycle** — runtime and coverage orchestration were validated with deterministic synthetic runner boundaries, not Maven/Surefire/JaCoCo.
4. **Live Watsonx/provider invocation** — focused generation/compile/runtime responses used deterministic fake clients; response metadata preservation is verified synthetically.
5. **Native Windows atomic replace semantics** — atomic persistence and simulated replacement failure passed on Linux; native Windows behavior was not separately executed.
6. **Byte-for-byte final comparison with original v10.2** — the original v10.2 source tree was not included in the Phase 6 archive. The changed-file inventory is reconstructed from retained Phase 1–6 manifests.
7. **External compiler diagnostic formats** — real `javac 21.0.10` fixture/test compilation passed, but no customer Maven compiler-plugin output was available beyond supported synthetic/parser tests.

## Intentionally fail-closed or bounded

- Unresolved/conflicting repository generics remain partial/unresolved; they are never guessed or treated as void.
- Dynamic/reflection-heavy return flow may remain unresolved.
- Required fixture graphs that cannot be constructed authoritatively remain partial/unsupported and unexposed.
- Ambiguous overloads, dynamic fixture state, unsupported fluent/lambda/reflection mutations, contradictory state, and unsafe collection uniqueness are rejected.
- Generation-time fixture augmentation is bounded to one owning mutation sequence and one transactional variant attempt.
- Focused compile LLM repair is bounded to one persisted attempt per test ID.
- Runtime repair is bounded by configured rounds/attempts and requires targeted plus complete-class acceptance.
- Non-test compiler diagnostics remain explicit; complete-class ServiceImpl LLM repair is deliberately disabled.

## Non-failing warnings

Five pre-existing pytest collection warnings arise because legacy tests import the `TestKind` enum under a `Test*` name. They do not skip or fail tests.
