from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import validate_method_block
from junitforge.execution.dependencies import (
    resolve_method_contract,
    resolve_repository_generic_binding,
)
from junitforge.execution.models import (
    DependencyInvocation,
    DependencyMethodContract,
    DependencyRef,
    ExecutionContext,
    ExecutionTargetKind,
    InvocationArgument,
    MethodExecutionContext,
    ResolutionStatus,
    ReturnConsumptionKind,
    StubbingRequirement,
)
from junitforge.generation.payloads import serviceimpl
from junitforge.models import (
    ClassSymbol,
    ClasspathProfile,
    GenerationContext,
    MethodSig,
    StackProfile,
    TemplateSpec,
    TestKind as JunitTestKind,
)
from junitforge.parser.java_symbols import parse_source


ENTITY = "GiPolicyEntity"
IDENTIFIER = "Long"


def _interface(
    name: str,
    *,
    type_parameters: list[str] | None = None,
    extends: str | None = None,
    implements: list[str] | None = None,
    methods: list[MethodSig] | None = None,
) -> ClassSymbol:
    return ClassSymbol(
        name=name,
        fqcn=f"sample.{name}",
        kind="interface",
        modifiers={"public"},
        type_parameters=list(type_parameters or ()),
        extends=extends,
        implements=list(implements or ()),
        methods=list(methods or ()),
    )


def _dependency(declared_type: str, simple_type: str | None = None) -> DependencyRef:
    simple = simple_type or declared_type.split("<", 1)[0].split(".")[-1]
    return DependencyRef(
        field_name="repository",
        parameter_name=None,
        declared_type=declared_type,
        simple_type=simple,
        fqcn=f"sample.{simple}",
        origin="field",
        resolution_status=ResolutionStatus.RESOLVED,
    )


def _arg(expression: str, type_name: str) -> InvocationArgument:
    return InvocationArgument(expression=expression, inferred_type=type_name)


def _lookup(symbols: list[ClassSymbol]):
    values: dict[str, ClassSymbol] = {}
    for symbol in symbols:
        values[symbol.name] = symbol
        values[symbol.fqcn] = symbol
    return lambda name: values.get(name) or values.get(name.split(".")[-1])


def _direct_jpa_lookup():
    spring = _interface("JpaRepository", type_parameters=["T", "ID"])
    return spring, _lookup([spring])


def _direct_crud_lookup():
    spring = _interface("CrudRepository", type_parameters=["T", "ID"])
    return spring, _lookup([spring])


def _custom_jpa_lookup():
    repository = _interface(
        "GiPolicyRepository",
        extends="JpaRepository<GiPolicyEntity, Long>",
    )
    return repository, _lookup([repository])


def _contract(
    method_name: str,
    *,
    dependency: DependencyRef | None = None,
    lookup=None,
    args: tuple[InvocationArgument, ...] = (),
) -> DependencyMethodContract:
    if dependency is None or lookup is None:
        repository, lookup = _custom_jpa_lookup()
        dependency = _dependency(repository.name)
    return resolve_method_contract(dependency, method_name, args, lookup)


def _analyze_service(source: str) -> tuple[GenerationContext, dict[str, MethodExecutionContext]]:
    repository_source = (
        "package sample; public interface GiPolicyRepository "
        "extends org.springframework.data.jpa.repository.JpaRepository<GiPolicyEntity, Long> {}"
    )
    entity_source = (
        "package sample; public class GiPolicyEntity { "
        "public Long getId() { return 1L; } }"
    )
    parsed = [
        parse_source(Path("GiPolicyRepository.java"), repository_source),
        parse_source(Path("GiPolicyEntity.java"), entity_source),
        parse_source(Path("PaymentServiceImpl.java"), source),
    ]
    symbols = [item.primary_type for item in parsed if item.primary_type is not None]
    lookup = _lookup(symbols)
    target_file = parsed[-1]
    target = target_file.primary_type
    assert target is not None
    execution = build_execution_context(
        source_file=target_file,
        symbol=target,
        lookup=lookup,
        target_kind=ExecutionTargetKind.SERVICE_IMPL,
    )
    assert execution is not None
    ctx = GenerationContext(
        cut_source=source,
        symbol=target,
        collaborators=[],
        test_package="sample",
        test_class_name="PaymentServiceImplTest",
        stack=StackProfile(java_version="17"),
        classpath=ClasspathProfile(has_junit_jupiter=True, has_mockito=True),
        template=TemplateSpec(JunitTestKind.PURE_UNIT, "unit"),
        source_path=Path("PaymentServiceImpl.java"),
        execution_context=execution,
    )
    return ctx, {method.method_id: method for method in execution.methods}


def _payload(ctx: GenerationContext, method: MethodSig) -> dict:
    method_context = next(
        item for item in ctx.execution_context.methods
        if item.method_id == f"{method.name}({','.join(t for t, _ in method.params)})"
    )
    closure = SimpleNamespace(method_source=method_context.method_source, reachable_methods=())
    with patch.object(serviceimpl, "build_source_closure", return_value=closure):
        messages = serviceimpl.build_generation_payload(ctx, method, mode="method")
    return json.loads(messages[1]["content"])


def _flatten_strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for item in value.values():
            yield from _flatten_strings(item)
    elif isinstance(value, list):
        for item in value:
            yield from _flatten_strings(item)


# 1. Direct JpaRepository inheritance/declaration.
def test_direct_jpa_repository_binding_resolves_entity_and_id() -> None:
    _spring, lookup = _direct_jpa_lookup()
    binding = resolve_repository_generic_binding(
        _dependency("JpaRepository<GiPolicyEntity, Long>", "JpaRepository"),
        lookup,
    )
    assert binding.resolution_status == ResolutionStatus.RESOLVED
    assert binding.entity_type == ENTITY
    assert binding.id_type == IDENTIFIER
    assert binding.base_interface == "JpaRepository"


# 2. Direct CrudRepository inheritance/declaration.
def test_direct_crud_repository_binding_resolves_entity_and_id() -> None:
    _spring, lookup = _direct_crud_lookup()
    binding = resolve_repository_generic_binding(
        _dependency("CrudRepository<GiPolicyEntity, Long>", "CrudRepository"),
        lookup,
    )
    assert binding.resolution_status == ResolutionStatus.RESOLVED
    assert (binding.entity_type, binding.id_type) == (ENTITY, IDENTIFIER)
    assert binding.base_interface == "CrudRepository"


def test_direct_spring_data_binding_does_not_require_source_lookup() -> None:
    binding = resolve_repository_generic_binding(
        _dependency("JpaRepository<GiPolicyEntity, Long>", "JpaRepository"),
        lambda _name: None,
    )
    assert binding.resolution_status == ResolutionStatus.RESOLVED
    assert (binding.entity_type, binding.id_type) == (ENTITY, IDENTIFIER)


def test_unbound_direct_spring_data_generics_remain_partial() -> None:
    binding = resolve_repository_generic_binding(
        _dependency("JpaRepository<T, ID>", "JpaRepository"),
        lambda _name: None,
    )
    assert binding.resolution_status == ResolutionStatus.PARTIAL
    assert binding.entity_type is None
    assert binding.id_type is None


# 3. Custom intermediate repository inheritance.
def test_custom_intermediate_repository_inheritance_is_resolved() -> None:
    base = _interface(
        "BaseRepository",
        type_parameters=["T", "ID"],
        extends="JpaRepository<T, ID>",
    )
    policy = _interface(
        "GiPolicyRepository",
        extends="BaseRepository<GiPolicyEntity, Long>",
    )
    binding = resolve_repository_generic_binding(_dependency(policy.name), _lookup([base, policy]))
    assert binding.resolution_status == ResolutionStatus.RESOLVED
    assert (binding.entity_type, binding.id_type) == (ENTITY, IDENTIFIER)


# 4. Multiple generic inheritance levels.
def test_multiple_generic_inheritance_levels_are_resolved_recursively() -> None:
    root = _interface(
        "RootRepository",
        type_parameters=["A", "B"],
        extends="JpaRepository<A, B>",
    )
    middle = _interface(
        "MiddleRepository",
        type_parameters=["X", "Y"],
        extends="RootRepository<X, Y>",
    )
    policy = _interface(
        "GiPolicyRepository",
        extends="MiddleRepository<GiPolicyEntity, Long>",
    )
    binding = resolve_repository_generic_binding(
        _dependency(policy.name),
        _lookup([root, middle, policy]),
    )
    assert binding.resolution_status == ResolutionStatus.RESOLVED
    assert (binding.entity_type, binding.id_type) == (ENTITY, IDENTIFIER)
    assert len(binding.inheritance_path) == 4


# 5. Exact entity and ID binding is retained on contracts.
def test_exact_entity_and_id_binding_is_exposed_on_contract() -> None:
    contract = _contract("findById", args=(_arg("id", IDENTIFIER),))
    assert contract.repository_entity_type == ENTITY
    assert contract.repository_id_type == IDENTIFIER
    assert contract.parameter_types == (IDENTIFIER,)
    assert contract.return_type == f"Optional<{ENTITY}>"


# 6. save.
def test_inherited_save_contract_is_exact() -> None:
    contract = _contract("save", args=(_arg("entity", ENTITY),))
    assert contract.return_type == ENTITY
    assert contract.parameter_types == (ENTITY,)
    assert contract.resolution_status == ResolutionStatus.RESOLVED


# 7. saveAndFlush.
def test_inherited_save_and_flush_contract_is_exact() -> None:
    contract = _contract("saveAndFlush", args=(_arg("entity", ENTITY),))
    assert contract.return_type == ENTITY
    assert contract.parameter_types == (ENTITY,)


# 8. saveAll.
def test_inherited_save_all_contract_is_exact() -> None:
    contract = _contract("saveAll", args=(_arg("entities", f"Iterable<{ENTITY}>") ,))
    assert contract.return_type == f"List<{ENTITY}>"
    assert contract.parameter_types == (f"Iterable<{ENTITY}>",)


def test_crud_repository_save_all_and_find_all_preserve_iterable_return() -> None:
    _spring, lookup = _direct_crud_lookup()
    dependency = _dependency("CrudRepository<GiPolicyEntity, Long>", "CrudRepository")
    save_all = _contract(
        "saveAll",
        dependency=dependency,
        lookup=lookup,
        args=(_arg("entities", f"Iterable<{ENTITY}>"),),
    )
    find_all = _contract("findAll", dependency=dependency, lookup=lookup)
    assert save_all.return_type == f"Iterable<{ENTITY}>"
    assert find_all.return_type == f"Iterable<{ENTITY}>"


def test_crud_only_jpa_method_is_partial_not_void() -> None:
    _spring, lookup = _direct_crud_lookup()
    dependency = _dependency("CrudRepository<GiPolicyEntity, Long>", "CrudRepository")
    contract = _contract("flush", dependency=dependency, lookup=lookup)
    assert contract.return_type is None
    assert contract.resolution_status == ResolutionStatus.PARTIAL
    assert contract.is_void is False


# 9. findById.
def test_inherited_find_by_id_contract_is_exact() -> None:
    contract = _contract("findById", args=(_arg("id", IDENTIFIER),))
    assert contract.return_type == f"Optional<{ENTITY}>"
    assert contract.parameter_types == (IDENTIFIER,)


# 10. findAll.
def test_inherited_find_all_contract_is_exact() -> None:
    contract = _contract("findAll")
    assert contract.return_type == f"List<{ENTITY}>"
    assert contract.parameter_types == ()


# 11. count.
def test_inherited_count_contract_is_exact() -> None:
    contract = _contract("count")
    assert contract.return_type == "long"
    assert contract.parameter_types == ()


# 12. deleteById.
def test_inherited_delete_by_id_contract_is_resolved_void() -> None:
    contract = _contract("deleteById", args=(_arg("id", IDENTIFIER),))
    assert contract.return_type == "void"
    assert contract.is_void
    assert contract.parameter_types == (IDENTIFIER,)


# 13. flush.
def test_inherited_flush_contract_is_resolved_void() -> None:
    contract = _contract("flush")
    assert contract.return_type == "void"
    assert contract.is_void
    assert contract.parameter_types == ()


def test_resolved_void_is_forbidden_for_normal_return_stubbing() -> None:
    contract = _contract("flush")
    invocation = DependencyInvocation(
        invocation_id="execute()#1",
        caller_method_id="execute()",
        dependency_field="repository",
        dependency_type="GiPolicyRepository",
        method_name="flush",
        arguments=(),
        contract=contract,
        return_value_consumed=False,
        consumption_kind=ReturnConsumptionKind.IGNORED_RESULT,
        return_flow_resolution_status=ResolutionStatus.RESOLVED,
    )
    assert invocation.normal_stubbing_requirement == StubbingRequirement.FORBIDDEN


@pytest.mark.parametrize(
    ("method_name", "expected_return", "expected_parameters"),
    [
        ("existsById", "boolean", (IDENTIFIER,)),
        ("delete", "void", (ENTITY,)),
    ],
)
def test_additional_required_spring_data_contracts_are_exact(
    method_name: str,
    expected_return: str,
    expected_parameters: tuple[str, ...],
) -> None:
    arg_type = expected_parameters[0] if expected_parameters else None
    args = (_arg("value", arg_type),) if arg_type else ()
    contract = _contract(method_name, args=args)
    assert contract.return_type == expected_return
    assert contract.parameter_types == expected_parameters


# 14-18. Return-consumption semantics.
SERVICE_SOURCE = """package sample;
public class PaymentServiceImpl {
    private final GiPolicyRepository repository;
    public PaymentServiceImpl(GiPolicyRepository repository) { this.repository = repository; }

    public GiPolicyEntity ignored(GiPolicyEntity entity) {
        repository.save(entity);
        return entity;
    }

    public Long consumed(GiPolicyEntity entity) {
        GiPolicyEntity saved = repository.save(entity);
        return saved.getId();
    }

    public boolean branchTested(Long id) {
        if (repository.existsById(id)) {
            return true;
        }
        return false;
    }

    public GiPolicyEntity optionalConsumed(Long id) {
        return repository.findById(id).orElseThrow();
    }

    public GiPolicyEntity helperPropagation(GiPolicyEntity entity) {
        return saveHelper(entity);
    }

    public long streamConsumed() {
        return repository.findAll().stream().count();
    }

    public GiPolicyEntity passedToCall(GiPolicyEntity entity) {
        return normalize(repository.save(entity));
    }

    private GiPolicyEntity saveHelper(GiPolicyEntity entity) {
        return repository.save(entity);
    }

    private GiPolicyEntity normalize(GiPolicyEntity entity) {
        return entity;
    }
}
"""


@pytest.fixture(scope="module")
def analyzed_service():
    return _analyze_service(SERVICE_SOURCE)


def _only_invocation(methods: dict[str, MethodExecutionContext], method_id: str) -> DependencyInvocation:
    values = methods[method_id].dependency_invocations
    assert len(values) == 1
    return values[0]


def test_ignored_non_void_return_is_not_stub_required(analyzed_service) -> None:
    _ctx, methods = analyzed_service
    invocation = _only_invocation(methods, "ignored(GiPolicyEntity)")
    assert invocation.contract.is_non_void
    assert invocation.return_value_consumed is False
    assert invocation.consumption_kind == ReturnConsumptionKind.IGNORED_RESULT
    assert invocation.normal_stubbing_requirement == StubbingRequirement.UNNECESSARY


def test_consumed_non_void_return_requires_normal_stub(analyzed_service) -> None:
    _ctx, methods = analyzed_service
    invocation = _only_invocation(methods, "consumed(GiPolicyEntity)")
    assert invocation.return_value_consumed is True
    assert invocation.consumption_kind == ReturnConsumptionKind.ASSIGNED
    assert invocation.normal_stubbing_requirement == StubbingRequirement.REQUIRED


def test_helper_return_propagation_is_traced_interprocedurally(analyzed_service) -> None:
    _ctx, methods = analyzed_service
    invocation = _only_invocation(methods, "helperPropagation(GiPolicyEntity)")
    assert invocation.caller_method_id == "saveHelper(GiPolicyEntity)"
    assert invocation.return_value_consumed is True
    assert invocation.consumption_kind == ReturnConsumptionKind.RETURNED_FROM_HELPER
    assert invocation.normal_stubbing_requirement == StubbingRequirement.REQUIRED


def test_branch_tested_return_is_consumed(analyzed_service) -> None:
    _ctx, methods = analyzed_service
    invocation = _only_invocation(methods, "branchTested(Long)")
    assert invocation.return_value_consumed is True
    assert invocation.consumption_kind == ReturnConsumptionKind.BRANCH_TESTED
    assert invocation.normal_stubbing_requirement == StubbingRequirement.OPTIONAL


def test_optional_return_flow_is_consumed(analyzed_service) -> None:
    _ctx, methods = analyzed_service
    invocation = _only_invocation(methods, "optionalConsumed(Long)")
    assert invocation.return_value_consumed is True
    assert invocation.consumption_kind == ReturnConsumptionKind.OPTIONAL_FLOW
    assert invocation.normal_stubbing_requirement == StubbingRequirement.REQUIRED


def test_stream_return_flow_is_distinguished(analyzed_service) -> None:
    _ctx, methods = analyzed_service
    invocation = _only_invocation(methods, "streamConsumed()")
    assert invocation.return_value_consumed is True
    assert invocation.consumption_kind == ReturnConsumptionKind.STREAM_FLOW


def test_return_passed_to_another_call_is_distinguished(analyzed_service) -> None:
    _ctx, methods = analyzed_service
    invocation = _only_invocation(methods, "passedToCall(GiPolicyEntity)")
    assert invocation.return_value_consumed is True
    assert invocation.consumption_kind == ReturnConsumptionKind.PASSED_TO_CALL


# 19. Unresolved return is not classified as void.
def test_unresolved_return_type_is_null_and_never_void() -> None:
    repository = _interface("UnknownRepository")
    dependency = _dependency(repository.name)
    contract = resolve_method_contract(
        dependency,
        "mystery",
        (_arg("id", IDENTIFIER),),
        _lookup([repository]),
    )
    assert contract.return_type is None
    assert contract.resolution_status == ResolutionStatus.UNRESOLVED
    assert contract.is_void is False
    assert contract.is_non_void is False


def test_unresolved_return_flow_is_not_treated_as_ignored() -> None:
    contract = _contract("save", args=(_arg("entity", ENTITY),))
    invocation = DependencyInvocation(
        invocation_id="execute(GiPolicyEntity)#1",
        caller_method_id="execute(GiPolicyEntity)",
        dependency_field="repository",
        dependency_type="GiPolicyRepository",
        method_name="save",
        arguments=(_arg("entity", ENTITY),),
        contract=contract,
        return_value_consumed=False,
        consumption_kind=ReturnConsumptionKind.UNRESOLVED,
        return_flow_resolution_status=ResolutionStatus.UNRESOLVED,
    )
    assert invocation.normal_stubbing_requirement == StubbingRequirement.UNRESOLVED
    assert invocation.return_flow_is_resolved is False


# 20. A required unresolved contract fails closed.
def test_unresolved_required_contract_produces_unresolved_diagnostic() -> None:
    production_method = MethodSig(
        "execute",
        modifiers={"public"},
        return_type="Object",
        params=[("Long", "id")],
    )
    contract = DependencyMethodContract(
        dependency_field="repository",
        dependency_type="UnknownRepository",
        method_name="mystery",
        return_type=None,
        parameter_types=("Long",),
        resolution_status=ResolutionStatus.UNRESOLVED,
    )
    invocation = DependencyInvocation(
        invocation_id="execute(Long)#1",
        caller_method_id="execute(Long)",
        dependency_field="repository",
        dependency_type="UnknownRepository",
        method_name="mystery",
        arguments=(_arg("id", "Long"),),
        contract=contract,
        return_value_consumed=True,
        consumption_kind=ReturnConsumptionKind.RETURNED_FROM_TARGET,
        invocation_expression="repository.mystery(id)",
        return_flow_resolution_status=ResolutionStatus.RESOLVED,
    )
    method_context = MethodExecutionContext(
        method_id="execute(Long)",
        signature=production_method.render(),
        source_range=(1, 1),
        method_source="public Object execute(Long id) { return repository.mystery(id); }",
        endpoint=None,
        dependency_invocations=(invocation,),
    )
    symbol = ClassSymbol(
        "PaymentServiceImpl",
        "sample.PaymentServiceImpl",
        "class",
        modifiers={"public"},
        methods=[production_method],
    )
    ctx = GenerationContext(
        cut_source=method_context.method_source,
        symbol=symbol,
        collaborators=[],
        test_package="sample",
        test_class_name="PaymentServiceImplTest",
        stack=StackProfile(java_version="17"),
        classpath=ClasspathProfile(has_junit_jupiter=True, has_mockito=True),
        template=TemplateSpec(JunitTestKind.PURE_UNIT, "unit"),
        source_path=Path("PaymentServiceImpl.java"),
        execution_context=ExecutionContext(
            target_kind=ExecutionTargetKind.SERVICE_IMPL,
            target_fqcn=symbol.fqcn,
            methods=(method_context,),
        ),
    )
    block = """@Test
void execute_unresolvedContract_failsClosed() {
    when(repository.mystery(anyLong())).thenReturn(null);
    assertNull(paymentServiceImpl.execute(1L));
}
"""
    result = validate_method_block(ctx, production_method, method_context, block, set())
    assert result.ok is False
    assert "UNRESOLVED_COLLABORATOR_CONTRACT" in (result.reason or "")
    assert "is void" not in (result.reason or "")


# 21. Payloads preserve null return types.
def test_payload_preserves_null_return_type_for_unresolved_contract() -> None:
    production_method = MethodSig("execute", modifiers={"public"}, return_type="Object")
    contract = DependencyMethodContract(
        dependency_field="repository",
        dependency_type="UnknownRepository",
        method_name="mystery",
        return_type=None,
        resolution_status=ResolutionStatus.UNRESOLVED,
    )
    invocation = DependencyInvocation(
        invocation_id="execute()#1",
        caller_method_id="execute()",
        dependency_field="repository",
        dependency_type="UnknownRepository",
        method_name="mystery",
        arguments=(),
        contract=contract,
        return_value_consumed=True,
        consumption_kind=ReturnConsumptionKind.RETURNED_FROM_TARGET,
        invocation_expression="repository.mystery()",
        return_flow_resolution_status=ResolutionStatus.RESOLVED,
    )
    method_context = MethodExecutionContext(
        method_id="execute()",
        signature=production_method.render(),
        source_range=(1, 1),
        method_source="public Object execute() { return repository.mystery(); }",
        endpoint=None,
        dependency_invocations=(invocation,),
    )
    symbol = ClassSymbol(
        "PaymentServiceImpl",
        "sample.PaymentServiceImpl",
        "class",
        modifiers={"public"},
        methods=[production_method],
    )
    ctx = GenerationContext(
        cut_source=method_context.method_source,
        symbol=symbol,
        collaborators=[],
        test_package="sample",
        test_class_name="PaymentServiceImplTest",
        stack=StackProfile(java_version="17"),
        classpath=ClasspathProfile(has_junit_jupiter=True, has_mockito=True),
        template=TemplateSpec(JunitTestKind.PURE_UNIT, "unit"),
        source_path=Path("PaymentServiceImpl.java"),
        execution_context=ExecutionContext(
            target_kind=ExecutionTargetKind.SERVICE_IMPL,
            target_fqcn=symbol.fqcn,
            methods=(method_context,),
        ),
    )
    payload = _payload(ctx, production_method)
    collaborator_method = payload["relevant_collaborator_contracts"][0]["methods"][0]
    assert collaborator_method["return_type"] is None
    assert collaborator_method["signature"] is None
    assert collaborator_method["resolution_status"] == "unresolved"
    assert collaborator_method["normal_stubbing"] == "unresolved"


# 22. Focused payloads exclude unrelated repository contracts.
def test_focused_payload_excludes_unrelated_repository_contracts(analyzed_service) -> None:
    ctx, _methods = analyzed_service
    method = next(item for item in ctx.symbol.methods if item.name == "ignored")
    payload = _payload(ctx, method)
    rendered = json.dumps(payload["relevant_collaborator_contracts"])
    assert '"method_name": "save"' in rendered
    assert "findById" not in rendered
    assert "existsById" not in rendered
    assert "saveAndFlush" not in rendered
    assert "findAll" not in rendered


# 23. Phase 1 permanent instructions are preserved once and not duplicated.
def test_existing_general_instructions_are_preserved_and_not_duplicated(analyzed_service) -> None:
    ctx, _methods = analyzed_service
    method = next(item for item in ctx.symbol.methods if item.name == "ignored")
    payload = _payload(ctx, method)
    serviceimpl.validate_general_instructions_preserved()
    assert payload["general_instructions"] == serviceimpl._GENERATION_INSTRUCTION
    strings = list(_flatten_strings(payload["general_instructions"]))
    assert len(strings) == len(set(strings))
    permanent_json = json.dumps(payload["general_instructions"], sort_keys=True)
    assert "GiPolicyRepository" not in permanent_json
    assert "GiPolicyEntity" not in permanent_json
    assert "ignored(GiPolicyEntity)" not in permanent_json
    full_json = json.dumps(payload, sort_keys=True)
    assert full_json.count('"general_instructions"') == 1
