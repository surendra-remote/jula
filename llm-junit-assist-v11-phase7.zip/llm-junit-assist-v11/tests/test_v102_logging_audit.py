from __future__ import annotations

import json
import logging
import tempfile
import unittest
from dataclasses import dataclass
from io import StringIO
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from junitforge import __version__
from junitforge.audit import AuditRecorder, STAGE_DIRS, safe_name
from junitforge.audit.console import STAGE_TAGS, stage
from junitforge.config import GenConfig
from junitforge.loop import Engine
from junitforge.models import ClassSymbol, JavaSourceFile, ModuleInfo, StackProfile
from junitforge.pipeline.context import PreparedTarget
from junitforge.timing import event, heartbeat
from junitforge.vendor.javac import CompileResult


class ConsoleContractV102Test(unittest.TestCase):
    def test_version_and_exact_stage_vocabulary(self) -> None:
        self.assertEqual("11.0.0", __version__)
        self.assertEqual(
            (
                "TECH_STACK", "SOURCE_FILE_INFO", "PARSE", "CLASSIFY", "DESTINATION",
                "COLLABORATORS", "EXECUTION_CONTEXT", "GENERATION_CONTEXT", "GENERATION",
                "METHOD_GENERATION", "COMPILE", "COMPILE_REPAIR", "RUNTIME",
                "RUNTIME_REPAIR", "COVERAGE", "PUBLICATION", "FINAL",
            ),
            STAGE_TAGS,
        )

    def test_stage_logger_uses_only_supported_tags(self) -> None:
        with self.assertLogs("junitforge.console", level=logging.INFO) as captured:
            stage("PARSE", "%s started", "PaymentServiceImpl.java")
        self.assertIn("[PARSE] PaymentServiceImpl.java started", captured.output[0])
        with self.assertRaises(ValueError):
            stage("CACHE", "hit")

    def test_timing_and_heartbeat_are_not_info_console_noise(self) -> None:
        logger = logging.getLogger("junitforge.timing")
        stream = StringIO()
        handler = logging.StreamHandler(stream)
        handler.setLevel(logging.INFO)
        old_level = logger.level
        logger.setLevel(logging.INFO)
        logger.addHandler(handler)
        try:
            event("symbol.cache.hit", type="Payment")
            with heartbeat("parse", interval_seconds=0.01, target="PaymentServiceImpl"):
                pass
        finally:
            logger.removeHandler(handler)
            logger.setLevel(old_level)
        self.assertEqual("", stream.getvalue())


@dataclass
class _SampleRecord:
    path: Path
    values: set[int]


class AuditRecorderV102Test(unittest.TestCase):
    def test_manifest_tree_safe_names_and_redaction(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            audit = AuditRecorder(root, version="10.2", run_id="run-001")
            audit.start_run(
                repository_root=root,
                configuration={
                    "build_tool": "maven",
                    "coverage_enabled": True,
                    "overwrite": True,
                    "offline": False,
                    "api_key": "secret-value",
                },
            )
            target = audit.register_target("PaymentServiceImpl", root / "PaymentServiceImpl.java")
            self.assertEqual("PaymentServiceImpl", target)
            target_dir = audit.target_dir(target)
            for stage_dir in STAGE_DIRS:
                self.assertTrue((target_dir / stage_dir).is_dir(), stage_dir)
            self.assertEqual(
                "execute_String_List_String",
                safe_name("execute(String,List<String>)"),
            )
            audit.write_json(target, "04-context/sample.json", {
                "record": _SampleRecord(Path("x"), {3, 1}),
                "authorization": "Bearer abc.def",
            })
            payload = json.loads((target_dir / "04-context/sample.json").read_text())
            self.assertEqual("<redacted>", payload["authorization"])
            self.assertEqual([1, 3], payload["record"]["values"])
            manifest = json.loads((audit.root / "manifest.json").read_text())
            self.assertEqual("<redacted>", manifest["configuration"]["api_key"])
            outcome = SimpleNamespace(status="compiled", notes=[])
            audit.finalize_target(target, outcome=outcome)
            audit.finalize_run(status="completed", outcomes=[outcome], totals={"tokens_used": 0})
            self.assertTrue((target_dir / "final-manifest.json").exists())
            self.assertTrue((audit.root / "final-manifest.json").exists())

    def test_source_snapshots_are_byte_exact_and_llm_totals_are_recorded(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            audit = AuditRecorder(root, version="10.2", run_id="run-source")
            audit.start_run(repository_root=root, configuration={})
            target = audit.register_target("PaymentServiceImpl", root / "PaymentServiceImpl.java")
            source = 'class PaymentServiceImplTest { String value = "Bearer example-token"; }\n'
            path = audit.write_text(target, "07-class-assembly/assembled.java", source)
            self.assertEqual(source, path.read_text(encoding="utf-8"))
            audit.record_llm_usage(SimpleNamespace(prompt_tokens=11, completion_tokens=7, total_tokens=18))
            audit.finalize_run(status="completed", outcomes=[], totals={})
            final = json.loads((audit.root / "final-manifest.json").read_text())
            self.assertEqual(1, final["totals"]["llm_calls"])
            self.assertEqual(11, final["totals"]["input_tokens"])
            self.assertEqual(7, final["totals"]["output_tokens"])
            self.assertEqual(18, final["totals"]["tokens_used"])

    def test_serialization_warning_does_not_crash(self) -> None:
        class Opaque:
            __slots__ = ()

        with tempfile.TemporaryDirectory() as tmp:
            audit = AuditRecorder(Path(tmp), version="10.2", run_id="run-serialization")
            audit.start_run(repository_root=Path(tmp), configuration={})
            path = audit.write_json(None, "opaque.json", {"value": Opaque()})
            self.assertIsNotNone(path)
            self.assertTrue(audit.serialization_warnings)


class MockedAuditLifecycleV102Test(unittest.TestCase):
    def test_active_serviceimpl_audit_lifecycle_is_complete_without_augmentation(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            audit = AuditRecorder(root, version="10.2", run_id="e2e-audit")
            audit.start_run(repository_root=root, configuration={"coverage_enabled": True})
            target = audit.register_target("PaymentServiceImpl", root / "PaymentServiceImpl.java")
            files = {
                "01-parse/summary.json": {},
                "02-classification/summary.json": {},
                "03-destination/summary.json": {},
                "04-context/collaborators.json": {},
                "04-context/execution-context-summary.json": {},
                "04-context/generation-context-summary.json": {},
                "05-skeleton/compile-command.json": {},
                "05-skeleton/compile-result.json": {},
                "06-method-generation/execute/request.json": {"request_type": "method_test_generation"},
                "06-method-generation/execute/structural-validation.json": {},
                "06-method-generation/execute/registry-after.json": {},
                "07-class-assembly/registry.json": {},
                "07-class-assembly/summary.json": {},
                "08-compile/command.json": {},
                "08-compile/compiler-errors.json": {},
                "08-compile/result.json": {},
                "09-compile-repair/attempt-001/request.json": {"request_type": "compile_repair"},
                "09-compile-repair/attempt-001/compile-after.json": {},
                "09-compile-repair/attempt-001/decision.json": {"accepted": True},
                "10-runtime/full-run.json": {},
                "10-runtime/failures.json": {},
                "10-runtime/registry-after.json": {},
                "11-runtime-repair/execute/attempt-001/request.json": {"request_type": "runtime_repair"},
                "11-runtime-repair/execute/attempt-001/targeted-result.json": {},
                "11-runtime-repair/execute/attempt-001/full-result.json": {},
                "11-runtime-repair/execute/attempt-001/decision.json": {"accepted": True},
                "12-coverage/run.json": {},
                "12-coverage/freshness.json": {},
                "12-coverage/parsed.json": {},
                "13-publication/decision.json": {},
            }
            for relative, payload in files.items():
                audit.write_json(target, relative, payload)
            for relative in (
                "05-skeleton/generated.java", "05-skeleton/compiled.java",
                "06-method-generation/execute/response.txt",
                "06-method-generation/execute/extracted-tests.java",
                "07-class-assembly/assembled.java", "08-compile/stdout.log",
                "08-compile/stderr.log", "09-compile-repair/attempt-001/response.txt",
                "09-compile-repair/attempt-001/before.java",
                "09-compile-repair/attempt-001/candidate.java",
                "11-runtime-repair/execute/attempt-001/response.txt",
                "11-runtime-repair/execute/attempt-001/failing-tests-before.java",
                "11-runtime-repair/execute/attempt-001/repaired-tests.java",
                "11-runtime-repair/execute/attempt-001/candidate-class.java",
                "12-coverage/stdout.log", "12-coverage/stderr.log",
            ):
                audit.write_text(target, relative, "sample\n")
            audit.finalize_target(target, outcome={"status": "threshold_met"})
            audit.finalize_run(status="completed", outcomes=[{"status": "threshold_met"}], totals={})
            target_dir = audit.target_dir(target)
            for relative in files:
                self.assertTrue((target_dir / relative).exists(), relative)
            self.assertFalse(any("augmentation" in str(path) for path in target_dir.rglob("*")))
            self.assertTrue((audit.root / "final-manifest.json").exists())


class MockedPipelineAuditV102Test(unittest.TestCase):
    def test_run_target_emits_stage_console_and_numbered_audit_tree(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source_path = root / "src/main/java/sample/PaymentServiceImpl.java"
            source_path.parent.mkdir(parents=True)
            source_path.write_text("package sample; public class PaymentServiceImpl {}", encoding="utf-8")
            test_path = root / "src/test/java/sample/PaymentServiceImplTest.java"
            symbol = ClassSymbol(
                name="PaymentServiceImpl",
                fqcn="sample.PaymentServiceImpl",
                kind="class",
                modifiers={"public"},
                package_name="sample",
            )
            java_file = JavaSourceFile(
                path=source_path,
                package="sample",
                types=[symbol],
                source=source_path.read_text(),
            )
            module = ModuleInfo("root", root, root / "pom.xml")
            audit = AuditRecorder(root, version="10.2", run_id="pipeline-run")
            audit.start_run(repository_root=root, configuration={"build_tool": "maven"})

            class Gate:
                ready = False
                def check(self, _path, _module):
                    return CompileResult(ok=True, cmd=["javac", str(_path)]), []

            engine = Engine(
                llm=None,
                compile_gate=Gate(),
                coverage_runner=None,
                stack=StackProfile(),
                modules=[module],
                repo_root=root,
                lookup=lambda _name: None,
                cfg=GenConfig(run_coverage=False),
                test_path_fn=lambda *_args: test_path,
                symbol_resolver=SimpleNamespace(parse_target=lambda _path: java_file),
                audit=audit,
            )
            template = SimpleNamespace(kind=SimpleNamespace(value="pure_unit"), testable=True, reasons=[])
            cp = SimpleNamespace(has_junit_jupiter=True)
            ctx = SimpleNamespace(
                execution_context=None,
                test_package="sample",
                test_class_name="PaymentServiceImplTest",
                symbol=symbol,
                template=template,
                collaborators=[],
                source_imports=[],
            )
            generated = "package sample; class PaymentServiceImplTest {}"
            with (
                patch("junitforge.pipeline.context.module_for_source", return_value=module),
                patch("junitforge.pipeline.context.is_test_target", return_value=(True, "")),
                patch.object(engine, "_classpath_profile", return_value=cp),
                patch("junitforge.pipeline.context.classify", return_value=template),
                patch("junitforge.pipeline.context.resolve_collaborators", return_value=[]),
                patch("junitforge.pipeline.context.classify_execution_target", return_value=SimpleNamespace(value="service-impl")),
                patch("junitforge.pipeline.context.build_execution_context", return_value=None),
                patch("junitforge.pipeline.context.build_context", return_value=ctx),
                patch.object(engine, "_generate", return_value=generated),
            ):
                with self.assertLogs("junitforge.console", level=logging.INFO) as captured:
                    outcome = engine.run_target(source_path)

            self.assertEqual("compiled", outcome.status)
            output = "\n".join(captured.output)
            for tag in ("PARSE", "SOURCE_FILE_INFO", "CLASSIFY", "DESTINATION", "GENERATION", "COMPILE", "COVERAGE", "PUBLICATION", "FINAL"):
                self.assertIn(f"[{tag}]", output)
            target_dir = audit.root / "PaymentServiceImpl"
            self.assertTrue((target_dir / "01-parse/summary.json").exists())
            self.assertTrue((target_dir / "02-classification/summary.json").exists())
            self.assertTrue((target_dir / "03-destination/summary.json").exists())
            self.assertTrue((target_dir / "07-class-assembly/assembled.java").exists())
            self.assertTrue((target_dir / "08-compile/result.json").exists())
            self.assertTrue((target_dir / "13-publication/decision.json").exists())
            self.assertTrue((target_dir / "final-manifest.json").exists())


if __name__ == "__main__":
    unittest.main()
