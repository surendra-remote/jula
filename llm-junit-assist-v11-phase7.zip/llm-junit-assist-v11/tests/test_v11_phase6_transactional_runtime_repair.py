from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import MagicMock


from junitforge.compile_gate import CompileError
from junitforge.config import GenConfig
from junitforge.coverage_run import CoverageRunResult, CoverageSignals, RuntimeTestRunResult, SurefireFailure
from junitforge.execution.models import ExecutionContext, ExecutionTargetKind, MethodExecutionContext
from junitforge.generation.payloads import serviceimpl
from junitforge.loop import Engine
from junitforge.models import (
    ClassSymbol,
    ClasspathProfile,
    CompileState,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    MethodSig,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TemplateSpec,
    TestCaseRecord as RegistryTestCaseRecord,
    TestDisposition as RegistryTestDisposition,
    TestKind as RegistryTestKind,
)
from junitforge.pipeline.result import test_record_by_name as find_test_record
from junitforge.registry import RegistryStore, source_hash
from junitforge.runtime.result_parser import group_runtime_failures_by_test, map_runtime_failure_test
from junitforge.vendor.javac import CompileResult
from junitforge.vendor.llm.base import LLMResponse, TokenUsage


OWNER = "execute()"
TEST_FQCN = "sample.PaymentServiceImplTest"
FAILING = "execute_fails"
PASSING = "execute_passes"
ORIGINAL_FAILING_SOURCE = "@Test void execute_fails() { assertNull(paymentServiceImpl.execute()); }"
REPAIRED_FAILING_SOURCE = """@Test void execute_fails() {
    Object result = paymentServiceImpl.execute();
    assertNotNull(result);
}"""


def _suite(failing_source: str = ORIGINAL_FAILING_SOURCE) -> str:
    return f"""class PaymentServiceImplTest {{
// JUNITFORGE_METHOD_BEGIN: execute()
@Test void execute_passes() {{ assertTrue(true); }}
{failing_source}
// JUNITFORGE_METHOD_END: execute()
}}
"""


def _context(root: Path) -> tuple[GenerationContext, ModuleInfo]:
    method = MethodSig("execute", modifiers={"public"}, return_type="Object")
    method_context = MethodExecutionContext(
        method_id=OWNER,
        signature=method.render(),
        source_range=(1, 3),
        method_source="public Object execute() { return new Object(); }",
        endpoint=None,
    )
    execution = ExecutionContext(
        target_kind=ExecutionTargetKind.SERVICE_IMPL,
        target_fqcn="sample.PaymentServiceImpl",
        methods=(method_context,),
    )
    symbol = ClassSymbol(
        "PaymentServiceImpl",
        "sample.PaymentServiceImpl",
        "class",
        modifiers={"public"},
        methods=[method],
    )
    ctx = GenerationContext(
        cut_source=method_context.method_source,
        symbol=symbol,
        collaborators=[],
        test_package="sample",
        test_class_name="PaymentServiceImplTest",
        stack=StackProfile(),
        classpath=ClasspathProfile(has_junit_jupiter=True, has_mockito=True),
        template=TemplateSpec(RegistryTestKind.PURE_UNIT, "unit"),
        source_path=root / "PaymentServiceImpl.java",
        execution_context=execution,
    )
    return ctx, ModuleInfo("sample", root, root / "pom.xml")


def _outcome(root: Path) -> TargetOutcome:
    passing_source = "@Test void execute_passes() { assertTrue(true); }"
    method = MethodGenerationRecord(
        method_id=OWNER,
        final_status=MethodDisposition.GENERATED.value,
        tests=[
            RegistryTestCaseRecord(
                owner_method_id=OWNER,
                test_name=PASSING,
                generated_source=passing_source,
                latest_accepted_source=passing_source,
                source_hash=source_hash(passing_source),
                validation_state="VALID",
                compile_state=CompileState.PASSED.value,
                runtime_state="PASSED",
                final_disposition=RegistryTestDisposition.RETAINED.value,
            ),
            RegistryTestCaseRecord(
                owner_method_id=OWNER,
                test_name=FAILING,
                generated_source=ORIGINAL_FAILING_SOURCE,
                latest_accepted_source=ORIGINAL_FAILING_SOURCE,
                source_hash=source_hash(ORIGINAL_FAILING_SOURCE),
                validation_state="VALID",
                compile_state=CompileState.PASSED.value,
                final_disposition=RegistryTestDisposition.RETAINED.value,
            ),
        ],
    )
    outcome = TargetOutcome(
        fqcn="sample.PaymentServiceImpl",
        module="sample",
        source_path=str(root / "PaymentServiceImpl.java"),
        test_path=str(root / "PaymentServiceImplTest.java"),
        classification="service-impl",
        testable=True,
        registry_path=str(root / "reports/audit/run/PaymentServiceImpl/07-class-assembly/registry.json"),
        method_results=[method],
    )
    RegistryStore(outcome).persist()
    return outcome


def _failure(*, line: int = 999, message: str = "expected: <null> but was: <value>") -> SurefireFailure:
    return SurefireFailure(
        TEST_FQCN,
        FAILING,
        "failure",
        "org.opentest4j.AssertionFailedError",
        message,
        "trace",
        generated_test_line=line,
        category="ASSERTION_VALUE_MISMATCH",
    )


def _before(failure: SurefireFailure | None = None) -> CoverageRunResult:
    failure = failure or _failure()
    return CoverageRunResult(
        ok=True,
        measured=True,
        note="before",
        signals=CoverageSignals(tests_executed=True, tests_run=2, tests_failed=1),
        failures=(failure,),
        executed_test_names=(PASSING, FAILING),
        maven_execution_success=True,
        coverage_current=True,
    )


def _runtime(*, tests: tuple[str, ...], failures: tuple[SurefireFailure, ...] = ()) -> RuntimeTestRunResult:
    error_count = sum(1 for item in failures if item.status == "error")
    failure_count = len(failures) - error_count
    return RuntimeTestRunResult(
        True,
        "runtime",
        signals=CoverageSignals(
            tests_executed=True,
            tests_run=len(tests),
            tests_failed=failure_count,
            tests_errors=error_count,
        ),
        failures=failures,
        executed_test_names=tests,
    )


def _engine(root: Path, *, compile_result: tuple[CompileResult, list] | None = None, runs=()) -> Engine:
    llm = MagicMock()
    llm.chat.return_value = LLMResponse(
        message=REPAIRED_FAILING_SOURCE,
        usage=TokenUsage(prompt_tokens=31, completion_tokens=17, total_tokens=48),
        response_state="COMPLETED",
        finish_reason="stop",
    )
    compile_gate = MagicMock()
    compile_gate.check.return_value = compile_result or (CompileResult(ok=True, return_code=0), [])
    runner = MagicMock()
    runner.run_tests.side_effect = list(runs)
    return Engine(
        llm=llm,
        compile_gate=compile_gate,
        coverage_runner=runner,
        stack=StackProfile(),
        modules=[],
        repo_root=root,
        lookup=lambda _name: None,
        cfg=GenConfig(max_runtime_repair_rounds=4, max_runtime_repairs_per_owner=3),
    )


def _invoke(engine: Engine, ctx, module, test_path, outcome, failure=None, attempt=1):
    failure = failure or _failure()
    engine._compile_with_repair = MagicMock(side_effect=AssertionError("nested compile repair invoked"))
    result = engine._repair_runtime_owner(
        ctx=ctx,
        test_path=test_path,
        module=module,
        owner=OWNER,
        owner_failures=[failure],
        before_run=_before(failure),
        outcome=outcome,
        test_fqcn=TEST_FQCN,
        round_no=attempt,
        attempt_no=attempt,
    )
    engine._compile_with_repair.assert_not_called()
    return result


def test_runtime_failure_maps_to_stable_test_id_without_line_identity() -> None:
    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        outcome = _outcome(root)
        failure = _failure(line=123456)
        record, source, confidence = map_runtime_failure_test(
            failure, outcome, expected_test_class=TEST_FQCN
        )
        assert record is not None
        assert record.test_id == f"{OWNER}::{FAILING}"
        assert source == "registry_test_id"
        assert confidence == "high"
        grouped, unmapped = group_runtime_failures_by_test(
            [failure], outcome, expected_test_class=TEST_FQCN
        )
        assert list(grouped) == [record.test_id]
        assert not unmapped


def test_runtime_payload_is_single_test_focused_and_excludes_catalogues() -> None:
    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        ctx, _module = _context(root)
        method = ctx.symbol.methods[0]
        messages = serviceimpl.build_runtime_repair_payload(
            ctx,
            method,
            failing_tests=[{
                "test_id": f"{OWNER}::{FAILING}",
                "owner_method_id": OWNER,
                "test_name": FAILING,
                "source": ORIGINAL_FAILING_SOURCE,
                "runtime_status": "failure",
                "diagnostics": [{"category": "ASSERTION_VALUE_MISMATCH", "message": "expected null"}],
            }],
            test_class_source=_suite(),
        )
        payload = json.loads(messages[1]["content"])
        assert payload["failing_registry_test"]["test_id"] == f"{OWNER}::{FAILING}"
        rendered = json.dumps(payload)
        assert PASSING not in rendered
        assert "complete_catalogue" not in rendered
        assert "schema_catalog" not in rendered
        assert "test_class_source" not in rendered
        assert "general_instructions" in payload
        assert "approved_runtime_repair_additions" in payload


def test_runtime_prompt_preserves_general_instructions_with_one_minimal_replacement() -> None:
    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        ctx, _module = _context(root)
        messages = serviceimpl.build_runtime_repair_payload(
            ctx,
            ctx.symbol.methods[0],
            failing_tests=[{
                "test_id": f"{OWNER}::{FAILING}",
                "test_name": FAILING,
                "source": ORIGINAL_FAILING_SOURCE,
                "diagnostics": [],
            }],
        )
        payload = json.loads(messages[1]["content"])
        expected = deepcopy(serviceimpl._GENERATION_INSTRUCTION)
        expected["objective"]["requested_test_kind"] = "focused_runtime_repair"
        assert payload["general_instructions"] == expected
        assert list(payload).count("general_instructions") == 1
        assert list(payload).count("approved_runtime_repair_additions") == 1
        assert serviceimpl.general_instructions_fingerprint() == serviceimpl._PHASE1_GENERAL_INSTRUCTIONS_SHA256


def test_successful_candidate_compiles_once_executes_target_then_full_and_commits() -> None:
    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        ctx, module = _context(root)
        outcome = _outcome(root)
        test_path = Path(outcome.test_path)
        test_path.write_text(_suite(), encoding="utf-8")
        engine = _engine(
            root,
            runs=[_runtime(tests=(FAILING,)), _runtime(tests=(PASSING, FAILING))],
        )
        accepted, full, reason = _invoke(engine, ctx, module, test_path, outcome)
        assert accepted and full is not None and reason == "accepted"
        assert engine.compile_gate.check.call_count == 1
        assert engine.coverage_runner.run_tests.call_count == 2
        assert engine.coverage_runner.run_tests.call_args_list[0].args[1] == [f"{TEST_FQCN}#{FAILING}"]
        assert engine.coverage_runner.run_tests.call_args_list[1].args[1] == [TEST_FQCN]
        record = find_test_record(outcome, FAILING)
        assert record.generated_source == ORIGINAL_FAILING_SOURCE
        assert record.previous_accepted_source == ORIGINAL_FAILING_SOURCE
        assert record.latest_accepted_source == REPAIRED_FAILING_SOURCE
        assert record.candidate_source == ""
        assert record.runtime_repair_attempts[-1]["decision"] == "COMMIT"
        assert test_path.read_text(encoding="utf-8") == _suite(REPAIRED_FAILING_SOURCE)


def test_compile_failure_rolls_back_immediately_and_makes_zero_compile_repair_calls() -> None:
    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        ctx, module = _context(root)
        outcome = _outcome(root)
        test_path = Path(outcome.test_path)
        original = _suite()
        test_path.write_text(original, encoding="utf-8")
        error = CompileError(file=test_path, line=4, col=9, message="cannot find symbol", raw="raw")
        engine = _engine(
            root,
            compile_result=(CompileResult(ok=False, return_code=1, stderr="bad"), [error]),
        )
        accepted, result, reason = _invoke(engine, ctx, module, test_path, outcome)
        assert not accepted and result is None and reason == "RUNTIME_CANDIDATE_COMPILE_FAILED"
        assert engine.compile_gate.check.call_count == 1
        assert engine.coverage_runner.run_tests.call_count == 0
        assert test_path.read_text(encoding="utf-8") == original
        record = find_test_record(outcome, FAILING)
        assert record.generated_source == ORIGINAL_FAILING_SOURCE
        assert record.latest_accepted_source == ORIGINAL_FAILING_SOURCE
        assert record.candidate_source == ""
        attempt = record.runtime_repair_attempts[-1]
        assert attempt["compile_repair_llm_calls"] == 0
        assert attempt["compile_result"]["status"] == "FAILED"
        assert attempt["compile_diagnostics"][0]["column"] == 9
        assert attempt["decision"] == "ROLLBACK"


def test_targeted_execution_failure_prevents_full_run_and_commit() -> None:
    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        ctx, module = _context(root)
        outcome = _outcome(root)
        test_path = Path(outcome.test_path)
        original = _suite()
        test_path.write_text(original, encoding="utf-8")
        failing = _failure(message="still failing")
        engine = _engine(root, runs=[_runtime(tests=(FAILING,), failures=(failing,))])
        accepted, result, reason = _invoke(engine, ctx, module, test_path, outcome)
        assert not accepted and result is None and reason == "TARGETED_EXECUTION_FAILED"
        assert engine.coverage_runner.run_tests.call_count == 1
        assert test_path.read_text(encoding="utf-8") == original
        assert find_test_record(outcome, FAILING).latest_accepted_source == ORIGINAL_FAILING_SOURCE


def test_complete_retained_class_failure_prevents_commit() -> None:
    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        ctx, module = _context(root)
        outcome = _outcome(root)
        test_path = Path(outcome.test_path)
        original = _suite()
        test_path.write_text(original, encoding="utf-8")
        sibling_failure = SurefireFailure(
            TEST_FQCN,
            PASSING,
            "failure",
            "AssertionFailedError",
            "regression",
            "trace",
            category="ASSERTION_VALUE_MISMATCH",
        )
        engine = _engine(
            root,
            runs=[
                _runtime(tests=(FAILING,)),
                _runtime(tests=(PASSING, FAILING), failures=(sibling_failure,)),
            ],
        )
        accepted, result, reason = _invoke(engine, ctx, module, test_path, outcome)
        assert not accepted and result is None and reason == "FULL_SUITE_NOT_GREEN"
        assert test_path.read_text(encoding="utf-8") == original
        assert find_test_record(outcome, FAILING).latest_accepted_source == ORIGINAL_FAILING_SOURCE


def test_runtime_attempt_persists_response_metadata_and_append_only_history() -> None:
    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        ctx, module = _context(root)
        outcome = _outcome(root)
        record = find_test_record(outcome, FAILING)
        record.runtime_repair_attempts.append({"attempt_number": 0, "decision": "PRIOR"})
        RegistryStore(outcome).persist()
        test_path = Path(outcome.test_path)
        test_path.write_text(_suite(), encoding="utf-8")
        engine = _engine(root, runs=[_runtime(tests=(FAILING,)), _runtime(tests=(PASSING, FAILING))])
        accepted, _full, _reason = _invoke(engine, ctx, module, test_path, outcome)
        assert accepted
        history = find_test_record(outcome, FAILING).runtime_repair_attempts
        assert history[0]["decision"] == "PRIOR"
        attempt = history[-1]
        assert attempt["request_hash"]
        assert attempt["response_hash"]
        assert attempt["token_counts"] == {"input_tokens": 31, "output_tokens": 17, "total_tokens": 48}
        assert attempt["finish_reason"] == "stop"
        assert attempt["response_size"] > 0
        assert attempt["truncation_state"] == "NOT_TRUNCATED"
        assert attempt["candidate_hash"] == source_hash(REPAIRED_FAILING_SOURCE)


def test_identical_rejected_response_stops_without_second_compile() -> None:
    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        ctx, module = _context(root)
        outcome = _outcome(root)
        test_path = Path(outcome.test_path)
        original = _suite()
        test_path.write_text(original, encoding="utf-8")
        failure = _failure(message="still failing")
        engine = _engine(root, runs=[_runtime(tests=(FAILING,), failures=(failure,))])
        first = _invoke(engine, ctx, module, test_path, outcome, failure=failure, attempt=1)
        assert first[2] == "TARGETED_EXECUTION_FAILED"
        assert test_path.read_text(encoding="utf-8") == original
        assert find_test_record(outcome, FAILING).candidate_source == ""

        engine.coverage_runner.run_tests.reset_mock()
        second = _invoke(engine, ctx, module, test_path, outcome, failure=failure, attempt=2)
        assert second[2] == "IDENTICAL_REJECTED_RESPONSE"
        assert engine.compile_gate.check.call_count == 1
        assert engine.coverage_runner.run_tests.call_count == 0
        history = find_test_record(outcome, FAILING).runtime_repair_attempts
        assert len(history) == 2
        assert history[-1]["decision"] == "ROLLBACK"
        assert test_path.read_text(encoding="utf-8") == original


def test_each_failed_attempt_rolls_back_before_next_baseline() -> None:
    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        ctx, module = _context(root)
        outcome = _outcome(root)
        test_path = Path(outcome.test_path)
        original = _suite()
        test_path.write_text(original, encoding="utf-8")
        failure = _failure()
        engine = _engine(root, runs=[_runtime(tests=(FAILING,), failures=(failure,))])
        first = _invoke(engine, ctx, module, test_path, outcome, failure=failure, attempt=1)
        assert first[2] == "TARGETED_EXECUTION_FAILED"
        assert test_path.read_text(encoding="utf-8") == original
        assert find_test_record(outcome, FAILING).candidate_source == ""
        assert find_test_record(outcome, FAILING).latest_accepted_source == ORIGINAL_FAILING_SOURCE

        # A different second provider response avoids the identical-response stop.
        # The second request must still be constructed from the original accepted
        # test, not from the rejected first candidate.
        engine.llm.chat.return_value = LLMResponse(
            message=REPAIRED_FAILING_SOURCE + "\n",
            usage=TokenUsage(prompt_tokens=7, completion_tokens=5, total_tokens=12),
            response_state="COMPLETED",
            finish_reason="stop",
        )
        engine.compile_gate.check.return_value = (
            CompileResult(ok=False, return_code=1, stderr="second compile rejected"),
            [],
        )
        second = _invoke(engine, ctx, module, test_path, outcome, failure=failure, attempt=2)
        assert second[2] == "RUNTIME_CANDIDATE_COMPILE_FAILED"
        history = find_test_record(outcome, FAILING).runtime_repair_attempts
        second_payload = json.loads(history[-1]["request"][1]["content"])
        assert second_payload["failing_registry_test"]["source"] == ORIGINAL_FAILING_SOURCE
        assert test_path.read_text(encoding="utf-8") == original
        assert find_test_record(outcome, FAILING).candidate_source == ""
        assert find_test_record(outcome, FAILING).latest_accepted_source == ORIGINAL_FAILING_SOURCE
