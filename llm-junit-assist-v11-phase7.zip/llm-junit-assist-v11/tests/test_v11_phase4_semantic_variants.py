from __future__ import annotations

from dataclasses import replace
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from junitforge.execution.models import (
    ConfigurationField,
    ConstructionKind,
    DependencyInvocation,
    DependencyMethodContract,
    ExecutionContext,
    ExecutionTargetKind,
    FixtureCompileStatus,
    FixtureSpec,
    MethodExecutionContext,
    PayloadProperty,
    PayloadSchema,
    PropertyKind,
    ResolutionStatus,
)
from junitforge.generation.fixture_variants import augment_fixture_variant
from junitforge.generation.payloads import serviceimpl
from junitforge.generation.semantic_validation import (
    SemanticCategory,
    deterministically_correct_serviceimpl,
    validate_serviceimpl_semantics,
)
from junitforge.generation.validation import validate_generated_test
from junitforge.models import (
    ClassSymbol,
    ClasspathProfile,
    FieldSig,
    GenerationContext,
    MethodSig,
    StackProfile,
    TemplateSpec,
    TestCaseRecord as CaseRecord,
    TestKind as JunitTestKind,
)
from junitforge.pipeline.result import sync_test_registry_sources
from junitforge.models import MethodGenerationRecord, TargetOutcome


def _prop(name, type_name, *, getter=None, setter=None, kind=PropertyKind.SCALAR, element=None):
    return PayloadProperty(
        name=name,
        type_name=type_name,
        resolved_type=type_name,
        readable=bool(getter),
        writable=bool(setter),
        getter=getter,
        setter=setter,
        kind=kind,
        element_type=element,
    )


def _context():
    status = PayloadSchema(
        "PolicyStatus", "sample.PolicyStatus", "enum",
        enum_constants=("PENDING", "INFORCE"),
        resolution_status=ResolutionStatus.RESOLVED,
        construction_kind=ConstructionKind.ENUM,
    )
    bill = PayloadSchema(
        "Bill", "sample.Bill", "class",
        properties=(_prop("code", "String", getter="getCode", setter="setCode"),),
        resolution_status=ResolutionStatus.RESOLVED,
        construction_kind=ConstructionKind.NO_ARGS_SETTERS,
    )
    child = PayloadSchema(
        "Child", "sample.Child", "class",
        properties=(_prop("name", "String", getter="getName", setter="setName"),),
        resolution_status=ResolutionStatus.RESOLVED,
        construction_kind=ConstructionKind.NO_ARGS_SETTERS,
    )
    other = PayloadSchema(
        "OtherChild", "sample.OtherChild", "class",
        properties=(), resolution_status=ResolutionStatus.RESOLVED,
        construction_kind=ConstructionKind.NO_ARGS_SETTERS,
    )
    policy = PayloadSchema(
        "Policy", "sample.Policy", "class",
        properties=(
            _prop("status", "Character", getter="getStatus", setter="setStatus"),
            _prop("loading", "Integer", getter="getLoading", setter="setLoading"),
            _prop("amount", "BigDecimal", getter="getAmount", setter="setAmount"),
            _prop("code", "String", getter="getCode", setter="setCode"),
            _prop("active", "Boolean", getter="getActive", setter="setActive"),
            _prop("policyStatus", "PolicyStatus", getter="getPolicyStatus", setter="setPolicyStatus", kind=PropertyKind.ENUM),
            _prop("bills", "Set<Bill>", getter="getBills", setter="setBills", kind=PropertyKind.SET, element="Bill"),
            _prop("names", "List<String>", getter="getNames", setter="setNames", kind=PropertyKind.LIST, element="String"),
            _prop("child", "Child", getter="getChild", setter="setChild", kind=PropertyKind.OBJECT),
        ),
        resolution_status=ResolutionStatus.RESOLVED,
        construction_kind=ConstructionKind.NO_ARGS_SETTERS,
    )
    fixtures = (
        FixtureSpec("sample.Policy", "validPolicy", "Policy", "sample.Policy", compile_status=FixtureCompileStatus.COMPILED, method_source="private Policy validPolicy(){ return new Policy(); }"),
        FixtureSpec("sample.Bill", "validBill", "Bill", "sample.Bill", compile_status=FixtureCompileStatus.COMPILED, method_source="private Bill validBill(){ return new Bill(); }"),
        FixtureSpec("sample.Child", "validChild", "Child", "sample.Child", compile_status=FixtureCompileStatus.COMPILED, method_source="private Child validChild(){ return new Child(); }"),
        FixtureSpec("sample.OtherChild", "validOtherChild", "OtherChild", "sample.OtherChild", compile_status=FixtureCompileStatus.COMPILED, method_source="private OtherChild validOtherChild(){ return new OtherChild(); }"),
    )
    contracts = (
        DependencyMethodContract("repository", "Repository", "flush", "void", (), resolution_status=ResolutionStatus.RESOLVED),
        DependencyMethodContract("repository", "Repository", "saveAndFlush", "Policy", ("Policy",), resolution_status=ResolutionStatus.RESOLVED),
        DependencyMethodContract("repository", "Repository", "mystery", None, (), resolution_status=ResolutionStatus.UNRESOLVED),
        DependencyMethodContract("repository", "Repository", "find", "Policy", ("String", "char"), resolution_status=ResolutionStatus.RESOLVED),
    )
    invocations = tuple(
        DependencyInvocation(
            invocation_id=f"execute(Policy)#{i}", caller_method_id="execute(Policy)",
            dependency_field="repository", dependency_type="Repository",
            method_name=contract.method_name, arguments=(), contract=contract,
        ) for i, contract in enumerate(contracts, 1)
    )
    method = MethodSig("execute", {"public"}, "Policy", [("Policy", "policy")])
    method_context = MethodExecutionContext(
        method_id="execute(Policy)", signature=method.render(), source_range=(1, 8),
        method_source="public Policy execute(Policy policy) { char localStatus = 'P'; return policy; }",
        endpoint=None, dependency_invocations=invocations,
        local_variables=(SimpleNamespace(name="localStatus"),),
        payload_schemas=(policy, bill, child, other, status),
        required_schema_ids=("sample.Policy", "sample.Bill", "sample.Child", "sample.OtherChild", "sample.PolicyStatus"),
        input_payload_types=("Policy",), output_payload_types=("Policy",),
        required_fixture_ids=("sample.Policy", "sample.Bill", "sample.Child", "sample.OtherChild"),
    )
    execution = ExecutionContext(
        ExecutionTargetKind.SERVICE_IMPL, "sample.SampleServiceImpl",
        methods=(method_context,), payload_schemas=(policy, bill, child, other, status),
        fixtures=fixtures,
        configuration_fields=(ConfigurationField("productType", "char", "product.type", "M", "'M'", "@Value", False),),
    )
    symbol = ClassSymbol(
        "SampleServiceImpl", "sample.SampleServiceImpl", "class", methods=[method],
        fields=[FieldSig("productType", "char", {"private"})],
    )
    ctx = GenerationContext(
        cut_source="private static final char POLICY_STATUS_PENDING = 'P';",
        symbol=symbol, collaborators=[], test_package="sample", test_class_name="SampleServiceImplTest",
        stack=StackProfile(java_version="17"),
        classpath=ClasspathProfile(has_junit_jupiter=True, has_mockito=True),
        template=TemplateSpec(JunitTestKind.PURE_UNIT, "unit"),
        source_path=Path("SampleServiceImpl.java"), execution_context=execution,
    )
    return ctx, method, method_context


def _test(body: str) -> str:
    return f"@Test void generated() {{\n{body}\n}}"


def _categories(source: str):
    ctx, method, method_context = _context()
    result = validate_serviceimpl_semantics(ctx, method, method_context, source)
    return {item.category for item in result.diagnostics}


@pytest.mark.parametrize("body,category", [
    ("Policy policy = validPolicy(); when(repository.flush()).thenReturn(policy); sampleServiceImpl.execute(policy);", SemanticCategory.VOID_THEN_RETURN.value),
    ("Policy policy = validPolicy(); doNothing().when(repository).saveAndFlush(policy); sampleServiceImpl.execute(policy);", SemanticCategory.NON_VOID_AS_VOID.value),
    ("Policy policy = validPolicy(); doNothing().when(repository).mystery(); sampleServiceImpl.execute(policy);", SemanticCategory.UNRESOLVED_AS_VOID.value),
    ("Policy policy = validPolicy(); policy.isActive(); sampleServiceImpl.execute(policy);", SemanticCategory.WRONG_GETTER.value),
    ("Policy policy = validPolicy(); when(repository.find(eq(\"x\"), 'P')).thenReturn(policy); sampleServiceImpl.execute(policy);", SemanticCategory.MATCHER_CONSISTENCY.value),
    ("Policy policy = validPolicy(); policy.setStatus(\"P\"); sampleServiceImpl.execute(policy);", SemanticCategory.SCALAR_TYPE.value),
    ("Policy policy = validPolicy(); policy.setStatus(1); sampleServiceImpl.execute(policy);", SemanticCategory.SCALAR_TYPE.value),
    ("Policy policy = validPolicy(); policy.setLoading(10.0); sampleServiceImpl.execute(policy);", SemanticCategory.SCALAR_TYPE.value),
    ("Policy policy = validPolicy(); policy.setAmount(10.0); sampleServiceImpl.execute(policy);", SemanticCategory.SCALAR_TYPE.value),
    ("Policy policy = validPolicy(); policy.setCode(BigDecimal.TEN); sampleServiceImpl.execute(policy);", SemanticCategory.SCALAR_TYPE.value),
    ("Policy policy = validPolicy(); policy.setBills(List.of(validBill())); sampleServiceImpl.execute(policy);", SemanticCategory.COLLECTION_FAMILY.value),
    ("Policy policy = validPolicy(); policy.setNames(Set.of(\"x\")); sampleServiceImpl.execute(policy);", SemanticCategory.COLLECTION_FAMILY.value),
    ("Policy policy = validPolicy(); policy.setBills(Set.of(\"x\")); sampleServiceImpl.execute(policy);", SemanticCategory.COLLECTION_ELEMENT.value),
    ("Policy policy = validPolicy(); policy.setPolicyStatus(PolicyStatus.UNKNOWN); sampleServiceImpl.execute(policy);", SemanticCategory.UNKNOWN_ENUM_CONSTANT.value),
    ("Policy policy = validPolicy(); policy.setMissing(1); sampleServiceImpl.execute(policy);", SemanticCategory.UNKNOWN_SETTER.value),
    ("Policy policy = validPolicy(); policy.getMissing(); sampleServiceImpl.execute(policy);", SemanticCategory.UNKNOWN_GETTER.value),
    ("Policy policy = validPolicy(); policy.missing(); sampleServiceImpl.execute(policy);", SemanticCategory.UNKNOWN_METHOD.value),
    ("Policy policy = validPolicy(); policy.missing = 1; sampleServiceImpl.execute(policy);", SemanticCategory.UNKNOWN_FIELD.value),
    ("Policy policy = validPolicy(); when(repository.find(anyString(), eq(productType))).thenReturn(policy); sampleServiceImpl.execute(policy);", SemanticCategory.PRIVATE_CUT_IDENTIFIER.value),
    ("Policy policy = validPolicy(); char x = localStatus; sampleServiceImpl.execute(policy);", SemanticCategory.PRODUCTION_IDENTIFIER.value),
    ("Policy policy = validPolicy(); InventedDto value = new InventedDto(); sampleServiceImpl.execute(policy);", SemanticCategory.INVENTED_APPLICATION_TYPE.value),
    ("Policy policy = validPolicy(); OtherChild other = validOtherChild(); policy.setChild(other); sampleServiceImpl.execute(policy);", SemanticCategory.WRONG_NESTED_TYPE.value),
    ("Policy policy = validPolicy(); assertThat(policy).isNotNull(); sampleServiceImpl.execute(policy);", SemanticCategory.ASSERTION_FRAMEWORK.value),
    ("Policy policy = new Policy(); sampleServiceImpl.execute(policy);", SemanticCategory.FIXTURE_CONSTRUCTION.value),
    ("Policy policy = validPolicy(); policy.setCode(\"x\"); sampleServiceImpl.execute(policy);", SemanticCategory.FIXTURE_MUTATION.value),
    ("Policy policy = Policy.builder().build(); sampleServiceImpl.execute(policy);", SemanticCategory.FIXTURE_CONSTRUCTION.value),
    ("Policy policy = validPolicy(); ReflectionTestUtils.setField(policy, \"code\", \"x\"); sampleServiceImpl.execute(policy);", SemanticCategory.FIXTURE_MUTATION.value),
])
def test_known_semantic_categories_are_rejected(body, category):
    assert category in _categories(_test(body))


def test_boolean_wrapper_uses_authoritative_getter_convention():
    ctx, method, method_context = _context()
    source = _test("Policy policy = validPolicy(); policy.getActive(); sampleServiceImpl.execute(policy);")
    assert validate_serviceimpl_semantics(ctx, method, method_context, source).ok


def test_deterministic_corrections_are_structured_and_source_backed():
    ctx, method, method_context = _context()
    source = _test("Policy policy = validPolicy(); policy.setStatus(\"P\"); Mockito.when(repository.find(any(String.class), eq(productType))).thenReturn(policy); sampleServiceImpl.execute(policy);")
    result = deterministically_correct_serviceimpl(ctx, method, method_context, source)
    assert "setStatus('P')" in result.source
    assert "when(repository.find(any(String.class), eq('M')))" in result.source
    assert result.actions
    assert all({"sequence", "timestamp", "diagnostic_category", "source_before", "source_after", "authoritative_contract", "result"} <= set(action) for action in result.actions)


def test_fixture_variant_is_compiled_then_reused_by_normalized_signature():
    ctx, method, method_context = _context()
    source = deterministically_correct_serviceimpl(ctx, method, method_context, _test("Policy policy = validPolicy();\npolicy.setStatus(\"P\");\nsampleServiceImpl.execute(policy);")).source
    calls = []
    first = augment_fixture_variant(ctx, source, compile_variant=lambda name, helper: (calls.append((name, helper)) or True, ()))
    assert first.accepted and first.variant and first.variant.scenario_variant
    second = augment_fixture_variant(ctx, source, compile_variant=lambda *_: (_ for _ in ()).throw(AssertionError("must reuse")))
    assert second.accepted and second.variant.method_name == first.variant.method_name
    assert len(calls) == 1


def test_fixture_variant_rejects_local_capture_and_unresolved_constant_scope():
    ctx, method, method_context = _context()
    local = _test("Policy policy = validPolicy();\nSet<Bill> bills = Set.of(validBill());\npolicy.setBills(bills);\nsampleServiceImpl.execute(policy);")
    result = augment_fixture_variant(ctx, local, compile_variant=lambda *_: (True, ()))
    assert not result.accepted and "bills" in result.reason
    bad_constant = _test("Policy policy = validPolicy();\npolicy.setStatus(UNKNOWN_STATUS);\nsampleServiceImpl.execute(policy);")
    result = augment_fixture_variant(ctx, bad_constant, compile_variant=lambda *_: (True, ()))
    assert not result.accepted and "UNKNOWN_STATUS" in result.reason


def test_transactional_variant_failure_is_isolated():
    ctx, method, method_context = _context()
    source = _test("Policy policy = validPolicy();\npolicy.setStatus('P');\nsampleServiceImpl.execute(policy);")
    before = len(ctx.execution_context.fixtures)
    failed = augment_fixture_variant(ctx, source, compile_variant=lambda *_: (False, ("javac failure",)))
    assert not failed.accepted and len(ctx.execution_context.fixtures) == before
    accepted = augment_fixture_variant(ctx, source, compile_variant=lambda *_: (True, ()))
    assert accepted.accepted and len(ctx.execution_context.fixtures) == before + 1


def test_generated_source_immutable_candidate_preserved_and_not_prematurely_committed():
    record = CaseRecord("execute(Policy)", "generated", generated_source="original")
    with pytest.raises(AttributeError):
        record.generated_source = "changed"
    outcome = TargetOutcome("sample.SampleServiceImpl", "sample", "x.java", "xTest.java", "unit", True)
    outcome.method_results = [MethodGenerationRecord("execute(Policy)", tests=[record])]
    source = "class X {\n@Test void generated() { assertTrue(true); }\n}"
    sync_test_registry_sources(outcome, source, accepted=False)
    assert record.candidate_source and record.latest_accepted_source == ""
    assert record.compile_state == "NOT_RUN"


def test_validated_variant_test_contains_no_fixture_mutation():
    ctx, method, method_context = _context()
    source = _test("Policy policy = validPolicy();\npolicy.setStatus('P');\nsampleServiceImpl.execute(policy);")
    augmented = augment_fixture_variant(ctx, source, compile_variant=lambda *_: (True, ()))
    assert augmented.accepted
    assert ".setStatus(" not in augmented.source
    assert validate_generated_test(ctx, method, method_context, augmented.source).ok


def test_focused_payload_contains_only_relevant_contracts_and_single_instruction_copy():
    ctx, method, method_context = _context()
    closure = SimpleNamespace(method_source=method_context.method_source, reachable_methods=())
    with patch.object(serviceimpl, "build_source_closure", return_value=closure):
        payload = json.loads(serviceimpl.build_generation_payload(ctx, method)[1]["content"])
    assert "general_instructions" in payload
    assert "relevant_fixture_contracts" in payload
    assert "relevant_collaborator_contracts" in payload
    assert "fixtures" not in payload and "collaborators" not in payload
    rendered = json.dumps(payload)
    assert rendered.count('"general_instructions"') == 1
    assert "complete semantic catalogue" not in rendered


def test_required_general_instruction_clauses_are_minimally_replaced():
    serviceimpl.validate_general_instructions_preserved()
    rendered = json.dumps(serviceimpl._GENERATION_INSTRUCTION)
    required = [
        "Select an existing compiled fixture variant or request one bounded fixture-augmentation attempt",
        "Do not mutate fixture-supported application DTOs or entities inside @Test methods",
        "Do not replace or mutate a compiled fixture graph inside an @Test method",
        "If no valid compiled fixture can provide the required state, do not select that path",
        "Required selected-path state must come from a compiled fixture variant",
        "Do not classify or stub an unresolved collaborator contract as void",
        "Use only the supplied authorised static Mockito APIs and imports",
    ]
    for clause in required:
        assert rendered.count(clause) == 1
    assert "Never stub, spy, verify, or directly invoke a same-class helper" in rendered
    assert "Output exactly one complete Java @Test method" in rendered


def test_allowed_standard_java_values_remain_legal():
    ctx, method, method_context = _context()
    source = _test(
        "Policy policy = validPolicy(); "
        "BigDecimal amount = BigDecimal.valueOf(10); "
        "List<String> names = List.of(\"A\"); "
        "Set<String> codes = Set.of(\"C\"); "
        "Map<String, Object> values = Map.of(\"k\", amount); "
        "Optional<String> optional = Optional.of(\"x\"); "
        "sampleServiceImpl.execute(policy);"
    )
    assert validate_serviceimpl_semantics(ctx, method, method_context, source).ok


def test_fixture_supported_mock_or_spy_is_rejected_as_data_setup():
    categories = _categories(_test("Policy policy = mock(Policy.class); sampleServiceImpl.execute(policy);"))
    assert SemanticCategory.FIXTURE_DATA_MOCK.value in categories


def test_mockito_qualification_and_primitive_matcher_are_normalized():
    ctx, method, method_context = _context()
    source = _test(
        "Policy policy = validPolicy(); "
        "Mockito.when(repository.find(Mockito.any(String.class), Mockito.any(char.class))).thenReturn(policy); "
        "sampleServiceImpl.execute(policy);"
    )
    result = deterministically_correct_serviceimpl(ctx, method, method_context, source)
    assert "Mockito.when" not in result.source
    assert "Mockito.any" not in result.source
    assert "anyChar()" in result.source


def test_focused_validation_repair_payload_contains_one_method_only():
    ctx, method, method_context = _context()
    messages = serviceimpl.build_validation_repair_payload(
        ctx,
        method,
        _test("Policy policy = validPolicy(); policy.setMissing(1); sampleServiceImpl.execute(policy);"),
        "generated",
        [{"category": "unknown_setter", "message": "setMissing does not exist"}],
    )
    payload = json.loads(messages[1]["content"])
    assert payload["request_type"] == "focused_method_generation_repair"
    assert payload["invalid_test"]["test_name"] == "generated"
    assert "test_class" not in payload
    assert payload["repair_instructions"]["attempts"] == 1


def test_synthetic_compiled_fixture_variant_java_source(tmp_path):
    import shutil
    import subprocess

    javac = shutil.which("javac")
    if javac is None:
        pytest.skip("javac is unavailable")
    ctx, method, method_context = _context()
    source = _test("Policy policy = validPolicy();\npolicy.setStatus('P');\nsampleServiceImpl.execute(policy);")
    augmented = augment_fixture_variant(ctx, source, compile_variant=lambda *_: (True, ()))
    assert augmented.variant is not None
    helper = augmented.variant.method_source.replace("    private", "    private")
    java = (
        "public class VariantHarness {\n"
        "    static class Policy { void setStatus(Character value) {} }\n"
        "    private Policy validPolicy() { return new Policy(); }\n"
        f"{helper}\n"
        "}\n"
    )
    source_path = tmp_path / "VariantHarness.java"
    source_path.write_text(java, encoding="utf-8")
    completed = subprocess.run(
        [javac, str(source_path)],
        cwd=tmp_path,
        text=True,
        capture_output=True,
        check=False,
    )
    assert completed.returncode == 0, completed.stderr
