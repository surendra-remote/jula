from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from junitforge.audit import NullAuditRecorder
from junitforge.compilation.diagnostic_mapper import (
    DiagnosticScope,
    group_errors_by_test,
    map_compile_diagnostics,
)
from junitforge.compilation.provider_response import (
    FocusedProviderMetadata,
    identical_rejected_response,
    provider_metadata,
    request_hash,
    response_hash,
)
from junitforge.compilation.repair_coordinator import CompilationRepairMixin
from junitforge.compile_gate import parse_maven_compiler_errors
from junitforge.execution.models import ConfigurationField, ConfigurationRequirement
from junitforge.compilation.response_normalizer import normalize_focused_test_response
from junitforge.generation.payloads import serviceimpl
from junitforge.models import (
    ClassSymbol,
    CompileError,
    FieldSig,
    CompileState,
    MethodGenerationRecord,
    ModuleInfo,
    TargetOutcome,
    TestCaseRecord as _TestCaseRecord,
    TestDisposition as _TestDisposition,
)
from junitforge.registry import (
    RegistryStore,
    load_registry,
    recalculate_registry_ranges,
)
from junitforge.vendor.llm.base import LLMResponse, TokenUsage


def _source() -> str:
    return """package sample;
import java.util.List;
class SampleServiceImplTest {
    private Object field;

    @BeforeEach
    void setUp() {
        field = new Object();
    }

    Object validObject() {
        return new Object();
    }

    // JUNITFORGE_METHOD_BEGIN: execute(String)
    @Test
    void first() {
        Object value = validObject();
        assertNotNull(value);
    }

    @Test
    void second() {
        assertTrue(true);
    }
    // JUNITFORGE_METHOD_END: execute(String)
}
"""


def _outcome(tmp_path: Path) -> tuple[TargetOutcome, TestCaseRecord, TestCaseRecord]:
    first = _TestCaseRecord(
        "execute(String)",
        "first",
        generated_source="@Test\nvoid first() { Object value = validObject(); assertNotNull(value); }",
        final_disposition=_TestDisposition.RETAINED.value,
    )
    second = _TestCaseRecord(
        "execute(String)",
        "second",
        generated_source="@Test\nvoid second() { assertTrue(true); }",
        final_disposition=_TestDisposition.RETAINED.value,
    )
    outcome = TargetOutcome(
        "sample.SampleServiceImpl",
        "sample",
        "SampleServiceImpl.java",
        "SampleServiceImplTest.java",
        "service-impl",
        True,
        registry_path=str(tmp_path / "07-class-assembly" / "registry.json"),
        method_results=[MethodGenerationRecord("execute(String)", tests=[first, second])],
    )
    recalculate_registry_ranges(outcome, _source(), fixture_method_names=("validObject",))
    return outcome, first, second


def _line(source: str, token: str) -> int:
    return next(i for i, value in enumerate(source.splitlines(), start=1) if token in value)


def _error(source: str, token: str, message: str = "cannot find symbol") -> CompileError:
    return CompileError(Path("SampleServiceImplTest.java"), _line(source, token), 5, message)


def test_01_correct_diagnostic_to_test_mapping_uses_stable_test_id(tmp_path: Path) -> None:
    outcome, first, _second = _outcome(tmp_path)
    ownership = map_compile_diagnostics(outcome, [_error(_source(), "Object value")])
    assert list(ownership.by_test) == [first.test_id]
    assert ownership.by_test[first.test_id][0].test_name == "first"


def test_02_multiple_errors_are_grouped_into_one_test_repair_unit(tmp_path: Path) -> None:
    outcome, first, _second = _outcome(tmp_path)
    errors = [
        _error(_source(), "Object value"),
        _error(_source(), "assertNotNull", "incompatible types"),
    ]
    grouped = group_errors_by_test(outcome, errors)
    assert list(grouped) == [first.test_id]
    assert len(grouped[first.test_id]) == 2


def test_03_line_ranges_recalculate_after_reassembly(tmp_path: Path) -> None:
    outcome, first, _second = _outcome(tmp_path)
    before = (first.source_start_line, first.source_end_line)
    shifted = "// inserted\n// inserted again\n" + _source()
    recalculate_registry_ranges(outcome, shifted, fixture_method_names=("validObject",))
    assert first.source_start_line == before[0] + 2
    assert first.source_end_line == before[1] + 2
    persisted = json.loads(Path(outcome.registry_path).read_text(encoding="utf-8"))
    assert persisted["source_ranges"]["fixtures"][0]["name"] == "validObject"
    assert persisted["assembled_source_hash"] == outcome.registry_source_hash


def test_04_fixture_diagnostic_classification(tmp_path: Path) -> None:
    outcome, _first, _second = _outcome(tmp_path)
    ownership = map_compile_diagnostics(outcome, [_error(_source(), "return new Object")])
    assert len(ownership.fixture) == 1
    assert ownership.fixture[0].scope == DiagnosticScope.FIXTURE.value


def test_05_skeleton_diagnostic_classification(tmp_path: Path) -> None:
    outcome, _first, _second = _outcome(tmp_path)
    ownership = map_compile_diagnostics(outcome, [_error(_source(), "field =")])
    assert len(ownership.skeleton) == 1
    assert ownership.skeleton[0].range_name == "setUp"


def test_06_class_import_diagnostic_classification(tmp_path: Path) -> None:
    outcome, _first, _second = _outcome(tmp_path)
    ownership = map_compile_diagnostics(outcome, [_error(_source(), "import java.util.List")])
    assert len(ownership.import_class) == 1


def test_07_assembly_diagnostic_classification_has_priority(tmp_path: Path) -> None:
    outcome, _first, _second = _outcome(tmp_path)
    error = _error(_source(), "assertNotNull", "reached end of file while parsing")
    ownership = map_compile_diagnostics(outcome, [error])
    assert len(ownership.assembly) == 1
    assert not ownership.by_test


def test_08_unmapped_diagnostics_remain_unmapped(tmp_path: Path) -> None:
    outcome, _first, _second = _outcome(tmp_path)
    error = CompileError(Path("SampleServiceImplTest.java"), 999, 1, "cannot find symbol")
    ownership = map_compile_diagnostics(outcome, [error])
    assert len(ownership.unmapped) == 1
    assert not ownership.by_test


class _Harness(CompilationRepairMixin):
    def __init__(self, deterministic_source: str | None, llm_source: str | None):
        self.deterministic_source = deterministic_source
        self.llm_source = llm_source
        self.cfg = SimpleNamespace(temperature_repair=0.0, max_tokens_repair=256)
        self.audit = NullAuditRecorder()
        self.compile_calls: list[str] = []
        self.llm = object()

    def _compile_candidate(self, test_path, module):
        source = Path(test_path).read_text(encoding="utf-8")
        self.compile_calls.append(source)
        bad_line = next((i for i, line in enumerate(source.splitlines(), 1) if "BAD" in line), None)
        ok = bad_line is None
        result = SimpleNamespace(ok=ok, return_code=0 if ok else 1, stdout="", stderr="", cmd=["javac"])
        errors = [] if ok else [CompileError(Path(test_path), bad_line, 1, "cannot find symbol")]
        return result, errors

    def _deterministic_focused_candidate(self, ctx, test_record, diagnostics):
        if self.deterministic_source is None:
            return None, [], "no deterministic correction"
        return self.deterministic_source, [{"action": "synthetic deterministic repair"}], "VALID"

    def _focused_llm_response(self, *, ctx, outcome, test_record, diagnostics):
        outcome.focused_compile_repair_attempts += 1
        metadata = FocusedProviderMetadata(
            response_state="COMPLETED",
            finish_reason="stop",
            input_token_count=10,
            output_token_count=20,
            response_size=len(self.llm_source or ""),
            request_hash="request",
            response_hash=response_hash(self.llm_source),
            truncation_state="NOT_TRUNCATED",
            normalization_result="RAW_JAVA_ACCEPTED" if self.llm_source else "REJECTED",
            rejection_reason=None if self.llm_source else "empty",
        )
        return self.llm_source, metadata, "VALID" if self.llm_source else "empty"


def _integration(
    tmp_path: Path,
    *,
    deterministic_source: str | None,
    llm_source: str | None,
):
    bad_test = "@Test\nvoid broken() {\n    BAD value;\n}"
    source = """class SampleServiceImplTest {
// JUNITFORGE_METHOD_BEGIN: execute()
@Test
void broken() {
    BAD value;
}
// JUNITFORGE_METHOD_END: execute()
}
"""
    record = _TestCaseRecord(
        "execute()",
        "broken",
        generated_source=bad_test,
        final_disposition=_TestDisposition.RETAINED.value,
    )
    outcome = TargetOutcome(
        "sample.SampleServiceImpl",
        "sample",
        "SampleServiceImpl.java",
        str(tmp_path / "SampleServiceImplTest.java"),
        "service-impl",
        True,
        registry_path=str(tmp_path / "registry.json"),
        method_results=[MethodGenerationRecord("execute()", tests=[record])],
    )
    test_path = Path(outcome.test_path)
    test_path.write_text(source, encoding="utf-8")
    ctx = SimpleNamespace(
        symbol=ClassSymbol("SampleServiceImpl", "sample.SampleServiceImpl", "class", methods=[]),
        execution_context=SimpleNamespace(fixtures=(), methods=()),
    )
    recalculate_registry_ranges(outcome, source)
    initial_error = _error(source, "BAD value")
    harness = _Harness(deterministic_source, llm_source)
    result = harness._compile_registry_focused_repair(
        ctx,
        test_path,
        ModuleInfo("sample", tmp_path, tmp_path / "pom.xml"),
        outcome,
        [initial_error],
    )
    return harness, outcome, record, result, test_path


def test_09_complete_class_serviceimpl_repair_is_disabled(tmp_path: Path) -> None:
    harness = _Harness(None, None)
    outcome, _first, _second = _outcome(tmp_path)
    with pytest.raises(RuntimeError, match="disabled"):
        harness._disabled_complete_class_serviceimpl_repair()
    assert outcome.complete_class_serviceimpl_llm_repair_attempts == 0


def test_10_deterministic_candidate_commits_only_after_compile_success(tmp_path: Path) -> None:
    good = "@Test\nvoid broken() {\n    int value = 1;\n    assertTrue(value == 1);\n}"
    harness, outcome, record, result, _path = _integration(
        tmp_path, deterministic_source=good, llm_source=None
    )
    assert result is not None
    assert record.latest_accepted_source == good
    assert record.compile_state == CompileState.REPAIRED_AND_PASSED.value
    assert record.generated_source != record.latest_accepted_source
    assert harness.compile_calls


def test_11_deterministic_candidate_rolls_back_on_compile_failure(tmp_path: Path) -> None:
    bad = "@Test\nvoid broken() {\n    BAD stillBroken;\n}"
    good_llm = "@Test\nvoid broken() {\n    assertTrue(true);\n}"
    _harness, _outcome, record, result, _path = _integration(
        tmp_path, deterministic_source=bad, llm_source=good_llm
    )
    assert result is not None
    assert record.latest_accepted_source == good_llm
    assert any(item.get("decision") == "ROLLBACK" for item in record.compile_attempts if isinstance(item, dict))


def test_12_llm_candidate_commit(tmp_path: Path) -> None:
    good = "@Test\nvoid broken() {\n    assertTrue(true);\n}"
    _harness, outcome, record, result, _path = _integration(
        tmp_path, deterministic_source=None, llm_source=good
    )
    assert result is not None
    assert record.latest_accepted_source == good
    assert outcome.focused_compile_repair_attempts == 1


def test_13_llm_candidate_rollback_and_explicit_removal(tmp_path: Path) -> None:
    bad = "@Test\nvoid broken() {\n    BAD remains;\n}"
    _harness, outcome, record, result, path = _integration(
        tmp_path, deterministic_source=None, llm_source=bad
    )
    assert result is not None  # salvaged empty class compiles
    assert record.latest_accepted_source == ""
    assert record.candidate_source == ""
    assert record.compile_state == CompileState.REMOVED.value
    assert "void broken" not in path.read_text(encoding="utf-8")
    assert outcome.focused_compile_repair_attempts == 1


def test_14_generated_source_remains_immutable_during_repair(tmp_path: Path) -> None:
    good = "@Test\nvoid broken() { assertTrue(true); }"
    _harness, _outcome, record, _result, _path = _integration(
        tmp_path, deterministic_source=good, llm_source=None
    )
    assert "BAD value" in record.generated_source


def test_15_latest_accepted_source_not_updated_before_compile_success(tmp_path: Path) -> None:
    bad = "@Test\nvoid broken() { BAD candidate; }"
    _harness, _outcome, record, _result, _path = _integration(
        tmp_path, deterministic_source=bad, llm_source=None
    )
    assert record.latest_accepted_source == ""


def test_16_complete_outer_fence_normalization() -> None:
    result = normalize_focused_test_response(
        "```java\n@Test void exact() { assertTrue(true); }\n```",
        expected_test_name="exact",
    )
    assert result.accepted and result.outer_fence_removed


@pytest.mark.parametrize(
    "response,reason",
    [
        ("```java\n@Test void exact() {}", "probable truncation"),
        ("```java\n@Test void exact() {}\n```\n```", "multiple"),
        ("prose\n```java\n@Test void exact() {}\n```", "prose"),
    ],
)
def test_17_to_19_fence_and_prose_rejections(response: str, reason: str) -> None:
    result = normalize_focused_test_response(response, expected_test_name="exact")
    assert not result.accepted
    assert reason in (result.rejection_reason or "").lower()


def test_20_truncation_detection_for_unbalanced_java() -> None:
    result = normalize_focused_test_response(
        "@Test void exact() { assertTrue(true);",
        expected_test_name="exact",
    )
    assert not result.accepted and result.probable_truncation


def test_21_wrong_test_identity_rejection() -> None:
    result = normalize_focused_test_response(
        "@Test void renamed() { assertTrue(true); }",
        expected_test_name="exact",
    )
    assert not result.accepted and "wrong test identity" in (result.rejection_reason or "")


def test_22_provider_response_metadata_persists(tmp_path: Path) -> None:
    response = LLMResponse(
        "@Test void exact() {}",
        usage=TokenUsage(11, 7, 18),
        raw={"choices": [{"finish_reason": "stop"}], "status": "completed"},
    )
    digest = request_hash([{"role": "user", "content": "x"}], temperature=0.0, max_tokens=50)
    metadata = provider_metadata(response, request_digest=digest)
    outcome, first, _second = _outcome(tmp_path)
    RegistryStore(outcome).append_history(
        first,
        "llm_repair_history",
        {"provider_metadata": metadata.to_dict(), "status": "accepted"},
    )
    loaded = load_registry(Path(outcome.registry_path))[0].tests[0]
    persisted = loaded.llm_repair_history[-1]["provider_metadata"]
    assert persisted["input_token_count"] == 11
    assert persisted["output_token_count"] == 7
    assert persisted["finish_reason"] == "stop"
    assert persisted["response_size"] == len(response.message.encode("utf-8"))
    assert persisted["request_hash"] == digest
    assert persisted["response_hash"] == response_hash(response.message)
    assert persisted["truncation_state"] == "NOT_TRUNCATED"
    assert persisted["raw_provider_response"]["status"] == "completed"


def test_23_request_and_response_hashing_is_deterministic() -> None:
    messages = [{"role": "user", "content": "repair"}]
    assert request_hash(messages, temperature=0.0, max_tokens=100) == request_hash(
        messages, temperature=0.0, max_tokens=100
    )
    assert response_hash("a\r\nb") == response_hash("a\nb")


def test_24_identical_rejected_response_stops() -> None:
    history = [{
        "status": "rejected",
        "provider_metadata": {
            "request_hash": "request",
            "response_hash": "response",
            "rejection_reason": "wrong identity",
        },
    }]
    assert identical_rejected_response(
        history, request_digest="request", response_digest="response"
    ) == "wrong identity"


def test_25_append_only_compile_history(tmp_path: Path) -> None:
    good = "@Test\nvoid broken() { assertTrue(true); }"
    _harness, outcome, record, _result, _path = _integration(
        tmp_path, deterministic_source=good, llm_source=None
    )
    assert len(outcome.compile_history) >= 2
    assert record.compile_attempts
    assert [item["attempt_number"] for item in outcome.compile_history] == sorted(
        item["attempt_number"] for item in outcome.compile_history
    )


def _payload_context():
    method = SimpleNamespace(name="execute", params=[], render=lambda: "public Object execute()")
    method_context = SimpleNamespace(
        method_id="execute()",
        method_source="public Object execute() { return new Object(); }",
        required_fixture_ids=(),
        required_schema_ids=(),
        input_payload_types=(),
        output_payload_types=(),
        payload_schemas=(),
        configuration_requirements=(),
        dependency_invocations=(),
    )
    ctx = SimpleNamespace(
        symbol=SimpleNamespace(fqcn="sample.SampleServiceImpl", name="SampleServiceImpl"),
        test_class_name="SampleServiceImplTest",
        source_imports=("java.util.List", "java.util.Map"),
        execution_context=SimpleNamespace(
            methods=(method_context,),
            fixtures=(),
            configuration_fields=(),
        ),
    )
    return ctx, method


def test_26_focused_payload_excludes_unrelated_complete_class_content() -> None:
    ctx, method = _payload_context()
    test_source = "@Test void exact() { List<String> value = List.of(); assertNotNull(value); }"
    error = CompileError(Path("SampleServiceImplTest.java"), 20, 1, "incompatible types")
    messages = serviceimpl.build_compile_repair_payload(
        ctx,
        test_source,
        [error],
        method=method,
        test_name="exact",
        test_id="execute()::exact",
        mode="individual",
    )
    payload = json.loads(messages[1]["content"])
    rendered = messages[1]["content"]
    assert payload["current_test_source"] == test_source
    assert "UNRELATED_COMPLETE_CLASS_SENTINEL" not in rendered
    assert "test_class" not in payload
    assert payload["authorised_imports"] == ["java.util.List"]


def test_27_preserved_nonduplicated_general_instructions() -> None:
    ctx, method = _payload_context()
    messages = serviceimpl.build_compile_repair_payload(
        ctx,
        "@Test void exact() { assertTrue(true); }",
        [CompileError(Path("SampleServiceImplTest.java"), 1, 1, "cannot find symbol")],
        method=method,
        test_name="exact",
        test_id="execute()::exact",
        mode="individual",
    )
    payload = json.loads(messages[1]["content"])
    assert list(key for key in payload if key == "general_instructions") == ["general_instructions"]
    expected = json.loads(json.dumps(serviceimpl._GENERATION_INSTRUCTION))
    actual = payload["general_instructions"]
    expected["objective"]["requested_test_kind"] = "focused_compile_repair"
    assert actual == expected
    assert payload["approved_compile_repair_additions"]["attempt_limit"] == 1
    assert "current_test_source" not in json.dumps(actual)
    assert "relevant_fixture_contracts" not in json.dumps(actual)


def test_28_unmatched_closing_fence_is_not_classified_as_truncation() -> None:
    result = normalize_focused_test_response(
        "@Test void exact() { assertTrue(true); }\n```",
        expected_test_name="exact",
    )
    assert not result.accepted
    assert not result.probable_truncation
    assert "unmatched closing" in (result.rejection_reason or "")


def test_29_focused_llm_attempt_limit_is_persisted_per_test(tmp_path: Path) -> None:
    harness = _Harness(None, "@Test void broken() { assertTrue(true); }")
    record = _TestCaseRecord(
        "execute()",
        "broken",
        generated_source="@Test void broken() { BAD value; }",
        final_disposition=_TestDisposition.RETAINED.value,
        llm_repair_history=[{
            "action": "focused_compile_repair_response",
            "status": "rejected",
        }],
    )
    outcome = TargetOutcome(
        "sample.SampleServiceImpl", "sample", "SampleServiceImpl.java",
        str(tmp_path / "SampleServiceImplTest.java"), "service-impl", True,
        method_results=[MethodGenerationRecord("execute()", tests=[record])],
    )
    ctx = SimpleNamespace(
        symbol=ClassSymbol("SampleServiceImpl", "sample.SampleServiceImpl", "class", methods=[]),
        execution_context=SimpleNamespace(fixtures=(), methods=()),
    )
    source, metadata, state = CompilationRepairMixin._focused_llm_response(
        harness, ctx=ctx, outcome=outcome, test_record=record, diagnostics=[]
    )
    assert source is None and metadata is None
    assert state == "owner production method context unavailable"
    # The real attempt-limit path is checked after authoritative owner resolution.
    method = SimpleNamespace(name="execute", params=[], render=lambda: "public void execute()")
    method_context = SimpleNamespace(method_id="execute()")
    ctx.symbol.methods = [method]
    ctx.execution_context.methods = (method_context,)
    source, metadata, state = CompilationRepairMixin._focused_llm_response(
        harness, ctx=ctx, outcome=outcome, test_record=record, diagnostics=[]
    )
    assert source is None and metadata is None
    assert state == "FOCUSED_LLM_ATTEMPT_LIMIT_REACHED"
    assert outcome.focused_compile_repair_attempts == 0


def test_30_compiler_parser_retains_all_diagnostics_details_and_raw_text() -> None:
    log = """[ERROR] C:/repo/SampleServiceImplTest.java:[10,7] cannot find symbol
[ERROR]   symbol:   variable missing
[ERROR]   location: class SampleServiceImplTest
[ERROR] C:/repo/SampleServiceImplTest.java:[20,3] incompatible types: java.lang.String cannot be converted to int
[ERROR]   required: int
[ERROR]   found:    java.lang.String
"""
    errors = parse_maven_compiler_errors(log)
    assert len(errors) == 2
    assert errors[0].line == 10 and errors[0].col == 7
    assert errors[0].diagnostic_category == "cannot_find_symbol"
    assert errors[0].detail == [
        "symbol: variable missing",
        "location: class SampleServiceImplTest",
    ]
    assert "symbol:" in errors[0].raw and "location:" in errors[0].raw
    assert errors[1].diagnostic_category == "incompatible_types"
    assert errors[1].detail == ["required: int", "found: java.lang.String"]


def test_31_constants_and_configuration_values_are_not_duplicated() -> None:
    ctx, method = _payload_context()
    ctx.symbol.fields = [
        FieldSig(
            "MAX_RETRIES",
            "int",
            modifiers={"private", "static", "final"},
            initializer="3",
        )
    ]
    ctx.execution_context.configuration_fields = (
        ConfigurationField("timeoutMs", "long", "service.timeout", None, "5000L", "@Value"),
    )
    ctx.execution_context.methods[0].configuration_requirements = (
        ConfigurationRequirement("timeoutMs", "timeoutMs > 0"),
    )
    source = "@Test void exact() { assertTrue(MAX_RETRIES > 0); assertTrue(timeoutMs > 0); }"
    messages = serviceimpl.build_compile_repair_payload(
        ctx,
        source,
        [CompileError(Path("SampleServiceImplTest.java"), 1, 1, "cannot find symbol")],
        method=method,
        test_name="exact",
        test_id="execute()::exact",
        source_start_line=1,
        mode="individual",
    )
    payload = json.loads(messages[1]["content"])
    constant_names = {item["name"] for item in payload["relevant_constants"]}
    configuration_names = {item["name"] for item in payload["relevant_configuration_values"]}
    assert constant_names == {"MAX_RETRIES"}
    assert configuration_names == {"timeoutMs"}
    assert constant_names.isdisjoint(configuration_names)
