from __future__ import annotations

import logging
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from junitforge.config import GenConfig
from junitforge.loop import Engine
from junitforge.models import CompileError


class CompileRepairLoggingTest(unittest.TestCase):
    def test_methodwise_repair_logs_unmapped_header_error(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            engine = Engine(
                llm=None,
                compile_gate=None,
                coverage_runner=None,
                stack=None,
                modules=[],
                repo_root=root,
                lookup=lambda _: None,
                cfg=GenConfig(),
            )
            outcome = SimpleNamespace(notes=[])
            errors = [
                CompileError(
                    file=root / "GeneratedTest.java",
                    line=2,
                    col=None,
                    message="cannot find symbol",
                    detail=["symbol: class MissingType"],
                )
            ]
            current = "import sample.MissingType;\nclass GeneratedTest {}\n"

            with self.assertLogs("junitforge.loop", level=logging.DEBUG) as captured:
                repaired = engine._repair_methodwise_error_batch(
                    SimpleNamespace(),
                    current,
                    errors,
                    outcome,
                    label="method compile repair 1",
                )

        self.assertIsNone(repaired)
        output = "\n".join(captured.output)
        self.assertIn("diagnostic.map", output)
        self.assertIn("<outside-generated-method-block>", output)
        self.assertIn("stop.unmapped", output)
        self.assertTrue(any("outside any generated method block" in note for note in outcome.notes))


if __name__ == "__main__":
    unittest.main()
