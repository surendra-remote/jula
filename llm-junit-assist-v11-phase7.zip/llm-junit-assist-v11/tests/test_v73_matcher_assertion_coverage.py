from __future__ import annotations

import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from junitforge.config import load_config
from junitforge.coverage_run import CoverageRunner, parse_coverage_signals
from junitforge.execution.analyzer import _infer_argument
from junitforge.execution.assembly import (
    normalize_simple_assertj_assertions,
    normalize_writable_map_mutations,
    validate_method_block,
)
from junitforge.execution.models import (
    ArgumentOriginKind,
    ConfigurationField,
    DependencyRef,
    ExecutionContext,
    ExecutionTargetKind,
    InvocationArgument,
    MethodExecutionContext,
    ResolutionStatus,
)
from junitforge.execution.stub_planner import plan_argument
from junitforge.models import (
    ClassSymbol,
    ClasspathProfile,
    FieldSig,
    GenerationContext,
    MethodSig,
    ModuleInfo,
    StackProfile,
    TemplateSpec,
    TestKind,
)
from junitforge.prompts.augmentation import _global_rules_block
from junitforge.prompts.generation import build_method_generation_messages
from junitforge.prompts.repair import _deterministic_repair_rules


class MatcherOriginRegressionTest(unittest.TestCase):
    def test_private_cut_char_field_is_not_test_scope_available(self) -> None:
        argument = _infer_argument(
            "producType",
            {},
            {"producType": "char"},
            lambda _name: None,
            argument_index=2,
            cut_field_details={"producType": ("char", True, False, None)},
            cut_owner="PaymentServiceImpl",
        )
        self.assertEqual(ArgumentOriginKind.PRIVATE_CUT_FIELD, argument.origin_kind)
        self.assertFalse(argument.test_scope_available)
        self.assertFalse(argument.scenario_relevant)
        self.assertIsNone(argument.verified_test_expression)

    def test_scenario_irrelevant_private_char_field_uses_any_char(self) -> None:
        argument = InvocationArgument(
            expression="producType",
            inferred_type="char",
            origin_kind=ArgumentOriginKind.PRIVATE_CUT_FIELD,
            origin_owner="PaymentServiceImpl",
            test_scope_available=False,
            scenario_relevant=False,
        )
        plan = plan_argument(2, argument, "char")
        self.assertEqual("matcher", plan.strategy)
        self.assertEqual("anyChar()", plan.rendered)

    def test_exact_configuration_value_can_use_verified_test_expression(self) -> None:
        argument = InvocationArgument(
            expression="producType",
            inferred_type="char",
            origin_kind=ArgumentOriginKind.CONFIGURATION_FIELD,
            origin_owner="PaymentServiceImpl",
            test_scope_available=True,
            scenario_relevant=True,
            verified_test_expression="'M'",
        )
        plan = plan_argument(2, argument, "char")
        self.assertEqual("exact", plan.strategy)
        self.assertEqual("eq('M')", plan.rendered)

    def test_fixture_getter_expression_remains_exact(self) -> None:
        argument = _infer_argument(
            "policy.getPolicyNo()",
            {"policy": "GiPolicyEntity"},
            {"policy": "GiPolicyEntity"},
            lambda name: ClassSymbol(
                "GiPolicyEntity",
                "sample.GiPolicyEntity",
                "class",
                methods=[MethodSig("getPolicyNo", modifiers={"public"}, return_type="String")],
            ) if name == "GiPolicyEntity" else None,
            argument_index=0,
            cut_field_details={},
            cut_owner="PaymentServiceImpl",
        )
        self.assertEqual(ArgumentOriginKind.FIXTURE_GETTER_EXPRESSION, argument.origin_kind)
        self.assertTrue(argument.test_scope_available)
        self.assertEqual("eq(policy.getPolicyNo())", plan_argument(0, argument, "String").rendered)

    def test_primitive_any_matcher_is_normalized(self) -> None:
        block = "when(repo.find(any(char.class), any(int.class))).thenReturn(null);"
        normalized = normalize_writable_map_mutations(block)
        self.assertIn("anyChar()", normalized)
        self.assertIn("anyInt()", normalized)
        self.assertNotIn("any(char.class)", normalized)

    def _validation_context(self) -> tuple[GenerationContext, MethodSig, MethodExecutionContext]:
        method = MethodSig("execute", modifiers={"public"}, return_type="void")
        method_context = MethodExecutionContext(
            method_id="execute()",
            signature=method.render(),
            source_range=(1, 2),
            method_source="public void execute() {}",
            endpoint=None,
        )
        dependency = DependencyRef(
            "repo", None, "Repo", "Repo", "sample.Repo", "field", ResolutionStatus.RESOLVED
        )
        execution = ExecutionContext(
            target_kind=ExecutionTargetKind.SERVICE_IMPL,
            target_fqcn="sample.PaymentServiceImpl",
            dependencies=(dependency,),
            configuration_fields=(
                ConfigurationField(
                    field_name="producType",
                    type_name="char",
                    property_key="product.type",
                    default_value="M",
                    test_value="'M'",
                    annotation_expr='@Value("${product.type:M}")',
                ),
            ),
            methods=(method_context,),
        )
        symbol = ClassSymbol(
            "PaymentServiceImpl",
            "sample.PaymentServiceImpl",
            "class",
            modifiers={"public"},
            fields=[
                FieldSig("repo", "Repo", modifiers={"private"}),
                FieldSig("producType", "char", modifiers={"private"}, annotations=["Value"]),
            ],
            methods=[method],
        )
        ctx = GenerationContext(
            cut_source="",
            symbol=symbol,
            collaborators=[],
            test_package="sample",
            test_class_name="PaymentServiceImplTest",
            stack=StackProfile(),
            classpath=ClasspathProfile(),
            template=TemplateSpec(TestKind.PURE_UNIT, "unit"),
            source_path=Path("PaymentServiceImpl.java"),
            source_imports=[],
            execution_context=execution,
        )
        return ctx, method, method_context

    def test_unqualified_private_cut_field_is_rejected(self) -> None:
        ctx, method, method_context = self._validation_context()
        block = """
        @Test void badScope() {
            assertEquals('M', producType);
            paymentServiceImpl.execute();
        }
        """
        result = validate_method_block(ctx, method, method_context, block, set())
        self.assertFalse(result.ok)
        self.assertIn("not available in generated test scope", result.reason)
        self.assertIn("anyChar()", result.reason)

    def test_direct_private_cut_field_access_is_rejected(self) -> None:
        ctx, method, method_context = self._validation_context()
        block = """
        @Test void badDirectAccess() {
            assertEquals('M', paymentServiceImpl.producType);
            paymentServiceImpl.execute();
        }
        """
        result = validate_method_block(ctx, method, method_context, block, set())
        self.assertFalse(result.ok)
        self.assertIn("CUT field", result.reason)

    def test_declared_test_local_product_type_is_allowed(self) -> None:
        ctx, method, method_context = self._validation_context()
        block = """
        @Test void localScope() {
            char producType = 'M';
            assertEquals('M', producType);
            paymentServiceImpl.execute();
        }
        """
        result = validate_method_block(ctx, method, method_context, block, set())
        self.assertTrue(result.ok, result.reason)


class AssertionFrameworkRegressionTest(unittest.TestCase):
    def test_equal_to_is_normalized_to_junit(self) -> None:
        source = "assertThat(actual).isEqualTo(expected);"
        self.assertEqual(
            "assertEquals(expected, actual);",
            normalize_simple_assertj_assertions(source),
        )

    def test_is_empty_is_normalized_to_junit(self) -> None:
        source = "assertThat(actual).isEmpty();"
        self.assertEqual(
            "assertTrue(actual.isEmpty());",
            normalize_simple_assertj_assertions(source),
        )

    def test_has_size_is_normalized_to_junit(self) -> None:
        source = "assertThat(actual).hasSize(2);"
        self.assertEqual(
            "assertEquals(2, actual.size());",
            normalize_simple_assertj_assertions(source),
        )

    def test_complex_assertj_chain_is_not_normalized(self) -> None:
        source = "assertThat(actual).extracting(Item::getId).containsExactly(1L);"
        self.assertEqual(source, normalize_simple_assertj_assertions(source))

    def test_complex_assertj_chain_is_rejected(self) -> None:
        ctx, method, method_context = MatcherOriginRegressionTest()._validation_context()
        block = """
        @Test void unsupportedAssertion() {
            paymentServiceImpl.execute();
            assertThat(items).extracting(Item::getId).containsExactly(1L);
        }
        """
        result = validate_method_block(ctx, method, method_context, block, set())
        self.assertFalse(result.ok)
        self.assertIn("Unsupported assertion framework", result.reason)

    def test_generation_and_repair_prompts_preserve_junit_only_rule(self) -> None:
        ctx, method, _method_context = MatcherOriginRegressionTest()._validation_context()
        prompt = build_method_generation_messages(ctx, method, "")[1]["content"]
        self.assertIn("Do not use AssertJ", prompt)
        self.assertIn("production-only locals or private CUT fields", prompt)
        repair = _deterministic_repair_rules()
        self.assertIn("Do not use AssertJ", repair)
        self.assertIn("anyChar()", repair)
        augmentation = _global_rules_block(ctx)
        self.assertIn("never use AssertJ", augmentation)


class CoverageDiagnosticsRegressionTest(unittest.TestCase):
    def _runner_and_module(self, root: Path, *, module_root: Path | None = None):
        module_root = module_root or root
        (root / "pom.xml").write_text("<project/>", encoding="utf-8")
        module_root.mkdir(parents=True, exist_ok=True)
        module = ModuleInfo("sample", module_root, module_root / "pom.xml")
        runner = CoverageRunner(root, mvn_path="mvn", timeout_sec=30)
        return runner, module

    def test_coverage_cli_source_is_recorded(self) -> None:
        cfg = load_config(["--repo-path", ".", "--coverage"])
        self.assertTrue(cfg.gen.run_coverage)
        self.assertEqual("--coverage", cfg.gen.coverage_source)

    def test_surefire_and_jacoco_signals_are_parsed(self) -> None:
        blob = """
[INFO] --- jacoco-maven-plugin:0.8.13:prepare-agent ---
[INFO] argLine set to -javaagent:/tmp/org.jacoco.agent.jar=destfile=/tmp/jacoco.exec
[INFO] Tests run: 3, Failures: 1, Errors: 0, Skipped: 1
[INFO] --- jacoco-maven-plugin:0.8.13:report ---
"""
        signals = parse_coverage_signals(blob)
        self.assertTrue(signals.tests_executed)
        self.assertEqual(3, signals.tests_run)
        self.assertEqual(1, signals.tests_failed)
        self.assertEqual(1, signals.tests_skipped)
        self.assertTrue(signals.jacoco_argline_configured)
        self.assertTrue(signals.jacoco_javaagent_detected)

    def test_full_command_and_output_are_persisted_on_success(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            runner, module = self._runner_and_module(root)
            captured: list[list[str]] = []

            def fake_run(command, **_kwargs):
                captured.append(list(command))
                runner.exec_path(module).parent.mkdir(parents=True, exist_ok=True)
                runner.exec_path(module).write_bytes(b"exec-data")
                runner.xml_path(module).parent.mkdir(parents=True, exist_ok=True)
                runner.xml_path(module).write_text("<report/>", encoding="utf-8")
                stdout = (
                    "jacoco-maven-plugin:0.8.13:prepare-agent\n"
                    "argLine set to -javaagent:/tmp/org.jacoco.agent.jar\n"
                    "Tests run: 1, Failures: 0, Errors: 0, Skipped: 0\n"
                    "jacoco-maven-plugin:0.8.13:report\n"
                )
                return subprocess.CompletedProcess(command, 0, stdout, "stderr-detail")

            with patch.object(runner, "available", return_value=True), patch(
                "junitforge.coverage_run.subprocess.run", side_effect=fake_run
            ):
                result = runner.measure(module, ["sample.PaymentServiceImplTest"])

            self.assertTrue(result.ok, result.note)
            self.assertTrue(result.measured)
            self.assertIsNotNone(result.log_path)
            text = result.log_path.read_text(encoding="utf-8")
            self.assertIn("=== STDOUT ===", text)
            self.assertIn("stderr-detail", text)
            command = captured[0]
            self.assertIn("-DskipTests=false", command)
            self.assertIn("-Dmaven.test.skip=false", command)
            self.assertIn("-Dtest=sample.PaymentServiceImplTest", command)
            self.assertTrue(any(value.startswith("-Djacoco.destFile=") for value in command))

    def test_nonzero_maven_return_is_classified_before_missing_exec(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            runner, module = self._runner_and_module(root)
            proc = subprocess.CompletedProcess(["mvn"], 1, "BUILD FAILURE", "dependency error")
            with patch.object(runner, "available", return_value=True), patch(
                "junitforge.coverage_run.subprocess.run", return_value=proc
            ):
                result = runner.measure(module, ["sample.PaymentServiceImplTest"])
            self.assertFalse(result.ok)
            self.assertEqual("maven_execution_failed", result.reason)
            self.assertIn("maven_return_code=1", result.note)
            self.assertIsNotNone(result.log_path)

    def test_selector_mismatch_retries_once_with_simple_name(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            runner, module = self._runner_and_module(root)
            commands: list[list[str]] = []

            def fake_run(command, **_kwargs):
                commands.append(list(command))
                if len(commands) == 1:
                    return subprocess.CompletedProcess(
                        command,
                        0,
                        "No tests matching pattern sample.PaymentServiceImplTest were executed",
                        "",
                    )
                runner.exec_path(module).parent.mkdir(parents=True, exist_ok=True)
                runner.exec_path(module).write_bytes(b"exec")
                runner.xml_path(module).parent.mkdir(parents=True, exist_ok=True)
                runner.xml_path(module).write_text("<report/>", encoding="utf-8")
                return subprocess.CompletedProcess(
                    command,
                    0,
                    "Tests run: 1, Failures: 0, Errors: 0, Skipped: 0\n-javaagent:org.jacoco.agent",
                    "",
                )

            with patch.object(runner, "available", return_value=True), patch(
                "junitforge.coverage_run.subprocess.run", side_effect=fake_run
            ):
                result = runner.measure(module, ["sample.PaymentServiceImplTest"])
            self.assertTrue(result.ok, result.note)
            self.assertEqual(2, len(commands))
            self.assertIn("-Dtest=sample.PaymentServiceImplTest", commands[0])
            self.assertIn("-Dtest=PaymentServiceImplTest", commands[1])

    def test_missing_exec_after_no_tests_has_specific_reason(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            runner, module = self._runner_and_module(root)
            proc = subprocess.CompletedProcess(["mvn"], 0, "No tests to run", "")
            with patch.object(runner, "available", return_value=True), patch(
                "junitforge.coverage_run.subprocess.run", return_value=proc
            ):
                result = runner.measure(module, ["PaymentServiceImplTest"])
            self.assertEqual("no_tests_executed", result.reason)
            self.assertIn("tests_run=0", result.note)
            self.assertIsNotNone(result.log_path)

    def test_empty_exec_is_distinguished_from_missing_exec(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            runner, module = self._runner_and_module(root)

            def fake_run(command, **_kwargs):
                runner.exec_path(module).parent.mkdir(parents=True, exist_ok=True)
                runner.exec_path(module).write_bytes(b"")
                return subprocess.CompletedProcess(
                    command,
                    0,
                    "Tests run: 1, Failures: 0, Errors: 0, Skipped: 0\n-javaagent:org.jacoco.agent",
                    "",
                )

            with patch.object(runner, "available", return_value=True), patch(
                "junitforge.coverage_run.subprocess.run", side_effect=fake_run
            ):
                result = runner.measure(module, ["PaymentServiceImplTest"])
            self.assertEqual("jacoco_exec_empty", result.reason)

    def test_unrelated_sibling_exec_is_not_selected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            module_root = root / "module-a"
            sibling = root / "module-b"
            runner, module = self._runner_and_module(root, module_root=module_root)

            def fake_run(command, **_kwargs):
                sibling_exec = sibling / "target" / "jacoco.exec"
                sibling_exec.parent.mkdir(parents=True, exist_ok=True)
                sibling_exec.write_bytes(b"sibling")
                return subprocess.CompletedProcess(
                    command,
                    0,
                    "Tests run: 1, Failures: 0, Errors: 0, Skipped: 0\n-javaagent:org.jacoco.agent",
                    "",
                )

            with patch.object(runner, "available", return_value=True), patch(
                "junitforge.coverage_run.subprocess.run", side_effect=fake_run
            ):
                result = runner.measure(module, ["PaymentServiceImplTest"])
            self.assertFalse(result.ok)
            self.assertEqual("jacoco_exec_created_in_unexpected_module", result.reason)
            self.assertIsNone(result.selected_exec_path)


    def test_tests_skipped_and_report_skipped_signals_are_detected(self) -> None:
        blob = "Tests are skipped\nSkipping JaCoCo execution due to missing execution data file"
        signals = parse_coverage_signals(blob)
        self.assertTrue(signals.surefire_skipped)
        self.assertTrue(signals.jacoco_report_skipped)

    def test_no_selector_retry_without_explicit_selector_mismatch(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            runner, module = self._runner_and_module(root)
            commands: list[list[str]] = []

            def fake_run(command, **_kwargs):
                commands.append(list(command))
                return subprocess.CompletedProcess(command, 0, "No tests to run", "")

            with patch.object(runner, "available", return_value=True), patch(
                "junitforge.coverage_run.subprocess.run", side_effect=fake_run
            ):
                result = runner.measure(module, ["sample.PaymentServiceImplTest"])
            self.assertEqual("no_tests_executed", result.reason)
            self.assertEqual(1, len(commands))

    def test_stale_delete_failure_is_logged(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            runner, _module = self._runner_and_module(root)
            stale = root / "target" / "jacoco.exec"
            stale.parent.mkdir(parents=True, exist_ok=True)
            stale.write_bytes(b"old")
            with patch.object(Path, "unlink", side_effect=OSError("locked")):
                with self.assertLogs("junitforge.coverage_run", level="WARNING") as captured:
                    runner._delete_stale((stale,))
            self.assertTrue(any("stale.delete_failed" in line for line in captured.output))

    def test_unchanged_stale_exec_is_never_selected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            runner, module = self._runner_and_module(root)
            stale = runner.exec_path(module)
            stale.parent.mkdir(parents=True, exist_ok=True)
            stale.write_bytes(b"old-exec")
            original_unlink = Path.unlink

            def guarded_unlink(path_obj, *args, **kwargs):
                if path_obj == stale:
                    raise OSError("locked")
                return original_unlink(path_obj, *args, **kwargs)

            proc = subprocess.CompletedProcess(
                ["mvn"],
                0,
                "Tests run: 1, Failures: 0, Errors: 0, Skipped: 0\n-javaagent:org.jacoco.agent",
                "",
            )
            with patch.object(runner, "available", return_value=True), patch(
                "junitforge.coverage_run.subprocess.run", return_value=proc
            ), patch.object(Path, "unlink", autospec=True, side_effect=guarded_unlink):
                result = runner.measure(module, ["PaymentServiceImplTest"])
            self.assertFalse(result.measured)
            self.assertNotEqual(stale, result.selected_exec_path)

    def test_no_coverage_flag_remains_authoritative(self) -> None:
        cfg = load_config(["--repo-path", ".", "--coverage", "--no-coverage"])
        self.assertFalse(cfg.gen.run_coverage)
        self.assertEqual("--no-coverage", cfg.gen.coverage_source)


if __name__ == "__main__":
    unittest.main()
