from __future__ import annotations

from dataclasses import replace
import json
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

from junitforge.execution.fixture_builder_emitter import emit_fixture_catalog
from junitforge.execution.models import (
    ExecutionContext,
    ExecutionTargetKind,
    FixtureCompileStatus,
    FixtureSupportStatus,
    MethodExecutionContext,
    PropertyKind,
)
from junitforge.execution.payload_schema import (
    apply_usage_constraints,
    build_payload_schemas,
    extract_collection_requirements,
)
from junitforge.execution.renderer import write_fixture_catalog_json
from junitforge.generation.payloads import serviceimpl
from junitforge.generation.skeleton_generator import update_fixture_compile_status
from junitforge.models import (
    ClassSymbol,
    ClasspathProfile,
    FieldSig,
    GenerationContext,
    MethodSig,
    StackProfile,
    TemplateSpec,
    TestKind as JunitTestKind,
)


def _getter(name: str, type_name: str) -> MethodSig:
    return MethodSig(f"get{name[:1].upper()}{name[1:]}", {"public"}, type_name)


def _setter(name: str, type_name: str) -> MethodSig:
    return MethodSig(
        f"set{name[:1].upper()}{name[1:]}",
        {"public"},
        "void",
        [(type_name, name)],
    )


def _dto(name: str, fields: list[tuple[str, str]]) -> ClassSymbol:
    return ClassSymbol(
        name=name,
        fqcn=f"sample.{name}",
        kind="class",
        modifiers={"public"},
        package_name="sample",
        fields=[FieldSig(field_name, field_type, modifiers={"private"}) for field_name, field_type in fields],
        methods=[
            method
            for field_name, field_type in fields
            for method in (_getter(field_name, field_type), _setter(field_name, field_type))
        ],
    )


def _lookup(*symbols: ClassSymbol):
    values = {symbol.name: symbol for symbol in symbols}
    values.update({symbol.fqcn: symbol for symbol in symbols})
    return lambda type_name, owner=None: values.get(type_name) or values.get(type_name.rsplit(".", 1)[-1])


def _fixture(fixtures, fixture_id: str):
    return next(value for value in fixtures if value.fixture_id == fixture_id)


def _generation_context(execution: ExecutionContext, method: MethodSig) -> GenerationContext:
    symbol = ClassSymbol(
        "SampleServiceImpl",
        "sample.SampleServiceImpl",
        "class",
        modifiers={"public"},
        methods=[method],
    )
    return GenerationContext(
        cut_source="",
        symbol=symbol,
        collaborators=[],
        test_package="sample",
        test_class_name="SampleServiceImplTest",
        stack=StackProfile(java_version="17"),
        classpath=ClasspathProfile(has_junit_jupiter=True, has_mockito=True),
        template=TemplateSpec(JunitTestKind.PURE_UNIT, "unit"),
        source_path=Path("SampleServiceImpl.java"),
        execution_context=execution,
    )


def _payload(ctx: GenerationContext, method: MethodSig) -> dict:
    method_context = ctx.execution_context.methods[0]
    closure = SimpleNamespace(method_source=method_context.method_source, reachable_methods=())
    with patch.object(serviceimpl, "build_source_closure", return_value=closure):
        messages = serviceimpl.build_generation_payload(ctx, method, mode="method")
    return json.loads(messages[1]["content"])


def test_required_dereference_path_hydrates_every_nested_schema_level() -> None:
    leaf = _dto("LeafEntity", [("value", "String")])
    child = _dto("ChildEntity", [("leaf", "LeafEntity")])
    root = _dto("RootEntity", [("child", "ChildEntity")])
    schemas, diagnostics = build_payload_schemas(
        ["RootEntity"],
        _lookup(root, child, leaf),
        path_requests=[("RootEntity", "child.leaf.value")],
        max_depth=2,
    )
    assert not diagnostics
    by_name = {schema.type_name: schema for schema in schemas}
    assert next(p for p in by_name["RootEntity"].properties if p.name == "child").baseline_required
    assert next(p for p in by_name["ChildEntity"].properties if p.name == "leaf").baseline_required
    assert next(p for p in by_name["LeafEntity"].properties if p.name == "value").baseline_required

    emitted = emit_fixture_catalog(schemas)
    root_fixture = _fixture(emitted.fixtures, "sample.RootEntity")
    child_fixture = _fixture(emitted.fixtures, "sample.ChildEntity")
    assert "setChild(validChildEntity())" in root_fixture.method_source
    assert "setLeaf(validLeafEntity())" in child_fixture.method_source
    assert root_fixture.required_relationship_paths == ("child", "child.leaf")
    assert child_fixture.required_relationship_paths == ("leaf",)


def test_required_collection_minimum_is_mutable_compatible_and_non_null() -> None:
    item = _dto("ItemEntity", [("code", "String")])
    root = _dto("RootEntity", [("items", "List<ItemEntity>")])
    schemas, _ = build_payload_schemas(["RootEntity"], _lookup(root, item), max_depth=5)
    requirements = extract_collection_requirements("root.getItems().get(1).getCode(); root.getItems().add(new ItemEntity());")
    constrained = apply_usage_constraints(schemas, ("root.getItems().get(1).getCode();",), requirements)
    emitted = emit_fixture_catalog(constrained)
    root_fixture = _fixture(emitted.fixtures, "sample.RootEntity")
    assert root_fixture.support_status == FixtureSupportStatus.SUPPORTED
    assert root_fixture.minimum_collection_sizes == (("items", 2),)
    assert "new ArrayList<>(List.of(itemsElement1, itemsElement2))" in root_fixture.method_source
    assert root_fixture.method_source.count("validItemEntity()") == 2
    assert "null" not in root_fixture.method_source


def test_fixture_catalog_records_direct_and_transitive_dependencies() -> None:
    leaf = _dto("LeafEntity", [("value", "String")])
    child = _dto("ChildEntity", [("leaf", "LeafEntity")])
    root = _dto("RootEntity", [("child", "ChildEntity")])
    schemas, _ = build_payload_schemas(["RootEntity"], _lookup(root, child, leaf), max_depth=5)
    emitted = emit_fixture_catalog(schemas)
    root_fixture = _fixture(emitted.fixtures, "sample.RootEntity")
    child_fixture = _fixture(emitted.fixtures, "sample.ChildEntity")
    assert root_fixture.dependent_fixture_ids == ("sample.ChildEntity",)
    assert root_fixture.transitive_fixture_ids == ("sample.ChildEntity", "sample.LeafEntity")
    assert child_fixture.dependent_fixture_ids == ("sample.LeafEntity",)


def test_object_identity_guarantees_match_attached_fixture_instances() -> None:
    child = _dto("ChildEntity", [("value", "String")])
    root = _dto("RootEntity", [("child", "ChildEntity"), ("items", "List<ChildEntity>")])
    schemas, _ = build_payload_schemas(
        ["RootEntity"],
        _lookup(root, child),
        path_requests=[("RootEntity", "child.value"), ("RootEntity", "items.value")],
        max_depth=5,
    )
    constrained = apply_usage_constraints(
        schemas,
        ("root.getItems().iterator().next().getValue();",),
        extract_collection_requirements("root.getItems().iterator().next().getValue();"),
    )
    emitted = emit_fixture_catalog(constrained)
    fixture = _fixture(emitted.fixtures, "sample.RootEntity")
    assert any("child is the exact instance returned by validChildEntity()" in value for value in fixture.identity_guarantees)
    assert any("items[0] is the exact itemsElement instance" in value for value in fixture.identity_guarantees)
    assert "setChild(validChildEntity())" in fixture.method_source
    assert "setItems(new ArrayList<>(List.of(itemsElement)))" in fixture.method_source


def test_cycle_preserves_forward_edge_and_omits_only_reverse_edge() -> None:
    a = _dto("A", [("b", "B")])
    b = _dto("B", [("a", "A")])
    schemas, schema_diagnostics = build_payload_schemas(
        ["A"],
        _lookup(a, b),
        path_requests=[("A", "b")],
        max_depth=5,
    )
    emitted = emit_fixture_catalog(schemas)
    a_fixture = _fixture(emitted.fixtures, "sample.A")
    b_fixture = _fixture(emitted.fixtures, "sample.B")
    assert "setB(validB())" in a_fixture.method_source
    assert "setA(" not in b_fixture.method_source
    assert any(item.action == "preserve-forward-edge" for item in a_fixture.cycle_decisions)
    assert any(item.action == "omit-reverse-edge" for item in b_fixture.cycle_decisions)
    assert b_fixture.omitted_edges == ("B.a",)
    assert emitted.back_edges == [("sample.B", "a")]
    assert any("cycle" in value for value in (*schema_diagnostics, *emitted.diagnostics))


def test_unresolved_required_child_fails_closed_and_marks_parent_partial() -> None:
    parent = _dto("ParentEntity", [("child", "MissingEntity")])
    schemas, _ = build_payload_schemas(
        ["ParentEntity"],
        _lookup(parent),
        path_requests=[("ParentEntity", "child.value")],
    )
    emitted = emit_fixture_catalog(schemas)
    parent_fixture = _fixture(emitted.fixtures, "sample.ParentEntity")
    missing_fixture = next(value for value in emitted.fixtures if value.return_type == "MissingEntity")
    assert missing_fixture.support_status == FixtureSupportStatus.UNSUPPORTED
    assert parent_fixture.support_status == FixtureSupportStatus.PARTIAL
    assert parent_fixture.supported is False
    assert parent_fixture.semantic_valid is False
    assert parent_fixture.method_source == ""
    assert any("required child fixture unsupported" in value for value in parent_fixture.blocking_reasons)


def test_catalogue_guarantees_are_present_in_emitted_source() -> None:
    child = _dto("ChildEntity", [("code", "String")])
    root = _dto("RootEntity", [("name", "String"), ("child", "ChildEntity")])
    schemas, _ = build_payload_schemas(
        ["RootEntity"],
        _lookup(root, child),
        path_requests=[("RootEntity", "child.code")],
    )
    emitted = emit_fixture_catalog(schemas)
    fixture = _fixture(emitted.fixtures, "sample.RootEntity")
    assert fixture.semantic_valid
    for path, expression in fixture.guaranteed_scalar_state:
        if "." not in path:
            assert expression in fixture.method_source
        else:
            assert any(
                expression in _fixture(emitted.fixtures, dependency_id).method_source
                for dependency_id in fixture.transitive_fixture_ids
            )
    for dependency_id in fixture.dependent_fixture_ids:
        dependency = _fixture(emitted.fixtures, dependency_id)
        assert f"{dependency.method_name}()" in fixture.method_source
    assert fixture.guaranteed_relationships == ("child",)


def test_uncompiled_fixture_is_not_exposed_then_becomes_exposed_after_skeleton_compile() -> None:
    request = _dto("RequestDto", [("name", "String")])
    schemas, _ = build_payload_schemas(["RequestDto"], _lookup(request))
    emitted = emit_fixture_catalog(schemas)
    fixture = _fixture(emitted.fixtures, "sample.RequestDto")
    assert fixture.compile_status == FixtureCompileStatus.NOT_COMPILED

    method = MethodSig("run", {"public"}, "void", [("RequestDto", "request")])
    method_context = MethodExecutionContext(
        method_id="run(RequestDto)",
        signature=method.render(),
        source_range=(1, 1),
        method_source="public void run(RequestDto request) {}",
        endpoint=None,
        required_fixture_ids=(fixture.fixture_id,),
    )
    execution = ExecutionContext(
        target_kind=ExecutionTargetKind.SERVICE_IMPL,
        target_fqcn="sample.SampleServiceImpl",
        methods=(method_context,),
        fixtures=tuple(emitted.fixtures),
    )
    ctx = _generation_context(execution, method)
    assert _payload(ctx, method)["relevant_fixture_contracts"] == []

    update_fixture_compile_status(ctx, True)
    payload_fixture = _payload(ctx, method)["relevant_fixture_contracts"][0]
    assert payload_fixture["fixture_method_name"] == "validRequestDto"
    assert payload_fixture["application_type"] == "RequestDto"
    assert payload_fixture["support_status"] == "supported"
    assert payload_fixture["compiled_status"] == "compiled"
    assert "method_source" not in payload_fixture


def test_failed_skeleton_compile_marks_supported_fixtures_failed_and_unexposed() -> None:
    request = _dto("RequestDto", [("name", "String")])
    schemas, _ = build_payload_schemas(["RequestDto"], _lookup(request))
    emitted = emit_fixture_catalog(schemas)
    method = MethodSig("run", {"public"}, "void", [("RequestDto", "request")])
    execution = ExecutionContext(
        target_kind=ExecutionTargetKind.SERVICE_IMPL,
        target_fqcn="sample.SampleServiceImpl",
        methods=(MethodExecutionContext(
            method_id="run(RequestDto)", signature=method.render(), source_range=(1, 1),
            method_source="public void run(RequestDto request) {}", endpoint=None,
            required_fixture_ids=("sample.RequestDto",),
        ),),
        fixtures=tuple(emitted.fixtures),
    )
    ctx = _generation_context(execution, method)
    update_fixture_compile_status(ctx, False)
    fixture = _fixture(ctx.execution_context.fixtures, "sample.RequestDto")
    assert fixture.compile_status == FixtureCompileStatus.FAILED
    assert not fixture.exposed_to_generation
    assert _payload(ctx, method)["relevant_fixture_contracts"] == []


def test_optional_get_requires_present_value_without_fake_collection_minimum() -> None:
    root = _dto("RootEntity", [("label", "Optional<String>")])
    schemas, _ = build_payload_schemas(["RootEntity"], _lookup(root))
    requirements = extract_collection_requirements("root.getLabel().get();")
    constrained = apply_usage_constraints(schemas, ("root.getLabel().get();",), requirements)
    emitted = emit_fixture_catalog(constrained)
    fixture = _fixture(emitted.fixtures, "sample.RootEntity")
    assert fixture.support_status == FixtureSupportStatus.SUPPORTED
    assert fixture.minimum_collection_sizes == ()
    assert 'setLabel(Optional.of("label-value"))' in fixture.method_source
    assert "Optional.of(null)" not in fixture.method_source


def test_required_cycle_reverse_dereference_fails_closed() -> None:
    a = _dto("A", [("b", "B")])
    b = _dto("B", [("a", "A")])
    schemas, _ = build_payload_schemas(
        ["A"],
        _lookup(a, b),
        path_requests=[("A", "b.a")],
        max_depth=5,
    )
    emitted = emit_fixture_catalog(schemas)
    a_fixture = _fixture(emitted.fixtures, "sample.A")
    b_fixture = _fixture(emitted.fixtures, "sample.B")
    assert b_fixture.support_status == FixtureSupportStatus.PARTIAL
    assert any("required cycle reverse edge omitted" in value for value in b_fixture.blocking_reasons)
    assert a_fixture.support_status == FixtureSupportStatus.PARTIAL
    assert not a_fixture.exposed_to_generation


def test_fixture_catalogue_persists_compile_and_exposure_state() -> None:
    request = _dto("RequestDto", [("name", "String")])
    schemas, _ = build_payload_schemas(["RequestDto"], _lookup(request))
    emitted = emit_fixture_catalog(schemas)
    method = MethodSig("run", {"public"}, "void", [("RequestDto", "request")])
    execution = ExecutionContext(
        target_kind=ExecutionTargetKind.SERVICE_IMPL,
        target_fqcn="sample.SampleServiceImpl",
        methods=(MethodExecutionContext(
            method_id="run(RequestDto)", signature=method.render(), source_range=(1, 1),
            method_source="public void run(RequestDto request) {}", endpoint=None,
            required_fixture_ids=("sample.RequestDto",),
        ),),
        fixtures=tuple(emitted.fixtures),
    )
    ctx = _generation_context(execution, method)
    update_fixture_compile_status(ctx, True)
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "fixture-catalog.json"
        write_fixture_catalog_json(ctx.execution_context, path)
        payload = json.loads(path.read_text(encoding="utf-8"))
    fixture = payload["fixtures"][0]
    assert fixture["method_name"] == "validRequestDto"
    assert fixture["support_status"] == "supported"
    assert fixture["compile_status"] == "compiled"
    assert fixture["semantic_valid"] is True
    assert fixture["method_source"]


def test_generated_fixture_graph_compiles_in_synthetic_java_harness() -> None:
    leaf = _dto("LeafEntity", [("code", "String")])
    child = _dto("ChildEntity", [("leaf", "LeafEntity")])
    root = _dto("RootEntity", [("children", "List<ChildEntity>")])
    schemas, _ = build_payload_schemas(["RootEntity"], _lookup(root, child, leaf), max_depth=5)
    constrained = apply_usage_constraints(
        schemas,
        ("root.getChildren().get(1).getLeaf().getCode();",),
        extract_collection_requirements("root.getChildren().get(1).getLeaf().getCode();"),
    )
    emitted = emit_fixture_catalog(constrained)
    helpers = "\n\n".join(emitted.helpers)
    source = f'''package sample;
import java.util.*;
public class FixtureGraphCompileTest {{
{helpers}
    static class RootEntity {{ private List<ChildEntity> children; public void setChildren(List<ChildEntity> v) {{ children=v; }} public List<ChildEntity> getChildren() {{ return children; }} }}
    static class ChildEntity {{ private LeafEntity leaf; public void setLeaf(LeafEntity v) {{ leaf=v; }} public LeafEntity getLeaf() {{ return leaf; }} }}
    static class LeafEntity {{ private String code; public void setCode(String v) {{ code=v; }} public String getCode() {{ return code; }} }}
}}
'''
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "sample" / "FixtureGraphCompileTest.java"
        path.parent.mkdir(parents=True)
        path.write_text(source, encoding="utf-8")
        result = subprocess.run(["javac", str(path)], capture_output=True, text=True, check=False)
        assert result.returncode == 0, result.stderr + "\n" + source


def test_focused_fixture_payload_excludes_unrelated_and_partial_fixtures() -> None:
    request = _dto("RequestDto", [("name", "String")])
    unrelated = _dto("UnrelatedDto", [("value", "String")])
    broken = _dto("BrokenDto", [("child", "MissingDto")])
    schemas, _ = build_payload_schemas(
        ["RequestDto", "UnrelatedDto", "BrokenDto"],
        _lookup(request, unrelated, broken),
        path_requests=[("BrokenDto", "child.value")],
    )
    emitted = emit_fixture_catalog(schemas)
    compiled = tuple(
        replace(value, compile_status=FixtureCompileStatus.COMPILED)
        if value.supported and value.semantic_valid else value
        for value in emitted.fixtures
    )
    method = MethodSig("run", {"public"}, "void", [("RequestDto", "request")])
    execution = ExecutionContext(
        target_kind=ExecutionTargetKind.SERVICE_IMPL,
        target_fqcn="sample.SampleServiceImpl",
        methods=(MethodExecutionContext(
            method_id="run(RequestDto)", signature=method.render(), source_range=(1, 1),
            method_source="public void run(RequestDto request) {}", endpoint=None,
            required_fixture_ids=("sample.RequestDto", "sample.BrokenDto"),
        ),),
        fixtures=compiled,
    )
    payload = _payload(_generation_context(execution, method), method)
    assert [value["application_type"] for value in payload["relevant_fixture_contracts"]] == ["RequestDto"]
    rendered = json.dumps(payload)
    assert "UnrelatedDto" not in rendered
    assert "BrokenDto" not in rendered
    assert "MissingDto" not in rendered
    assert "private RequestDto" not in rendered


def test_general_instructions_are_preserved_once_without_dynamic_catalogue_content() -> None:
    assert serviceimpl.general_instructions_fingerprint() == serviceimpl._PHASE1_GENERAL_INSTRUCTIONS_SHA256
    serviceimpl.validate_general_instructions_preserved()

    values: list[str] = []
    def collect(value):
        if isinstance(value, str):
            values.append(value)
        elif isinstance(value, dict):
            for nested in value.values():
                collect(nested)
        elif isinstance(value, list):
            for nested in value:
                collect(nested)
    collect(serviceimpl._GENERATION_INSTRUCTION)
    assert len(values) == len(set(values)), "permanent instruction clauses must not be duplicated"
    permanent = json.dumps(serviceimpl._GENERATION_INSTRUCTION)
    assert "fixture_method_name" not in permanent
    assert "compile_status" not in permanent
    assert "fixture_id" not in permanent
