from __future__ import annotations

import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from junitforge.compile_gate import parse_javac_errors
from junitforge.execution.assembly import (
    insert_method_block,
    validate_method_block,
)
from junitforge.execution.dependencies import resolve_method_contract
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.models import (
    ConstructionKind,
    DependencyInvocation,
    DependencyMethodContract,
    DependencyRef,
    ExecutionContext,
    ExecutionTargetKind,
    FixtureSpec,
    InvocationArgument,
    MethodExecutionContext,
    PayloadProperty,
    PayloadSchema,
    PropertyKind,
    ResolutionStatus,
    ReturnConsumptionKind,
)
from junitforge.execution.oracle_planner import build_oracle_plan
from junitforge.execution.stub_planner import build_stub_plans
from junitforge.loop import _select_method_repair_owner
from junitforge.models import (
    ClassSymbol,
    ClasspathProfile,
    CompileError,
    FieldSig,
    GenerationContext,
    JavaSourceFile,
    MethodSig,
    StackProfile,
    TemplateSpec,
    TestKind,
)
from junitforge.vendor.javac import JavacRunner, parse_errors
from junitforge.prompts.generation import build_method_generation_messages
from junitforge.prompts.repair import build_method_compile_repair_messages


def _template() -> TemplateSpec:
    return TemplateSpec(TestKind.PURE_UNIT, "unit")


def _schema(
    name: str,
    properties: tuple[PayloadProperty, ...] = (),
    *,
    enum_constants: tuple[str, ...] = (),
    fixture: str | None = None,
) -> PayloadSchema:
    return PayloadSchema(
        type_name=name,
        fqcn=f"sample.{name}",
        kind="enum" if enum_constants else "class",
        properties=properties,
        enum_constants=enum_constants,
        resolution_status=ResolutionStatus.RESOLVED,
        construction_kind=ConstructionKind.ENUM if enum_constants else ConstructionKind.NO_ARGS_SETTERS,
        fixture_method_name=fixture,
    )


def _context(
    method: MethodSig,
    method_context: MethodExecutionContext,
    *,
    schemas: tuple[PayloadSchema, ...] = (),
    fixtures: tuple[FixtureSpec, ...] = (),
    dependencies: tuple[DependencyRef, ...] = (),
) -> GenerationContext:
    execution = ExecutionContext(
        target_kind=ExecutionTargetKind.SERVICE_IMPL,
        target_fqcn="sample.SampleServiceImpl",
        dependencies=dependencies,
        methods=(method_context,),
        payload_schemas=schemas,
        fixtures=fixtures,
    )
    symbol = ClassSymbol(
        "SampleServiceImpl",
        "sample.SampleServiceImpl",
        "class",
        modifiers={"public"},
        methods=[method],
    )
    return GenerationContext(
        cut_source="",
        symbol=symbol,
        collaborators=[],
        test_package="sample",
        test_class_name="SampleServiceImplTest",
        stack=StackProfile(),
        classpath=ClasspathProfile(),
        template=_template(),
        source_path=Path("SampleServiceImpl.java"),
        source_imports=[],
        execution_context=execution,
    )


class VerifiedMemberAndFixtureValidationTest(unittest.TestCase):
    def setUp(self) -> None:
        self.method = MethodSig("execute", modifiers={"public"}, return_type="ResultResponse")
        self.success_property = PayloadProperty(
            name="success",
            type_name="boolean",
            readable=True,
            writable=True,
            getter="isSuccess",
            setter="setSuccess",
            resolved_type="boolean",
            kind=PropertyKind.PRIMITIVE,
        )
        self.result_schema = _schema("ResultResponse", (self.success_property,), fixture="validResultResponse")
        self.result_fixture = FixtureSpec(
            fixture_id="sample.ResultResponse",
            method_name="validResultResponse",
            return_type="ResultResponse",
            schema_id="sample.ResultResponse",
        )
        self.method_context = MethodExecutionContext(
            method_id="execute()",
            signature=self.method.render(),
            source_range=(1, 4),
            method_source="public ResultResponse execute() { ResultResponse r = new ResultResponse(); r.setSuccess(true); return r; }",
            endpoint=None,
            payload_schemas=(self.result_schema,),
            required_fixture_ids=("sample.ResultResponse",),
        )
        self.ctx = _context(
            self.method,
            self.method_context,
            schemas=(self.result_schema,),
            fixtures=(self.result_fixture,),
        )

    def test_oracle_uses_verified_is_getter(self) -> None:
        plan = build_oracle_plan(self.method_context, self.result_schema)
        self.assertEqual(1, len(plan.set_fields))
        self.assertEqual("isSuccess", plan.set_fields[0].getter)
        self.assertNotIn("getSuccess", plan.unset_getters)

    def test_unknown_getter_is_rejected(self) -> None:
        block = """
        @Test void wrongGetter() {
            ResultResponse result = sampleServiceImpl.execute();
            assertTrue(result.getSuccess());
        }
        """
        validation = validate_method_block(self.ctx, self.method, self.method_context, block, set())
        self.assertFalse(validation.ok)
        self.assertIn("getSuccess", validation.reason)
        self.assertIn("isSuccess", validation.reason)

    def test_direct_constructor_is_rejected_when_fixture_exists(self) -> None:
        block = """
        @Test void directConstruction() {
            ResultResponse result = new ResultResponse();
            sampleServiceImpl.execute();
        }
        """
        validation = validate_method_block(self.ctx, self.method, self.method_context, block, set())
        self.assertFalse(validation.ok)
        self.assertIn("validResultResponse()", validation.reason)

    def test_builder_is_rejected_when_fixture_exists(self) -> None:
        block = """
        @Test void directBuilder() {
            ResultResponse result = ResultResponse.builder().build();
            sampleServiceImpl.execute();
        }
        """
        validation = validate_method_block(self.ctx, self.method, self.method_context, block, set())
        self.assertFalse(validation.ok)
        self.assertIn("direct construction", validation.reason)

    def test_unknown_application_type_is_rejected(self) -> None:
        block = """
        @Test void inventedType() {
            GiDocGenStatusEntity status = null;
            sampleServiceImpl.execute();
        }
        """
        validation = validate_method_block(self.ctx, self.method, self.method_context, block, set())
        self.assertFalse(validation.ok)
        self.assertIn("unknown application type GiDocGenStatusEntity", validation.reason)


    def test_unknown_unqualified_constant_is_rejected(self) -> None:
        block = """
        @Test void inventedConstant() {
            ResultResponse result = sampleServiceImpl.execute();
            assertEquals(PRODUCT_TYPE_MOTOR, result.isSuccess());
        }
        """
        validation = validate_method_block(self.ctx, self.method, self.method_context, block, set())
        self.assertFalse(validation.ok)
        self.assertIn("PRODUCT_TYPE_MOTOR", validation.reason)

    def test_verified_static_constant_is_accepted(self) -> None:
        self.ctx.symbol.fields.append(
            FieldSig("SUCCESS_FLAG", "boolean", modifiers={"public", "static", "final"}, initializer="true")
        )
        block = """
        @Test void verifiedConstant() {
            ResultResponse result = sampleServiceImpl.execute();
            assertEquals(SUCCESS_FLAG, result.isSuccess());
        }
        """
        validation = validate_method_block(self.ctx, self.method, self.method_context, block, set())
        self.assertTrue(validation.ok, validation.reason)

    def test_schema_mock_is_rejected_when_fixture_exists(self) -> None:
        block = """
        @Test void schemaMock() {
            ResultResponse result = mock(ResultResponse.class);
            sampleServiceImpl.execute();
        }
        """
        validation = validate_method_block(self.ctx, self.method, self.method_context, block, set())
        self.assertFalse(validation.ok)
        self.assertIn("validResultResponse()", validation.reason)


class EnumAndCollectionTypeValidationTest(unittest.TestCase):
    def setUp(self) -> None:
        contact_type_schema = _schema(
            "ContactType",
            enum_constants=("EMAIL", "MOBILE_NO", "HOME_NO", "E", "M", "H"),
        )
        contact_property = PayloadProperty(
            name="contactType",
            type_name="ContactType",
            readable=True,
            writable=True,
            getter="getContactType",
            setter="setContactType",
            resolved_type="sample.ContactType",
            kind=PropertyKind.ENUM,
            enum_constants=("EMAIL", "MOBILE_NO", "HOME_NO", "E", "M", "H"),
        )
        tags_property = PayloadProperty(
            name="tags",
            type_name="Set<String>",
            readable=True,
            writable=True,
            getter="getTags",
            setter="setTags",
            resolved_type="Set<String>",
            kind=PropertyKind.SET,
            element_type="String",
        )
        self.contact_schema = _schema(
            "GiContactEntity", (contact_property, tags_property), fixture="validGiContactEntity"
        )
        self.fixture = FixtureSpec(
            fixture_id="sample.GiContactEntity",
            method_name="validGiContactEntity",
            return_type="GiContactEntity",
            schema_id="sample.GiContactEntity",
        )
        self.method = MethodSig("execute", modifiers={"public"}, return_type="void")
        self.method_context = MethodExecutionContext(
            method_id="execute()",
            signature=self.method.render(),
            source_range=(1, 2),
            method_source="public void execute() {}",
            endpoint=None,
            payload_schemas=(self.contact_schema, contact_type_schema),
            required_fixture_ids=("sample.GiContactEntity",),
        )
        self.ctx = _context(
            self.method,
            self.method_context,
            schemas=(self.contact_schema, contact_type_schema),
            fixtures=(self.fixture,),
        )

    def test_char_for_enum_setter_is_rejected(self) -> None:
        block = """
        @Test void wrongEnumType() {
            GiContactEntity contact = validGiContactEntity();
            contact.setContactType('M');
            sampleServiceImpl.execute();
        }
        """
        result = validate_method_block(self.ctx, self.method, self.method_context, block, set())
        self.assertFalse(result.ok)
        self.assertIn("requires enum ContactType", result.reason)

    def test_verified_enum_mutation_is_accepted(self) -> None:
        block = """
        @Test void validEnumType() {
            GiContactEntity contact = validGiContactEntity();
            contact.setContactType(ContactType.M);
            sampleServiceImpl.execute();
        }
        """
        result = validate_method_block(self.ctx, self.method, self.method_context, block, set())
        self.assertTrue(result.ok, result.reason)

    def test_unknown_enum_constant_is_rejected(self) -> None:
        block = """
        @Test void badEnumConstant() {
            GiContactEntity contact = validGiContactEntity();
            contact.setContactType(ContactType.MOBILE);
            sampleServiceImpl.execute();
        }
        """
        result = validate_method_block(self.ctx, self.method, self.method_context, block, set())
        self.assertFalse(result.ok)
        self.assertIn("invalid enum value", result.reason)

    def test_list_expression_for_set_property_is_rejected(self) -> None:
        block = """
        @Test void wrongCollection() {
            GiContactEntity contact = validGiContactEntity();
            contact.setTags(List.of("A"));
            sampleServiceImpl.execute();
        }
        """
        result = validate_method_block(self.ctx, self.method, self.method_context, block, set())
        self.assertFalse(result.ok)
        self.assertIn("requires Set", result.reason)


class RepositoryGenericAndMockitoPlanningTest(unittest.TestCase):
    def test_repository_generic_binding_resolves_entity_independent_of_variable_name(self) -> None:
        repo = ClassSymbol(
            "OddlyNamedRepository",
            "sample.OddlyNamedRepository",
            "interface",
            extends="JpaRepository<GiPolicyConfirmationDocEmailStatus, Long>",
        )
        dependency = DependencyRef(
            field_name="giDocGenStatusRepository",
            parameter_name=None,
            declared_type="OddlyNamedRepository",
            simple_type="OddlyNamedRepository",
            fqcn=repo.fqcn,
            origin="field",
            resolution_status=ResolutionStatus.RESOLVED,
        )
        contract = resolve_method_contract(
            dependency,
            "save",
            (InvocationArgument("status", inferred_type="GiPolicyConfirmationDocEmailStatus"),),
            lambda name: repo if name == "OddlyNamedRepository" else None,
        )
        self.assertEqual("GiPolicyConfirmationDocEmailStatus", contract.return_type)
        self.assertEqual(("GiPolicyConfirmationDocEmailStatus",), contract.parameter_types)
        self.assertNotIn("GiDocGenStatusEntity", contract.render() if hasattr(contract, "render") else str(contract))


    def test_save_and_flush_uses_repository_entity_binding(self) -> None:
        repo = ClassSymbol(
            "Repo", "sample.Repo", "interface",
            extends="JpaRepository<ActualEntity, Long>",
        )
        dependency = DependencyRef(
            "repo", None, "Repo", "Repo", repo.fqcn, "field", ResolutionStatus.RESOLVED
        )
        contract = resolve_method_contract(
            dependency, "saveAndFlush",
            (InvocationArgument("value", inferred_type="ActualEntity"),),
            lambda name: repo if name == "Repo" else None,
        )
        self.assertEqual("ActualEntity", contract.return_type)
        self.assertEqual(("ActualEntity",), contract.parameter_types)

    def test_unresolved_repository_generic_does_not_guess_entity(self) -> None:
        repo = ClassSymbol("Repo", "sample.Repo", "interface", extends="JpaRepository")
        dependency = DependencyRef(
            "giDocGenStatusRepository", None, "Repo", "Repo", repo.fqcn,
            "field", ResolutionStatus.RESOLVED,
        )
        contract = resolve_method_contract(
            dependency, "save", (InvocationArgument("status"),),
            lambda name: repo if name == "Repo" else None,
        )
        self.assertIsNone(contract.return_type)
        self.assertNotIn("GiDocGenStatusEntity", str(contract))

    def _ctx_for_invocation(self, invocation: DependencyInvocation):
        method = MethodSig("execute", modifiers={"public"}, return_type="void")
        method_context = MethodExecutionContext(
            method_id="execute()",
            signature=method.render(),
            source_range=(1, 2),
            method_source="public void execute() {}",
            endpoint=None,
            dependency_invocations=(invocation,),
        )
        dependency = DependencyRef(
            field_name=invocation.dependency_field,
            parameter_name=None,
            declared_type=invocation.dependency_type,
            simple_type=invocation.dependency_type,
            fqcn=f"sample.{invocation.dependency_type}",
            origin="field",
            resolution_status=ResolutionStatus.RESOLVED,
        )
        return _context(method, method_context, dependencies=(dependency,)), method, method_context

    def test_void_when_then_return_is_rejected(self) -> None:
        contract = DependencyMethodContract(
            "repository", "Repo", "updateStatus", "void", ("String",),
            resolution_status=ResolutionStatus.RESOLVED,
        )
        inv = DependencyInvocation(
            "execute():I1", "execute()", "repository", "Repo", "updateStatus",
            (InvocationArgument('"A"', inferred_type="String"),), contract,
        )
        ctx, method, method_context = self._ctx_for_invocation(inv)
        block = """
        @Test void wrongVoidStub() {
            when(repository.updateStatus(anyString())).thenReturn(null);
            sampleServiceImpl.execute();
        }
        """
        result = validate_method_block(ctx, method, method_context, block, set())
        self.assertFalse(result.ok)
        self.assertIn("is void", result.reason)

    def test_do_nothing_on_non_void_save_is_rejected(self) -> None:
        contract = DependencyMethodContract(
            "repository", "Repo", "save", "Entity", ("Entity",),
            resolution_status=ResolutionStatus.RESOLVED,
        )
        inv = DependencyInvocation(
            "execute():I1", "execute()", "repository", "Repo", "save",
            (InvocationArgument("entity", inferred_type="Entity"),), contract,
            return_value_consumed=False,
            consumption_kind=ReturnConsumptionKind.IGNORED,
        )
        ctx, method, method_context = self._ctx_for_invocation(inv)
        block = """
        @Test void wrongDoNothing() {
            doNothing().when(repository).save(any());
            sampleServiceImpl.execute();
        }
        """
        result = validate_method_block(ctx, method, method_context, block, set())
        self.assertFalse(result.ok)
        self.assertIn("non-void", result.reason)

    def test_then_return_fixture_type_mismatch_is_rejected(self) -> None:
        contract = DependencyMethodContract(
            "repository", "Repo", "find", "ExpectedResponse", (),
            resolution_status=ResolutionStatus.RESOLVED,
        )
        inv = DependencyInvocation(
            "execute():I1", "execute()", "repository", "Repo", "find", (), contract,
            assigned_to="result",
            return_value_consumed=True,
            consumption_kind=ReturnConsumptionKind.ASSIGNED_READ,
        )
        method = MethodSig("execute", modifiers={"public"}, return_type="void")
        expected_schema = _schema("ExpectedResponse", fixture="validExpectedResponse")
        other_schema = _schema("OtherResponse", fixture="validOtherResponse")
        fixtures = (
            FixtureSpec("sample.ExpectedResponse", "validExpectedResponse", "ExpectedResponse", "sample.ExpectedResponse"),
            FixtureSpec("sample.OtherResponse", "validOtherResponse", "OtherResponse", "sample.OtherResponse"),
        )
        method_context = MethodExecutionContext(
            "execute()", method.render(), (1, 2), "public void execute() {}", None,
            dependency_invocations=(inv,), payload_schemas=(expected_schema, other_schema),
            required_fixture_ids=("sample.ExpectedResponse", "sample.OtherResponse"),
        )
        dependency = DependencyRef(
            "repository", None, "Repo", "Repo", "sample.Repo", "field", ResolutionStatus.RESOLVED,
        )
        ctx = _context(
            method, method_context, schemas=(expected_schema, other_schema),
            fixtures=fixtures, dependencies=(dependency,),
        )
        block = """
        @Test void wrongReturnType() {
            when(repository.find()).thenReturn(validOtherResponse());
            sampleServiceImpl.execute();
        }
        """
        result = validate_method_block(ctx, method, method_context, block, set())
        self.assertFalse(result.ok)
        self.assertIn("return type mismatch", result.reason)

    def test_ignored_non_void_return_requires_no_stub(self) -> None:
        contract = DependencyMethodContract(
            "repository", "Repo", "save", "Entity", ("Entity",),
            resolution_status=ResolutionStatus.RESOLVED,
        )
        inv = DependencyInvocation(
            "execute():I1", "execute()", "repository", "Repo", "save",
            (InvocationArgument("entity", inferred_type="Entity"),), contract,
            return_value_consumed=False,
            consumption_kind=ReturnConsumptionKind.IGNORED,
        )
        plan = build_stub_plans(SimpleNamespace(dependency_invocations=(inv,)))[0]
        self.assertFalse(plan.stub_required)
        self.assertFalse(plan.return_value_consumed)

    def test_ignored_non_void_exception_stub_is_allowed(self) -> None:
        contract = DependencyMethodContract(
            "repository", "Repo", "save", "Entity", ("Entity",),
            resolution_status=ResolutionStatus.RESOLVED,
        )
        inv = DependencyInvocation(
            "execute():I1", "execute()", "repository", "Repo", "save",
            (InvocationArgument("entity", inferred_type="Entity"),), contract,
            return_value_consumed=False,
            consumption_kind=ReturnConsumptionKind.EXCEPTION_SCENARIO,
        )
        ctx, method, method_context = self._ctx_for_invocation(inv)
        block = """
        @Test void repositoryFailure() {
            when(repository.save(any())).thenThrow(new RuntimeException("boom"));
            assertThrows(RuntimeException.class, () -> sampleServiceImpl.execute());
        }
        """
        result = validate_method_block(ctx, method, method_context, block, set())
        self.assertTrue(result.ok, result.reason)

    def test_consumed_non_void_return_requires_stub(self) -> None:
        contract = DependencyMethodContract(
            "repository", "Repo", "save", "Entity", ("Entity",),
            resolution_status=ResolutionStatus.RESOLVED,
        )
        inv = DependencyInvocation(
            "execute():I1", "execute()", "repository", "Repo", "save",
            (InvocationArgument("entity", inferred_type="Entity"),), contract,
            assigned_to="saved",
            return_value_consumed=True,
            consumption_kind=ReturnConsumptionKind.DIRECT_DEREFERENCE,
        )
        plan = build_stub_plans(SimpleNamespace(dependency_invocations=(inv,)))[0]
        self.assertTrue(plan.stub_required)
        self.assertTrue(plan.return_value_consumed)

    def test_assigned_but_unread_return_is_ignored(self) -> None:
        contract = DependencyMethodContract(
            "repository", "Repo", "save", "Entity", ("Entity",),
            resolution_status=ResolutionStatus.RESOLVED,
        )
        inv = DependencyInvocation(
            "execute():I1", "execute()", "repository", "Repo", "save",
            (InvocationArgument("entity", inferred_type="Entity"),), contract,
            assigned_to="saved",
            return_value_consumed=False,
            consumption_kind=ReturnConsumptionKind.ASSIGNED_UNREAD,
        )
        plan = build_stub_plans(SimpleNamespace(dependency_invocations=(inv,)))[0]
        self.assertFalse(plan.stub_required)


class PromptAndTransitiveFixtureRegressionTest(unittest.TestCase):
    def test_method_prompt_contains_fixture_only_and_return_consumption_rules(self) -> None:
        method = MethodSig("execute", modifiers={"public"}, return_type="void")
        contract = DependencyMethodContract(
            "repo", "Repo", "save", "Entity", ("Entity",),
            resolution_status=ResolutionStatus.RESOLVED,
        )
        invocation = DependencyInvocation(
            "execute():I1", "execute()", "repo", "Repo", "save",
            (InvocationArgument("entity", inferred_type="Entity"),), contract,
            return_value_consumed=False,
            consumption_kind=ReturnConsumptionKind.IGNORED,
        )
        method_context = MethodExecutionContext(
            "execute()", method.render(), (1, 2), "public void execute() { repo.save(entity); }", None,
            dependency_invocations=(invocation,),
        )
        ctx = _context(method, method_context)
        prompt = build_method_generation_messages(ctx, method, "")[1]["content"]
        self.assertIn("Never derive or guess an application class name", prompt)
        self.assertIn("generate no normal stub and never use doNothing", prompt)
        self.assertIn("Never use new SchemaType", prompt)

    def test_compile_repair_prompt_preserves_deterministic_restrictions(self) -> None:
        method = MethodSig("execute", modifiers={"public"}, return_type="void")
        method_context = MethodExecutionContext(
            "execute()", method.render(), (1, 2), "public void execute() {}", None,
        )
        ctx = _context(method, method_context)
        messages = build_method_compile_repair_messages(
            ctx, method, "@Test void t(){ sampleServiceImpl.execute(); }",
            [CompileError(Path("T.java"), 1, None, "cannot find symbol")],
        )
        prompt = messages[1]["content"]
        self.assertIn("never infer a class from a repository", prompt)
        self.assertIn("whose return is marked ignored require no normal stub", prompt)
        self.assertIn("call the existing fixture helper", prompt)

    def test_transitive_fixture_closure_exposes_nested_contact_fixture(self) -> None:
        contact = ClassSymbol(
            "GiContactEntity", "sample.GiContactEntity", "class", modifiers={"public"},
            fields=[FieldSig("contactType", "String", modifiers={"private"})],
            methods=[
                MethodSig("getContactType", modifiers={"public"}, return_type="String"),
                MethodSig("setContactType", modifiers={"public"}, return_type="void", params=[("String", "value")]),
            ],
        )
        person = ClassSymbol(
            "GiPersonEntity", "sample.GiPersonEntity", "class", modifiers={"public"},
            fields=[FieldSig("contacts", "List<GiContactEntity>", modifiers={"private"})],
            methods=[
                MethodSig("getContacts", modifiers={"public"}, return_type="List<GiContactEntity>"),
                MethodSig("setContacts", modifiers={"public"}, return_type="void", params=[("List<GiContactEntity>", "value")]),
            ],
        )
        method = MethodSig(
            "execute", modifiers={"public"}, return_type="String",
            params=[("GiPersonEntity", "person")], line=3, end_line=5,
        )
        service = ClassSymbol(
            "SampleServiceImpl", "sample.SampleServiceImpl", "class", modifiers={"public"},
            methods=[method],
        )
        source = """package sample;
public class SampleServiceImpl {
 public String execute(GiPersonEntity person) {
   return person.getContacts().get(0).getContactType();
 }
}
"""
        jf = JavaSourceFile(
            Path("SampleServiceImpl.java"), package="sample", types=[service], source=source,
        )
        symbols = {
            "GiPersonEntity": person, person.fqcn: person,
            "GiContactEntity": contact, contact.fqcn: contact,
        }
        context = build_execution_context(
            source_file=jf,
            symbol=service,
            lookup=lambda name: symbols.get(name) or symbols.get(name.rsplit(".", 1)[-1]),
            target_kind=ExecutionTargetKind.SERVICE_IMPL,
        )
        method_ctx = context.methods[0]
        self.assertIn("sample.GiPersonEntity", method_ctx.required_fixture_ids)
        self.assertIn("sample.GiContactEntity", method_ctx.required_fixture_ids)


class JavacDiagnosticsAndSchedulingTest(unittest.TestCase):
    def test_javac_command_contains_verbose_and_max_error_flags(self) -> None:
        captured: list[str] = []

        def runner(cmd: list[str], timeout: int):
            captured.extend(cmd)
            return subprocess.CompletedProcess(cmd, 0, "", "")

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "A.java"
            source.write_text("class A {}", encoding="utf-8")
            result = JavacRunner("", root / "out", runner=runner, javac_path="javac").compile_one(source)
        self.assertTrue(result.ok)
        self.assertIn("-Xmaxerrs", captured)
        self.assertEqual("1000", captured[captured.index("-Xmaxerrs") + 1])
        self.assertIn("-Xdiags:verbose", captured)
        self.assertLess(captured.index("-Xdiags:verbose"), captured.index(str(source)))

    def test_more_than_100_diagnostics_are_retained(self) -> None:
        stderr = "\n".join(
            f"C:\\repo\\GeneratedTest.java:{i}: error: error-{i}" for i in range(1, 151)
        ) + "\n150 errors\n"
        self.assertEqual(150, len(parse_javac_errors(stderr)))
        self.assertEqual(150, len(parse_errors(stderr)))

    def test_verbose_multiline_detail_stays_with_primary_error(self) -> None:
        stderr = """C:\\repo\\GeneratedTest.java:12: error: method save in interface Repo cannot be applied to given types;
  required: S
  found:    Object
  reason: inference variable S has incompatible bounds
    lower bounds: Entity
    lower bounds: Object
1 error
"""
        error = parse_javac_errors(stderr)[0]
        self.assertIn("lower bounds: Entity", error.detail)
        self.assertIn("lower bounds: Object", error.detail)

    def test_no_progress_owner_is_excluded_and_next_owner_is_selected(self) -> None:
        suite = "class T {\n"
        suite = insert_method_block(suite + "}\n", "a()", "@Test void ta() {}")
        suite = insert_method_block(suite, "b()", "@Test void tb() {}")
        lines = suite.splitlines()
        line_a = next(i for i, line in enumerate(lines, 1) if "void ta" in line)
        line_b = next(i for i, line in enumerate(lines, 1) if "void tb" in line)
        errors = [
            CompileError(Path("T.java"), line_a, None, "a1"),
            CompileError(Path("T.java"), line_a, None, "a2"),
            CompileError(Path("T.java"), line_b, None, "b1"),
        ]
        selected, counts, unmapped = _select_method_repair_owner(suite, errors, {"a()"})
        self.assertEqual("b()", selected)
        self.assertEqual(2, counts["a()"])
        self.assertEqual(0, unmapped)

    def test_unmapped_header_error_is_reported_separately(self) -> None:
        suite = "import sample.Missing;\nclass T {\n}\n"
        errors = [CompileError(Path("T.java"), 1, None, "cannot find symbol")]
        selected, counts, unmapped = _select_method_repair_owner(suite, errors)
        self.assertIsNone(selected)
        self.assertFalse(counts)
        self.assertEqual(1, unmapped)


if __name__ == "__main__":
    unittest.main()
