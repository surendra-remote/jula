from __future__ import annotations

from copy import deepcopy
from dataclasses import replace
import importlib
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

from junitforge.audit import NullAuditRecorder
from junitforge.compile_gate import CompileError
from junitforge.compilation.provider_response import FocusedProviderMetadata, response_hash
from junitforge.compilation.repair_coordinator import CompilationRepairMixin
from junitforge.config import GenConfig
from junitforge.cli import _final_audit_status
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageSignals,
    RuntimeTestRunResult,
    SurefireFailure,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import insert_method_block
from junitforge.execution.fixture_builder_emitter import emit_fixture_catalog
from junitforge.execution.models import ExecutionContext, ExecutionTargetKind, MethodExecutionContext
from junitforge.execution.payload_schema import (
    apply_usage_constraints,
    build_payload_schemas,
    extract_collection_requirements,
)
from junitforge.generation.fixture_variants import augment_fixture_variant
from junitforge.generation.method_generator import GenerationMixin
from junitforge.generation.payloads import serviceimpl
from junitforge.generation.semantic_validation import (
    deterministically_correct_serviceimpl,
    validate_serviceimpl_semantics,
)
from junitforge.loop import Engine
from junitforge.models import (
    ClassSymbol,
    ClasspathProfile,
    CompileState,
    GenerationContext,
    MethodDisposition,
    MethodSig,
    MethodGenerationRecord,
    ModuleInfo,
    RuntimeResultSnapshot,
    StackProfile,
    TargetOutcome,
    TemplateSpec,
    TestCaseRecord as RegistryTestCaseRecord,
    TestDisposition as RegistryTestDisposition,
    TestKind as RegistryTestKind,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_source
from junitforge.publication.publisher import PublicationMixin
from junitforge.registry import RegistryStore, recalculate_registry_ranges, source_hash
from junitforge.report import _summary, write_reports
from junitforge.runtime.result_parser import group_runtime_failures_by_test, map_runtime_failure_test
from junitforge.summary import TargetSummary, render_run_summary
from junitforge.vendor.javac import CompileResult, JavacRunner
from junitforge.vendor.llm.base import LLMResponse, TokenUsage


SOURCES = {
    "JpaRepository.java": """package org.springframework.data.jpa.repository;
public interface JpaRepository<T, ID> {
    T saveAndFlush(T entity);
}
""",
    "BaseRepository.java": """package sample;
public interface BaseRepository<T, ID>
        extends org.springframework.data.jpa.repository.JpaRepository<T, ID> {
}
""",
    "PolicyRepository.java": """package sample;
public interface PolicyRepository extends BaseRepository<Policy, Long> {
}
""",
    "Customer.java": """package sample;
public class Customer {
    private String name;
    public Customer() {}
    public String getName() { return name; }
    public void setName(String value) { name = value; }
}
""",
    "Bill.java": """package sample;
public class Bill {
    private String code;
    public Bill() {}
    public String getCode() { return code; }
    public void setCode(String value) { code = value; }
}
""",
    "Policy.java": """package sample;
import java.util.List;
public class Policy {
    private Customer customer;
    private List<Bill> bills;
    private Character status;
    public Policy() {}
    public Customer getCustomer() { return customer; }
    public void setCustomer(Customer value) { customer = value; }
    public List<Bill> getBills() { return bills; }
    public void setBills(List<Bill> value) { bills = value; }
    public Character getStatus() { return status; }
    public void setStatus(Character value) { status = value; }
}
""",
    "PaymentServiceImpl.java": """package sample;
public class PaymentServiceImpl {
    private final PolicyRepository repository;
    public PaymentServiceImpl(PolicyRepository repository) {
        this.repository = repository;
    }
    public Policy execute(Policy policy) {
        repository.saveAndFlush(policy);
        String name = policy.getCustomer().getName();
        String code = policy.getBills().get(1).getCode();
        return name != null && code != null ? policy : null;
    }
}
""",
}


def _parse_context(tmp_path: Path):
    parsed = [parse_source(Path(name), source) for name, source in SOURCES.items()]
    symbols = [item.primary_type for item in parsed if item.primary_type is not None]
    index = {}
    for symbol in symbols:
        index[symbol.name] = symbol
        index[symbol.fqcn] = symbol

    def lookup(name: str, *_args):
        raw = name.split("<", 1)[0]
        return index.get(name) or index.get(raw) or index.get(raw.rsplit(".", 1)[-1])

    target_file = parsed[-1]
    target = target_file.primary_type
    assert target is not None
    collaborators = resolve_collaborators(target, lookup)
    execution = build_execution_context(
        source_file=target_file,
        symbol=target,
        lookup=lookup,
        target_kind=ExecutionTargetKind.SERVICE_IMPL,
    )
    assert execution is not None and len(execution.methods) == 1
    method_context = execution.methods[0]

    schemas, diagnostics = build_payload_schemas(
        ["Policy"],
        lookup,
        path_requests=[("Policy", "customer.name"), ("Policy", "bills.code")],
    )
    assert diagnostics == []
    schemas = apply_usage_constraints(
        schemas,
        [method_context.method_source],
        extract_collection_requirements(method_context.method_source),
    )
    emitted = emit_fixture_catalog(schemas)
    assert not emitted.diagnostics
    method_context = replace(
        method_context,
        payload_schemas=tuple(schemas),
        required_schema_ids=tuple(schema.fqcn for schema in schemas),
        required_fixture_ids=tuple(fixture.fixture_id for fixture in emitted.fixtures),
    )
    execution = replace(
        execution,
        methods=(method_context,),
        payload_schemas=tuple(schemas),
        fixtures=tuple(emitted.fixtures),
    )
    ctx = GenerationContext(
        cut_source=SOURCES["PaymentServiceImpl.java"],
        symbol=target,
        collaborators=collaborators,
        test_package="sample",
        test_class_name="PaymentServiceImplTest",
        stack=StackProfile(java_version="17"),
        classpath=ClasspathProfile(has_junit_jupiter=True, has_mockito=True),
        template=TemplateSpec(RegistryTestKind.PURE_UNIT, "unit"),
        source_path=tmp_path / "PaymentServiceImpl.java",
        execution_context=execution,
    )
    return ctx, lookup, emitted


def _write_java_inputs(root: Path) -> list[Path]:
    paths = []
    for name, source in SOURCES.items():
        package = "org/springframework/data/jpa/repository" if name == "JpaRepository.java" else "sample"
        path = root / package / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(source, encoding="utf-8")
        paths.append(path)
    return paths


def _compile_sources(root: Path, files: list[Path]) -> CompileResult:
    return JavacRunner(
        classpath="",
        output_dir=root / "classes",
        release="17",
    ).compile_many(files)


class _GenerationHarness(GenerationMixin):
    def __init__(self, source: str):
        self.llm = MagicMock()
        self.llm.chat.return_value = LLMResponse(
            source,
            usage=TokenUsage(prompt_tokens=12, completion_tokens=8, total_tokens=20),
            response_state="COMPLETED",
            finish_reason="stop",
        )
        self.cfg = SimpleNamespace(
            model_id="fake-deterministic",
            temperature_gen=0.0,
            max_tokens_gen=1000,
            temperature_repair=0.0,
            max_tokens_repair=1000,
        )
        self.audit = NullAuditRecorder()


class _CompileHarness(CompilationRepairMixin):
    def __init__(self, llm_source: str):
        self.llm_source = llm_source
        self.cfg = SimpleNamespace(temperature_repair=0.0, max_tokens_repair=512)
        self.audit = NullAuditRecorder()
        self.compile_calls: list[str] = []
        self.llm = object()

    def _compile_candidate(self, test_path, module):
        source = Path(test_path).read_text(encoding="utf-8")
        self.compile_calls.append(source)
        bad_line = next((i for i, line in enumerate(source.splitlines(), 1) if "BAD" in line), None)
        ok = bad_line is None
        result = SimpleNamespace(ok=ok, return_code=0 if ok else 1, stdout="", stderr="", cmd=["javac"])
        errors = [] if ok else [CompileError(Path(test_path), bad_line, 1, "cannot find symbol")]
        return result, errors

    def _deterministic_focused_candidate(self, ctx, test_record, diagnostics):
        return None, [], "no deterministic correction"

    def _focused_llm_response(self, *, ctx, outcome, test_record, diagnostics):
        outcome.focused_compile_repair_attempts += 1
        metadata = FocusedProviderMetadata(
            response_state="COMPLETED",
            finish_reason="stop",
            input_token_count=10,
            output_token_count=20,
            response_size=len(self.llm_source),
            request_hash="request",
            response_hash=response_hash(self.llm_source),
            truncation_state="NOT_TRUNCATED",
            normalization_result="RAW_JAVA_ACCEPTED",
        )
        return self.llm_source, metadata, "VALID"


def _runtime_result(*, tests: tuple[str, ...], failures: tuple[SurefireFailure, ...] = ()):
    errors = sum(1 for item in failures if item.status == "error")
    return RuntimeTestRunResult(
        True,
        "synthetic",
        signals=CoverageSignals(
            tests_executed=True,
            tests_run=len(tests),
            tests_failed=len(failures) - errors,
            tests_errors=errors,
        ),
        failures=failures,
        executed_test_names=tests,
    )


def test_integrated_synthetic_serviceimpl_release_workflow(tmp_path: Path) -> None:
    ctx, _lookup, emitted = _parse_context(tmp_path)
    method = ctx.symbol.methods[0]
    method_context = ctx.execution_context.methods[0]

    # Parsing, collaborator resolution, inherited Spring Data generics, and
    # return-consumption semantics are connected in one analyzed method.
    assert [item.simple for item in ctx.collaborators] == ["PolicyRepository"]
    invocation = method_context.dependency_invocations[0]
    assert invocation.contract.repository_entity_type == "Policy"
    assert invocation.contract.repository_id_type == "Long"
    assert invocation.contract.return_type == "Policy"
    assert invocation.return_value_consumed is False
    assert invocation.consumption_kind.value == "ignored"

    # Schema catalogue, baseline graph, collection minimums, dependencies, and
    # cycle-safe bounded emission.
    policy_schema = next(schema for schema in ctx.execution_context.payload_schemas if schema.type_name == "Policy")
    props = {prop.name: prop for prop in policy_schema.properties}
    assert props["customer"].baseline_required
    assert props["bills"].baseline_required and props["bills"].minimum_size == 2
    policy_fixture = next(f for f in emitted.fixtures if f.return_type == "Policy")
    assert set(policy_fixture.dependent_fixture_ids) == {"sample.Customer", "sample.Bill"}
    assert set(policy_fixture.transitive_fixture_ids) == {"sample.Customer", "sample.Bill"}

    java_root = tmp_path / "java"
    java_inputs = _write_java_inputs(java_root)
    fixture_harness = java_root / "sample/FixtureHarness.java"
    fixture_harness.write_text(
        "package sample;\nimport java.util.ArrayList;\nimport java.util.List;\n"
        "public class FixtureHarness {\n"
        + "\n".join(fixture.method_source for fixture in emitted.fixtures)
        + "\n}\n",
        encoding="utf-8",
    )
    fixture_compile = _compile_sources(java_root, java_inputs + [fixture_harness])
    assert fixture_compile.ok, fixture_compile.stderr

    # Deterministic generation correction followed by scenario-specific fixture
    # variant compilation and publication.
    invalid = """@Test
void execute_status() {
    Policy policy = validPolicy();
    policy.setStatus("P");
    paymentServiceImpl.execute(policy);
}
"""
    semantic_before = validate_serviceimpl_semantics(ctx, method, method_context, invalid)
    assert not semantic_before.ok
    corrected = deterministically_correct_serviceimpl(ctx, method, method_context, invalid)
    assert "setStatus('P')" in corrected.source

    def compile_variant(_name: str, helper_source: str):
        variant_harness = java_root / "sample/FixtureVariantHarness.java"
        variant_harness.write_text(
            "package sample;\nimport java.util.ArrayList;\nimport java.util.List;\n"
            "public class FixtureVariantHarness {\n"
            + "\n".join(fixture.method_source for fixture in emitted.fixtures)
            + "\n"
            + helper_source
            + "\n}\n",
            encoding="utf-8",
        )
        result = _compile_sources(java_root / "variant", java_inputs + [variant_harness])
        return result.ok, tuple(result.errors or (result.stderr,))

    augmented = augment_fixture_variant(ctx, corrected.source, compile_variant=compile_variant)
    assert augmented.attempted and augmented.accepted and augmented.variant is not None
    assert augmented.variant.scenario_variant and augmented.variant.exposed_to_generation
    assert "policy.setStatus" not in augmented.source
    assert validate_serviceimpl_semantics(ctx, method, method_context, augmented.source).ok

    # Fake deterministic method generation, semantic validation, and registry
    # record initialization.
    generated_test = """@Test
void execute_valid() {
    Policy policy = validPolicy();
    Policy result = paymentServiceImpl.execute(policy);
    assertNotNull(result);
}
"""
    outcome = TargetOutcome(
        fqcn=ctx.symbol.fqcn,
        module="sample",
        source_path=str(ctx.source_path),
        test_path=str(tmp_path / "PaymentServiceImplTest.java"),
        classification="service-impl",
        testable=True,
        registry_path=str(tmp_path / "audit/07-class-assembly/registry.json"),
    )
    record = MethodGenerationRecord(method_context.method_id, final_status=MethodDisposition.SKIPPED.value)
    outcome.method_results = [record]
    generation = _GenerationHarness(generated_test)
    generated = generation.generate_one((0, method, method_context, record), ctx, 1, outcome)
    assert generated[2] is not None and generated[3] == ("execute_valid",)
    generated_record = record.tests[0]
    assert generated_record.test_id == "execute(Policy)::execute_valid"
    assert generated_record.generated_source and generated_record.latest_accepted_source == ""

    # Assembly, line ranges, registry persistence, and real test-class javac.
    skeleton = (
        "package sample;\nimport java.util.ArrayList;\nimport java.util.List;\n"
        "@interface Test {}\n"
        "public class PaymentServiceImplTest {\n"
        "  private final PolicyRepository repository = new PolicyRepository() {\n"
        "    public Policy saveAndFlush(Policy entity) { return entity; }\n"
        "  };\n"
        "  private final PaymentServiceImpl paymentServiceImpl = new PaymentServiceImpl(repository);\n"
        "  private static void assertNotNull(Object value) { if (value == null) throw new AssertionError(); }\n"
        + "\n".join(fixture.method_source for fixture in ctx.execution_context.fixtures)
        + "\n// JUNITFORGE_METHOD_BEGIN: execute(Policy)\n"
        "// JUNITFORGE_METHOD_END: execute(Policy)\n"
        "}\n"
    )
    assembled = insert_method_block(skeleton, method_context.method_id, generated[2])
    test_path = Path(outcome.test_path)
    test_path.write_text(assembled, encoding="utf-8")
    recalculate_registry_ranges(
        outcome,
        assembled,
        fixture_method_names=tuple(f.method_name for f in ctx.execution_context.fixtures),
    )
    assert generated_record.source_start_line and generated_record.source_end_line
    class_compile = _compile_sources(java_root / "testclass", java_inputs + [test_path])
    assert class_compile.ok, class_compile.stderr

    # Candidate lifecycle and rollback preserve the immutable generated source.
    store = RegistryStore(outcome)
    first_candidate = generated_record.generated_source.replace("assertNotNull", "assertNotNull")
    store.set_candidate(generated_record, first_candidate)
    store.rollback_candidate(
        generated_record,
        failed_attempt={"action": "synthetic_rejected_candidate"},
    )
    assert generated_record.latest_accepted_source == "" and generated_record.candidate_source == ""
    store.set_candidate(generated_record, first_candidate)
    store.commit_candidate(generated_record)
    assert generated_record.latest_accepted_source == first_candidate
    assert generated_record.generated_source == generated_test.strip()

    # Multiple diagnostics map to exactly one stable test repair unit; unrelated
    # diagnostics stay unmapped rather than being assigned to the nearest test.
    errors = [
        CompileError(test_path, generated_record.source_start_line, 3, "cannot find symbol"),
        CompileError(test_path, generated_record.source_end_line, 5, "incompatible types"),
        CompileError(test_path, len(assembled.splitlines()) + 20, 1, "outside generated source"),
    ]
    from junitforge.compilation.diagnostic_mapper import group_errors_by_test, map_compile_diagnostics

    ownership = map_compile_diagnostics(outcome, errors)
    grouped = group_errors_by_test(outcome, errors)
    assert list(grouped) == [generated_record.test_id]
    assert len(grouped[generated_record.test_id]) == 2
    assert len(ownership.unmapped) == 1

    # Focused fake-LLM compile repair sends and commits one test only. Complete
    # class ServiceImpl LLM repair remains at zero.
    bad_test = "@Test\nvoid broken() {\n    BAD value;\n}"
    compile_source = """class SampleServiceImplTest {
// JUNITFORGE_METHOD_BEGIN: execute()
@Test
void broken() {
    BAD value;
}
// JUNITFORGE_METHOD_END: execute()
}
"""
    compile_record = RegistryTestCaseRecord(
        "execute()", "broken", generated_source=bad_test,
        final_disposition=RegistryTestDisposition.RETAINED.value,
    )
    compile_outcome = TargetOutcome(
        "sample.SampleServiceImpl", "sample", "SampleServiceImpl.java",
        str(tmp_path / "SampleServiceImplTest.java"), "service-impl", True,
        registry_path=str(tmp_path / "compile-registry.json"),
        method_results=[MethodGenerationRecord("execute()", tests=[compile_record])],
    )
    compile_path = Path(compile_outcome.test_path)
    compile_path.write_text(compile_source, encoding="utf-8")
    recalculate_registry_ranges(compile_outcome, compile_source)
    compile_harness = _CompileHarness("@Test\nvoid broken() { assertNotNull(new Object()); }")
    compile_result = compile_harness._compile_registry_focused_repair(
        SimpleNamespace(
            symbol=SimpleNamespace(name="SampleServiceImpl", methods=[SimpleNamespace(name="execute", params=[])]),
            execution_context=SimpleNamespace(fixtures=(), methods=(SimpleNamespace(method_id="execute()"),)),
        ),
        compile_path,
        ModuleInfo("sample", tmp_path, tmp_path / "pom.xml"),
        compile_outcome,
        [CompileError(compile_path, 5, 1, "cannot find symbol")],
    )
    assert compile_result is not None
    assert compile_outcome.focused_compile_repair_attempts == 1
    assert compile_outcome.complete_class_serviceimpl_llm_repair_attempts == 0
    assert compile_record.latest_accepted_source.startswith("@Test")
    assert compile_record.generated_source == bad_test

    # Stable runtime mapping and transactional repair. The runtime candidate is
    # compiled directly once, executes the targeted test then the full class,
    # and never enters compile repair.
    owner = "execute()"
    failing_name = "execute_fails"
    passing_name = "execute_passes"
    original_failing = "@Test void execute_fails() { assertNull(paymentServiceImpl.execute()); }"
    repaired_failing = "@Test void execute_fails() { Object value = paymentServiceImpl.execute(); assertNotNull(value); }"
    runtime_suite = f"""class PaymentServiceImplTest {{
// JUNITFORGE_METHOD_BEGIN: execute()
@Test void execute_passes() {{ assertTrue(true); }}
{original_failing}
// JUNITFORGE_METHOD_END: execute()
}}
"""
    runtime_method = MethodGenerationRecord(
        owner,
        final_status=MethodDisposition.GENERATED.value,
        tests=[
            RegistryTestCaseRecord(
                owner, passing_name,
                generated_source="@Test void execute_passes() { assertTrue(true); }",
                latest_accepted_source="@Test void execute_passes() { assertTrue(true); }",
                final_disposition=RegistryTestDisposition.RETAINED.value,
                compile_state=CompileState.PASSED.value,
            ),
            RegistryTestCaseRecord(
                owner, failing_name,
                generated_source=original_failing,
                latest_accepted_source=original_failing,
                final_disposition=RegistryTestDisposition.RETAINED.value,
                compile_state=CompileState.PASSED.value,
            ),
        ],
    )
    runtime_outcome = TargetOutcome(
        "sample.PaymentServiceImpl", "sample", "PaymentServiceImpl.java",
        str(tmp_path / "RuntimePaymentServiceImplTest.java"), "service-impl", True,
        registry_path=str(tmp_path / "runtime-registry.json"),
        method_results=[runtime_method],
    )
    runtime_path = Path(runtime_outcome.test_path)
    runtime_path.write_text(runtime_suite, encoding="utf-8")
    recalculate_registry_ranges(runtime_outcome, runtime_suite)
    failure = SurefireFailure(
        "sample.PaymentServiceImplTest", failing_name, "failure",
        "org.opentest4j.AssertionFailedError", "expected null", "trace",
        generated_test_line=999, category="ASSERTION_VALUE_MISMATCH",
    )
    mapped, mapping, confidence = map_runtime_failure_test(
        failure, runtime_outcome, expected_test_class="sample.PaymentServiceImplTest"
    )
    assert mapped is not None and mapped.test_id == f"{owner}::{failing_name}"
    assert mapping == "registry_test_id" and confidence == "high"
    groups, unmapped_runtime = group_runtime_failures_by_test(
        [failure], runtime_outcome, expected_test_class="sample.PaymentServiceImplTest"
    )
    assert list(groups) == [mapped.test_id] and not unmapped_runtime

    runtime_symbol_method = MethodSig("execute", modifiers={"public"}, return_type="Object")
    runtime_method_context = MethodExecutionContext(
        method_id=owner,
        signature=runtime_symbol_method.render(),
        source_range=(1, 3),
        method_source="public Object execute() { return new Object(); }",
        endpoint=None,
    )
    runtime_ctx = GenerationContext(
        cut_source=runtime_method_context.method_source,
        symbol=ClassSymbol(
            "PaymentServiceImpl", "sample.PaymentServiceImpl", "class",
            modifiers={"public"}, methods=[runtime_symbol_method],
        ),
        collaborators=[],
        test_package="sample",
        test_class_name="PaymentServiceImplTest",
        stack=StackProfile(),
        classpath=ClasspathProfile(has_junit_jupiter=True, has_mockito=True),
        template=TemplateSpec(RegistryTestKind.PURE_UNIT, "unit"),
        source_path=tmp_path / "PaymentServiceImpl.java",
        execution_context=ExecutionContext(
            target_kind=ExecutionTargetKind.SERVICE_IMPL,
            target_fqcn="sample.PaymentServiceImpl",
            methods=(runtime_method_context,),
        ),
    )
    llm = MagicMock()
    llm.chat.return_value = LLMResponse(
        repaired_failing,
        usage=TokenUsage(prompt_tokens=21, completion_tokens=12, total_tokens=33),
        response_state="COMPLETED", finish_reason="stop",
    )
    compile_gate = MagicMock()
    compile_gate.check.return_value = (CompileResult(ok=True, return_code=0), [])
    runner = MagicMock()
    runner.run_tests.side_effect = [
        _runtime_result(tests=(failing_name,)),
        _runtime_result(tests=(passing_name, failing_name)),
    ]
    engine = Engine(
        llm=llm,
        compile_gate=compile_gate,
        coverage_runner=runner,
        stack=StackProfile(), modules=[], repo_root=tmp_path,
        lookup=lambda _name: None,
        cfg=GenConfig(max_runtime_repair_rounds=2, max_runtime_repairs_per_owner=1),
    )
    engine._compile_with_repair = MagicMock(side_effect=AssertionError("nested compile repair invoked"))
    accepted, full_run, reason = engine._repair_runtime_owner(
        ctx=runtime_ctx,
        test_path=runtime_path,
        module=ModuleInfo("sample", tmp_path, tmp_path / "pom.xml"),
        owner=owner,
        owner_failures=[failure],
        before_run=CoverageRunResult(
            ok=True, measured=True, note="before",
            signals=CoverageSignals(tests_executed=True, tests_run=2, tests_failed=1),
            failures=(failure,), executed_test_names=(passing_name, failing_name),
            maven_execution_success=True, coverage_current=True,
        ),
        outcome=runtime_outcome,
        test_fqcn="sample.PaymentServiceImplTest",
        round_no=1,
        attempt_no=1,
    )
    assert accepted and full_run is not None and reason == "accepted"
    engine._compile_with_repair.assert_not_called()
    assert compile_gate.check.call_count == 1
    runtime_record = runtime_method.tests[1]
    assert runtime_record.latest_accepted_source == repaired_failing
    assert runtime_record.generated_source == original_failing
    assert runtime_record.runtime_repair_attempts[-1]["compile_repair_llm_calls"] == 0

    # Summary/reporting and publication consume the same authoritative records.
    runtime_outcome.retained_tests = 2
    runtime_outcome.runtime_repair_attempts = 1
    runtime_outcome.runtime_last_green_full_run = RuntimeResultSnapshot(
        scope="full", tests_run=2, failures=0, errors=0,
        maven_execution_success=True, tests_green=True,
    )
    assert PublicationMixin._select_publishable_source_state(runtime_outcome) == "runtime-green"
    runtime_outcome.coverage_current = True
    runtime_outcome.line_pct = 85.0
    assert PublicationMixin._select_publishable_source_state(runtime_outcome) == "coverage-accepted"
    summary = _summary([compile_outcome, runtime_outcome])
    assert summary["generated_tests"] == 3
    assert summary["retained_tests"] == 3
    assert summary["rejected_tests"] == 0
    assert summary["repaired_tests"] >= 2
    assert summary["focused_compile_repair_attempts"] == 1
    assert summary["runtime_repair_attempts"] == 1
    json_report, md_report = write_reports(
        tmp_path / "reports", tmp_path, StackProfile(java_version="17"),
        [compile_outcome, runtime_outcome], timestamp="phase7",
    )
    assert json_report.exists() and md_report.exists()
    report_payload = json.loads(json_report.read_text(encoding="utf-8"))
    assert report_payload["summary"]["repaired_tests"] >= 2
    assert "Fixture variants" in md_report.read_text(encoding="utf-8")


def test_prompt_composition_is_single_preserved_and_method_focused(tmp_path: Path) -> None:
    ctx, _lookup, _emitted = _parse_context(tmp_path)
    method = ctx.symbol.methods[0]
    method_context = ctx.execution_context.methods[0]
    generated = serviceimpl.build_generation_payload(ctx, method, mode="method")
    compile_repair = serviceimpl.build_compile_repair_payload(
        ctx,
        "@Test void exact() { Policy policy = validPolicy(); paymentServiceImpl.execute(policy); }",
        [CompileError(Path("PaymentServiceImplTest.java"), 10, 2, "cannot find symbol")],
        method=method,
        test_name="exact",
        test_id="execute(Policy)::exact",
        mode="individual",
    )
    runtime_repair = serviceimpl.build_runtime_repair_payload(
        ctx,
        method,
        failing_tests=[{
            "test_id": "execute(Policy)::exact",
            "owner_method_id": "execute(Policy)",
            "test_name": "exact",
            "source": "@Test void exact() { Policy policy = validPolicy(); paymentServiceImpl.execute(policy); }",
            "runtime_status": "failure",
            "diagnostics": [{"category": "ASSERTION_VALUE_MISMATCH", "message": "expected non-null"}],
        }],
    )
    payloads = [json.loads(messages[1]["content"]) for messages in (generated, compile_repair, runtime_repair)]
    expected_generation = deepcopy(serviceimpl._GENERATION_INSTRUCTION)
    expected_compile = deepcopy(serviceimpl._GENERATION_INSTRUCTION)
    expected_compile["objective"]["requested_test_kind"] = "focused_compile_repair"
    expected_runtime = deepcopy(serviceimpl._GENERATION_INSTRUCTION)
    expected_runtime["objective"]["requested_test_kind"] = "focused_runtime_repair"
    assert payloads[0]["general_instructions"] == expected_generation
    assert payloads[1]["general_instructions"] == expected_compile
    assert payloads[2]["general_instructions"] == expected_runtime
    for payload in payloads:
        assert list(key for key in payload if key == "general_instructions") == ["general_instructions"]
        assert "complete_fixture_catalogue" not in json.dumps(payload)
        assert "complete_collaborator_catalogue" not in json.dumps(payload)
        assert len(json.dumps(payload).encode("utf-8")) < 200_000
    assert compile_repair[1]["content"].count("saveAndFlush") <= 2
    assert "current_test_source" not in json.dumps(payloads[0]["general_instructions"])
    assert "current_test_source" not in json.dumps(payloads[1]["general_instructions"])


def test_reporting_and_publication_do_not_claim_unverified_success(tmp_path: Path) -> None:
    outcome = TargetOutcome(
        "sample.ServiceImpl", "sample", "ServiceImpl.java", "ServiceImplTest.java",
        "service-impl", True, status="compiled",
    )
    assert PublicationMixin._select_publishable_source_state(outcome) == "compiling"
    rendered = TargetSummary.from_outcome(outcome).render()
    assert rendered.splitlines()[1].rstrip().endswith("OK")
    run = render_run_summary([TargetSummary.from_outcome(outcome)])
    assert "1 ok | 0 failed" in run
    prefixed = replace(outcome, status="compiled (coverage unmeasured: unavailable)")
    assert TargetSummary.from_outcome(prefixed).render().splitlines()[1].rstrip().endswith("OK")
    assert _final_audit_status([outcome]) == "completed"
    failed = replace(outcome, status="compile_failed")
    assert _final_audit_status([failed]) == "completed_with_failures"


def test_primary_package_imports_and_final_version() -> None:
    modules = [
        "junitforge",
        "junitforge.loop",
        "junitforge.pipeline.engine",
        "junitforge.pipeline.context",
        "junitforge.generation.method_generator",
        "junitforge.generation.fixture_variants",
        "junitforge.generation.semantic_validation",
        "junitforge.compilation.repair_coordinator",
        "junitforge.compilation.diagnostic_mapper",
        "junitforge.runtime.repair_coordinator",
        "junitforge.runtime.result_parser",
        "junitforge.publication.publisher",
        "junitforge.publication.report",
        "junitforge.report",
        "junitforge.summary",
    ]
    loaded = [importlib.import_module(name) for name in modules]
    assert all(loaded)
    from junitforge import __version__
    assert __version__ == "11.0.0"
