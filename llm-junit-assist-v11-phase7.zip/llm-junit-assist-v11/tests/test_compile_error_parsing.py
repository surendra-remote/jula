from __future__ import annotations

import logging
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from junitforge.compile_gate import CompileGate, parse_javac_errors
from junitforge.models import ModuleInfo
from junitforge.vendor.javac import CompileResult, JavacRunner, parse_errors


class WindowsJavacErrorParsingTest(unittest.TestCase):
    def test_structured_parser_accepts_windows_drive_letter_paths(self) -> None:
        stderr = """C:\\repo\\src\\test\\java\\sample\\GeneratedTest.java:487: error: method setRnldurn in class GiContractHeaderEntity cannot be applied to given types;
        value.setRnldurn(1);
             ^
  required: byte
  found:    int
  reason: argument mismatch; possible lossy conversion from int to byte
C:\\repo\\src\\test\\java\\sample\\GeneratedTest.java:547: error: incompatible types: possible lossy conversion from int to short
"""
        errors = parse_javac_errors(stderr)
        self.assertEqual(2, len(errors))
        self.assertEqual(487, errors[0].line)
        self.assertEqual(r"C:\repo\src\test\java\sample\GeneratedTest.java", str(errors[0].file))
        self.assertIn("required: byte", errors[0].detail)
        self.assertIn("found: int", errors[0].detail)
        self.assertIn("lossy conversion", errors[0].render())

    def test_compact_parser_accepts_windows_drive_letter_paths(self) -> None:
        stderr = """C:\\repo\\GeneratedTest.java:12: error: incompatible types: possible lossy conversion from int to byte
  required: byte
  found:    int
"""
        errors = parse_errors(stderr)
        self.assertEqual(1, len(errors))
        self.assertIn("required: byte", errors[0])
        self.assertIn("found: int", errors[0])

    def test_compile_gate_logs_every_parsed_diagnostic(self) -> None:
        stderr = """C:\\repo\\GeneratedTest.java:12: error: cannot find symbol
  symbol:   class MissingType
  location: class GeneratedTest
C:\\repo\\GeneratedTest.java:18: error: incompatible types: int cannot be converted to byte
  required: byte
  found:    int
"""
        result = CompileResult(
            ok=False,
            stderr=stderr,
            return_code=1,
            cmd=["javac", "GeneratedTest.java"],
        )

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            test_file = root / "GeneratedTest.java"
            test_file.write_text("class GeneratedTest {}", encoding="utf-8")
            module = ModuleInfo(name="sample", root=root, pom=root / "pom.xml")
            gate = CompileGate(repo_root=root, cache_dir=root / ".junitforge")

            with patch.object(JavacRunner, "compile_one", return_value=result):
                with self.assertLogs("junitforge.compile_gate", level=logging.DEBUG) as captured:
                    compiled, errors = gate.check(test_file, module)

        self.assertFalse(compiled.ok)
        self.assertEqual(2, len(errors))
        output = "\n".join(captured.output)
        self.assertIn("[COMPILE_GATE] check.start", output)
        self.assertIn("[COMPILE_GATE] check.result", output)
        self.assertIn("diagnostic 1/2", output)
        self.assertIn("diagnostic 2/2", output)
        self.assertIn("symbol: class MissingType", output)
        self.assertIn("required: byte", output)


if __name__ == "__main__":
    unittest.main()
