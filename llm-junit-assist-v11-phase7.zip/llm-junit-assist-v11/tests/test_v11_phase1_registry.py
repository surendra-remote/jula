from __future__ import annotations

import importlib
import json
from pathlib import Path
from unittest.mock import patch

import pytest

from junitforge.models import (
    CompileState,
    MethodGenerationRecord,
    TargetOutcome,
    TestCaseRecord as CaseRecord,
    TestDisposition as CaseDisposition,
)
from junitforge.publication.summary import _refresh_generation_counters
from junitforge.registry import (
    InvalidCompileStateTransition,
    RegistryPersistenceError,
    RegistryStore,
    atomic_write_registry,
    load_registry,
    source_hash,
)


def _outcome(path: Path | None = None) -> tuple[TargetOutcome, MethodGenerationRecord, CaseRecord]:
    test = CaseRecord(
        owner_method_id="execute(String)",
        test_name="execute_success",
        scenario_id="SUCCESS",
        generated_source="@Test\nvoid execute_success() {}",
        final_disposition=CaseDisposition.RETAINED.value,
    )
    method = MethodGenerationRecord(
        method_id="execute(String)",
        tests_retained=1,
        tests=[test],
    )
    outcome = TargetOutcome(
        fqcn="sample.SampleServiceImpl",
        module="sample",
        source_path="SampleServiceImpl.java",
        test_path="SampleServiceImplTest.java",
        classification="service-impl",
        testable=True,
        registry_path=str(path) if path is not None else None,
        method_results=[method],
    )
    return outcome, method, test


def test_dictionary_repair_history_does_not_crash_summary_reporting() -> None:
    outcome, _method, test = _outcome()
    test.deterministic_repair_history.extend(
        [
            {"action": "fixture_substitution:PaymentResource"},
            {"type": "unnecessary_return_stub_removed:repository.find"},
            {"event": "return_type_corrected:repository.find"},
            {"name": "unknown_member_removed:missingField"},
        ]
    )

    _refresh_generation_counters(outcome)

    assert outcome.fixture_substitutions == 1
    assert outcome.unnecessary_stubs_removed == 1
    assert outcome.return_type_mismatches_corrected == 1
    assert outcome.unknown_member_tests_repaired == 1


def test_legacy_string_repair_history_remains_supported() -> None:
    outcome, _method, test = _outcome()
    test.deterministic_repair_history.extend(
        [
            "fixture_substitution:PaymentResource",
            "void_return_stub_removed:repository.flush",
        ]
    )

    _refresh_generation_counters(outcome)

    assert outcome.fixture_substitutions == 1
    assert outcome.return_type_mismatches_corrected == 1


def test_generated_source_cannot_be_overwritten() -> None:
    _outcome_value, _method, test = _outcome()

    with pytest.raises(AttributeError, match="generated_source is immutable"):
        test.generated_source = "@Test\nvoid changed() {}"

    assert test.generated_source == "@Test\nvoid execute_success() {}"


def test_candidate_commit_updates_only_transactional_source_fields(tmp_path: Path) -> None:
    path = tmp_path / "07-class-assembly" / "registry.json"
    outcome, _method, test = _outcome(path)
    store = RegistryStore(outcome)
    original_generated = test.generated_source

    store.set_candidate(test, "@Test\nvoid execute_success() { assertTrue(true); }")
    store.commit_candidate(test, source_start_line=12, source_end_line=14)

    assert test.generated_source == original_generated
    assert test.latest_accepted_source.endswith("assertTrue(true); }")
    assert test.previous_accepted_source == ""
    assert test.candidate_source == ""
    assert test.source_start_line == 12
    assert test.source_end_line == 14
    assert test.source_hash == source_hash(test.latest_accepted_source)
    assert path.exists()


def test_rollback_preserves_latest_accepted_source(tmp_path: Path) -> None:
    path = tmp_path / "registry.json"
    outcome, _method, test = _outcome(path)
    store = RegistryStore(outcome)
    store.set_candidate(test, "accepted source")
    store.commit_candidate(test)
    accepted_hash = test.source_hash

    store.set_candidate(test, "rejected source")
    store.rollback_candidate(
        test,
        failed_attempt={"action": "compile_attempt", "status": "rejected"},
    )

    assert test.latest_accepted_source == "accepted source"
    assert test.previous_accepted_source == ""
    assert test.source_hash == accepted_hash
    assert test.candidate_source == ""
    assert test.compile_attempts[-1]["status"] == "rejected"


def test_previous_accepted_source_changes_only_after_successful_commit(tmp_path: Path) -> None:
    outcome, _method, test = _outcome(tmp_path / "registry.json")
    store = RegistryStore(outcome)
    store.set_candidate(test, "first")
    store.commit_candidate(test)
    assert test.previous_accepted_source == ""

    store.set_candidate(test, "failed second")
    store.rollback_candidate(test, failed_attempt="second rejected")
    assert test.latest_accepted_source == "first"
    assert test.previous_accepted_source == ""

    store.set_candidate(test, "second")
    store.commit_candidate(test)
    assert test.latest_accepted_source == "second"
    assert test.previous_accepted_source == "first"


def test_source_hash_is_deterministic_across_line_endings_and_trailing_space() -> None:
    left = "\n@Test  \r\nvoid sample() {   \r\n}\r\n\r\n"
    right = "@Test\nvoid sample() {\n}\n"

    assert source_hash(left) == source_hash(right)
    assert source_hash(left) != source_hash("@Test\nvoid other() {}\n")


def test_compile_state_transitions_persist_correctly(tmp_path: Path) -> None:
    path = tmp_path / "registry.json"
    outcome, _method, test = _outcome(path)
    store = RegistryStore(outcome)

    store.transition_compile_state(test, CompileState.FAILED)
    store.transition_compile_state(test, CompileState.DETERMINISTIC_REPAIR_PENDING)
    store.transition_compile_state(test, CompileState.REPAIRED_PENDING_COMPILE)
    store.transition_compile_state(test, CompileState.REPAIRED_AND_PASSED)

    reloaded = load_registry(path)[0].tests[0]
    assert reloaded.compile_state == CompileState.REPAIRED_AND_PASSED.value
    assert reloaded.test_id == "execute(String)::execute_success"


def test_invalid_compile_state_transition_is_rejected(tmp_path: Path) -> None:
    outcome, _method, test = _outcome(tmp_path / "registry.json")
    store = RegistryStore(outcome)

    with pytest.raises(InvalidCompileStateTransition, match="NOT_RUN -> LLM_REPAIR_PENDING"):
        store.transition_compile_state(test, CompileState.LLM_REPAIR_PENDING)

    assert test.compile_state == CompileState.NOT_RUN.value


def test_previous_compile_diagnostics_and_attempts_remain_available(tmp_path: Path) -> None:
    path = tmp_path / "registry.json"
    outcome, _method, test = _outcome(path)
    store = RegistryStore(outcome)

    store.transition_compile_state(
        test,
        CompileState.FAILED,
        diagnostics=["cannot find symbol"],
        attempt={"attempt": 1, "success": False},
    )
    store.transition_compile_state(test, CompileState.DETERMINISTIC_REPAIR_PENDING)
    store.transition_compile_state(
        test,
        CompileState.REPAIRED_PENDING_COMPILE,
        diagnostics=["incompatible types"],
        attempt={"attempt": 2, "success": False},
    )

    reloaded = load_registry(path)[0].tests[0]
    assert len(reloaded.compile_diagnostics) == 2
    assert reloaded.compile_diagnostics[0]["diagnostics"] == ["cannot find symbol"]
    assert reloaded.compile_diagnostics[1]["diagnostics"] == ["incompatible types"]
    assert [item["attempt"] for item in reloaded.compile_attempts] == [1, 2]
    assert reloaded.current_compile_diagnostics == ["incompatible types"]


def test_registry_serialization_and_reload_preserve_all_required_fields(tmp_path: Path) -> None:
    path = tmp_path / "registry.json"
    outcome, _method, test = _outcome(path)
    store = RegistryStore(outcome)
    store.set_validation_state(test, "VALID", diagnostics=["validated"])
    store.set_candidate(test, "accepted")
    store.commit_candidate(test, source_start_line=7, source_end_line=9)
    store.transition_compile_state(
        test,
        CompileState.PASSED,
        attempt={"attempt": 1, "success": True},
    )
    store.append_history(test, "deterministic_repair_history", {"action": "normalized"})
    store.append_history(test, "llm_repair_history", "legacy:accepted")
    store.set_runtime_state(test, "PASSED")
    store.append_history(
        test,
        "runtime_repair_attempts",
        {"action": "runtime_repair_attempt", "attempt": 1},
    )

    loaded = load_registry(path)[0].tests[0]
    required = {
        "test_id",
        "owner_method_id",
        "test_name",
        "scenario_id",
        "generated_source",
        "latest_accepted_source",
        "previous_accepted_source",
        "candidate_source",
        "source_start_line",
        "source_end_line",
        "source_hash",
        "validation_state",
        "validation_diagnostics",
        "compile_state",
        "compile_diagnostics",
        "compile_attempts",
        "deterministic_repair_history",
        "llm_repair_history",
        "runtime_state",
        "runtime_diagnostics",
        "runtime_repair_attempts",
        "final_disposition",
        "final_rejection_reason",
    }
    assert required <= set(loaded.__dataclass_fields__)
    assert loaded.test_id == test.test_id
    assert loaded.generated_source == test.generated_source
    assert loaded.latest_accepted_source == "accepted"
    assert loaded.compile_attempts == [{"attempt": 1, "success": True}]
    assert loaded.deterministic_repair_history == [{"action": "normalized"}]
    assert loaded.llm_repair_history == ["legacy:accepted"]
    assert loaded.runtime_repair_attempts[0]["attempt"] == 1


def test_older_registry_records_load_with_safe_defaults(tmp_path: Path) -> None:
    path = tmp_path / "registry.json"
    path.write_text(
        json.dumps(
            [
                {
                    "method_id": "execute(String)",
                    "tests": [
                        {
                            "owner_method_id": "execute(String)",
                            "test_name": "execute_success",
                            "generated_source": "original",
                            "deterministic_repair_history": ["legacy_action"],
                            "runtime_repair_attempts": 2,
                        }
                    ],
                }
            ]
        ),
        encoding="utf-8",
    )

    loaded = load_registry(path)[0].tests[0]

    assert loaded.test_id == "execute(String)::execute_success"
    assert loaded.latest_accepted_source == ""
    assert loaded.previous_accepted_source == ""
    assert loaded.candidate_source == ""
    assert loaded.compile_state == CompileState.NOT_RUN.value
    assert loaded.compile_attempts == []
    assert loaded.deterministic_repair_history == ["legacy_action"]
    assert len(loaded.runtime_repair_attempts) == 2


def test_failed_atomic_registry_write_does_not_corrupt_prior_file(tmp_path: Path) -> None:
    path = tmp_path / "registry.json"
    outcome, _method, _test = _outcome(path)
    atomic_write_registry(path, outcome.method_results)
    prior = path.read_bytes()

    with patch("junitforge.registry.os.replace", side_effect=OSError("simulated replace failure")):
        with pytest.raises(RegistryPersistenceError):
            atomic_write_registry(path, outcome.method_results)

    assert path.read_bytes() == prior
    assert list(tmp_path.glob(".registry.json.*.tmp")) == []


def test_all_main_junitforge_imports_succeed() -> None:
    modules = (
        "junitforge",
        "junitforge.models",
        "junitforge.registry",
        "junitforge.pipeline",
        "junitforge.pipeline.engine",
        "junitforge.generation",
        "junitforge.compilation",
        "junitforge.runtime",
        "junitforge.coverage",
        "junitforge.publication",
        "junitforge.audit",
    )

    for module in modules:
        assert importlib.import_module(module) is not None


def test_assembly_and_loop_import_without_circular_import() -> None:
    assembly = importlib.import_module("junitforge.execution.assembly")
    loop = importlib.import_module("junitforge.loop")

    assert hasattr(assembly, "build_test_skeleton")
    assert hasattr(loop, "Engine")
