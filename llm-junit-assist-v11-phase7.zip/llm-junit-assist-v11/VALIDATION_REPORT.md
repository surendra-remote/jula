# VALIDATION REPORT

## Release

`llm-junit-assist v7.3.3 — Compile-Repair Rollback and Deterministic Diagnostics Hotfix`

Validation date: 2026-08-03

## Result summary

| Validation | Passed | Failed | Skipped | Result |
|---|---:|---:|---:|---|
| Python compile validation | All project/test modules | 0 | 0 | PASS |
| Focused v7.3 recovery suite | 46 | 0 | 0 | PASS |
| New v7.3.3 regressions | 8 | 0 | 0 | PASS |
| Complete Python suite (`unittest`) | 160 | 0 | 0 | PASS |
| Complete Python suite (`pytest`) | 160 | 0 | 0 | PASS with 5 pre-existing collection warnings |
| Representative synthetic Java compilation | 2 | 0 | 0 | PASS |
| Windows path/log regressions | 4 | 0 | 0 | PASS |
| CLI help smoke check | 1 | 0 | 0 | PASS |
| Complete ZIP integrity | All entries | 0 | 0 | PASS |
| Changed-files ZIP integrity | All entries | 0 | 0 | PASS |

## Exact commands and results

### Python compilation

```bash
python -m compileall -q -f junitforge tests
```

Result: success; no Python syntax or bytecode compilation errors.

### Focused recovery suite

```bash
python -m unittest discover -s tests -p 'test_v73_generation_recovery.py'
```

Result:

```text
Ran 46 tests
OK
```

The eight v7.3.3 regressions verify:

1. tests outside the class body are structurally rejected;
2. changed diagnostics are not progress when the error count increases;
3. missing CUT argument locals are declared from the verified parameter position;
4. an invalid `isX()` accessor is corrected to the unique verified getter;
5. `getX().setX(...)` chained-setter hallucinations are collapsed;
6. an unknown collaborator receiver is corrected only from one unique verified dependency contract;
7. a worsening LLM candidate is rolled back before per-test salvage;
8. repeated owner-block replacement is indentation-idempotent.

### Complete Python suite

```bash
python -m unittest discover -s tests
```

Result:

```text
Ran 160 tests
OK
```

Counts: 160 passed, 0 failed, 0 errors, 0 skipped.

### Pytest cross-check

```bash
python -m pytest -q
```

Result:

```text
160 passed, 5 warnings
```

The five warnings are existing `PytestCollectionWarning` notices for imported `TestKind` enum names. They are not failures or skipped tests.

### Representative Java/Javac validation

```bash
python -m unittest \
  tests.test_schema_fixture_pipeline.SchemaFixturePipelineTest.test_emitted_fixture_java_compiles_and_is_deep \
  tests.test_schema_fixture_pipeline.SchemaFixturePipelineTest.test_byte_and_short_fixture_values_use_explicit_narrowing_casts \
  -v
```

Result:

```text
Ran 2 tests
OK
```

The tests emitted synthetic recursive fixture Java and explicit byte/short narrowing values and compiled them with `javac 21.0.10`.

### Windows regressions

```bash
python -m unittest \
  tests.test_compile_error_parsing.WindowsJavacErrorParsingTest \
  tests.test_v73_generation_recovery.ExistingBehaviorRegressionTest.test_35_windows_runtime_log_filename_remains_safe \
  -v
```

Result:

```text
Ran 4 tests
OK
```

### CLI smoke validation

```bash
python -m junitforge --help
```

Result: exit code 0; existing CLI options remained available.

### Archive integrity

```bash
unzip -t llm-junit-assist-v7.3.3.zip
unzip -t llm-junit-assist-v7.3.3-changed-files.zip
```

Result: both archives completed with no errors.

## Environment

```text
Python: 3.13.5
pytest: 9.0.2
Java runtime: OpenJDK 21.0.10
javac: 21.0.10
Ant: 1.10.15
Maven: unavailable in the validation container
```

## Environmental limitations

- The private enterprise Java repository was not available and was not executed.
- Maven was unavailable, so the actual enterprise Maven/Surefire/JaCoCo lifecycle was not executed.
- No live IBM watsonx request was made; LLM boundaries were exercised with deterministic test doubles.
- Representative Java validation used synthetic source-backed types and `javac`, not the proprietary enterprise classpath.
- No claim is made that `PaymentServiceImpl` itself compiled or executed in this environment.

## Unresolved issues

No failing Python or synthetic Java regression is known in the v7.3.3 archive. The actual accessor names, collaborator field name, and schema availability in the enterprise project remain authoritative; deterministic repair refuses ambiguous corrections and will reject only the affected test when a unique source-backed correction is unavailable.

---

## Loop.py restructuring validation

Validation date: 2026-08-05

| Validation | Result |
|---|---|
| Python compile validation | PASS |
| Original v7.3.3 regression tests | 160 passed |
| New restructuring regressions | 14 passed |
| Complete unittest suite | 174 passed |
| Complete pytest suite | 174 passed, 5 pre-existing collection warnings |
| CLI help smoke check | PASS |
| Original Engine methods available through facade | PASS; 30/30 |
| Original top-level helper compatibility | PASS |
| Payload routing for ServiceImpl/controller/DTO/entity/other | PASS |

Commands:

```bash
python -m compileall -q -f junitforge tests
python -m unittest discover -s tests -v
python -m pytest -q
python -m junitforge --help
```

Result:

```text
No intentional behavioural changes were introduced.
```
