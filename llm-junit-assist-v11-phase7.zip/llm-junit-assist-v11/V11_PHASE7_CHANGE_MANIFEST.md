# llm-junit-assist v11 Phase 7 Change Manifest

## Scope

Phase 7 is an integration/release gate. It adds no parallel registry, validator, compiler, runtime coordinator, or unrelated feature architecture.

## Corrected integration defects

| File | Defect | Correction |
|---|---|---|
| `junitforge/publication/publisher.py`, `pipeline/engine.py` | Default zero runtime counters could label an unexecuted source `runtime-green`. | Publication state now requires an authoritative green full-run snapshot; coverage acceptance also requires fresh coverage evidence. |
| `junitforge/summary.py` | `compiled`, `threshold_met`, and detailed `compiled (...)` outcomes were displayed as failures. | Success classification now recognizes valid compiled/coverage terminal states. |
| `junitforge/report.py` | Final reports omitted direct generated/repaired/removed counts, fixture-variant outcomes, and repair-attempt totals; retained/rejected counts could depend on stale aggregate counters. | Counts now derive from authoritative registry test records and structured histories. |
| `junitforge/cli.py` | Audit run manifest always used `completed` even when a target ended in a fatal status. | Fatal target outcomes now finalize as `completed_with_failures`. |
| `junitforge/timing.py` | Timing/audit metadata remained `11.0-phase5`. | Timing version now uses `junitforge.__version__` (`11.0.0`). |
| `junitforge/__init__.py` | Package still identified a phase build. | Finalized as `11.0.0`. |

Each correction has a Phase 7 regression test.

## Added integration tests

`tests/test_v11_phase7_integrated_release.py` covers:

- connected parsing → contracts → schemas → fixtures → real javac → variants → generation/validation → registry → assembly/ranges → real javac → compile repair → runtime repair → reporting/publication;
- prompt-composition preservation/focus/payload bounds;
- reporting/publication honesty;
- package-wide imports and final version consistency.

## Release validation

- 344 pytest cases passed in the working tree and again in the clean staged release tree.
- compileall passed.
- 83 package modules imported.
- real javac fixture, fixture-variant and test-class compilation passed.
- focused compile repair: 31 passed.
- transactional runtime repair: 10 passed.
- no required test failed; release packaging permitted.
