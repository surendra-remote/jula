# llm-junit-assist v10.2 Change Manifest

## Scope

v10.2 implements the finalized two-channel diagnostic design on top of v10.1:

1. concise stage-oriented console logging;
2. complete structured audit artifacts under `reports/audit/<run-id>/`.

The v10.1 ServiceImpl generation, complete-class compile repair, grouped failing-test runtime repair, coverage measurement, rollback, and publication behavior were preserved.

## Console logging

Normal pipeline progress now uses only:

`[TECH_STACK]`, `[SOURCE_FILE_INFO]`, `[PARSE]`, `[CLASSIFY]`, `[DESTINATION]`, `[COLLABORATORS]`, `[EXECUTION_CONTEXT]`, `[GENERATION_CONTEXT]`, `[GENERATION]`, `[METHOD_GENERATION]`, `[COMPILE]`, `[COMPILE_REPAIR]`, `[RUNTIME]`, `[RUNTIME_REPAIR]`, `[COVERAGE]`, `[PUBLICATION]`, and `[FINAL]`.

Parser internals, symbol extraction, cache activity, schema/fixture traversal, verbose diagnostics, repeated timing records, and heartbeat telemetry were removed from normal `INFO` output or demoted to `DEBUG`.

## Structured audit

Added the authoritative `junitforge.audit` package:

- `audit/console.py` — fixed console-stage vocabulary;
- `audit/models.py` — audit record models;
- `audit/paths.py` — deterministic run, target, method, and attempt paths;
- `audit/serializer.py` — deterministic serialization and secret redaction;
- `audit/recorder.py` — centralized audit lifecycle and artifact recording.

The audit recorder captures:

- run and target manifests;
- parse, classification, destination, and context summaries;
- skeleton source and preflight compilation;
- exact method-generation requests and raw responses;
- extracted tests, structural validation, and registry snapshots;
- assembled test classes;
- initial compile commands, outputs, and complete diagnostics;
- complete-class compile-repair requests, responses, candidates, results, and decisions;
- full runtime results and mapped test failures;
- grouped runtime-repair requests, repaired tests, targeted/full results, and decisions;
- JaCoCo execution, freshness, parsed counters, and raw outputs;
- publication decisions and final manifests.

## Safety and resilience

- Java and generated-test source snapshots remain byte-exact.
- Credentials, authorization values, API keys, passwords, and authentication tokens are redacted from structured metadata.
- Token telemetry fields such as `input_tokens` and `output_tokens` remain visible.
- Unsupported values are serialized safely with warnings instead of terminating the pipeline.
- Audit write failures are recorded and reported once without invalidating an otherwise successful test result.
- Audit totals include LLM call count and prompt/completion/total token counts.

## Compatibility

- `loop.py` remains the v10 compatibility facade.
- Direct `Engine(...)` and `Engine.run_target(...)` callers remain supported through `NullAuditRecorder` when no recorder is supplied.
- Maven and Ant paths remain supported.
- ServiceImpl validation-repair and coverage-augmentation LLM stages remain disabled.
- Controller, DTO/entity, and other target payload behavior was not redesigned.

## Version

The authoritative project version is now `10.2`.

## Modified files

ADDED junitforge/audit
ADDED tests/test_v102_logging_audit.py
MODIFIED junitforge/__init__.py
MODIFIED junitforge/cli.py
MODIFIED junitforge/compilation/deterministic_repairs.py
MODIFIED junitforge/compilation/diagnostics.py
MODIFIED junitforge/compilation/repair_coordinator.py
MODIFIED junitforge/compilation/salvage.py
MODIFIED junitforge/compile_gate.py
MODIFIED junitforge/coverage/augmentation.py
MODIFIED junitforge/coverage/coordinator.py
MODIFIED junitforge/coverage_run.py
MODIFIED junitforge/execution/config_values.py
MODIFIED junitforge/generation/method_generator.py
MODIFIED junitforge/generation/payloads/serviceimpl.py
MODIFIED junitforge/generation/skeleton_generator.py
MODIFIED junitforge/generation/validation.py
MODIFIED junitforge/parser/lazy_symbol_resolver.py
MODIFIED junitforge/pipeline/context.py
MODIFIED junitforge/pipeline/engine.py
MODIFIED junitforge/runtime/repair_coordinator.py
MODIFIED junitforge/timing.py
MODIFIED junitforge/toolchain.py
MODIFIED tests/test_compile_error_parsing.py
MODIFIED tests/test_compile_repair_logging.py

## Behavioral statement

No intentional behavioural changes were introduced outside the finalized console logging and structured audit changes.
