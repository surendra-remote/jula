# llm-junit-assist v11 ServiceImpl Pipeline — Before and After

## v10.2 before

`CLI → parse/classify → resolve basic collaborators/context → skeleton → per-method LLM generation → assemble class → compile → complete-class ServiceImpl compile repair → grouped runtime repair → coverage/augmentation → publication`

Key weaknesses addressed by v11:

- no authoritative transactional per-test registry lifecycle;
- unresolved collaborator returns could be conflated with void/ignored behavior;
- fixture graphs and scenario state were not guaranteed by compiled, explicit catalogue contracts;
- known semantic defects could reach Java compilation;
- ServiceImpl compile repair could receive/alter the complete class;
- runtime repair was not strictly one registry-owned test and could enter compile-repair orchestration;
- publication/reporting could infer green state from zero default counters.

## Final v11 after

`CLI → parse/classify → authoritative collaborator + inherited Spring Data contracts → return-consumption analysis → required schema catalogue → bounded compiled baseline fixture graph → skeleton compile/exposure gate → method-relevant prompt → generation-time structural + semantic validation → deterministic correction → transactional compiled fixture variant when required → registry record/candidate lifecycle → complete class assembly + persisted ranges → initial class compile → exact diagnostic ownership → per-test deterministic repair → one-test fake/provider LLM compile repair → rollback or commit → stable runtime failure ownership → one-test runtime candidate → direct compile once → targeted test → full retained class → commit or rollback → fresh coverage/augmentation when enabled → evidence-based publication → registry-derived summary/report`

## Source lifecycle

`generated_source (immutable) → candidate_source (temporary) → structural/semantic gates → temporary assembly → compile/runtime gates → latest_accepted_source (commit only) → previous_accepted_source retained for rollback`

## Compile repair boundary

`all diagnostics → exact scope mapping → one registry test_id → one repair candidate → compile once → commit/rollback`

Complete-class ServiceImpl LLM compile repair attempts: **0**.

## Runtime repair boundary

`Surefire failure → executed class/method + owner metadata + registry test_id → one failing @Test → candidate → semantic validation → direct compile once → targeted run → full retained-class run → commit/rollback`

Nested compile-repair calls from runtime repair: **0**.

## Publication boundary

- `coverage-accepted` requires fresh coverage plus an authoritative green full run.
- `runtime-green` requires an authoritative green full run with executed tests.
- Otherwise the strongest claim is `compiling`.
- Default zero runtime counters are never treated as execution evidence.
