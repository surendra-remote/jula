# llm-junit-assist v11 Phase 7 Complete Test Report

## Release result

**PASS — package eligible for release.**

- Complete suite: **344 passed**, 0 failed, 5 pre-existing `PytestCollectionWarning` messages.
- Python compileall: **PASS**, exit code 0.
- Package import smoke: **PASS**, 83 modules imported, version `11.0.0`.
- Real Java compiler: **PASS**, `javac 21.0.10` compiled the baseline fixture graph, scenario fixture variant, and assembled synthetic ServiceImpl test class.
- Focused compile-repair suite: **31 passed**.
- Runtime-repair suite: **10 passed**.
- Phase 1–4 focused regressions: **104 passed**.
- Connected Phase 7 synthetic workflow: **1 passed**.

## Commands and evidence

| Gate | Command | Result | Evidence file |
|---|---|---|---|
| Complete pytest | `PYTHONPATH=. pytest -q` | 344 passed | `V11_PHASE7_PYTEST_OUTPUT.txt` |
| Compileall | `python -m compileall -q junitforge tests` | exit 0 | `V11_PHASE7_COMPILEALL_OUTPUT.txt` |
| Import smoke | package walk/import of all modules except `__main__` | 83 imports passed | `V11_PHASE7_IMPORT_SMOKE_OUTPUT.txt` |
| Baseline fixture + variant javac | focused Phase 3 and Phase 4 tests | 2 passed; real javac | `V11_PHASE7_JAVA_FIXTURE_COMPILATION_OUTPUT.txt` |
| Synthetic assembled test class + connected pipeline | Phase 7 integrated test | 1 passed; real javac + fake deterministic provider/runner | `V11_PHASE7_INTEGRATED_WORKFLOW_OUTPUT.txt` |
| Focused compile repair | complete Phase 5 suite | 31 passed | `V11_PHASE7_FOCUSED_COMPILE_REPAIR_OUTPUT.txt` |
| Runtime repair | complete Phase 6 suite | 10 passed | `V11_PHASE7_RUNTIME_REPAIR_OUTPUT.txt` |
| Phase 1–4 regressions | four phase suites | 104 passed | `V11_PHASE7_PHASE1_4_REGRESSION_OUTPUT.txt` |
| Environment | Python/pytest/javac/Maven detection | Maven unavailable | `V11_PHASE7_ENVIRONMENT.txt` |
| Static invariants | AST/version/prompt fingerprint scan | passed | `V11_PHASE7_STATIC_INVARIANTS_OUTPUT.txt` |
| Clean staged release tree | pytest + compileall + import smoke after cache exclusion | 344 passed; exit 0; 83 imports | `V11_PHASE7_PACKAGED_TREE_VALIDATION_OUTPUT.txt` |

## Integrated workflow coverage

The Phase 7 connected test covers, in one execution:

1. Java source parsing and ServiceImpl symbol extraction.
2. Collaborator resolution, recursive inherited Spring Data generic binding, exact `saveAndFlush` return type, and ignored-return consumption.
3. Schema catalogue creation, required relationship/minimum-size propagation, fixture dependency and identity recording, and cycle-safe emission.
4. Real `javac` compilation of emitted fixtures.
5. Deterministic semantic correction, scenario fixture-variant creation, transactional real `javac` compilation, publication, and mutation-free rewritten test validation.
6. Fake deterministic method generation, structural/semantic validation, registry record initialization, immutable `generated_source`, and temporary candidate lifecycle.
7. Class assembly, source-range recalculation, registry persistence, and real `javac` compilation of the assembled synthetic test class.
8. Compiler diagnostic ownership, multiple-error grouping, unmapped preservation, deterministic/focused fake-LLM compile repair, and zero complete-class repair.
9. Stable runtime failure ownership, one-test runtime repair, one direct compile, targeted then full execution, commit/rollback rules, and zero nested compile repair.
10. Summary counts, publication source-state selection, report generation, and truthful runtime/coverage qualification.

## Prompt-composition validation

`test_prompt_composition_is_single_preserved_and_method_focused` proves generation, focused compile repair, and runtime repair:

- include `general_instructions` exactly once;
- preserve the canonical Phase 4 instruction object;
- replace only `objective.requested_test_kind` for compile/runtime repair copies;
- exclude complete collaborator/fixture catalogues and unrelated complete-class source;
- remain below the configured synthetic payload ceiling;
- retain only method-relevant dynamic contracts.

## Test-suite completeness by phase

| Phase | Dedicated test file | Top-level test functions | Final execution evidence |
|---|---|---:|---|
| Phase 1 | `tests/test_v11_phase1_registry.py` | 15 | `V11_PHASE7_PHASE1_4_REGRESSION_OUTPUT.txt` |
| Phase 2 | `tests/test_v11_phase2_collaborator_contracts.py` | 32 | `V11_PHASE7_PHASE1_4_REGRESSION_OUTPUT.txt` |
| Phase 3 | `tests/test_v11_phase3_fixture_graphs.py` | 15 | `V11_PHASE7_PHASE1_4_REGRESSION_OUTPUT.txt` |
| Phase 4 | `tests/test_v11_phase4_semantic_variants.py` | 15 | `V11_PHASE7_PHASE1_4_REGRESSION_OUTPUT.txt` |
| Phase 5 | `tests/test_v11_phase5_focused_compile_repair.py` | 29 | `V11_PHASE7_FOCUSED_COMPILE_REPAIR_OUTPUT.txt` |
| Phase 6 | `tests/test_v11_phase6_transactional_runtime_repair.py` | 10 | `V11_PHASE7_RUNTIME_REPAIR_OUTPUT.txt` |
| Phase 7 | `tests/test_v11_phase7_integrated_release.py` | 4 | `V11_PHASE7_INTEGRATED_WORKFLOW_OUTPUT.txt and complete suite` |


The total executed case count can exceed the top-level function count because parametrized tests generate multiple cases. No required Phase 1–6 suite is missing.

## Warnings

Five legacy tests import the `TestKind` enum under a `Test*` name, causing collection warnings. They are non-failing and unchanged from the baseline. No warning was treated as proof of successful Java/Maven execution.

## Unverified execution

- Real Maven was unavailable in the environment.
- No enterprise/customer repository was supplied.
- No live Watsonx/provider call was made.
- No real Surefire/JaCoCo runtime cycle was executed.

These are reported as `NOT_VERIFIED` in the requirement matrix.

## Dedicated test inventory

### Phase 1

- `test_dictionary_repair_history_does_not_crash_summary_reporting`
- `test_legacy_string_repair_history_remains_supported`
- `test_generated_source_cannot_be_overwritten`
- `test_candidate_commit_updates_only_transactional_source_fields`
- `test_rollback_preserves_latest_accepted_source`
- `test_previous_accepted_source_changes_only_after_successful_commit`
- `test_source_hash_is_deterministic_across_line_endings_and_trailing_space`
- `test_compile_state_transitions_persist_correctly`
- `test_invalid_compile_state_transition_is_rejected`
- `test_previous_compile_diagnostics_and_attempts_remain_available`
- `test_registry_serialization_and_reload_preserve_all_required_fields`
- `test_older_registry_records_load_with_safe_defaults`
- `test_failed_atomic_registry_write_does_not_corrupt_prior_file`
- `test_all_main_junitforge_imports_succeed`
- `test_assembly_and_loop_import_without_circular_import`

### Phase 2

- `test_direct_jpa_repository_binding_resolves_entity_and_id`
- `test_direct_crud_repository_binding_resolves_entity_and_id`
- `test_direct_spring_data_binding_does_not_require_source_lookup`
- `test_unbound_direct_spring_data_generics_remain_partial`
- `test_custom_intermediate_repository_inheritance_is_resolved`
- `test_multiple_generic_inheritance_levels_are_resolved_recursively`
- `test_exact_entity_and_id_binding_is_exposed_on_contract`
- `test_inherited_save_contract_is_exact`
- `test_inherited_save_and_flush_contract_is_exact`
- `test_inherited_save_all_contract_is_exact`
- `test_crud_repository_save_all_and_find_all_preserve_iterable_return`
- `test_crud_only_jpa_method_is_partial_not_void`
- `test_inherited_find_by_id_contract_is_exact`
- `test_inherited_find_all_contract_is_exact`
- `test_inherited_count_contract_is_exact`
- `test_inherited_delete_by_id_contract_is_resolved_void`
- `test_inherited_flush_contract_is_resolved_void`
- `test_resolved_void_is_forbidden_for_normal_return_stubbing`
- `test_additional_required_spring_data_contracts_are_exact`
- `test_ignored_non_void_return_is_not_stub_required`
- `test_consumed_non_void_return_requires_normal_stub`
- `test_helper_return_propagation_is_traced_interprocedurally`
- `test_branch_tested_return_is_consumed`
- `test_optional_return_flow_is_consumed`
- `test_stream_return_flow_is_distinguished`
- `test_return_passed_to_another_call_is_distinguished`
- `test_unresolved_return_type_is_null_and_never_void`
- `test_unresolved_return_flow_is_not_treated_as_ignored`
- `test_unresolved_required_contract_produces_unresolved_diagnostic`
- `test_payload_preserves_null_return_type_for_unresolved_contract`
- `test_focused_payload_excludes_unrelated_repository_contracts`
- `test_existing_general_instructions_are_preserved_and_not_duplicated`

### Phase 3

- `test_required_dereference_path_hydrates_every_nested_schema_level`
- `test_required_collection_minimum_is_mutable_compatible_and_non_null`
- `test_fixture_catalog_records_direct_and_transitive_dependencies`
- `test_object_identity_guarantees_match_attached_fixture_instances`
- `test_cycle_preserves_forward_edge_and_omits_only_reverse_edge`
- `test_unresolved_required_child_fails_closed_and_marks_parent_partial`
- `test_catalogue_guarantees_are_present_in_emitted_source`
- `test_uncompiled_fixture_is_not_exposed_then_becomes_exposed_after_skeleton_compile`
- `test_failed_skeleton_compile_marks_supported_fixtures_failed_and_unexposed`
- `test_optional_get_requires_present_value_without_fake_collection_minimum`
- `test_required_cycle_reverse_dereference_fails_closed`
- `test_fixture_catalogue_persists_compile_and_exposure_state`
- `test_generated_fixture_graph_compiles_in_synthetic_java_harness`
- `test_focused_fixture_payload_excludes_unrelated_and_partial_fixtures`
- `test_general_instructions_are_preserved_once_without_dynamic_catalogue_content`

### Phase 4

- `test_known_semantic_categories_are_rejected`
- `test_boolean_wrapper_uses_authoritative_getter_convention`
- `test_deterministic_corrections_are_structured_and_source_backed`
- `test_fixture_variant_is_compiled_then_reused_by_normalized_signature`
- `test_fixture_variant_rejects_local_capture_and_unresolved_constant_scope`
- `test_transactional_variant_failure_is_isolated`
- `test_generated_source_immutable_candidate_preserved_and_not_prematurely_committed`
- `test_validated_variant_test_contains_no_fixture_mutation`
- `test_focused_payload_contains_only_relevant_contracts_and_single_instruction_copy`
- `test_required_general_instruction_clauses_are_minimally_replaced`
- `test_allowed_standard_java_values_remain_legal`
- `test_fixture_supported_mock_or_spy_is_rejected_as_data_setup`
- `test_mockito_qualification_and_primitive_matcher_are_normalized`
- `test_focused_validation_repair_payload_contains_one_method_only`
- `test_synthetic_compiled_fixture_variant_java_source`

### Phase 5

- `test_01_correct_diagnostic_to_test_mapping_uses_stable_test_id`
- `test_02_multiple_errors_are_grouped_into_one_test_repair_unit`
- `test_03_line_ranges_recalculate_after_reassembly`
- `test_04_fixture_diagnostic_classification`
- `test_05_skeleton_diagnostic_classification`
- `test_06_class_import_diagnostic_classification`
- `test_07_assembly_diagnostic_classification_has_priority`
- `test_08_unmapped_diagnostics_remain_unmapped`
- `test_09_complete_class_serviceimpl_repair_is_disabled`
- `test_10_deterministic_candidate_commits_only_after_compile_success`
- `test_11_deterministic_candidate_rolls_back_on_compile_failure`
- `test_12_llm_candidate_commit`
- `test_13_llm_candidate_rollback_and_explicit_removal`
- `test_14_generated_source_remains_immutable_during_repair`
- `test_15_latest_accepted_source_not_updated_before_compile_success`
- `test_16_complete_outer_fence_normalization`
- `test_17_to_19_fence_and_prose_rejections`
- `test_20_truncation_detection_for_unbalanced_java`
- `test_21_wrong_test_identity_rejection`
- `test_22_provider_response_metadata_persists`
- `test_23_request_and_response_hashing_is_deterministic`
- `test_24_identical_rejected_response_stops`
- `test_25_append_only_compile_history`
- `test_26_focused_payload_excludes_unrelated_complete_class_content`
- `test_27_preserved_nonduplicated_general_instructions`
- `test_28_unmatched_closing_fence_is_not_classified_as_truncation`
- `test_29_focused_llm_attempt_limit_is_persisted_per_test`
- `test_30_compiler_parser_retains_all_diagnostics_details_and_raw_text`
- `test_31_constants_and_configuration_values_are_not_duplicated`

### Phase 6

- `test_runtime_failure_maps_to_stable_test_id_without_line_identity`
- `test_runtime_payload_is_single_test_focused_and_excludes_catalogues`
- `test_runtime_prompt_preserves_general_instructions_with_one_minimal_replacement`
- `test_successful_candidate_compiles_once_executes_target_then_full_and_commits`
- `test_compile_failure_rolls_back_immediately_and_makes_zero_compile_repair_calls`
- `test_targeted_execution_failure_prevents_full_run_and_commit`
- `test_complete_retained_class_failure_prevents_commit`
- `test_runtime_attempt_persists_response_metadata_and_append_only_history`
- `test_identical_rejected_response_stops_without_second_compile`
- `test_each_failed_attempt_rolls_back_before_next_baseline`

### Phase 7

- `test_integrated_synthetic_serviceimpl_release_workflow`
- `test_prompt_composition_is_single_preserved_and_method_focused`
- `test_reporting_and_publication_do_not_claim_unverified_success`
- `test_primary_package_imports_and_final_version`
