# llm-junit-assist v10.1 ServiceImpl Payloads

## 1. Method test generation

```json
{
  "request_type": "method_test_generation",
  "target_class": {
    "fqcn": "...",
    "test_instance": "..."
  },
  "target_method": {
    "method_id": "...",
    "signature": "...",
    "source": "COMPLETE TARGET METHOD SOURCE"
  },
  "reachable_same_class_methods": [
    {
      "method_id": "...",
      "signature": "...",
      "visibility": "private|protected|package|public",
      "source": "COMPLETE EXACT HELPER SOURCE"
    }
  ],
  "fixtures": [
    {
      "type": "...",
      "fixture_method": "...",
      "invocation": "...",
      "status": "compiled"
    }
  ],
  "collaborators": [
    {
      "field": "...",
      "type": "...",
      "methods": [
        {
          "method_id": "...",
          "signature": "...",
          "return_type": "...",
          "parameter_types": []
        }
      ]
    }
  ],
  "generation_instruction": {}
}
```

Output: exactly one raw Java JUnit 5 `@Test` method.

## 2. Complete-class compilation repair

```json
{
  "request_type": "compile_repair",
  "test_class": {
    "class_name": "...",
    "source": "COMPLETE CURRENT JAVA TEST CLASS"
  },
  "compilation_errors": [
    {
      "line": 0,
      "column": 0,
      "message": "...",
      "source_line": "..."
    }
  ],
  "repair_instructions": {}
}
```

Output: exactly one complete corrected Java test class. No Markdown or explanation.

Not included:

- target-method source closure;
- fixture catalog;
- collaborator catalog;
- selected test or owner scope;
- runtime results;
- coverage data.

## 3. Grouped failing-test runtime repair

```json
{
  "request_type": "runtime_repair",
  "target_class": {
    "fqcn": "...",
    "test_class_name": "..."
  },
  "target_method": {
    "method_id": "..."
  },
  "failing_tests": [
    {
      "test_name": "...",
      "source": "COMPLETE CURRENT @Test SOURCE",
      "runtime_status": "error|failure",
      "diagnostics": [
        {
          "type": "runtime_error|assertion_failure",
          "exception": "...",
          "message": "...",
          "expected": null,
          "actual": null,
          "source_line": null,
          "stack_trace": "BOUNDED RELEVANT STACK TRACE",
          "category": "..."
        }
      ]
    }
  ],
  "shared_test_context": {
    "required_mock_fields": [],
    "required_setup_fragments": [],
    "required_fixture_helpers": []
  },
  "repair_instructions": {}
}
```

Only tests with runtime state `ERROR` or `FAILURE` are included. Passed tests remain in the registry but are excluded from the LLM request.

Output: exactly one corrected `@Test` method for each supplied failing test, in the same order and with identical test names.

## Disabled ServiceImpl payloads

```text
validation_repair
coverage_augmentation
coverage_repair
```

These stages return an explicit disabled result and do not invoke the LLM.
