# llm-junit-assist v11 Phase 5 Validation Report

## Result

**PASS**

Phase 5 implements registry-driven ServiceImpl class compilation and focused compile repair. The complete candidate class is compiled once after assembly; all compiler diagnostics are retained and classified; test-level repair is owned by stable `test_id`; candidate source is transactional; and complete-class ServiceImpl LLM compile repair is disabled.

## Implemented behavior

### Initial compilation and authoritative registry alignment

Before initial compilation and every candidate compilation, the engine:

1. extracts the current assembled source;
2. recalculates every retained test range;
3. recalculates fixture, setup/skeleton, import/class, and assembly ranges;
4. stores the exact assembled-source SHA-256;
5. atomically rewrites `07-class-assembly/registry.json`;
6. compiles the same source represented by that persisted hash/range state.

The registry remains the persisted view of `TargetOutcome.method_results`; no second registry was introduced.

### Diagnostic parsing, ownership, and grouping

Compiler diagnostics retain:

- file;
- line;
- column;
- message;
- detail lines;
- normalized category;
- complete raw compiler text.

A diagnostic belongs to a test only when its line is inside that test's recalculated inclusive range. Ownership uses stable `test_id = owner_method_id + "::" + test_name`. Multiple diagnostics inside one test range form one repair unit and one focused request.

Diagnostics outside test ranges are held separately as fixture, skeleton/setup, import/class, assembly-structural, or unmapped diagnostics. They are never assigned to the nearest test. Phase 5 does not route those scopes through complete-class ServiceImpl LLM repair; unresolved non-test diagnostics remain explicit compile failures.

### Transactional per-test repair

For each failed registry-owned test:

1. transition to `FAILED` with grouped diagnostics;
2. transition to `DETERMINISTIC_REPAIR_PENDING`;
3. apply authoritative deterministic repair;
4. stage the method in `candidate_source`;
5. run structural and Phase 4 semantic validation;
6. assemble a temporary complete test class containing the candidate plus already accepted tests;
7. compile that candidate exactly once;
8. commit through `RegistryStore.commit_candidate()` only after success;
9. otherwise discard the candidate, append evidence, restore the prior source, and permit at most one focused LLM repair;
10. normalize and validate the LLM method;
11. compile that candidate exactly once;
12. commit on success or reject and remove the test through explicit registry transitions.

`generated_source` remains immutable. `latest_accepted_source` is not updated by candidate creation, validation, assembly, or LLM return alone.

### Strict focused response normalization

Accepted responses are either:

- one raw complete Java `@Test` method; or
- exactly one complete outer Markdown fence containing that method and no outside prose or nested fence.

The normalizer rejects unmatched fences, multiple/nested fences, prose, package/import/type declarations, multiple methods, wrong identity, additional Java, unbalanced braces, and truncated Java. An unmatched opening fence and structurally incomplete Java are recorded as probable truncation; an unmatched closing fence is not.

### Provider metadata and duplicate-response evidence

Focused repair preserves:

- response state;
- finish reason;
- input/output token counts;
- response byte size;
- canonical request hash;
- normalized response hash;
- truncation state;
- normalization result;
- rejection reason;
- raw provider response.

A persisted prior focused attempt prevents a second LLM call for the same test. If a matching request/response hash was previously rejected, the result is recorded as `IDENTICAL_REJECTED_RESPONSE`; no retry is made.

### Append-only compile history

Every initial, deterministic-candidate, LLM-candidate, and reassembled-class compilation appends an attempt record containing candidate hash, diagnostics, validation result, compile result, decision, and LLM request/response metadata where applicable. Success does not erase failed attempts.

### Focused prompt composition

The focused prompt contains only:

- target identity;
- owner production method ID;
- stable test identity/name;
- current test source;
- grouped diagnostics;
- directly referenced type/schema, collaborator, fixture, constant, and configuration contracts;
- directly relevant imports and authorised static APIs;
- one preserved instruction block;
- one focused compile-repair addition block.

It excludes the complete test class, unrelated tests, unrelated fixtures/catalogues, unrelated collaborators/catalogues, unrelated production methods, and unrelated diagnostics.

## Complete-class ServiceImpl repair evidence

**Observed and enforced attempts: 0**

- Initial ServiceImpl compilation routes only to `_compile_registry_focused_repair`.
- Maven compile recovery for ServiceImpl routes only to `_compile_registry_focused_repair`.
- The ServiceImpl payload builder rejects classwide compile-repair mode.
- The disabled complete-class entry point raises unconditionally.
- Regression tests assert the invariant and the persisted one-attempt focused limit.

Detailed evidence is retained in `V11_PHASE5_COMPLETE_CLASS_REPAIR_EVIDENCE.txt`.

## Validation commands and results

| Validation | Command | Result |
|---|---|---|
| Complete test suite | `python -m pytest -q` | **330 passed**, 5 pre-existing `TestKind` collection warnings |
| Focused Phase 5 suite | `python -m pytest -q tests/test_v11_phase5_focused_compile_repair.py` | **31 passed** |
| Synthetic diagnostic mapping | focused tests 01–08 and 30 | **9 passed** |
| Synthetic focused transaction integration | focused tests 09–15, 25, 29 | **9 passed** |
| Python bytecode compilation | `python -m compileall -q junitforge tests` | **PASS**, exit code 0 |
| Import/version/API/prompt smoke | Phase 5 imports and fingerprint validation | **PASS**, version `11.0-phase5` |

Raw outputs are retained in the `V11_PHASE5_*_OUTPUT.txt` files.

## Required test coverage mapping

The Phase 5 suite covers:

1. exact diagnostic-to-test mapping;
2. multiple errors grouped into one test unit;
3. range recalculation and persisted assembled-source hash;
4. fixture classification;
5. skeleton classification;
6. import/class classification;
7. assembly classification;
8. unmapped preservation;
9. complete-class repair disabled;
10. deterministic commit;
11. deterministic rollback;
12. LLM commit;
13. LLM rollback/removal;
14. generated-source immutability;
15. no premature accepted-source update;
16. complete outer-fence normalization;
17. unmatched opening-fence rejection/truncation;
18. multiple-fence rejection;
19. prose rejection;
20. truncation detection;
21. wrong identity rejection;
22. provider metadata persistence;
23. deterministic hashing;
24. identical rejected response stopping;
25. append-only compile history;
26. focused payload exclusion;
27. preserved/non-duplicated instructions;
28. unmatched closing-fence classification;
29. persisted per-test focused-attempt limit;
30. all compiler diagnostics/detail/raw/category parsing;
31. non-duplicated constant and configuration dynamic sections.

## Explicit unverified behavior

1. No live Watsonx or other external LLM call was made; provider metadata was validated with synthetic full responses.
2. No customer Maven/Ant repository was supplied, so transactional compilation was validated with a synthetic compile gate rather than a real multi-module Java project.
3. Real compiler diagnostics beyond the Maven/javac formats already supported by `compile_gate.py` were not observed during this run.
4. Fixture, skeleton/setup, import/class, assembly, and unmapped diagnostics are correctly classified and retained, but no new automatic non-test LLM repair is introduced because complete-class ServiceImpl LLM repair must remain zero.
5. Runtime repair and runtime acceptance were intentionally not changed or newly validated in Phase 5.
6. Phase 6 behavior was not implemented.
