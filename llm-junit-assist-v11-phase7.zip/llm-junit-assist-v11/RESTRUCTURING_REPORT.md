# LOOP.PY RESTRUCTURING REPORT

## Scope

This report documents the behaviour-preserving restructuring of `llm-junit-assist v7.3.3`.

The original `junitforge/loop.py` contained:

- 14 top-level helper functions;
- 30 `Engine` methods;
- 1 nested `generate_one(...)` function;
- 3,176 lines.

The refactored `junitforge/loop.py` is a 52-line compatibility facade. `Engine(...)` and `Engine.run_target(...)` remain available.

## Baseline

Before restructuring:

```text
python -m compileall -q -f junitforge tests   PASS
python -m unittest discover -s tests -v       160 passed
```

## Function-level responsibility and migration inventory

| Original function | Current responsibilities | Dependencies and state | Original callers | New owner | Migration action |
|---|---|---|---|---|---|
| `_select_method_repair_owner` | Maps each compiler diagnostic line to its generated production-method owner, counts owner errors, excludes blocked owners, selects the highest-error eligible owner, and reports unmapped diagnostics. | Reads generated-suite source and diagnostics; calls owner_method_id_for_line; no mutation. | _compile_methodwise_repair and focused compile repair tests. | `compilation/diagnostic_mapper.py` | Moved; re-exported by loop.py. |
| `_compile_candidate_is_strict_progress` | Decides whether a still-failing compile candidate is safe progress by requiring fewer total errors, no increase for unaffected owners, no increase for the selected owner, and no increase in unmapped/header errors. | Reads before/after source and diagnostics; no mutation. | _compile_methodwise_repair and deterministic-contract tests. | `compilation/candidate_validator.py` | Moved; re-exported by loop.py. |
| `_runtime_snapshot` | Normalizes coverage-backed or direct runtime results into RuntimeResultSnapshot with counts, executed names, failing names, execution success, green state, and note. | Reads run signals/failures; creates model; no mutation. | Runtime state recording functions. | `runtime/state.py` | Moved; re-exported by loop.py. |
| `validate_runtime_candidate_identity` | Enforces exact test identity after runtime repair, verifies targeted and full execution counts, requires selected tests to execute, compares owner/suite severity, and rejects newly introduced failures. | Reads before/after Java source and runtime results; uses method_block_for_id and test_method_names; no mutation. | _repair_runtime_owner and runtime gate tests. | `runtime/candidate_validator.py` | Moved; re-exported by loop.py. |
| `_mark_retained_compile_state` | Updates compile_state for tests whose final disposition remains retained without changing retained/rejected disposition. | Mutates TestCaseRecord.compile_state values in TargetOutcome. | Compile coordinator and salvage. | `runtime/state.py` | Moved; re-exported by loop.py. |
| `_record_test_runtime_states` | Marks retained generated tests PASSED or FAILED from authoritative executed/failing test-name sets. | Mutates per-test runtime_state in TargetOutcome. | Runtime state recording functions. | `runtime/state.py` | Moved; re-exported by loop.py. |
| `_refresh_generation_counters` | Recalculates authoritative selected/generated/partial/rejected method counts, retained/rejected test counts, deterministic and LLM repair counts, and categorized validation repair counters. | Reads method/test records and overwrites aggregate counters on TargetOutcome. | Method assembly, compile salvage, final reporting. | `publication/summary.py` | Moved; re-exported by loop.py. |
| `_map_runtime_failure_owner` | Maps a Surefire failure to a production-method owner using the generation registry, generated source line, then bounded test-name fallback. | Reads suite and failure metadata; calls owner mapping helpers; no mutation. | Runtime grouping and runtime repair loop. | `runtime/result_parser.py` | Moved; re-exported by loop.py. |
| `_group_runtime_failures` | Groups mapped Surefire failures by production-method owner and separates unmapped failures. | Reads failures and suite; returns grouped collections; no mutation. | Runtime repair loop and runtime candidate comparison. | `runtime/result_parser.py` | Moved; re-exported by loop.py. |
| `_runtime_owner_priority` | Scores a failing production-method owner using error count, failure count, and deterministic failure categories so higher-risk owners are repaired first. | Reads owner failure list; no mutation. | _runtime_failure_repair_loop. | `runtime/repair_coordinator.py` | Moved; re-exported by loop.py. |
| `_runtime_failure_excerpt` | Builds a bounded repair diagnostic containing test identity, category, exception, message, source location, and stack trace. | Reads one SurefireFailure; no mutation. | _repair_runtime_owner. | `runtime/result_parser.py` | Moved; re-exported by loop.py. |
| `_targeted_selector` | Builds a Surefire selector containing the generated test FQCN and the exact failing test methods for one targeted rerun. | Reads test FQCN and failures; no mutation. | _repair_runtime_owner. | `runtime/repair_coordinator.py` | Moved; re-exported by loop.py. |
| `_failure_signatures` | Creates stable unique failure signatures used to compare resolved, retained, and introduced runtime failures. | Reads failure sequence; no mutation. | _repair_runtime_owner and runtime acceptance gate. | `runtime/result_parser.py` | Moved; re-exported by loop.py. |
| `_deterministic_runtime_replacement` | Removes only source-local Mockito stubs proven unnecessary by runtime diagnostics and returns the modified owner block plus an action description. | Reads suite/owner/failures; mutates only a copied source block; uses method/line ownership helpers. | _repair_runtime_owner. | `runtime/repair_coordinator.py` | Moved; re-exported by loop.py. |
| `Engine.run_target` | Coordinates one target from preparation through generation, compile/repair, optional runtime/coverage, rollback/publication, final status, and TargetOutcome return. | Reads all Engine dependencies; writes generated test files; updates TargetOutcome and PipelineState; delegates all detailed stages. | cli.py and direct Engine callers. | `pipeline/engine.py` | Moved to GenerationPipeline; Engine facade inherits it. |
| `Engine._generate` | Routes controller and ServiceImpl targets to method-wise generation and all other supported targets to class-wide generation. | Reads GenerationContext.execution_context; delegates to generation mixin. | run_target. | `pipeline/engine.py` | Moved unchanged. |
| `Engine._generate_methodwise` | Obtains and preflights the deterministic skeleton, matches execution methods to production methods, runs per-method jobs concurrently, orders results deterministically, rejects duplicate test names, assembles owner blocks, refreshes counters, and finalizes the complete class once. | Reads ctx/execution/config; writes skeleton for preflight; updates TargetOutcome method/test records; delegates skeleton, payload, extraction, validation, and finalization. | _generate and direct regression tests. | `generation/method_generator.py` | Moved into GenerationMixin. |
| `generate_one (nested)` | Generates tests for one production method, records token usage, extracts individual tests, validates each test, applies deterministic validation repair, performs focused LLM validation repair, and returns a retained block plus MethodGenerationRecord. | Reads ctx/config/LLM; updates local MethodGenerationRecord and TestCaseRecord objects; no class-file publication. | ThreadPoolExecutor inside _generate_methodwise. | `generation/method_generator.py` | Extracted from nested function into named GenerationMixin.generate_one method. |
| `Engine._generate_classwide` | Builds the class-wide generation payload, performs bounded re-asks, injects reusable fixtures, finalizes the Java class, and reports rejection reasons. | Reads config/ctx; invokes shared LLM boundary; updates outcome notes. | _generate. | `generation/method_generator.py` | Moved into GenerationMixin and routed through target-type payload builder. |
| `Engine._compile_with_repair` | Runs initial compilation, handles non-repairable toolchain failures, routes method-wise or class-wide repair, accepts successful source, and updates retained compile state. | Reads compile gate/config/ctx; writes candidate source; mutates outcome compile errors/notes/test states. | run_target, runtime repair, coverage augmentation. | `compilation/repair_coordinator.py` | Moved into CompilationRepairMixin. |
| `Engine._compile_methodwise_repair` | Coordinates header repair, deterministic diagnostics repair, focused test repair, strict candidate progress, disk rollback, blocked-owner tracking, and final per-test salvage. | Reads/writes test file; calls diagnostic mapping, deterministic repair, candidate validator, focused repair, and salvage; mutates outcome records. | _compile_with_repair and Maven recovery. | `compilation/repair_coordinator.py` | Moved into CompilationRepairMixin. |
| `Engine._reject_irreparable_compile_tests` | Maps remaining diagnostics to individual tests, rejects only irreparable tests, preserves siblings, updates owner/test records, finalizes the reduced class, and recompiles it. | Reads/writes test source; mutates method/test records and aggregate counters. | _compile_methodwise_repair. | `compilation/salvage.py` | Moved into CompileSalvageMixin. |
| `Engine._repair_methodwise_header_errors` | Builds class/header repair input for unmapped import, class-structure, or fixture errors, finalizes the candidate, and rejects candidates that alter existing test identities or structure. | Invokes target-specific compile payload builder and LLM; reads current suite; returns candidate without committing it. | _compile_methodwise_repair. | `compilation/repair_coordinator.py` | Moved into CompilationRepairMixin. |
| `Engine._repair_compile_diagnostics_deterministically` | Groups compiler diagnostics by owner/test, applies source-backed deterministic fixes, revalidates affected tests and sibling identity, finalizes the candidate, and returns pending repair actions. | Reads ctx/errors/current source; creates candidate; does not commit metadata until accepted. | _compile_methodwise_repair. | `compilation/deterministic_repairs.py` | Moved into DeterministicRepairsMixin. |
| `Engine._commit_deterministic_compile_actions` | Commits accepted deterministic repair source and action history to matching TestCaseRecord entries. | Mutates test record generated_source, histories, and compile state. | _compile_methodwise_repair after candidate acceptance. | `compilation/deterministic_repairs.py` | Moved into DeterministicRepairsMixin. |
| `Engine._repair_methodwise_error_batch` | Selects one failing owner/test, builds the individual compile-repair payload, invokes the LLM, enforces exact test identity, applies deterministic post-repair normalization, validates the test and siblings, and returns a rebuilt candidate class. | Reads current suite/errors/context; invokes payload builder/LLM; returns candidate and pending metadata without committing acceptance. | _compile_methodwise_repair and Maven recovery; direct regression tests. | `compilation/repair_coordinator.py` | Moved into CompilationRepairMixin and routed through target-type payload builder. |
| `Engine._commit_methodwise_llm_repair` | Records an accepted focused LLM compile repair, source, repair history, and compile state in the matching test record. | Mutates TestCaseRecord only after accepted candidate. | _compile_methodwise_repair. | `compilation/repair_coordinator.py` | Moved into CompilationRepairMixin. |
| `Engine._coverage_loop` | Runs authoritative coverage measurement, detects Maven compile failures, gates on runtime success, invokes runtime repair, evaluates thresholds, performs bounded augmentation, recompiles, remeasures, and stops on success or no progress. | Reads coverage runner/config/context; writes test source through delegated stages; mutates runtime/coverage outcome fields and status. | run_target and runtime orchestration tests. | `coverage/coordinator.py` | Moved into CoverageCoordinatorMixin. |
| `Engine._augment` | Routes method-wise augmentation for ServiceImpl/controllers or builds a class-wide uncovered-source payload, finalizes the returned class, and writes accepted augmented source. | Reads JaCoCo class coverage and current test file; invokes target-specific coverage payload builder/LLM; writes candidate on validation success. | _coverage_loop. | `coverage/augmentation.py` | Moved into CoverageAugmentationMixin. |
| `Engine._augment_methodwise` | Selects the owner with the most uncovered lines, builds bounded source/branch hints, requests additional tests for that owner, validates the block, preserves existing names, replaces the owner block, and finalizes the class. | Reads coverage/context/current source; invokes target-specific method augmentation payload; writes accepted source. | _augment. | `coverage/augmentation.py` | Moved into CoverageAugmentationMixin. |
| `Engine._record_coverage_runtime_result` | Records the authoritative runtime result embedded in a coverage run, updates initial/final counts and failure categories, tracks freshness/report paths, and updates per-test runtime states. | Mutates TargetOutcome runtime snapshots, counts, paths, hashes, and test records. | _coverage_loop and runtime repair loop. | `runtime/state.py` | Moved into RuntimeStateMixin. |
| `Engine._record_runtime_test_result` | Records targeted or full direct test runs, maintains authoritative full-suite counts and last-green state, and updates per-test runtime states. | Mutates TargetOutcome runtime snapshots, counts, paths, and test records. | _repair_runtime_owner. | `runtime/state.py` | Moved into RuntimeStateMixin. |
| `Engine._runtime_failure_repair_loop` | Normalizes failures, groups and prioritizes owners, enforces repair limits/timeouts/no-progress rules, invokes owner repair, tracks blocked owners, and remeasures fresh coverage after successful runtime repair. | Reads runner/config/current source/outcome; calls result parser, owner repair, coverage measurement, and state recorder; mutates outcome. | _coverage_loop and direct runtime orchestration tests. | `runtime/repair_coordinator.py` | Moved into RuntimeRepairMixin. |
| `Engine._repair_runtime_owner` | Repairs one failing owner deterministically or through the LLM, preserves exact selected/sibling test identities, compiles the candidate, runs targeted and full suites, validates improvement, accepts the source or rolls it back. | Reads/writes test source; invokes payload builder/LLM/compiler/runtime runner; mutates outcome only for accepted or reported attempts. | _runtime_failure_repair_loop and direct regression tests. | `runtime/repair_coordinator.py` | Moved into RuntimeRepairMixin and routed through target-type runtime payload. |
| `Engine._build_failure_reason` | Extracts a concise Maven plugin or compilation failure reason from the build-log tail. | Reads log text; regular-expression parsing; no mutation. | Coverage/Maven failure reporting. | `coverage/run.py` | Moved into CoverageRunMixin as static method. |
| `Engine._restore_or_remove` | Restores the original test source or removes a newly created invalid test file. | Writes/deletes test path; no outcome mutation. | Generation/compile/coverage failure paths. | `publication/publisher.py` | Moved into PublicationMixin as static method. |
| `Engine._capture_failed_test_snapshot` | Persists the rejected non-compiling source beside the generated test using the existing .failing naming behavior and records the path/note. | Reads test file; writes snapshot; mutates outcome failing snapshot path/notes. | Final compile failure path. | `publication/publisher.py` | Moved into PublicationMixin as static method. |
| `Engine._log_compile_failure` | Emits bounded compile diagnostics safely for direct Engine callers without raising a second exception. | Reads outcome errors and logger; no source mutation. | Final compile failure path and logging regression test. | `compilation/diagnostics.py` | Moved into CompileDiagnosticsMixin; legacy logger category preserved. |
| `Engine._test_fqcn` | Builds the fully qualified generated test-class selector from test package and class name. | Reads GenerationContext identity; no mutation. | Coverage and runtime runners. | `pipeline/context.py` | Moved into PipelineContextMixin as static method. |
| `Engine._own_maven_errors` | Parses Maven compiler output and filters diagnostics to the generated test file. | Reads log tail/test path; calls parse_maven_compiler_errors; no mutation. | Coverage loop and Maven compile recovery. | `compilation/diagnostics.py` | Moved into CompileDiagnosticsMixin as static method. |
| `Engine._recover_maven_compile` | Repairs generated-test compilation failures discovered during Maven coverage execution, using method-wise or class-wide repair, and remeasures coverage after each bounded attempt. | Reads/writes test file; invokes diagnostic filter, compile repair payload, LLM, finalizer, and coverage runner; mutates outcome. | Coverage loop. | `compilation/repair_coordinator.py` | Moved into CompilationRepairMixin and routed through target-type compile payload. |
| `Engine._classpath_profile` | Builds the test classpath profile from the resolved compile-gate classpath and falls back to POM artifact inspection. | Reads compile gate, stack, repo root, and module; no mutation. | Target preparation. | `pipeline/context.py` | Moved into PipelineContextMixin. |
| `Engine._class_cov` | Parses JaCoCo XML and returns the class-coverage record matching the selected production class. | Reads XML/module/symbol; no mutation. | Coverage loop. | `coverage/parse.py` | Moved into CoverageParseMixin. |
| `Engine._branch_hints` | Converts uncovered branch line numbers into bounded source-line hints for augmentation prompts. | Reads source and line numbers; no mutation. | Class-wide and method-wise augmentation. | `coverage/augmentation.py` | Moved into CoverageAugmentationMixin as static method. |
| `Engine._chat` | Provides the shared LLM invocation boundary for repair and augmentation, preserving temperature/token settings, token accounting, timing, error notes, and response extraction. | Reads LLM/config inputs; mutates outcome token count and notes. | Class-wide generation, compile repair, runtime repair, and augmentation. | `pipeline/engine.py` | Moved unchanged to GenerationPipeline. |

## New structural helpers

| New function/type | Responsibility | Owner |
|---|---|---|
| `prepare_target` | Coordinates parsing, module lookup, testability checks, classification, test destination, and GenerationContext preparation; returns an explicit terminal/non-terminal PreparedTarget. | `pipeline/context.py` |
| `parse_target_source` | Preserves lazy resolver versus parse_file fallback and parse timing. | `pipeline/context.py` |
| `resolve_test_destination` | Preserves overwrite, skip, and side-by-side JfTest naming. | `pipeline/context.py` |
| `build_pipeline_context` | Resolves collaborators, execution context, diagnostics, and GenerationContext. | `pipeline/context.py` |
| `write_context_diagnostics` | Preserves execution-context, schema, and fixture report writing. | `pipeline/context.py` |
| `generate_and_validate_skeleton` | Builds, writes, and preflight-compiles the deterministic method-wise skeleton. | `generation/skeleton_generator.py` |
| `payload_builder_for / payload_builder_for_context` | Selects ServiceImpl, controller, DTO/entity, or other payload builder without embedding prompt logic. | `generation/payloads/__init__.py` |
| `PipelineState` | Tracks generated, compiling, runtime-green, coverage-valid, and rollback source snapshots. | `pipeline/state.py` |
| `CompilerMixin._compile_candidate` | Centralizes CompileGate.check invocation. | `compilation/compiler.py` |
| `RuntimeRunnerMixin._run_tests` | Centralizes targeted/full runtime test execution. | `runtime/runner.py` |
| `CoverageRunMixin._measure_coverage` | Centralizes CoverageRunner.measure invocation. | `coverage/run.py` |

## Final package structure

```text
junitforge/
├── loop.py
├── pipeline/
│   ├── __init__.py
│   ├── engine.py
│   ├── context.py
│   ├── state.py
│   ├── result.py
│   └── stages.py
├── generation/
│   ├── __init__.py
│   ├── skeleton_generator.py
│   ├── method_generator.py
│   ├── source_closure.py
│   ├── response_extractor.py
│   ├── validation.py
│   └── payloads/
│       ├── __init__.py
│       ├── common.py
│       ├── serviceimpl.py
│       ├── controller.py
│       ├── dto_entity.py
│       └── other.py
├── compilation/
│   ├── __init__.py
│   ├── compiler.py
│   ├── diagnostics.py
│   ├── diagnostic_mapper.py
│   ├── repair_coordinator.py
│   ├── deterministic_repairs.py
│   ├── candidate_validator.py
│   └── salvage.py
├── runtime/
│   ├── __init__.py
│   ├── runner.py
│   ├── result_parser.py
│   ├── repair_coordinator.py
│   ├── candidate_validator.py
│   └── state.py
├── coverage/
│   ├── __init__.py
│   ├── run.py
│   ├── parse.py
│   ├── models.py
│   ├── augmentation.py
│   └── coordinator.py
└── publication/
    ├── __init__.py
    ├── publisher.py
    ├── summary.py
    └── report.py
```

## Payload routing

Each Java target type has one payload builder that owns all five LLM request stages:

```text
generation/payloads/serviceimpl.py
generation/payloads/controller.py
generation/payloads/dto_entity.py
generation/payloads/other.py
```

Each exposes:

```text
build_generation_payload
build_validation_repair_payload
build_compile_repair_payload
build_runtime_repair_payload
build_coverage_augmentation_payload
```

The builders delegate to the original v7.3.3 prompt functions, so system-role content, user-role content, ordering, and output contracts remain unchanged. The dispatcher contains routing only.

## Compatibility retained

- `from junitforge.loop import Engine` remains valid.
- `Engine(...)` retains the original dataclass constructor fields and defaults.
- `Engine.run_target(source_path)` remains the CLI/direct-caller entry point.
- Original top-level `loop.py` helpers used by tests remain re-exported.
- The legacy `junitforge.loop` logger category remains used by moved logic.
- Existing `coverage_run.py`, `coverage_parse.py`, `report.py`, and `summary.py` remain valid; new package modules wrap or reuse them without duplicate execution implementations.
- Existing direct private-method calls remain available through inherited mixins.
- Tests that patched implementation globals were updated to patch the new authoritative owner module.

## Files affected by dependency migration

- `junitforge/loop.py`: replaced by compatibility facade.
- `junitforge/pipeline/*`: new orchestration, context, state, result, and stage modules.
- `junitforge/generation/*`: new skeleton, method generation, payload routing, source closure, response extraction, and validation modules.
- `junitforge/compilation/*`: new compiler boundary, diagnostics, repair, deterministic repair, candidate gate, and salvage modules.
- `junitforge/runtime/*`: new runner, result parsing, repair, candidate gate, and state modules.
- `junitforge/coverage/*`: new runner wrapper, parser wrapper, models, augmentation, and coordinator modules.
- `junitforge/publication/*`: new publisher, counter summary, and report compatibility modules.
- `tests/test_v73_generation_recovery.py`: patch targets updated to authoritative compilation modules.
- `tests/test_v721_runtime_repair_gate.py`: patch targets updated to authoritative runtime module.
- `tests/test_loop_restructuring.py`: added facade, ownership, payload routing, source-state, source-closure, and run-target regressions.

`junitforge/cli.py` required no behavioural change. It continues constructing `Engine` and calling `engine.run_target(src)`.

## Validation after restructuring

```text
python -m compileall -q -f junitforge tests   PASS
python -m unittest discover -s tests -v       174 passed
python -m pytest -q                            174 passed, 5 pre-existing warnings
python -m junitforge --help                    PASS
```

The 14 additional tests cover the refactored facade and module boundaries.

## Behavioural result

No intentional behavioural changes were introduced.
