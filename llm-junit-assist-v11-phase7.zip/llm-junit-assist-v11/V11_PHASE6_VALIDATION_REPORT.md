# llm-junit-assist v11 Phase 6 Validation Report

## Result

**Phase 6 passed the required local validation matrix. Phase 7 packaging work was not started.**

## Implemented behavior

- Runtime failures map to stable registry `test_id = owner_method_id + "::" + test_name` using executed class/method and registry ownership, not source line numbers.
- Each transaction repairs exactly one failing registry-owned `@Test` method.
- Every attempt records runtime diagnostics, focused request/response and hashes, candidate source/hash, structural and semantic validation, compile diagnostics, targeted/full execution results, decision, token counts, finish reason, response size, and truncation state.
- A runtime candidate is compiled once through the direct compile gate.
- Runtime repair contains zero calls to `_compile_with_repair()` or any compile-repair coordinator.
- Compile failure, targeted-test failure, or complete-class failure rolls the class and registry candidate back immediately.
- Commit occurs only through `RegistryStore.commit_candidate()` after all five gates pass.
- `generated_source` remains immutable; rollback preserves `latest_accepted_source`; accepted-source and attempt history remain available.
- Identical rejected provider responses are stopped by the existing request/response hash mechanism before another compile or test run.
- Runtime payloads exclude the complete test class, unrelated tests, unrelated production methods, and complete catalogues.

## Test results

| Validation | Command | Result |
|---|---|---|
| Complete pytest suite | `PYTHONPATH=. pytest -q` | **340 passed**, 5 pre-existing Pytest collection warnings, exit 0 |
| Python bytecode compilation | `python -m compileall -q junitforge tests` | Passed, exit 0 |
| Import smoke | `PYTHONPATH=. python <import-smoke>` | Passed, exit 0 |
| Synthetic runtime-repair integration | `PYTHONPATH=. pytest -q tests/test_v11_phase6_transactional_runtime_repair.py` | **10 passed**, exit 0 |
| No nested compile repair | Static AST check plus focused pytest | 0 nested calls; 1 direct candidate compile; **2 passed**, exit 0 |

## Zero compile-repair LLM-call evidence

- Static AST scan of `junitforge/runtime/repair_coordinator.py` found:
  - `runtime_nested_compile_repair_calls=0`
  - `runtime_direct_compile_gate_calls=1`
- The compile-failure synthetic test injects a failing direct compile result, patches `_compile_with_repair()` to raise if called, asserts it was never called, verifies no targeted/full execution occurred, and confirms the attempt persisted `compile_repair_llm_calls = 0`.
- The candidate is rolled back with `RUNTIME_CANDIDATE_COMPILE_FAILED`, while `generated_source` and `latest_accepted_source` remain unchanged.

## Explicitly unverified behavior

- No live external Watsonx/LLM provider call was made; provider metadata and response normalization were validated with deterministic synthetic responses.
- No customer/enterprise Java repository was compiled or executed. Compile and Surefire behavior was validated through the project’s synthetic integration harness and mocked `CompileGate`/runtime runner boundaries.
- No real Maven/JDK/JaCoCo runtime-repair cycle against an external ServiceImpl project was executed in this environment.
- Filesystem audit persistence was exercised through the existing audit abstraction; remote log aggregation or external storage integrations were not tested.

These items are environmental integration checks, not known Phase 6 implementation failures.
