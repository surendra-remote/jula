# llm-junit-assist v11 Phase 1 Validation Report

## Scope completed

Phase 1 establishes the authoritative registry, stable per-test identity, immutable generated-source baseline, candidate/accepted source lifecycle, deterministic hashing, compile-state validation, immediate atomic registry persistence, backward-compatible registry loading, structured/legacy repair-history compatibility, and append-only repair evidence.

The existing `07-class-assembly/registry.json` remains the sole persisted registry. Its in-memory source of truth is still `TargetOutcome.method_results`; no parallel registry collection was introduced.

## Validation results

| Validation | Result |
|---|---|
| Complete pytest suite | PASS — 210 tests passed |
| New Phase 1 tests | PASS — 15 tests passed |
| Python compileall for `junitforge` and `tests` | PASS |
| Main package import smoke tests | PASS |
| `junitforge.execution.assembly` import | PASS |
| `junitforge.loop` import | PASS |
| Simulated failed atomic registry replacement | PASS — prior registry remained byte-for-byte unchanged |

Pytest reported five pre-existing `PytestCollectionWarning` messages for the `TestKind` enum. The same warning category was present in the v10.2 baseline and does not represent a test failure.

## Key guarantees verified

- `test_id` is always `owner_method_id + "::" + test_name`.
- `generated_source` cannot be replaced after initialization.
- Candidate commit updates `previous_accepted_source`, `latest_accepted_source`, `source_hash`, source ranges, and clears `candidate_source` transactionally.
- Candidate rollback preserves generated and accepted source snapshots, records the failed attempt, clears the candidate, and persists.
- Source hashing is independent of source line numbers and stable across CRLF/LF and trailing whitespace differences.
- Compile transitions are centrally validated; impossible transitions raise `InvalidCompileStateTransition`.
- Compile diagnostics and attempt evidence remain available after later attempts.
- Structured dictionary and legacy string repair histories are both supported by summary reporting.
- Older registry records load with safe defaults, including legacy integer runtime-repair counts.
- Registry writes use same-directory temporary files, `fsync`, and atomic `os.replace`.

## Explicitly unverified behavior

- No external customer Java repository was compiled or executed with Maven/Ant during this phase.
- No live IBM Watsonx/LLM invocation was performed.
- Atomic replacement was validated on the execution environment and with a simulated `os.replace` failure; native Windows filesystem replacement behavior was not separately exercised.
- Fixture variants, semantic repair, new compile-repair algorithms, and new runtime-repair algorithms were intentionally not implemented or validated in Phase 1.
