# v10.2 Console Logging Specification

## Purpose

Console logs answer only:

> What stage is running, and what happened?

Detailed requests, responses, source, compiler diagnostics, stack traces, command outputs, registry snapshots, and repair decisions belong in audit files.

## Supported stage vocabulary

```text
[TECH_STACK]
[SOURCE_FILE_INFO]
[PARSE]
[CLASSIFY]
[DESTINATION]
[COLLABORATORS]
[EXECUTION_CONTEXT]
[GENERATION_CONTEXT]
[GENERATION]
[METHOD_GENERATION]
[COMPILE]
[COMPILE_REPAIR]
[RUNTIME]
[RUNTIME_REPAIR]
[COVERAGE]
[PUBLICATION]
[FINAL]
```

`junitforge.audit.console.stage()` rejects unsupported tags.

## Information level

At `INFO`, each line is limited to stage boundaries, essential counts, pass/fail state, concise reasons, elapsed time where useful, and an audit path where useful.

At `DEBUG`, the project may retain parser internals, symbol resolution, cache activity, context traversal, detailed diagnostics, timing events, and long-running heartbeat telemetry.

Normal successful operations do not emit heartbeats. Heartbeats are debug-only, have a minimum 60-second interval, and default to 90 seconds.

## Sample

See `V10_2_SAMPLE_CONSOLE.txt`.
