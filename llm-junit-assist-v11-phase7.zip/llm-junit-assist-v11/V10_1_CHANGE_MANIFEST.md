# llm-junit-assist v10.1 Change Manifest

## Baseline

- Input version: **v10**, the modular restructuring derived from v7.3.3.
- Output version: **v10.1**.
- Scope: ServiceImpl payload and stage workflow only.

## Implemented ServiceImpl flow

```text
method_test_generation
→ complete test-class assembly
→ complete-class compile repair
→ full runtime execution
→ failing tests grouped by production-method owner
→ failing-test runtime repair
→ targeted rerun
→ authoritative full-class rerun
→ fresh JaCoCo measurement and reporting
```

## Active ServiceImpl LLM requests

- `method_test_generation`
- `compile_repair`
- `runtime_repair`

## Disabled ServiceImpl LLM requests

- `validation_repair`
- `coverage_augmentation`
- `coverage_repair`

Disabled stages return an explicit `ServiceImplPayloadStageDisabled` result and do not invoke the LLM.

## Major changes

### Generation

- Added the finalized structured ServiceImpl method-generation payload.
- Complete target method source is emitted under `target_method.source`.
- Exact reachable same-class helper sources are emitted under `reachable_same_class_methods[].source`.
- Only verified compiled fixtures and collaborator contracts are emitted.
- ServiceImpl LLM validation repair is disabled.
- Only deterministic structural validation remains before full-class compilation.

### Compilation repair

- ServiceImpl compile repair now receives the complete current Java test class.
- Every current compiler diagnostic is included with line, column, message, and source line when available.
- The LLM must return exactly one complete Java test class.
- Method fragments, Markdown-fenced output, package changes, class identity changes, test loss, and unsafe regressions are rejected.
- Per-test salvage remains available only after bounded complete-class repair is exhausted.

### Method/test registry

- Existing `MethodGenerationRecord` and `TestCaseRecord` are the authoritative registry.
- Each method exposes its generated-test count and ordered test names.
- Per-test source, compile state, runtime state, diagnostics, repair attempts, and latest accepted source are synchronized after every accepted transition.
- Registry snapshots are restored transactionally when a runtime candidate is rejected.

### Runtime repair

- Runtime errors and assertion failures are attached to the exact generated test record.
- Failures are grouped by authoritative production-method owner.
- Runtime LLM requests contain only failing/error tests for that owner.
- Passed tests and unrelated method blocks are excluded from the request.
- Returned test identities and order must match the request exactly.
- Passed test source must remain unchanged.
- Acceptance requires compile success, targeted green execution, and an authoritative full test class with zero failures and zero errors.
- Rejected candidates restore test source, registry source/status, and authoritative runtime state.

### Coverage

- ServiceImpl coverage augmentation and coverage repair are disabled.
- Coverage runs only after the ServiceImpl suite compiles and is runtime-green.
- Fresh JaCoCo instruction, line, branch, and method coverage is stored and reported.
- Uncovered lines, partially covered branch lines, XML path, execution-data path, and source freshness evidence are reported.
- Below-threshold coverage is informational and does not invoke the LLM.

### Compatibility

- Controller payloads and workflows are unchanged.
- DTO/entity class-wide payloads and workflows are unchanged.
- Other target types are unchanged.
- `Engine(...)`, `Engine.run_target(...)`, Maven, Ant, direct Engine callers, and the v10 modular architecture remain compatible.
- `pipeline.__init__` uses lazy exports to avoid a registry-related circular import.

## Modified source files

- `junitforge/__init__.py`
- `junitforge/models.py`
- `junitforge/generation/payloads/serviceimpl.py`
- `junitforge/generation/method_generator.py`
- `junitforge/generation/validation.py`
- `junitforge/compilation/candidate_validator.py`
- `junitforge/compilation/repair_coordinator.py`
- `junitforge/runtime/result_parser.py`
- `junitforge/runtime/state.py`
- `junitforge/runtime/candidate_validator.py`
- `junitforge/runtime/repair_coordinator.py`
- `junitforge/coverage/augmentation.py`
- `junitforge/coverage/coordinator.py`
- `junitforge/pipeline/__init__.py`
- `junitforge/pipeline/result.py`
- `junitforge/report.py`

## Modified or added tests

- `tests/test_loop_restructuring.py`
- `tests/test_v721_runtime_repair_gate.py`
- `tests/test_v73_generation_recovery.py`
- `tests/test_v101_serviceimpl_payload_workflow.py` — new

## Behaviour statement

No intentional behavioural changes were introduced outside the finalized ServiceImpl payload and pipeline changes.
