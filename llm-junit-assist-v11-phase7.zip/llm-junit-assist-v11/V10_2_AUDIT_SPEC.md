# v10.2 Structured Audit Specification

## Authoritative root

```text
reports/audit/<run-id>/
```

There is one authoritative audit implementation. No parallel `llm-audit`, `repair-audit`, or `debug-audit` tree is created.

## Directory contract

```text
reports/audit/
  <run-id>/
    manifest.json
    <TargetClass>/
      01-parse/summary.json
      02-classification/summary.json
      03-destination/summary.json
      04-context/
        collaborators.json
        execution-context-summary.json
        generation-context-summary.json
      05-skeleton/
        generated.java
        compile-command.json
        compile-result.json
        compiled.java
      06-method-generation/<safe-method-id>/
        request.json
        response.txt
        extracted-tests.java
        structural-validation.json
        registry-after.json
      07-class-assembly/
        registry.json
        assembled.java
        summary.json
      08-compile/
        command.json
        compiler-errors.json
        stdout.log
        stderr.log
        result.json
      09-compile-repair/attempt-NNN/
        request.json
        response.txt
        before.java
        candidate.java
        compile-after.json
        decision.json
      10-runtime/
        full-run.json
        failures.json
        registry-after.json
      11-runtime-repair/<safe-method-id>/attempt-NNN/
        request.json
        response.txt
        failing-tests-before.java
        repaired-tests.java
        candidate-class.java
        targeted-result.json
        full-result.json
        decision.json
      12-coverage/
        run.json
        freshness.json
        parsed.json
        stdout.log
        stderr.log
      13-publication/decision.json
      final-manifest.json
    final-manifest.json
```

## LLM-backed stages

Only active v10.1 ServiceImpl request types are audited as LLM calls:

- `method_test_generation`;
- `compile_repair`;
- `runtime_repair`.

ServiceImpl `validation_repair`, `coverage_augmentation`, and `coverage_repair` remain disabled and produce no LLM audit calls.

## Deterministic stages

Parsing, classification, destination resolution, collaborator/context construction, skeleton generation/preflight, assembly, compilation, runtime execution/parsing, coverage measurement/parsing, and publication are recorded as deterministic evidence.

## Serialization and safety

- UTF-8, sorted JSON keys, two-space indentation, and LF newlines;
- dataclasses, enums, paths, sets, tuples, exceptions, and nested result models supported;
- sensitive metadata redacted;
- Java source snapshots preserved exactly;
- serialization/write failures do not terminate the main pipeline.

## Sample

See `V10_2_SAMPLE_AUDIT_TREE.txt`.
