# llm-junit-assist v11 Phase 4 Change Manifest

## Scope

Phase 4 adds generation-time ServiceImpl semantic validation, fixture-only application-object setup, compiled scenario-specific fixture variants, deterministic semantic correction, one bounded fixture-augmentation attempt, and one focused invalid-method repair attempt. It extends the existing Phase 1 registry/source lifecycle, Phase 2 collaborator contracts, and Phase 3 authoritative compiled fixture catalogue. It does not add a parallel registry, fixture framework, semantic framework, compile-repair orchestrator, runtime-repair flow, or Phase 5 compile-acceptance behavior.

## Changed files and responsibilities

| File | Responsibility |
|---|---|
| `junitforge/__init__.py` | Updates package identity to `11.0-phase4`. |
| `junitforge/timing.py` | Aligns persisted timing-event version metadata with `11.0-phase4`. |
| `junitforge/execution/assembly.py` | Extends the existing method validation result with structured semantic diagnostics while preserving prior structural validation behavior. |
| `junitforge/execution/models.py` | Extends the authoritative `FixtureSpec` with baseline linkage, normalized state signature, and scenario-variant metadata used for deduplication and catalogue reuse. |
| `junitforge/generation/__init__.py` | Exposes the Phase 4 semantic-validation and fixture-variant APIs through the existing generation package. |
| `junitforge/generation/semantic_validation.py` | Implements contract-indexed ServiceImpl semantic validation, authoritative deterministic corrections, diagnostic categories, and structured append-only change history. |
| `junitforge/generation/fixture_variants.py` | Implements one bounded fixture-augmentation attempt, helper-scope validation, normalized state signatures, variant reuse, transactional per-variant compilation, isolated failure, catalogue publication after compile success, and test substitution. |
| `junitforge/generation/validation.py` | Combines existing structural validation with the new ServiceImpl semantic gate and routes deterministic correction through the Phase 4 validator without changing non-ServiceImpl validation. |
| `junitforge/generation/method_generator.py` | Integrates deterministic semantic correction, one transactional fixture-variant attempt, one focused method-only repair, semantic revalidation, candidate-source staging, generated-source immutability, and no premature accepted-source promotion. |
| `junitforge/generation/payloads/serviceimpl.py` | Applies the five required minimal fixture-only instruction replacements, adds two genuinely missing permanent safeguards, constructs focused method-specific contract sections, emits focused warnings, and supports one method-only semantic repair payload. |
| `tests/test_loop_restructuring.py` | Updates existing restructuring fixtures/assertions to the Phase 4 payload contract while retaining orchestration coverage. |
| `tests/test_v101_serviceimpl_payload_workflow.py` | Updates legacy ServiceImpl payload assertions for focused Phase 4 dynamic sections and method-only validation repair. |
| `tests/test_v102_logging_audit.py` | Updates the package-version assertion to `11.0-phase4`; logging/audit behavior is otherwise unchanged. |
| `tests/test_v11_phase2_collaborator_contracts.py` | Preserves Phase 2 collaborator-contract regressions while adapting assertions to the focused Phase 4 payload keys. |
| `tests/test_v11_phase3_fixture_graphs.py` | Preserves Phase 3 fixture regressions while accepting scenario variants in the compiled fixture selection path and the approved Phase 4 instruction fingerprint. |
| `tests/test_v11_phase4_semantic_variants.py` | Adds 41 focused regressions covering the required semantic categories, deterministic fixes, fixture-only restrictions, helper scope, variant deduplication/augmentation/isolation, source lifecycle, focused payload composition, instruction preservation, and synthetic Java compilation. |
| `V11_PHASE4_PYTEST_OUTPUT.txt` | Captures the complete pytest result. |
| `V11_PHASE4_COMPILEALL_OUTPUT.txt` | Captures Python bytecode compilation validation; an empty file indicates successful quiet execution. |
| `V11_PHASE4_IMPORT_SMOKE_OUTPUT.txt` | Captures package/version/API/prompt-fingerprint import smoke validation. |
| `V11_PHASE4_JAVA_FIXTURE_VARIANT_COMPILE_OUTPUT.txt` | Captures the synthetic scenario-specific fixture variant `javac` test. |
| `V11_PHASE4_SEMANTIC_VALIDATION_OUTPUT.txt` | Captures the focused Phase 4 semantic and fixture-variant test suite. |
| `V11_PHASE4_TEST_RESULTS.txt` | Summarizes all required validation commands and results. |
| `V11_PHASE4_VALIDATION_REPORT.md` | Summarizes Phase 4 behavior, validation evidence, instruction replacements, and explicit unsupported cases. |
| `V11_PHASE4_MODIFIED_FILES.txt` | Provides the exact machine-readable changed-file list. |

## Exact ServiceImpl `general_instructions` replacements

Only the following five directly conflicting clauses were replaced.

### Replacement 1

**Before**

> Inspect the target method and reached same-class helper sources to determine which fixture fields or relationships must be adjusted for the selected path.

**After**

> Inspect the target method and reached same-class helper sources to determine the required fixture state for the selected path. Select an existing compiled fixture variant or request one bounded fixture-augmentation attempt. Do not adjust fixture-supported application objects inside the @Test method.

**Reason:** selected-path state must be supplied by a compiled fixture variant rather than in-test mutation.

### Replacement 2

**Before**

> Apply only the smallest mutations required to satisfy selected-path conditions, dereferences, collaborator arguments, or expected behavior.

**After**

> Do not mutate fixture-supported application DTOs or entities inside @Test methods. Use a compiled fixture variant whose guaranteed state satisfies the selected path.

**Reason:** fixture-supported application objects are fixture-only in Phase 4.

### Replacement 3

**Before**

> Do not replace a populated nested object graph when a smaller field mutation is sufficient.

**After**

> Do not replace or mutate a compiled fixture graph inside an @Test method. Use a compiled fixture variant whose guaranteed graph satisfies the selected path.

**Reason:** neither graph replacement nor smaller in-test mutation is allowed for compiled fixtures.

### Replacement 4

**Before**

> If a selected path requires a field or object relationship that cannot be established using the supplied fixtures and verified available members, do not select that path.

**After**

> If a selected path requires fixture state not provided by an existing compiled fixture, request one bounded fixture-augmentation attempt. If no valid compiled fixture can provide the required state, do not select that path.

**Reason:** Phase 4 permits one bounded transactional variant-generation attempt before path rejection.

### Replacement 5

**Before**

> Do not mutate fields unrelated to the selected path.

**After**

> Do not mutate fields of fixture-supported application DTOs or entities inside @Test methods. Required selected-path state must come from a compiled fixture variant.

**Reason:** the former clause still permitted selected-path fixture mutation.

## Approved non-duplicate permanent additions

The existing instruction set did not state these two requirements explicitly, so each was added once:

1. `Do not classify or stub an unresolved collaborator contract as void.`
2. `Use only the supplied authorised static Mockito APIs and imports.`

No complete semantic, collaborator, fixture, schema, enum, constant, or scenario catalogue was added to permanent instructions. Those facts remain dynamically selected per method.

## Prompt composition safeguards

- `general_instructions` appears exactly once.
- Dynamic sections appear exactly once and are limited to the selected method:
  - `selected_scenario`;
  - relevant target method source;
  - reachable same-class helper source;
  - `relevant_collaborator_contracts`;
  - `relevant_fixture_contracts`;
  - `relevant_type_contracts`;
  - `relevant_constants`;
  - authorised imports/static APIs;
  - focused diagnostics/warnings.
- The complete semantic catalogue is not embedded in each request.
- The approved permanent-instruction SHA-256 fingerprint is `e0873b732e770b07bfa940ab1f17e5fb3925b5c4b6ec4053add41280ff37cb43`.

## Explicitly unchanged

- Phase 1 authoritative registry, stable test identity, generated-source immutability, candidate staging, accepted-source semantics, rollback, and append-only history foundation.
- Phase 2 recursive repository generic resolution, inherited Spring Data contracts, collaborator return-consumption semantics, and unresolved-contract state.
- Phase 3 baseline fixture graph emitter, schema catalogue, fixture compilation through skeleton preflight, and fixture support/compile gates.
- Existing class-level compile-repair orchestration.
- Existing runtime repair and coverage workflows.
- Controller, DTO/entity, and unrelated generation behavior.
- Phase 5 compilation acceptance and source promotion work.
