# llm-junit-assist v11 Final Requirement Matrix

## Status definitions

- **IMPLEMENTED_AND_VERIFIED** — implementation exists and the cited acceptance test passed in the final Phase 7 run.
- **IMPLEMENTED_SOURCE_ONLY** — source exists but no acceptance execution was available.
- **PARTIALLY_IMPLEMENTED**, **BROKEN**, **NOT_IMPLEMENTED**, **NOT_VERIFIED** — used exactly as required by the Phase 7 prompt.

> Final suite: 344 passed. Real Java compilation: verified with `javac 21.0.10`. Maven/enterprise repository execution: not available.

| Phase | Requirement | Status | Acceptance evidence | Notes |
|---|---|---|---|---|
| Phase 1 | Use 07-class-assembly/registry.json as the sole authoritative persisted registry. | IMPLEMENTED_AND_VERIFIED | test_v11_phase1_registry.py; integrated workflow registry persistence | No parallel registry introduced. |
| Phase 1 | Stable test_id is owner_method_id + "::" + test_name and is independent of source lines. | IMPLEMENTED_AND_VERIFIED | Phase 1 registry tests; Phase 5/6 ownership tests; Phase 7 integrated workflow |  |
| Phase 1 | Persist the required per-test identity, source, diagnostics, attempt, runtime, and disposition fields. | IMPLEMENTED_AND_VERIFIED | test_registry_serialization_and_reload_preserve_all_required_fields |  |
| Phase 1 | Keep generated_source immutable after initialization. | IMPLEMENTED_AND_VERIFIED | test_generated_source_cannot_be_overwritten; Phase 4/5/7 lifecycle proofs |  |
| Phase 1 | Use candidate_source only as temporary transactional state. | IMPLEMENTED_AND_VERIFIED | candidate commit/rollback tests; Phase 7 integrated workflow |  |
| Phase 1 | Update latest_accepted_source only through successful acceptance/commit. | IMPLEMENTED_AND_VERIFIED | candidate commit test; no-premature-update Phase 4/5 tests |  |
| Phase 1 | Preserve previous_accepted_source and accepted source on rollback. | IMPLEMENTED_AND_VERIFIED | rollback and previous-source tests; Phase 5/6 rollback tests |  |
| Phase 1 | Use deterministic source hashes independent of line endings/trailing whitespace and source locations. | IMPLEMENTED_AND_VERIFIED | test_source_hash_is_deterministic_across_line_endings_and_trailing_space |  |
| Phase 1 | Validate explicit compile-state transitions and reject impossible transitions. | IMPLEMENTED_AND_VERIFIED | compile-state transition tests |  |
| Phase 1 | Preserve diagnostics and attempts append-only across later attempts. | IMPLEMENTED_AND_VERIFIED | previous-diagnostics test; Phase 5/6 history tests |  |
| Phase 1 | Load older registry records safely, including legacy runtime-repair counters/history. | IMPLEMENTED_AND_VERIFIED | test_older_registry_records_load_with_safe_defaults |  |
| Phase 1 | Support structured dictionary and legacy string history entries in summary reporting. | IMPLEMENTED_AND_VERIFIED | dictionary and legacy summary tests; Phase 7 report test |  |
| Phase 1 | Persist atomically without corrupting the prior registry on failed replacement. | IMPLEMENTED_AND_VERIFIED | test_failed_atomic_registry_write_does_not_corrupt_prior_file |  |
| Phase 1 | Primary package and assembly/loop imports succeed without circular imports. | IMPLEMENTED_AND_VERIFIED | Phase 1 import tests; Phase 7 package-wide 83-module smoke |  |
| Phase 1 | Native Windows filesystem atomic replacement semantics. | NOT_VERIFIED | Not run in this Linux validation environment | Implementation and simulated replacement failure are verified; native Windows behavior is not. |
| Phase 2 | Resolve direct Spring Data repository entity and ID generics without requiring Spring source symbols. | IMPLEMENTED_AND_VERIFIED | Phase 2 direct JpaRepository/CrudRepository tests |  |
| Phase 2 | Resolve custom and intermediate repository interfaces recursively across multiple generic levels. | IMPLEMENTED_AND_VERIFIED | custom intermediate and multiple inheritance-level tests; Phase 7 integrated workflow |  |
| Phase 2 | Preserve partial/unresolved state for unbound, missing, or conflicting generic bindings. | IMPLEMENTED_AND_VERIFIED | unbound generic and unresolved contract tests |  |
| Phase 2 | Resolve exact inherited save/saveAndFlush/saveAll contracts using the bound entity type. | IMPLEMENTED_AND_VERIFIED | inherited contract tests; Phase 7 exact saveAndFlush proof |  |
| Phase 2 | Resolve exact findById/findAll/count/exists/delete/deleteById/flush contracts. | IMPLEMENTED_AND_VERIFIED | Phase 2 inherited Spring Data contract suite |  |
| Phase 2 | Preserve List versus Iterable repository return families and never treat unavailable JPA methods as void. | IMPLEMENTED_AND_VERIFIED | Crud/JPA family and partial-not-void tests |  |
| Phase 2 | Keep contract resolution distinct from return-consumption state. | IMPLEMENTED_AND_VERIFIED | Phase 2 flow-state tests |  |
| Phase 2 | Classify ignored, assigned/read, dereferenced, branch-tested, Optional, stream, passed-to-call, helper-return, and unresolved flows. | IMPLEMENTED_AND_VERIFIED | Phase 2 interprocedural flow tests |  |
| Phase 2 | Never reclassify unresolved flow as ignored or unresolved contract as void. | IMPLEMENTED_AND_VERIFIED | unresolved flow/return tests; Phase 7 cross-phase proof |  |
| Phase 2 | Derive required/optional/unnecessary/forbidden/unresolved normal-stubbing semantics. | IMPLEMENTED_AND_VERIFIED | void, ignored non-void, consumed non-void, unresolved tests |  |
| Phase 2 | Do not require unnecessary stubbing for ignored non-void repository results. | IMPLEMENTED_AND_VERIFIED | test_ignored_non_void_return_is_not_stub_required; Phase 7 integrated workflow |  |
| Phase 2 | Emit only method-relevant collaborator contracts with nullable unresolved return types. | IMPLEMENTED_AND_VERIFIED | focused payload and null-return payload tests |  |
| Phase 2 | Preserve existing general_instructions and avoid dynamic catalogue duplication. | IMPLEMENTED_AND_VERIFIED | Phase 2 prompt fingerprint/payload tests; Phase 7 prompt test |  |
| Phase 2 | Dynamic/reflection-heavy return flow and unavailable application repository source. | NOT_VERIFIED | Explicit Phase 2 limitation | Fails closed as partial/unresolved; no enterprise source corpus was supplied. |
| Phase 3 | Propagate baseline_required and dereference requirements through every required nested schema level. | IMPLEMENTED_AND_VERIFIED | Phase 3 required path test; Phase 7 integrated workflow |  |
| Phase 3 | Honor collection minimum size, indexed access, iteration, streams, and mutation requirements. | IMPLEMENTED_AND_VERIFIED | Phase 3 collection tests; Phase 7 minimum-size proof |  |
| Phase 3 | Build required nested objects through deterministic child fixture methods. | IMPLEMENTED_AND_VERIFIED | Phase 3 graph/dependency tests; real javac harness |  |
| Phase 3 | Emit compatible non-null mutable collection elements at the authoritative minimum size. | IMPLEMENTED_AND_VERIFIED | Phase 3 collection test; real javac harness |  |
| Phase 3 | Record direct/transitive fixture dependencies and relationship paths. | IMPLEMENTED_AND_VERIFIED | Phase 3 dependency test; Phase 7 integrated workflow |  |
| Phase 3 | Record identity guarantees for the exact attached nested/collection instances. | IMPLEMENTED_AND_VERIFIED | Phase 3 identity test |  |
| Phase 3 | Terminate fixture cycles safely, preserve the forward edge, and omit only the recursive reverse edge. | IMPLEMENTED_AND_VERIFIED | Phase 3 cycle tests |  |
| Phase 3 | Fail closed when a required child or required reverse cycle edge cannot be built. | IMPLEMENTED_AND_VERIFIED | Phase 3 partial/fail-closed tests |  |
| Phase 3 | Expose fixtures only when supported, semantically valid, and skeleton-compiled. | IMPLEMENTED_AND_VERIFIED | uncompiled/failed skeleton tests and catalogue persistence test |  |
| Phase 3 | Exclude unrelated, partial, unsupported, failed, or source-heavy fixtures from focused prompts. | IMPLEMENTED_AND_VERIFIED | Phase 3 focused fixture payload test |  |
| Phase 3 | Compile a generated baseline fixture graph with a real Java compiler. | IMPLEMENTED_AND_VERIFIED | V11_PHASE7_JAVA_FIXTURE_COMPILATION_OUTPUT.txt; javac 21.0.10 |  |
| Phase 3 | Unsupported graphs such as unresolvable required types/maps/wrappers or unsafe uniqueness. | IMPLEMENTED_AND_VERIFIED | Fail-closed implementation and regression coverage where applicable | These conditions are intentionally unsupported, not silently claimed as covered. |
| Phase 4 | Run structural and semantic validation before temporary class assembly. | IMPLEMENTED_AND_VERIFIED | Phase 4 semantic suite; Phase 7 integrated workflow |  |
| Phase 4 | Validate exact setters/getters, Boolean conventions, unknown methods/members/types, and collection/generic compatibility. | IMPLEMENTED_AND_VERIFIED | test_known_semantic_categories_are_rejected and focused semantic cases |  |
| Phase 4 | Validate collaborator methods, void/non-void/unresolved state, Mockito API/matcher consistency, and authorised imports. | IMPLEMENTED_AND_VERIFIED | Phase 4 semantic and matcher tests |  |
| Phase 4 | Reject non-JUnit-Jupiter assertion frameworks except safe deterministic normalization. | IMPLEMENTED_AND_VERIFIED | Phase 4 semantic suite |  |
| Phase 4 | Forbid construction, mutation, reflection mutation, mocks/spies, and manual graphs for fixture-supported application objects. | IMPLEMENTED_AND_VERIFIED | fixture mutation/mock tests; accepted mutation-free test proof |  |
| Phase 4 | Apply only source-backed deterministic corrections and append structured before/after history. | IMPLEMENTED_AND_VERIFIED | test_deterministic_corrections_are_structured_and_source_backed |  |
| Phase 4 | Create/reuse one bounded scenario-specific fixture variant by normalized application state. | IMPLEMENTED_AND_VERIFIED | fixture variant compile/reuse test |  |
| Phase 4 | Compile fixture variants transactionally and publish only after success. | IMPLEMENTED_AND_VERIFIED | variant transaction tests; real javac variant test; Phase 7 workflow |  |
| Phase 4 | Reject one invalid fixture variant without contaminating unrelated tests or variants. | IMPLEMENTED_AND_VERIFIED | test_transactional_variant_failure_is_isolated |  |
| Phase 4 | Rewrite accepted tests to call compiled variants and contain no in-test fixture mutation. | IMPLEMENTED_AND_VERIFIED | test_validated_variant_test_contains_no_fixture_mutation |  |
| Phase 4 | Keep generated_source immutable and do not promote accepted source before compile acceptance. | IMPLEMENTED_AND_VERIFIED | Phase 4 source lifecycle test |  |
| Phase 4 | Use at most one focused generation-repair request containing one method and relevant diagnostics/contracts. | IMPLEMENTED_AND_VERIFIED | focused validation-repair payload test |  |
| Phase 4 | Preserve non-conflicting general_instructions and apply only the approved minimal fixture-rule replacements. | IMPLEMENTED_AND_VERIFIED | minimal instruction replacement test; Phase 7 prompt test |  |
| Phase 4 | Compile a generated scenario fixture variant with a real Java compiler. | IMPLEMENTED_AND_VERIFIED | V11_PHASE7_JAVA_FIXTURE_COMPILATION_OUTPUT.txt; javac 21.0.10 |  |
| Phase 4 | Complex dynamic state, ambiguous overloads, unsupported fluent/lambda/reflection mutation patterns. | IMPLEMENTED_AND_VERIFIED | Explicit fail-closed behavior documented in Phase 4 report | Unsupported cases are rejected rather than guessed. |
| Phase 5 | Assemble the complete candidate class, recalculate all ranges, persist registry state, then compile once. | IMPLEMENTED_AND_VERIFIED | Phase 5 range/registry tests; Phase 7 real assembled-class javac |  |
| Phase 5 | Parse all compiler diagnostics including file, line, column, message, category, and raw text. | IMPLEMENTED_AND_VERIFIED | Phase 5 test 30 |  |
| Phase 5 | Map diagnostics exactly to registry tests, fixtures, skeleton/setup, import/class, assembly, or unmapped scope. | IMPLEMENTED_AND_VERIFIED | Phase 5 tests 01 and 04-08; Phase 7 integrated mapping |  |
| Phase 5 | Group multiple diagnostics owned by one test into one repair unit. | IMPLEMENTED_AND_VERIFIED | Phase 5 test 02; Phase 7 integrated workflow |  |
| Phase 5 | Recalculate accurate test/source ranges after repair, reassembly, and removal. | IMPLEMENTED_AND_VERIFIED | Phase 5 test 03; Phase 7 integrated workflow |  |
| Phase 5 | Leave unmapped diagnostics unmapped rather than assigning the nearest test. | IMPLEMENTED_AND_VERIFIED | Phase 5 test 08; Phase 7 integrated workflow |  |
| Phase 5 | Apply deterministic repair only to the owning test and commit only after candidate compilation succeeds. | IMPLEMENTED_AND_VERIFIED | Phase 5 deterministic commit/rollback tests |  |
| Phase 5 | Use at most one focused LLM compile repair for one registry-owned test. | IMPLEMENTED_AND_VERIFIED | Phase 5 focused integration and attempt-limit tests; Phase 7 fake deterministic client |  |
| Phase 5 | Never invoke complete-class ServiceImpl LLM compile repair. | IMPLEMENTED_AND_VERIFIED | Phase 5 test 09/evidence; Phase 7 integrated assertion |  |
| Phase 5 | Rollback failed candidates and explicitly reject/remove only the irreparable test. | IMPLEMENTED_AND_VERIFIED | Phase 5 rollback/removal tests |  |
| Phase 5 | Preserve generated_source and prevent premature latest_accepted_source updates. | IMPLEMENTED_AND_VERIFIED | Phase 5 tests 14-15 |  |
| Phase 5 | Normalize only one raw method or one complete outer fence; reject prose, nested/multiple/unmatched/truncated/wrong-identity responses. | IMPLEMENTED_AND_VERIFIED | Phase 5 response-normalization tests 16-21 and 28 |  |
| Phase 5 | Preserve provider response state, finish reason, token counts, byte size, raw response, hashes, and truncation/normalization evidence. | IMPLEMENTED_AND_VERIFIED | Phase 5 metadata/hash tests |  |
| Phase 5 | Do not retry an identical rejected request/response. | IMPLEMENTED_AND_VERIFIED | Phase 5 test 24 |  |
| Phase 5 | Keep compile attempt and repair histories append-only. | IMPLEMENTED_AND_VERIFIED | Phase 5 test 25 |  |
| Phase 5 | Focused prompt includes one preserved instruction block and only directly relevant dynamic contracts/imports/APIs. | IMPLEMENTED_AND_VERIFIED | Phase 5 payload tests; Phase 7 prompt test |  |
| Phase 5 | Real customer multi-module Maven/Ant focused compile-repair execution. | NOT_VERIFIED | Maven unavailable; no customer repository supplied | Algorithmic transaction is verified with deterministic fake compile gates; assembled Java source is real-javac verified. |
| Phase 6 | Map runtime failures to stable registry test_id using executed class/method, owner metadata, and registry identity without line-number identity. | IMPLEMENTED_AND_VERIFIED | Phase 6 mapping test; Phase 7 integrated workflow |  |
| Phase 6 | Repair exactly one failing registry-owned @Test and exclude siblings/classes/catalogues/unrelated methods. | IMPLEMENTED_AND_VERIFIED | Phase 6 focused payload test |  |
| Phase 6 | Record diagnostics, request/response metadata, hashes, candidate source/hash, validation, compile, targeted/full run, and decision per attempt. | IMPLEMENTED_AND_VERIFIED | Phase 6 metadata/history test |  |
| Phase 6 | Compile each runtime candidate directly exactly once. | IMPLEMENTED_AND_VERIFIED | Phase 6 successful/compile-failure tests; Phase 7 integrated call count |  |
| Phase 6 | Never enter compile repair from runtime repair. | IMPLEMENTED_AND_VERIFIED | Phase 6 zero-nested evidence; Phase 7 patched fail-if-called assertion |  |
| Phase 6 | On candidate compile failure, perform zero compile-repair LLM calls and rollback immediately. | IMPLEMENTED_AND_VERIFIED | Phase 6 compile-failure test |  |
| Phase 6 | Run the targeted failing test before the complete retained class. | IMPLEMENTED_AND_VERIFIED | Phase 6 successful transaction test |  |
| Phase 6 | Commit only after structural identity, semantic, direct compile, targeted execution, and full-green class gates pass. | IMPLEMENTED_AND_VERIFIED | Phase 6 successful and rejection-gate tests |  |
| Phase 6 | Rollback after targeted failure or full-class failure without modifying accepted siblings/source. | IMPLEMENTED_AND_VERIFIED | Phase 6 targeted/full failure and rollback-baseline tests |  |
| Phase 6 | Preserve generated_source, latest accepted baseline, and append-only attempt/history evidence. | IMPLEMENTED_AND_VERIFIED | Phase 6 history and rollback tests |  |
| Phase 6 | Stop identical rejected runtime responses without a second compile. | IMPLEMENTED_AND_VERIFIED | Phase 6 duplicate-response test |  |
| Phase 6 | Preserve one general_instructions copy with only the runtime requested-test-kind replacement. | IMPLEMENTED_AND_VERIFIED | Phase 6 prompt test; Phase 7 prompt test |  |
| Phase 6 | Real Maven/Surefire/JaCoCo runtime-repair cycle against an enterprise ServiceImpl repository. | NOT_VERIFIED | Maven unavailable; no enterprise repository supplied | Runtime orchestration is verified with deterministic synthetic runners. |
| Phase 7 cross-phase proof | Required baseline fixture relationships are populated. | IMPLEMENTED_AND_VERIFIED | Phase 3 required graph tests; Phase 7 integrated workflow |  |
| Phase 7 cross-phase proof | Required fixture collections satisfy minimum size. | IMPLEMENTED_AND_VERIFIED | Phase 3 collection test; Phase 7 integrated workflow |  |
| Phase 7 cross-phase proof | Fixture cycles terminate safely. | IMPLEMENTED_AND_VERIFIED | Phase 3 cycle tests |  |
| Phase 7 cross-phase proof | Unresolved repository contracts are not treated as void. | IMPLEMENTED_AND_VERIFIED | Phase 2 unresolved contract tests |  |
| Phase 7 cross-phase proof | Inherited saveAndFlush returns the exact entity type. | IMPLEMENTED_AND_VERIFIED | Phase 2 exact contract test; Phase 7 integrated workflow |  |
| Phase 7 cross-phase proof | Ignored non-void repository returns are not unnecessarily stubbed. | IMPLEMENTED_AND_VERIFIED | Phase 2 ignored-return test; Phase 7 integrated workflow |  |
| Phase 7 cross-phase proof | Fixture-supported objects are not mutated inside accepted @Test methods. | IMPLEMENTED_AND_VERIFIED | Phase 4 mutation-free acceptance test |  |
| Phase 7 cross-phase proof | Known semantic errors do not reach Java compilation. | IMPLEMENTED_AND_VERIFIED | Phase 4 semantic gate; Phase 7 correct-before-javac workflow |  |
| Phase 7 cross-phase proof | One invalid fixture variant does not reject unrelated tests. | IMPLEMENTED_AND_VERIFIED | Phase 4 transactional isolation test |  |
| Phase 7 cross-phase proof | generated_source remains immutable. | IMPLEMENTED_AND_VERIFIED | Phase 1/4/5/7 tests |  |
| Phase 7 cross-phase proof | candidate_source is temporary. | IMPLEMENTED_AND_VERIFIED | Phase 1 lifecycle and Phase 7 workflow |  |
| Phase 7 cross-phase proof | latest_accepted_source changes only after acceptance gates. | IMPLEMENTED_AND_VERIFIED | Phase 1/4/5/6 tests |  |
| Phase 7 cross-phase proof | Rollback preserves the previous accepted source. | IMPLEMENTED_AND_VERIFIED | Phase 1/5/6 tests |  |
| Phase 7 cross-phase proof | Line ranges remain accurate after repair and removal. | IMPLEMENTED_AND_VERIFIED | Phase 5 range test; Phase 7 workflow |  |
| Phase 7 cross-phase proof | Multiple compiler errors for one test produce one repair unit. | IMPLEMENTED_AND_VERIFIED | Phase 5 grouping test; Phase 7 workflow |  |
| Phase 7 cross-phase proof | Unmapped diagnostics are not assigned to the nearest test. | IMPLEMENTED_AND_VERIFIED | Phase 5 unmapped test; Phase 7 workflow |  |
| Phase 7 cross-phase proof | Complete-class ServiceImpl LLM compile repair is never called. | IMPLEMENTED_AND_VERIFIED | Phase 5 evidence; Phase 7 workflow |  |
| Phase 7 cross-phase proof | Focused compile repair receives only one test. | IMPLEMENTED_AND_VERIFIED | Phase 5 payload/integration tests |  |
| Phase 7 cross-phase proof | Runtime repair never enters compile repair. | IMPLEMENTED_AND_VERIFIED | Phase 6 evidence; Phase 7 workflow |  |
| Phase 7 cross-phase proof | Runtime candidate compile failure triggers zero compile-repair LLM calls. | IMPLEMENTED_AND_VERIFIED | Phase 6 compile-failure test |  |
| Phase 7 cross-phase proof | Registry histories remain append-only. | IMPLEMENTED_AND_VERIFIED | Phase 1/5/6 history tests |  |
| Phase 7 cross-phase proof | Dictionary history entries do not crash summary reporting. | IMPLEMENTED_AND_VERIFIED | Phase 1 dictionary-history test |  |
| Phase 7 cross-phase proof | All primary package imports succeed without circular imports. | IMPLEMENTED_AND_VERIFIED | Phase 7 83-module import smoke |  |
| Phase 7 cross-phase proof | Identical rejected responses are not retried. | IMPLEMENTED_AND_VERIFIED | Phase 5 and Phase 6 duplicate-response tests |  |
| Phase 7 cross-phase proof | Provider response metadata is preserved. | IMPLEMENTED_AND_VERIFIED | Phase 5 and Phase 6 metadata tests |  |

## Aggregate status

- IMPLEMENTED_AND_VERIFIED: 107
- NOT_VERIFIED: 4
- IMPLEMENTED_SOURCE_ONLY: 0
- PARTIALLY_IMPLEMENTED: 0
- BROKEN: 0
- NOT_IMPLEMENTED: 0

The `NOT_VERIFIED` rows are environmental integration boundaries, not silently waived requirements.
