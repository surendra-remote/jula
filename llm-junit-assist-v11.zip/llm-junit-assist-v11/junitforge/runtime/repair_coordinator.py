"""Runtime failure repair coordination and deterministic repair helpers."""

from __future__ import annotations

import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.audit.console import stage as console_stage
from junitforge.audit.paths import safe_name
from junitforge.audit.recorder import sha256_text
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get

log = get("junitforge.loop")
from junitforge.generation.response_extractor import extract_generated_tests
from junitforge.generation.response_normalizer import normalize_focused_java_response

from junitforge.generation.payloads import payload_builder_for_context
from junitforge.generation.validation import is_serviceimpl_context, validate_generated_test
from junitforge.pipeline.result import (
    commit_candidate_source,
    restore_test_registry,
    snapshot_test_registry,
    stage_candidate_source,
    sync_test_registry_sources,
    test_record_by_name,
)
from junitforge.runtime.candidate_validator import validate_runtime_candidate_identity
from junitforge.runtime.state import restore_runtime_outcome, snapshot_runtime_outcome
from junitforge.runtime.result_parser import (
    _failure_signatures,
    _group_runtime_failures,
    _map_runtime_failure_owner,
    _runtime_failure_excerpt,
    runtime_diagnostic,
)

def _runtime_owner_priority(item: tuple[str, list[SurefireFailure]]) -> tuple[int, int, str]:
    owner, failures = item
    errors = sum(1 for failure in failures if failure.status == "error")
    deterministic = sum(
        1
        for failure in failures
        if failure.category
        in {
            "INVALID_CHECKED_EXCEPTION_STUB",
            "UNNECESSARY_STUBBING",
            "UNEXPECTED_NULL_POINTER",
        }
    )
    return errors, len(failures) + deterministic, owner

def _targeted_selector(test_fqcn: str, failures: list[SurefireFailure]) -> str:
    names: list[str] = []
    for failure in failures:
        name = failure.test_method.split("(", 1)[0]
        if name and name not in names:
            names.append(name)
    return test_fqcn + ("#" + "+".join(names) if names else "")

def _deterministic_runtime_replacement(
    suite: str,
    owner: str,
    failures: list[SurefireFailure],
) -> tuple[str | None, str | None]:
    """Apply only high-confidence, source-local runtime fixes before LLM repair."""
    unused_lines = sorted(
        {
            failure.generated_test_line
            for failure in failures
            if failure.category == "UNNECESSARY_STUBBING"
            and failure.generated_test_line is not None
            and owner_method_id_for_line(suite, failure.generated_test_line) == owner
        },
        reverse=True,
    )
    if not unused_lines:
        return None, None

    lines = suite.splitlines()
    removed = 0
    stub_start = re.compile(
        r"\b(?:lenient\s*\(\s*\)\s*\.)?when\s*\(|"
        r"\bdo(?:Return|Throw|Answer|Nothing)\s*\("
    )
    for line_number in unused_lines:
        index = line_number - 1
        if index < 0 or index >= len(lines):
            continue
        start = index
        while start >= 0 and index - start <= 8 and not stub_start.search(lines[start]):
            start -= 1
        if start < 0 or index - start > 8:
            continue
        end = start
        while end < len(lines) and end - start <= 16:
            if ";" in lines[end]:
                break
            end += 1
        if end >= len(lines) or end - start > 16:
            continue
        statement = "\n".join(lines[start : end + 1])
        if not stub_start.search(statement) or "verify(" in statement:
            continue
        del lines[start : end + 1]
        removed += 1

    if not removed:
        return None, None
    updated = "\n".join(lines) + ("\n" if suite.endswith("\n") else "")
    block = method_block_for_id(updated, owner)
    return block, f"removed_unused_local_stubs={removed}"


class RuntimeRepairMixin:
    def _runtime_failure_repair_loop(
        self,
        ctx: GenerationContext,
        test_path: Path,
        module: ModuleInfo,
        initial_run: CoverageRunResult,
        outcome: TargetOutcome,
    ) -> CoverageRunResult | None:
        runner = self.coverage_runner
        assert runner is not None
        current_run: CoverageRunResult | RuntimeTestRunResult = initial_run
        if (
            outcome.runtime_failures_initial == 0
            and outcome.runtime_errors_initial == 0
            and (initial_run.signals.tests_failed or initial_run.signals.tests_errors)
        ):
            outcome.runtime_failures_initial = initial_run.signals.tests_failed
            outcome.runtime_errors_initial = initial_run.signals.tests_errors
            outcome.runtime_failure_categories_initial = dict(
                Counter(f.category for f in initial_run.failures)
            )
        owner_attempts: Counter[str] = Counter()
        blocked_owners: set[str] = set()
        visited_owners: set[str] = set()
        no_progress_rounds = 0
        max_rounds = max(0, self.cfg.max_runtime_repair_rounds)
        test_fqcn = self._test_fqcn(ctx)

        log.debug(
            "[RUNTIME_REPAIR] start | target=%s | tests_run=%d | failures=%d | "
            "errors=%d | max_rounds=%d | per_owner=%d | max_owners=%d",
            ctx.symbol.name,
            current_run.signals.tests_run,
            current_run.signals.tests_failed,
            current_run.signals.tests_errors,
            max_rounds,
            self.cfg.max_runtime_repairs_per_owner,
            self.cfg.max_runtime_repair_owners,
        )

        for round_no in range(1, max_rounds + 1):
            if current_run.signals.tests_green:
                break
            suite = test_path.read_text(encoding="utf-8")
            failures = current_run.failures
            if not failures and current_run.log_tail:
                failures = parse_surefire_failures_from_log(
                    current_run.log_tail,
                    [test_fqcn],
                )
                if failures:
                    current_run.failures = failures
                    log.debug(
                        "[RUNTIME_REPAIR] report.source | source=log_tail_last_resort | failures=%d",
                        len(failures),
                    )
            if not failures:
                outcome.notes.append(
                    "runtime repair stopped: Surefire reported failures/errors but no structured "
                    "failure entries could be parsed"
                )
                log.error(
                    "[RUNTIME_REPAIR] exhausted | reason=no_structured_failures | failures=%d | errors=%d",
                    current_run.signals.tests_failed,
                    current_run.signals.tests_errors,
                )
                outcome.status = "runtime_failed"
                return None

            grouped, unmapped = _group_runtime_failures(suite, failures, outcome)
            for failure in failures:
                owner, source, confidence = _map_runtime_failure_owner(suite, failure, outcome)
                log.debug(
                    "[RUNTIME_REPAIR] owner.map | test_method=%s | generated_owner=%s | "
                    "mapping_source=%s | confidence=%s | category=%s",
                    failure.test_method,
                    owner,
                    source,
                    confidence,
                    failure.category,
                )
            outcome.remaining_runtime_owners = sorted(grouped)
            if unmapped:
                outcome.notes.append(
                    f"runtime failures not mapped to a generated owner: {len(unmapped)}"
                )

            eligible = [
                item
                for item in grouped.items()
                if item[0] not in blocked_owners
                and owner_attempts[item[0]] < self.cfg.max_runtime_repairs_per_owner
                and (item[0] in visited_owners or len(visited_owners) < self.cfg.max_runtime_repair_owners)
            ]
            if not eligible:
                outcome.status = "repair_exhausted"
                log.error(
                    "[RUNTIME_REPAIR] exhausted | reason=no_eligible_owner | blocked=%s | "
                    "attempts=%s | remaining=%s",
                    sorted(blocked_owners),
                    dict(owner_attempts),
                    sorted(grouped),
                )
                return None

            owner, owner_failures = max(eligible, key=_runtime_owner_priority)
            owner_attempts[owner] += 1
            visited_owners.add(owner)
            outcome.runtime_repair_attempts += 1
            console_stage("RUNTIME_REPAIR", "method=%s | failing_tests=%d", owner, len(owner_failures))
            log.debug(
                "[RUNTIME_REPAIR] owner.select | round=%d | owner=%s | owner_failures=%d | "
                "attempt=%d | categories=%s",
                round_no,
                owner,
                len(owner_failures),
                owner_attempts[owner],
                dict(Counter(f.category for f in owner_failures)),
            )

            accepted, next_run, reason = self._repair_runtime_owner(
                ctx=ctx,
                test_path=test_path,
                module=module,
                owner=owner,
                owner_failures=owner_failures,
                before_run=current_run,
                outcome=outcome,
                test_fqcn=test_fqcn,
                round_no=round_no,
                attempt_no=owner_attempts[owner],
            )
            if accepted and next_run is not None:
                current_run = next_run
                no_progress_rounds = 0
                runner.invalidate_coverage(module)
                outcome.coverage_current = False
                if current_run.signals.tests_green:
                    log.debug(
                        "[RUNTIME_REPAIR] success | rounds=%d | attempts=%d | action=fresh_coverage",
                        round_no,
                        outcome.runtime_repair_attempts,
                    )
                    fresh = self._measure_coverage(runner, module, test_classes=[test_fqcn])
                    self._record_coverage_runtime_result(outcome, fresh, initial=False)
                    log.debug(
                        "[RUNTIME_GATE] result | tests_run=%d | failures=%d | errors=%d | "
                        "tests_green=%s | coverage_measured=%s | coverage_current=%s | "
                        "action=%s",
                        fresh.signals.tests_run,
                        fresh.signals.tests_failed,
                        fresh.signals.tests_errors,
                        fresh.tests_green,
                        fresh.measured,
                        fresh.coverage_current,
                        "coverage" if fresh.tests_green else "runtime_repair",
                    )
                    if fresh.ok and fresh.measured and fresh.tests_green and fresh.coverage_current:
                        outcome.status = "pending"
                        return fresh
                    current_run = fresh
                continue

            no_progress_rounds += 1
            if owner_attempts[owner] >= self.cfg.max_runtime_repairs_per_owner:
                blocked_owners.add(owner)
                log.debug(
                    "[RUNTIME_REPAIR] owner.blocked | owner=%s | attempts=%d | reason=%s",
                    owner,
                    owner_attempts[owner],
                    reason,
                )
            if no_progress_rounds >= self.cfg.max_runtime_no_progress_rounds:
                outcome.status = "repair_exhausted"
                log.error(
                    "[RUNTIME_REPAIR] exhausted | reason=no_progress | rounds=%d | "
                    "blocked=%s",
                    no_progress_rounds,
                    sorted(blocked_owners),
                )
                return None

        if current_run.signals.tests_green:
            runner.invalidate_coverage(module)
            fresh = self._measure_coverage(runner, module, test_classes=[test_fqcn])
            self._record_coverage_runtime_result(outcome, fresh, initial=False)
            if fresh.ok and fresh.measured and fresh.tests_green and fresh.coverage_current:
                outcome.status = "pending"
                return fresh
        outcome.status = "repair_exhausted" if outcome.runtime_repair_attempts else "runtime_failed"
        log.error(
            "[RUNTIME_REPAIR] exhausted | reason=round_limit | attempts=%d | failures=%d | errors=%d",
            outcome.runtime_repair_attempts,
            outcome.runtime_failures_final,
            outcome.runtime_errors_final,
        )
        return None

    def _repair_runtime_owner(
        self,
        *,
        ctx: GenerationContext,
        test_path: Path,
        module: ModuleInfo,
        owner: str,
        owner_failures: list[SurefireFailure],
        before_run: CoverageRunResult | RuntimeTestRunResult,
        outcome: TargetOutcome,
        test_fqcn: str,
        round_no: int,
        attempt_no: int,
    ) -> tuple[bool, RuntimeTestRunResult | None, str]:
        runner = self.coverage_runner
        assert runner is not None
        current = test_path.read_text(encoding="utf-8")
        registry_before = snapshot_test_registry(outcome)
        runtime_outcome_before = snapshot_runtime_outcome(outcome)
        audit_dir = f"11-runtime-repair/{safe_name(owner)}/attempt-{attempt_no:03d}"
        decision_base = {
            "stage": "runtime_repair",
            "method_id": owner,
            "attempt": attempt_no,
        }

        def record_decision(*, accepted: bool, reason: str, rollback: bool, **extra) -> None:
            self.audit.write_json(ctx.symbol.name, f"{audit_dir}/decision.json", {
                **decision_base,
                **extra,
                "accepted": accepted,
                "rollback_performed": rollback,
                "reason": reason,
            })

        def rollback_state() -> None:
            test_path.write_text(current, encoding="utf-8")
            restore_test_registry(outcome, registry_before)
            restore_runtime_outcome(outcome, runtime_outcome_before)
        method = next(
            (
                candidate
                for candidate in (ctx.symbol.methods or [])
                if f"{candidate.name}({','.join(type_name for type_name, _ in candidate.params)})" == owner
            ),
            None,
        )
        method_context = next(
            (candidate for candidate in ctx.execution_context.methods if candidate.method_id == owner),
            None,
        ) if ctx.execution_context is not None else None
        current_block = method_block_for_id(current, owner)
        if method is None or method_context is None or current_block is None:
            outcome.notes.append(f"runtime repair skipped [{owner}]: owner context missing")
            return False, None, "owner_context_missing"

        original_complete_names = tuple(test_method_names(current))
        original_owner_names = tuple(test_method_names(current_block))
        selected_test_names = {
            failure.test_method.split("(", 1)[0]
            for failure in owner_failures
            if failure.test_method
        }
        if not selected_test_names:
            outcome.notes.append(f"runtime repair skipped [{owner}]: no selected test identity")
            return False, None, "selected_test_identity_missing"
        for test_name in selected_test_names:
            registry_record = test_record_by_name(outcome, test_name)
            if registry_record is not None:
                registry_record.runtime_state = "REPAIR_PENDING"
                registry_record.runtime_repair_attempts += 1

        def persist_registry_attempt(
            reason: str,
            *,
            state: str = "FAILED",
            result: str = "REJECTED",
            after_rollback: bool = False,
            diagnostics: list[str] | None = None,
        ) -> None:
            """Persist one per-test runtime attempt, including rollback paths."""
            for test_name in selected_test_names:
                registry_record = test_record_by_name(outcome, test_name)
                if registry_record is None:
                    continue
                if after_rollback:
                    # The authoritative snapshot predates this attempt.
                    registry_record.runtime_repair_attempts += 1
                registry_record.runtime_state = state
                history = {
                    "stage": "runtime_repair",
                    "round": round_no,
                    "attempt": attempt_no,
                    "owner": owner,
                    "result": result,
                    "reason": reason,
                }
                if diagnostics:
                    history["diagnostics"] = diagnostics
                registry_record.runtime_repair_history.append(history)
            write_registry = getattr(self, "_write_registry_audit", None)
            if callable(write_registry):
                write_registry(ctx, outcome)

        log.debug(
            "[RUNTIME_REPAIR] deterministic.start | round=%d | owner=%s | categories=%s",
            round_no,
            owner,
            dict(Counter(failure.category for failure in owner_failures)),
        )
        replacement, deterministic_action = _deterministic_runtime_replacement(
            current,
            owner,
            owner_failures,
        )
        if replacement is not None:
            log.debug(
                "[RUNTIME_REPAIR] deterministic.result | owner=%s | changed=true | action=%s",
                owner,
                deterministic_action,
            )
        else:
            log.debug(
                "[RUNTIME_REPAIR] deterministic.result | owner=%s | changed=false | action=llm",
                owner,
            )
            log.debug(
                "[RUNTIME_REPAIR] llm.start | round=%d | owner=%s | failures=%d",
                round_no,
                owner,
                len(owner_failures),
            )
            extracted_by_name = {
                test.name: test.source for test in extract_generated_tests(current_block)
            }
            failing_tests = []
            for test_name in original_owner_names:
                if test_name not in selected_test_names:
                    continue
                attached = [
                    failure
                    for failure in owner_failures
                    if failure.test_method.split("(", 1)[0] == test_name
                ]
                if not attached:
                    continue
                runtime_status = (
                    "error"
                    if any((failure.status or "").lower() == "error" for failure in attached)
                    else "failure"
                )
                failing_tests.append({
                    "test_name": test_name,
                    "source": extracted_by_name.get(test_name, ""),
                    "runtime_status": runtime_status,
                    "diagnostics": [runtime_diagnostic(failure) for failure in attached],
                })
            if len(failing_tests) != len(selected_test_names):
                persist_registry_attempt("failing_test_source_missing")
                record_decision(accepted=False, reason="failing_test_source_missing", rollback=False,
                                selected_tests=sorted(selected_test_names))
                return False, None, "failing_test_source_missing"
            self.audit.write_text(
                ctx.symbol.name,
                f"{audit_dir}/failing-tests-before.java",
                "\n\n".join(test["source"] for test in failing_tests),
            )
            builder = payload_builder_for_context(ctx)
            messages = builder.build_runtime_repair_payload(
                ctx,
                method,
                failing_tests=failing_tests,
                test_class_source=current,
            )
            self.audit.write_json(ctx.symbol.name, f"{audit_dir}/request.json", {
                "request_type": "runtime_repair",
                "target_class": ctx.symbol.fqcn,
                "method_id": owner,
                "selected_tests": [test["test_name"] for test in failing_tests],
                "excluded_passed_test_count": max(0, len(original_owner_names) - len(failing_tests)),
                "model_id": self.cfg.model_id,
                "temperature": self.cfg.temperature_repair,
                "max_tokens": self.cfg.max_tokens_repair,
                "messages": messages,
            })
            raw = self._chat(
                messages,
                self.cfg.temperature_repair,
                self.cfg.max_tokens_repair,
                outcome,
            )
            self.audit.write_text(ctx.symbol.name, f"{audit_dir}/response.txt", raw or "")
            normalized_response = normalize_focused_java_response(raw or "")
            self.audit.write_json(ctx.symbol.name, f"{audit_dir}/response-metadata.json", {
                "state": normalized_response.state.value,
                "reason": normalized_response.reason,
                "raw_hash": normalized_response.raw_hash,
                "normalized_hash": normalized_response.normalized_hash,
                "character_count": normalized_response.character_count,
            })
            if normalized_response.source is None:
                persist_registry_attempt(normalized_response.state.value)
                record_decision(
                    accepted=False,
                    reason=normalized_response.state.value,
                    rollback=False,
                    selected_tests=sorted(selected_test_names),
                )
                return False, None, normalized_response.state.value
            repaired_tests = extract_generated_tests(normalized_response.source)
            self.audit.write_text(
                ctx.symbol.name,
                f"{audit_dir}/repaired-tests.java",
                "\n\n".join(test.source for test in repaired_tests),
            )
            expected_order = tuple(test["test_name"] for test in failing_tests)
            returned_order = tuple(test.name for test in repaired_tests)
            returned_names = set(returned_order)
            if returned_names != selected_test_names or len(repaired_tests) != len(selected_test_names):
                outcome.notes.append(
                    f"runtime repair rejected [{owner}]: selected test identity changed; "
                    f"expected={sorted(selected_test_names)} returned={sorted(returned_names)}"
                )
                record_decision(
                    accepted=False, reason="selected_test_identity_changed", rollback=False,
                    selected_tests=sorted(selected_test_names), returned_test_names=list(returned_order),
                    test_identity_preserved=False,
                )
                persist_registry_attempt("selected_test_identity_changed")
                return False, None, "selected_test_identity_changed"
            if returned_order != expected_order:
                outcome.notes.append(
                    f"runtime repair rejected [{owner}]: selected test order changed; "
                    f"expected={list(expected_order)} returned={list(returned_order)}"
                )
                record_decision(
                    accepted=False, reason="selected_test_order_changed", rollback=False,
                    selected_tests=list(expected_order), returned_test_names=list(returned_order),
                    test_identity_preserved=False,
                )
                persist_registry_attempt("selected_test_order_changed")
                return False, None, "selected_test_order_changed"
            replacement = current_block
            for repaired_test in repaired_tests:
                updated = replace_test_method(
                    replacement,
                    repaired_test.name,
                    normalize_writable_map_mutations(repaired_test.source),
                )
                if updated is None:
                    persist_registry_attempt("selected_test_merge_failed")
                    return False, None, "selected_test_merge_failed"
                replacement = updated
            log.debug(
                "[RUNTIME_REPAIR] llm.end | round=%d | owner=%s | selected_tests=%s | "
                "raw_chars=%d | replacement_chars=%d",
                round_no,
                owner,
                sorted(selected_test_names),
                len(raw or ""),
                len(replacement),
            )
        if not replacement.strip() or replacement.strip() == current_block.strip():
            log.debug(
                "[RUNTIME_REPAIR] rollback | owner=%s | reason=source_unchanged",
                owner,
            )
            persist_registry_attempt("source_unchanged")
            return False, None, "source_unchanged"

        existing_names = set(test_method_names(current)) - set(test_method_names(current_block))
        validation = validate_generated_test(
            ctx,
            method,
            method_context,
            replacement,
            existing_names,
        )
        if not validation.ok:
            outcome.notes.append(f"runtime repair rejected [{owner}]: {validation.reason}")
            log.debug(
                "[RUNTIME_REPAIR] validation.result | owner=%s | accepted=false | reason=%s",
                owner,
                validation.reason,
            )
            persist_registry_attempt("validation_failed", diagnostics=[validation.reason])
            return False, None, "validation_failed"
        log.debug(
            "[RUNTIME_REPAIR] validation.result | owner=%s | accepted=true | tests=%d",
            owner,
            len(validation.test_names),
        )

        candidate = replace_method_block(current, owner, replacement)
        finalized = finalize_java(
            candidate,
            test_package=ctx.test_package,
            test_class_name=ctx.test_class_name,
            template=ctx.template,
            cut_symbol=ctx.symbol,
            collaborators=ctx.collaborators,
            source_imports=ctx.source_imports,
        )
        if not finalized.ok or not finalized.code:
            outcome.notes.append(f"runtime repair rejected [{owner}]: {finalized.reason}")
            persist_registry_attempt(
                "finalize_failed",
                diagnostics=[finalized.reason or "invalid finalized Java"],
            )
            return False, None, "finalize_failed"
        candidate_complete_names = tuple(test_method_names(finalized.code))
        candidate_owner_names = tuple(
            test_method_names(method_block_for_id(finalized.code, owner) or "")
        )
        if (
            len(candidate_complete_names) != len(original_complete_names)
            or set(candidate_complete_names) != set(original_complete_names)
            or len(candidate_owner_names) != len(original_owner_names)
            or set(candidate_owner_names) != set(original_owner_names)
        ):
            lost = set(original_complete_names) - set(candidate_complete_names)
            outcome.tests_lost_during_runtime_repair += len(lost)
            outcome.notes.append(
                f"runtime repair rejected [{owner}]: TEST_IDENTITY_CHANGED; missing={sorted(lost)}"
            )
            persist_registry_attempt("TEST_IDENTITY_CHANGED")
            return False, None, "TEST_IDENTITY_CHANGED"

        self.audit.write_text(ctx.symbol.name, f"{audit_dir}/candidate-class.java", finalized.code)
        candidate_owner_block = method_block_for_id(finalized.code, owner) or ""
        for test_name in selected_test_names:
            candidate_test = test_method_for_name(candidate_owner_block, test_name)
            registry_record = test_record_by_name(outcome, test_name)
            if candidate_test is not None and registry_record is not None:
                stage_candidate_source(outcome, test_name, candidate_test.source)
        test_path.write_text(finalized.code, encoding="utf-8")
        log.debug("[RUNTIME_REPAIR] compile.start | owner=%s | nested_repair=false", owner)
        compile_result, compile_errors = self._compile_candidate(test_path, module)
        self.audit.write_json(ctx.symbol.name, f"{audit_dir}/compile-result.json", {
            "success": compile_result.ok,
            "error_count": len(compile_errors),
            "diagnostics": [error.render() for error in compile_errors],
            "nested_compile_repair": False,
        })
        if not compile_result.ok:
            for test_name in selected_test_names:
                record = test_record_by_name(outcome, test_name)
                if record is not None:
                    record.compile_state = "FAILED"
                    record.runtime_diagnostics.append({
                        "type": "runtime_repair_compile_failure",
                        "diagnostics": [error.render() for error in compile_errors],
                    })
            rollback_state()
            persist_registry_attempt(
                "compile_failed",
                result="ROLLBACK",
                after_rollback=True,
                diagnostics=[error.render() for error in compile_errors],
            )
            record_decision(accepted=False, reason="compile_failed", rollback=True,
                            selected_tests=sorted(selected_test_names), nested_compile_repair=False)
            console_stage("RUNTIME_REPAIR", "method=%s | rejected | reason=compile_failed", owner, level="warning")
            console_stage("RUNTIME_REPAIR", "rollback | restored=last_runtime_green_source", level="warning")
            return False, None, "compile_failed"
        good = finalized.code
        compiled_complete_names = tuple(test_method_names(good))
        compiled_owner_names = tuple(test_method_names(method_block_for_id(good, owner) or ""))
        if (
            len(compiled_complete_names) != len(original_complete_names)
            or set(compiled_complete_names) != set(original_complete_names)
            or len(compiled_owner_names) != len(original_owner_names)
            or set(compiled_owner_names) != set(original_owner_names)
        ):
            lost = set(original_complete_names) - set(compiled_complete_names)
            outcome.tests_lost_during_runtime_repair += len(lost)
            rollback_state()
            outcome.notes.append(
                f"runtime compile repair rolled back [{owner}]: TEST_IDENTITY_CHANGED; missing={sorted(lost)}"
            )
            persist_registry_attempt(
                "TEST_IDENTITY_CHANGED",
                result="ROLLBACK",
                after_rollback=True,
            )
            return False, None, "TEST_IDENTITY_CHANGED"
        test_path.write_text(good, encoding="utf-8")
        log.debug("[RUNTIME_REPAIR] compile.result | owner=%s | success=true", owner)

        targeted_selector = _targeted_selector(test_fqcn, owner_failures)
        log.debug(
            "[RUNTIME_REPAIR] targeted_rerun.start | owner=%s | selector=%s",
            owner,
            targeted_selector,
        )
        targeted = self._run_tests(runner, 
            module,
            [targeted_selector],
            label=f"runtime-repair-{round_no}-{owner.split('(', 1)[0]}-targeted",
            timeout_sec=self.cfg.runtime_repair_timeout_seconds,
        )
        self._record_runtime_test_result(outcome, targeted, scope="targeted")
        self.audit.write_json(ctx.symbol.name, f"{audit_dir}/targeted-result.json", {
            "selected_test_names": sorted(selected_test_names),
            "tests_actually_executed": targeted.executed_test_names,
            "tests_run": targeted.signals.tests_run,
            "passed": max(0, targeted.signals.tests_run - targeted.signals.tests_failed - targeted.signals.tests_errors - targeted.signals.tests_skipped),
            "failures": targeted.signals.tests_failed,
            "errors": targeted.signals.tests_errors,
            "skipped": targeted.signals.tests_skipped,
            "source_hash": sha256_text(good),
        })
        console_stage(
            "RUNTIME_REPAIR",
            "targeted_tests=%d | passed=%d | failures=%d | errors=%d",
            targeted.signals.tests_run,
            max(0, targeted.signals.tests_run - targeted.signals.tests_failed - targeted.signals.tests_errors - targeted.signals.tests_skipped),
            targeted.signals.tests_failed,
            targeted.signals.tests_errors,
        )
        log.debug(
            "[RUNTIME_REPAIR] targeted_rerun.result | owner=%s | tests_run=%d | "
            "failures=%d | errors=%d | green=%s",
            owner,
            targeted.signals.tests_run,
            targeted.signals.tests_failed,
            targeted.signals.tests_errors,
            targeted.tests_green,
        )
        expected_targeted = len(selected_test_names)
        actual_targeted = targeted.signals.tests_run
        targeted_executed = set(targeted.executed_test_names)
        missing_targeted = sorted(selected_test_names - targeted_executed) if targeted_executed else []
        if actual_targeted != expected_targeted:
            rollback_state()
            outcome.notes.append(
                f"TARGETED_TEST_COUNT_MISMATCH [{owner}]: selected={sorted(selected_test_names)}; "
                f"expected={expected_targeted}; actual={actual_targeted}; missing={missing_targeted}"
            )
            log.debug(
                "[RUNTIME_REPAIR] rollback | owner=%s | reason=TARGETED_TEST_COUNT_MISMATCH | "
                "selected=%s | expected=%d | actual=%d | missing=%s",
                owner, sorted(selected_test_names), expected_targeted, actual_targeted, missing_targeted,
            )
            persist_registry_attempt(
                "TARGETED_TEST_COUNT_MISMATCH",
                result="ROLLBACK",
                after_rollback=True,
            )
            return False, None, "TARGETED_TEST_COUNT_MISMATCH"
        if targeted_executed and missing_targeted:
            rollback_state()
            outcome.notes.append(
                f"runtime repair rolled back [{owner}]: selected tests not executed; missing={missing_targeted}"
            )
            persist_registry_attempt(
                "SELECTED_TEST_NOT_EXECUTED_TARGETED",
                result="ROLLBACK",
                after_rollback=True,
            )
            return False, None, "SELECTED_TEST_NOT_EXECUTED_TARGETED"
        if not targeted.maven_execution_success or not targeted.signals.tests_executed:
            rollback_state()
            persist_registry_attempt(
                "TARGETED_EXECUTION_FAILED",
                result="ROLLBACK",
                after_rollback=True,
            )
            return False, None, "TARGETED_EXECUTION_FAILED"

        log.debug("[RUNTIME_REPAIR] full_rerun.start | owner=%s | selector=%s", owner, test_fqcn)
        full = self._run_tests(runner, 
            module,
            [test_fqcn],
            label=f"runtime-repair-{round_no}-{owner.split('(', 1)[0]}-full",
            timeout_sec=self.cfg.runtime_repair_timeout_seconds,
        )
        self._record_runtime_test_result(outcome, full, scope="full")
        self.audit.write_json(ctx.symbol.name, f"{audit_dir}/full-result.json", {
            "tests_run": full.signals.tests_run,
            "passed": max(0, full.signals.tests_run - full.signals.tests_failed - full.signals.tests_errors - full.signals.tests_skipped),
            "failures": full.signals.tests_failed,
            "errors": full.signals.tests_errors,
            "skipped": full.signals.tests_skipped,
            "executed_test_names": full.executed_test_names,
            "source_hash": sha256_text(test_path.read_text(encoding="utf-8")),
        })
        log.debug(
            "[RUNTIME_REPAIR] full_rerun.result | owner=%s | tests_run=%d | failures=%d | "
            "errors=%d | green=%s",
            owner,
            full.signals.tests_run,
            full.signals.tests_failed,
            full.signals.tests_errors,
            full.tests_green,
        )
        after_source = test_path.read_text(encoding="utf-8")
        accepted, acceptance_reason, identity_details = validate_runtime_candidate_identity(
            before_source=current,
            after_source=after_source,
            owner=owner,
            selected_test_names=selected_test_names,
            before_run=before_run,
            targeted_run=targeted,
            full_run=full,
            owner_failures_before=owner_failures,
            require_full_green=is_serviceimpl_context(ctx),
        )
        before_total = before_run.signals.tests_failed + before_run.signals.tests_errors
        after_total = full.signals.tests_failed + full.signals.tests_errors
        grouped_after, _ = _group_runtime_failures(after_source, full.failures, outcome)
        owner_after = len(grouped_after.get(owner, ()))
        resolved = _failure_signatures(owner_failures) - _failure_signatures(full.failures)
        introduced = _failure_signatures(full.failures) - _failure_signatures(before_run.failures)
        log.debug(
            "[RUNTIME_REPAIR] progress | owner=%s | before_failures=%d | before_errors=%d | "
            "after_failures=%d | after_errors=%d | owner_before=%d | owner_after=%d | "
            "resolved=%d | introduced=%d | acceptance_reason=%s | details=%s | accepted=%s",
            owner,
            before_run.signals.tests_failed,
            before_run.signals.tests_errors,
            full.signals.tests_failed,
            full.signals.tests_errors,
            len(owner_failures),
            owner_after,
            len(resolved),
            len(introduced),
            acceptance_reason,
            identity_details,
            accepted,
        )
        if not accepted:
            if acceptance_reason in {
                "TEST_IDENTITY_CHANGED",
                "OWNER_TEST_IDENTITY_CHANGED",
                "SELECTED_TEST_DISAPPEARED",
                "FULL_TEST_IDENTITY_MISMATCH",
            }:
                outcome.tests_lost_during_runtime_repair += len(identity_details)
            rollback_state()
            persist_registry_attempt(
                acceptance_reason,
                result="ROLLBACK",
                after_rollback=True,
                diagnostics=list(identity_details),
            )
            outcome.notes.append(
                f"runtime repair rolled back [{owner}]: {acceptance_reason}; details={list(identity_details)}"
            )
            record_decision(
                accepted=False,
                reason=acceptance_reason,
                rollback=True,
                selected_tests=sorted(selected_test_names),
                returned_test_names=sorted(selected_test_names),
                test_identity_preserved=acceptance_reason not in {"TEST_IDENTITY_CHANGED", "OWNER_TEST_IDENTITY_CHANGED", "SELECTED_TEST_DISAPPEARED", "FULL_TEST_IDENTITY_MISMATCH"},
                passed_test_hashes_unchanged=acceptance_reason != "PASSED_TEST_SOURCE_CHANGED",
                targeted_result={"tests_run": targeted.signals.tests_run, "failures": targeted.signals.tests_failed, "errors": targeted.signals.tests_errors},
                full_result={"tests_run": full.signals.tests_run, "failures": full.signals.tests_failed, "errors": full.signals.tests_errors},
            )
            console_stage("RUNTIME_REPAIR", "method=%s | rejected | reason=%s", owner, acceptance_reason, level="warning")
            console_stage("RUNTIME_REPAIR", "rollback | restored=last_runtime_green_source", level="warning")
            log.debug(
                "[RUNTIME_REPAIR] rollback | owner=%s | reason=%s | details=%s",
                owner, acceptance_reason, identity_details,
            )
            compatibility_reason = (
                "full_suite_no_progress"
                if acceptance_reason in {
                    "NEW_FAILING_TEST_INTRODUCED",
                    "OWNER_FAILURE_SEVERITY_NOT_IMPROVED",
                    "FULL_SUITE_SEVERITY_WORSENED",
                }
                else acceptance_reason
            )
            return False, None, compatibility_reason

        outcome.notes.append(
            f"runtime repair accepted [{owner}]: {before_total} -> {after_total} failures/errors"
        )
        outcome.runtime_repair_history.append(
            f"round={round_no};owner={owner};before={before_run.signals.tests_failed}F/"
            f"{before_run.signals.tests_errors}E;after={full.signals.tests_failed}F/"
            f"{full.signals.tests_errors}E;owner_before={len(owner_failures)};"
            f"owner_after={owner_after};accepted=true"
        )
        accepted_source = test_path.read_text(encoding="utf-8")
        for test_name in selected_test_names:
            record = test_record_by_name(outcome, test_name)
            if record is not None and record.candidate_source:
                commit_candidate_source(outcome, test_name, compile_state="REPAIRED_AND_PASSED")
                record.runtime_state = "PASSED"
                record.runtime_repair_history.append({
                    "stage": "runtime_repair",
                    "round": round_no,
                    "attempt": attempt_no,
                    "owner": owner,
                    "result": "accepted",
                })
        sync_test_registry_sources(outcome, accepted_source, compile_state="PASSED", accepted=False)
        write_registry = getattr(self, "_write_registry_audit", None)
        if callable(write_registry):
            write_registry(ctx, outcome)
        record_decision(
            accepted=True,
            reason="targeted and authoritative full-class executions passed",
            rollback=False,
            selected_tests=sorted(selected_test_names),
            excluded_passed_test_count=max(0, len(original_owner_names) - len(selected_test_names)),
            returned_test_names=sorted(selected_test_names),
            test_identity_preserved=True,
            passed_test_hashes_unchanged=True,
            targeted_result={"tests_run": targeted.signals.tests_run, "failures": targeted.signals.tests_failed, "errors": targeted.signals.tests_errors},
            full_result={"tests_run": full.signals.tests_run, "failures": full.signals.tests_failed, "errors": full.signals.tests_errors},
        )
        console_stage(
            "RUNTIME_REPAIR",
            "full_suite | tests=%d | failures=%d | errors=%d | accepted",
            full.signals.tests_run,
            full.signals.tests_failed,
            full.signals.tests_errors,
        )
        return True, full, "accepted"
