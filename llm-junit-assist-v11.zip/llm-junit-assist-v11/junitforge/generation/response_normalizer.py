"""Normalize focused Java LLM responses without hiding truncation.

A complete single outer Markdown fence is harmless formatting and can be
removed deterministically.  An unmatched fence, prose outside the fence,
multiple fences, or unbalanced Java is a protocol/truncation failure.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import hashlib
import re


class ResponseState(str, Enum):
    RAW_JAVA_ACCEPTED = "RAW_JAVA_ACCEPTED"
    MARKDOWN_WRAPPER_STRIPPED = "MARKDOWN_WRAPPER_STRIPPED"
    MARKDOWN_RESPONSE_INVALID = "MARKDOWN_RESPONSE_INVALID"
    MULTIPLE_MARKDOWN_FENCES = "MULTIPLE_MARKDOWN_FENCES"
    TRUNCATED_RESPONSE = "TRUNCATED_RESPONSE"
    OUTPUT_LIMIT_REACHED = "OUTPUT_LIMIT_REACHED"
    UNBALANCED_JAVA_STRUCTURE = "UNBALANCED_JAVA_STRUCTURE"
    TEST_IDENTITY_MISMATCH = "TEST_IDENTITY_MISMATCH"


@dataclass(frozen=True, slots=True)
class NormalizedJavaResponse:
    source: str | None
    state: ResponseState
    reason: str | None
    raw_hash: str
    normalized_hash: str | None
    character_count: int
    finish_reason: str | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None


def _hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _balanced_java(source: str) -> bool:
    """Lexically balance braces while ignoring comments and literals."""
    depth = 0
    i = 0
    quote: str | None = None
    line_comment = False
    block_comment = False
    escaped = False
    while i < len(source):
        ch = source[i]
        nxt = source[i + 1] if i + 1 < len(source) else ""
        if line_comment:
            if ch == "\n":
                line_comment = False
            i += 1
            continue
        if block_comment:
            if ch == "*" and nxt == "/":
                block_comment = False
                i += 2
            else:
                i += 1
            continue
        if quote:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                quote = None
            i += 1
            continue
        if ch == "/" and nxt == "/":
            line_comment = True
            i += 2
            continue
        if ch == "/" and nxt == "*":
            block_comment = True
            i += 2
            continue
        if ch in {'"', "'"}:
            quote = ch
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth < 0:
                return False
        i += 1
    return depth == 0 and quote is None and not block_comment


def normalize_focused_java_response(
    raw: str,
    *,
    finish_reason: str | None = None,
    input_tokens: int | None = None,
    output_tokens: int | None = None,
) -> NormalizedJavaResponse:
    text = (raw or "").strip()
    raw_hash = _hash(raw or "")
    output_limited = (finish_reason or "").lower() in {
        "length", "max_tokens", "token_limit", "max_output_tokens"
    }
    if output_limited:
        return NormalizedJavaResponse(
            None,
            ResponseState.OUTPUT_LIMIT_REACHED,
            "model stopped at the configured output-token limit",
            raw_hash,
            None,
            len(raw or ""),
            finish_reason,
            input_tokens,
            output_tokens,
        )
    if not text:
        return NormalizedJavaResponse(
            None, ResponseState.TRUNCATED_RESPONSE, "empty Java response",
            raw_hash, None, len(raw or ""), finish_reason, input_tokens, output_tokens,
        )

    fence_count = text.count("```")
    state = ResponseState.RAW_JAVA_ACCEPTED
    source = text
    if fence_count:
        lines = text.splitlines()
        if fence_count > 2:
            return NormalizedJavaResponse(
                None, ResponseState.MULTIPLE_MARKDOWN_FENCES,
                "response contains more than one outer Markdown block",
                raw_hash, None, len(raw or ""), finish_reason, input_tokens, output_tokens,
            )
        if fence_count != 2 or not lines or lines[0].strip() not in {"```", "```java"}:
            return NormalizedJavaResponse(
                None, ResponseState.TRUNCATED_RESPONSE,
                "Markdown opening fence is unmatched or not outermost",
                raw_hash, None, len(raw or ""), finish_reason, input_tokens, output_tokens,
            )
        if lines[-1].strip() != "```":
            return NormalizedJavaResponse(
                None, ResponseState.TRUNCATED_RESPONSE,
                "Markdown closing fence is missing",
                raw_hash, None, len(raw or ""), finish_reason, input_tokens, output_tokens,
            )
        source = "\n".join(lines[1:-1]).strip()
        if "```" in source:
            return NormalizedJavaResponse(
                None, ResponseState.MULTIPLE_MARKDOWN_FENCES,
                "response contains nested Markdown fences",
                raw_hash, None, len(raw or ""), finish_reason, input_tokens, output_tokens,
            )
        state = ResponseState.MARKDOWN_WRAPPER_STRIPPED

    if not _balanced_java(source):
        return NormalizedJavaResponse(
            None, ResponseState.UNBALANCED_JAVA_STRUCTURE,
            "Java braces, comments, or literals are not structurally complete",
            raw_hash, None, len(raw or ""), finish_reason, input_tokens, output_tokens,
        )
    if not re.search(r"(?m)^\s*@Test\b", source):
        return NormalizedJavaResponse(
            None, ResponseState.MARKDOWN_RESPONSE_INVALID if fence_count else ResponseState.TRUNCATED_RESPONSE,
            "focused repair response does not contain an @Test method",
            raw_hash, None, len(raw or ""), finish_reason, input_tokens, output_tokens,
        )
    return NormalizedJavaResponse(
        source,
        state,
        None,
        raw_hash,
        _hash(source),
        len(raw or ""),
        finish_reason,
        input_tokens,
        output_tokens,
    )


__all__ = [
    "NormalizedJavaResponse",
    "ResponseState",
    "normalize_focused_java_response",
]
