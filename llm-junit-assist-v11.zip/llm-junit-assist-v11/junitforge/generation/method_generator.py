"""Method-wise and class-wide test generation."""

from __future__ import annotations

from dataclasses import replace
import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.audit.console import stage as console_stage
from junitforge.audit.paths import safe_name
from junitforge.audit.recorder import sha256_text
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.execution.models import FixtureSpec
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get

log = get("junitforge.loop")


def _structured_repair_history(
    actions,
    *,
    phase: str,
    source_before: str = "",
    source_after: str = "",
    authoritative_contract: str = "schema/execution/fixture catalogue",
):
    return [
        {
            "sequence": index,
            "phase": phase,
            "diagnostic_category": str(action).split(":", 1)[0],
            "action": str(action),
            "source_before": source_before,
            "source_after": source_after,
            "authoritative_contract": authoritative_contract,
            "result": "APPLIED",
        }
        for index, action in enumerate(actions or (), start=1)
    ]


def _simple_fixture_type(rendered: str) -> str:
    text = (rendered or "").strip().replace("[]", "")
    if "<" in text:
        text = text.split("<", 1)[0]
    return text.rsplit(".", 1)[-1]


def _register_compiled_fixture_variants(ctx: GenerationContext, results) -> tuple[FixtureSpec, ...]:
    """Add compiled scenario variants to the authoritative fixture catalogue.

    Variant helpers are discovered after concurrent method generation.  They
    are deduplicated by normalized state signature and become available to
    focused validation/compile/runtime repair payloads in the same run.
    """
    execution = ctx.execution_context
    if execution is None:
        return ()
    existing = list(execution.fixtures)
    by_method = {fixture.method_name: fixture for fixture in existing}
    by_type = {
        _simple_fixture_type(fixture.return_type): fixture
        for fixture in existing
        if fixture.supported
    }
    added: list[FixtureSpec] = []
    seen = {
        (fixture.return_type, fixture.state_signature)
        for fixture in existing
        if fixture.fixture_variant
    }
    for result in results:
        record = result[6]
        for test in record.tests:
            helpers_by_name: dict[str, str] = {}
            for helper_source in test.fixture_variant_sources:
                match = re.search(
                    r"\b(?:private|protected|public)\s+([A-Za-z_$][\w$<>?,.\[\] ]*)\s+"
                    r"([A-Za-z_$][\w$]*)\s*\(",
                    helper_source,
                )
                if match:
                    helpers_by_name[match.group(2)] = helper_source
            for dependency in test.fixture_dependencies:
                if not dependency.get("fixture_variant") or dependency.get("compile_state") != "PASSED":
                    continue
                method_name = str(dependency.get("fixture_method") or "")
                helper_source = helpers_by_name.get(method_name)
                return_type = str(dependency.get("type") or "")
                state_signature = str(dependency.get("state_signature") or "")
                if not method_name or not helper_source or not return_type:
                    continue
                dedup_key = (return_type, state_signature)
                if dedup_key in seen:
                    continue
                base_method = str(dependency.get("base_fixture_method") or "")
                base_fixture = by_method.get(base_method) or by_type.get(
                    _simple_fixture_type(return_type)
                )
                dependent_ids: list[str] = []
                if base_fixture is not None:
                    dependent_ids.append(base_fixture.fixture_id)
                signature = re.search(r"\((?P<params>[^)]*)\)\s*\{", helper_source)
                if signature:
                    for parameter in signature.group("params").split(","):
                        parameter = parameter.strip()
                        if not parameter:
                            continue
                        rendered_type = parameter.rsplit(" ", 1)[0].strip()
                        referenced = by_type.get(_simple_fixture_type(rendered_type))
                        if referenced is not None and referenced.fixture_id not in dependent_ids:
                            dependent_ids.append(referenced.fixture_id)
                seed = f"{return_type}:{state_signature}"
                fixture_id = f"variant:{_simple_fixture_type(return_type)}:{sha256_text(seed)[:12]}"
                added.append(
                    FixtureSpec(
                        fixture_id=fixture_id,
                        method_name=method_name,
                        return_type=return_type,
                        schema_id=(base_fixture.schema_id if base_fixture else return_type),
                        dependent_fixture_ids=tuple(dependent_ids),
                        imports=(base_fixture.imports if base_fixture else ()),
                        method_source=helper_source,
                        supported=True,
                        diagnostics=("compiled scenario fixture variant",),
                        fixture_variant=True,
                        state_signature=state_signature,
                        base_fixture_id=(base_fixture.fixture_id if base_fixture else None),
                        compile_state="PASSED",
                    )
                )
                seen.add(dedup_key)
    if added:
        ctx.execution_context = replace(
            execution,
            fixtures=tuple((*existing, *added)),
        )
    return tuple(added)
from junitforge.generation.response_extractor import extract_generated_tests
from junitforge.generation.response_normalizer import normalize_focused_java_response
from junitforge.generation.fixture_variants import inject_fixture_variant_helpers

from junitforge.generation.payloads import payload_builder_for_context
from junitforge.generation.skeleton_generator import generate_and_validate_skeleton
from junitforge.generation.validation import (
    is_serviceimpl_context,
    repair_validation_failure_deterministically,
    validate_generated_test,
)
from junitforge.pipeline.result import (
    initialize_latest_accepted_sources,
    refresh_test_registry_ranges,
    sync_test_registry_sources,
)
from junitforge.publication.summary import _refresh_generation_counters


class GenerationMixin:
    def _generate_methodwise(
        self,
        ctx: GenerationContext,
        outcome: TargetOutcome,
        *,
        module: ModuleInfo | None = None,
        test_path: Path | None = None,
    ) -> str | None:
        """Generate method blocks concurrently, assemble deterministically, finalize once."""
        execution = ctx.execution_context
        if execution is None:
            return None
        _t = perf_counter()
        try:
            skeleton_result = generate_and_validate_skeleton(
                ctx,
                compile_gate=self.compile_gate,
                module=module,
                test_path=test_path,
                outcome=outcome,
            )
        except Exception as exc:  # noqa: BLE001
            outcome.notes.append(f"method-wise skeleton failed: {type(exc).__name__}: {exc}")
            return None
        skeleton = skeleton_result.source
        skeleton_elapsed = perf_counter() - _t
        self.audit.write_text(ctx.symbol.name, "05-skeleton/generated.java", skeleton)
        compile_result = getattr(skeleton_result, "compile_result", None)
        self.audit.write_json(ctx.symbol.name, "05-skeleton/compile-command.json", {
            "command": getattr(compile_result, "cmd", []),
            "working_directory": str(getattr(module, "root", self.repo_root)) if module is not None else str(self.repo_root),
            "elapsed_seconds": skeleton_elapsed,
        })
        self.audit.write_json(ctx.symbol.name, "05-skeleton/compile-result.json", {
            "exit_code": getattr(compile_result, "return_code", None),
            "success": skeleton_result.compiled,
            "compiler_error_count": len(skeleton_result.diagnostics),
            "diagnostic_summary": list(skeleton_result.diagnostics),
        })
        if skeleton_result.compiled:
            self.audit.write_text(ctx.symbol.name, "05-skeleton/compiled.java", skeleton)
        if skeleton_result.compiled is False:
            return None

        method_by_id = {
            f"{method.name}({','.join(type_name for type_name, _ in method.params)})": method
            for method in (ctx.symbol.methods or [])
        }
        jobs = []
        skipped_records: list[MethodGenerationRecord] = []
        for order, method_context in enumerate(execution.methods):
            production_method = method_by_id.get(method_context.method_id)
            if production_method is None:
                outcome.notes.append(f"method context skipped; signature not found: {method_context.method_id}")
                skipped_records.append(
                    MethodGenerationRecord(
                        method_id=method_context.method_id,
                        scenarios_planned=max(1, len(method_context.branches) + 1),
                        final_status=MethodDisposition.SKIPPED.value,
                    )
                )
                continue
            jobs.append((order, production_method, method_context))

        workers = max(1, min(int(os.getenv("JUNITFORGE_METHOD_WORKERS", "3")), len(jobs) or 1))
        batch_started = perf_counter()
        results = []
        with heartbeat(
            "llm.batch",
            interval_seconds=90.0,
            target=ctx.symbol.name,
            methods=len(jobs),
            workers=workers,
        ):
            with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="junitforge-method") as pool:
                futures = [pool.submit(self.generate_one, job, ctx, len(jobs)) for job in jobs]
                for future in as_completed(futures):
                    results.append(future.result())
        _elapsed = perf_counter() - batch_started

        variant_helpers = tuple(
            helper
            for result in results
            for test in result[6].tests
            for helper in test.fixture_variant_sources
        )
        if variant_helpers:
            augmented_skeleton = inject_fixture_variant_helpers(skeleton, variant_helpers)
            variant_skeleton_ok = True
            variant_errors = []
            if module is not None and test_path is not None:
                test_path.write_text(augmented_skeleton, encoding="utf-8")
                variant_compile, variant_errors = self.compile_gate.check(test_path, module)
                variant_skeleton_ok = bool(variant_compile.ok)
            self.audit.write_json(ctx.symbol.name, "05-skeleton/fixture-variant-compile-result.json", {
                "success": variant_skeleton_ok,
                "compiler_error_count": len(variant_errors),
                "diagnostics": [error.render() for error in variant_errors],
                "variant_helper_count": len(variant_helpers),
            })
            if variant_skeleton_ok:
                skeleton = augmented_skeleton
                self.audit.write_text(ctx.symbol.name, "05-skeleton/compiled-with-fixture-variants.java", skeleton)
                for result in results:
                    for test in result[6].tests:
                        for dependency in test.fixture_dependencies:
                            dependency["compile_state"] = "PASSED"
                registered_variants = _register_compiled_fixture_variants(ctx, results)
                self.audit.write_json(ctx.symbol.name, "05-skeleton/fixture-variants.json", {
                    "fixtures": registered_variants,
                    "count": len(registered_variants),
                })
                if registered_variants and ctx.execution_context is not None:
                    diagnostic_name = ctx.symbol.fqcn.replace(".", "_") + ".json"
                    fixture_path = (
                        self.repo_root / "reports" / "fixture-catalog" / diagnostic_name
                    )
                    write_fixture_catalog_json(ctx.execution_context, fixture_path)
            else:
                for result in results:
                    record = result[6]
                    for test in record.tests:
                        if not test.fixture_variant_sources:
                            continue
                        test.validation_state = "REJECTED"
                        test.final_disposition = TestDisposition.REJECTED.value
                        test.final_rejection_reason = "fixture variant skeleton compilation failed"
                        for dependency in test.fixture_dependencies:
                            dependency["compile_state"] = "FAILED"
                    record.tests_retained = sum(
                        1 for test in record.tests
                        if test.final_disposition == TestDisposition.RETAINED.value
                    )
                    record.tests_rejected = len(record.tests) - record.tests_retained

        current = skeleton
        accepted = 0
        existing_names: set[str] = set()
        outcome.selected_production_methods = len(execution.methods)
        outcome.method_results = list(skipped_records)
        for order, method_context, block, names, tokens, reason, record in sorted(
            results, key=lambda item: item[0]
        ):
            outcome.tokens_used += tokens
            outcome.method_results.append(record)
            if block is None:
                console_stage(
                    "METHOD_GENERATION",
                    "%s failed | reason=%s",
                    method_context.method_id,
                    reason or "no extractable @Test method",
                    level="warning",
                )
                outcome.notes.append(
                    f"method generation rejected [{method_context.method_id}]: {reason}"
                )
                continue

            surviving_sources: list[str] = []
            surviving_names: list[str] = []
            for extracted in extract_generated_tests(block):
                registry_match = next(
                    (test for test in record.tests if test.test_name == extracted.name),
                    None,
                )
                if registry_match is not None and registry_match.final_disposition != TestDisposition.RETAINED.value:
                    continue
                if extracted.name in existing_names:
                    matching = next(
                        (
                            test
                            for test in record.tests
                            if test.test_name == extracted.name
                            and test.final_disposition == TestDisposition.RETAINED.value
                        ),
                        None,
                    )
                    if matching is not None:
                        matching.final_disposition = TestDisposition.REJECTED.value
                        matching.validation_state = "REJECTED"
                        matching.final_rejection_reason = "duplicate test name across production-method owners"
                        record.tests_retained -= 1
                        record.tests_rejected += 1
                    continue
                surviving_sources.append(extracted.source)
                surviving_names.append(extracted.name)

            if not surviving_sources:
                record.final_status = MethodDisposition.REJECTED.value
                outcome.notes.append(
                    f"method generation rejected [{method_context.method_id}]: no unique valid tests remain"
                )
                continue

            if record.tests_rejected:
                record.final_status = MethodDisposition.PARTIALLY_GENERATED.value
            else:
                record.final_status = MethodDisposition.GENERATED.value
            current = insert_method_block(
                current,
                method_context.method_id,
                "\n\n".join(surviving_sources),
            )
            existing_names.update(surviving_names)
            accepted += 1
            status_label = (
                "partially generated"
                if record.final_status == MethodDisposition.PARTIALLY_GENERATED.value
                else "generated"
            )
            outcome.notes.append(
                f"method {status_label} [{method_context.method_id}]: "
                f"{len(surviving_names)} retained, {record.tests_rejected} rejected"
            )
            console_stage(
                "METHOD_GENERATION",
                "%s | generated=%d | retained=%d | rejected=%d",
                method_context.method_id,
                record.tests_extracted,
                len(surviving_names),
                record.tests_rejected,
            )

        _refresh_generation_counters(outcome)

        if accepted == 0 or not test_method_names(current):
            outcome.notes.append("method-wise generation produced no accepted test methods")
            return None

        _t = perf_counter()
        final = finalize_java(
            current,
            test_package=ctx.test_package,
            test_class_name=ctx.test_class_name,
            template=ctx.template,
            cut_symbol=ctx.symbol,
            collaborators=ctx.collaborators,
            source_imports=ctx.source_imports,
        )
        _elapsed = perf_counter() - _t
        if not final.ok or not final.code:
            outcome.notes.append(f"assembled method-wise test rejected: {final.reason}")
            return None
        outcome.notes.extend(final.issues)
        initialize_latest_accepted_sources(outcome, final.code)
        refresh_test_registry_ranges(outcome, final.code)
        outcome.notes.append(f"method-wise generation complete: {accepted}/{len(execution.methods)} production methods")
        return final.code


    def generate_one(self, job, ctx, total_jobs):
        order, production_method, method_context = job
        started = perf_counter()
        console_stage("METHOD_GENERATION", "%s started", method_context.method_id)
        builder = payload_builder_for_context(ctx)
        try:
            messages = builder.build_generation_payload(ctx, production_method, "", mode="method")
        except Exception as exc:  # noqa: BLE001
            record = MethodGenerationRecord(
                method_id=method_context.method_id,
                scenarios_planned=max(1, len(method_context.branches) + 1),
                final_status=MethodDisposition.REJECTED.value,
            )
            return (
                order,
                method_context,
                None,
                (),
                0,
                f"generation payload rejected: {type(exc).__name__}: {str(exc)[:180]}",
                record,
            )
        method_dir = f"06-method-generation/{safe_name(method_context.method_id)}"
        self.audit.write_json(ctx.symbol.name, f"{method_dir}/request.json", {
            "request_type": "method_test_generation",
            "target_class": ctx.symbol.fqcn,
            "method_id": method_context.method_id,
            "model_id": self.cfg.model_id,
            "temperature": self.cfg.temperature_gen,
            "max_tokens": self.cfg.max_tokens_gen,
            "messages": messages,
        })
        try:
            with heartbeat(
                "llm.method",
                interval_seconds=90.0,
                target=ctx.symbol.name,
                method=method_context.method_id,
                worker_index=order + 1,
            ):
                resp = self.llm.chat(
                    messages,
                    temperature=self.cfg.temperature_gen,
                    max_tokens=self.cfg.max_tokens_gen,
                )
            raw = resp.message
            tokens = resp.usage.total_tokens if getattr(resp, "usage", None) else 0
            self.audit.record_llm_usage(getattr(resp, "usage", None))
            self.audit.write_text(ctx.symbol.name, f"{method_dir}/response.txt", raw or "")
        except Exception as exc:  # noqa: BLE001
            record = MethodGenerationRecord(
                method_id=method_context.method_id,
                scenarios_planned=max(1, len(method_context.branches) + 1),
                final_status=MethodDisposition.REJECTED.value,
            )
            return order, method_context, None, (), 0, f"llm error: {str(exc)[:180]}", record

        extracted = extract_generated_tests(raw or "")
        self.audit.write_text(
            ctx.symbol.name,
            f"{method_dir}/extracted-tests.java",
            "\n\n".join(item.source for item in extracted),
        )
        record = MethodGenerationRecord(
            method_id=method_context.method_id,
            scenarios_planned=max(1, len(method_context.branches) + 1),
            tests_returned_by_llm=(raw or "").count("@Test"),
            tests_extracted=len(extracted),
        )
        retained_sources: list[str] = []
        retained_names: list[str] = []

        for extracted_test in extracted:
            test_record = TestCaseRecord(
                owner_method_id=method_context.method_id,
                test_name=extracted_test.name,
                scenario_id=extracted_test.scenario_id,
                generated_source=extracted_test.source,
                source_start_line=extracted_test.start_line,
                source_end_line=extracted_test.end_line,
            )
            initial_validation = validate_generated_test(
                ctx, production_method, method_context, extracted_test.source, set()
            )
            if initial_validation.ok:
                record.tests_valid_before_repair += 1
                test_record.validation_state = "VALID"
                test_record.final_disposition = TestDisposition.RETAINED.value
                test_record.latest_accepted_source = extracted_test.source
                retained_sources.append(extracted_test.source)
                retained_names.append(extracted_test.name)
                record.tests.append(test_record)
                continue

            test_record.validation_diagnostics.append(initial_validation.reason)
            deterministic = repair_validation_failure_deterministically(
                ctx, production_method, method_context, extracted_test.source
            )
            candidate = deterministic.source
            test_record.deterministic_repair_history.extend(
                _structured_repair_history(
                    deterministic.actions,
                    phase="generation_validation",
                    source_before=extracted_test.source,
                    source_after=candidate,
                )
            )
            test_record.fixture_variant_sources.extend(deterministic.fixture_variant_sources)
            test_record.fixture_dependencies.extend(deterministic.fixture_dependencies)
            deterministic_validation = validate_generated_test(
                ctx, production_method, method_context, candidate, set()
            )
            if deterministic_validation.ok:
                record.tests_deterministically_repaired += 1
                test_record.validation_state = "VALID_AFTER_DETERMINISTIC_REPAIR"
                test_record.latest_accepted_source = candidate
                test_record.final_disposition = TestDisposition.RETAINED.value
                retained_sources.append(candidate)
                retained_names.append(extracted_test.name)
                record.tests.append(test_record)
                continue

            test_record.validation_diagnostics.append(deterministic_validation.reason)
            record.tests_sent_to_llm_repair += 1
            repair_messages = builder.build_validation_repair_payload(
                ctx,
                production_method,
                candidate,
                extracted_test.name,
                deterministic_validation.reason,
            )
            try:
                with heartbeat(
                    "llm.test.validation_repair",
                    interval_seconds=90.0,
                    target=ctx.symbol.name,
                    method=method_context.method_id,
                    test=extracted_test.name,
                    worker_index=order + 1,
                ):
                    repaired = self.llm.chat(
                        repair_messages,
                        temperature=self.cfg.temperature_repair,
                        max_tokens=self.cfg.max_tokens_repair,
                    )
                if getattr(repaired, "usage", None):
                    tokens += repaired.usage.total_tokens
                self.audit.record_llm_usage(getattr(repaired, "usage", None))
                normalized_repair = normalize_focused_java_response(
                    repaired.message or "",
                    finish_reason=getattr(repaired, "finish_reason", None),
                    input_tokens=getattr(getattr(repaired, "usage", None), "prompt_tokens", None),
                    output_tokens=getattr(getattr(repaired, "usage", None), "completion_tokens", None),
                )
                self.audit.write_json(ctx.symbol.name, f"{method_dir}/validation-repair-{extracted_test.name}-response.json", {
                    "state": normalized_repair.state.value,
                    "reason": normalized_repair.reason,
                    "raw_hash": normalized_repair.raw_hash,
                    "normalized_hash": normalized_repair.normalized_hash,
                    "character_count": normalized_repair.character_count,
                    "finish_reason": normalized_repair.finish_reason,
                    "input_tokens": normalized_repair.input_tokens,
                    "output_tokens": normalized_repair.output_tokens,
                })
                if normalized_repair.source is None:
                    raise ValueError(normalized_repair.state.value)
                repaired_tests = extract_generated_tests(normalized_repair.source)
                if len(repaired_tests) != 1:
                    raise ValueError("repair must return exactly one @Test method")
                repaired_test = repaired_tests[0]
                if repaired_test.name != extracted_test.name:
                    raise ValueError(
                        f"repair changed test name from {extracted_test.name} to {repaired_test.name}"
                    )
                post_deterministic = repair_validation_failure_deterministically(
                    ctx, production_method, method_context, repaired_test.source
                )
                repaired_candidate = post_deterministic.source
                test_record.deterministic_repair_history.extend(
                    _structured_repair_history(
                        post_deterministic.actions,
                        phase="generation_llm_validation_repair",
                        source_before=repaired_test.source,
                        source_after=repaired_candidate,
                    )
                )
                test_record.fixture_variant_sources.extend(
                    post_deterministic.fixture_variant_sources
                )
                test_record.fixture_dependencies.extend(
                    post_deterministic.fixture_dependencies
                )
                repaired_validation = validate_generated_test(
                    ctx, production_method, method_context, repaired_candidate, set()
                )
                test_record.llm_repair_history.append({
                    "phase": "generation_validation_repair",
                    "result": "ACCEPTED" if repaired_validation.ok else "REJECTED",
                    "reason": None if repaired_validation.ok else repaired_validation.reason,
                })
                if repaired_validation.ok:
                    test_record.validation_state = "VALID_AFTER_LLM_REPAIR"
                    test_record.latest_accepted_source = repaired_candidate
                    test_record.final_disposition = TestDisposition.RETAINED.value
                    retained_sources.append(repaired_candidate)
                    retained_names.append(extracted_test.name)
                    record.tests.append(test_record)
                    continue
                test_record.validation_diagnostics.append(repaired_validation.reason)
            except Exception as exc:  # noqa: BLE001
                test_record.llm_repair_history.append({
                    "phase": "generation_validation_repair",
                    "result": "ERROR",
                    "reason": f"{type(exc).__name__}:{str(exc)[:160]}",
                })

            test_record.validation_state = "REJECTED"
            test_record.final_disposition = TestDisposition.REJECTED.value
            test_record.final_rejection_reason = (
                test_record.validation_diagnostics[-1]
                if test_record.validation_diagnostics
                else "validation repair failed"
            )
            record.tests.append(test_record)

        record.tests_retained = len(retained_sources)
        record.tests_rejected = len(record.tests) - record.tests_retained
        if record.tests_retained == 0:
            record.final_status = MethodDisposition.REJECTED.value
            reason = (
                "; ".join(
                    f"{test.test_name}: {test.final_rejection_reason or 'rejected'}"
                    for test in record.tests
                )
                or "no @Test methods returned"
            )
            self.audit.write_json(ctx.symbol.name, f"{method_dir}/structural-validation.json", {
                "tests": record.tests,
                "accepted": 0,
                "rejected": record.tests_rejected,
                "reason": reason,
            })
            self.audit.write_json(ctx.symbol.name, f"{method_dir}/registry-after.json", record)
            console_stage(
                "METHOD_GENERATION",
                "%s completed | elapsed=%.2fs",
                method_context.method_id,
                perf_counter() - started,
            )
            return order, method_context, None, (), tokens, reason, record
        record.final_status = (
            MethodDisposition.PARTIALLY_GENERATED.value
            if record.tests_rejected
            else MethodDisposition.GENERATED.value
        )
        block = "\n\n".join(retained_sources).strip()
        elapsed = perf_counter() - started
        self.audit.write_json(ctx.symbol.name, f"{method_dir}/structural-validation.json", {
            "tests": record.tests,
            "accepted": record.tests_retained,
            "rejected": record.tests_rejected,
        })
        self.audit.write_json(ctx.symbol.name, f"{method_dir}/registry-after.json", record)
        console_stage("METHOD_GENERATION", "%s completed | elapsed=%.2fs", method_context.method_id, elapsed)
        return (
            order,
            method_context,
            block,
            tuple(retained_names),
            tokens,
            None,
            record,
        )


    def _generate_classwide(self, ctx: GenerationContext, outcome: TargetOutcome) -> str | None:
        """Existing whole-class path retained for DTO/entity and other stable types."""
        builder = payload_builder_for_context(ctx)
        messages = builder.build_generation_payload(ctx, mode="classwide")
        for attempt in range(self.cfg.max_gen_reasks + 1):
            raw = self._chat(messages, self.cfg.temperature_gen, self.cfg.max_tokens_gen, outcome)
            candidate = inject_reusable_fixtures(raw or "", ctx)
            res = finalize_java(
                candidate, test_package=ctx.test_package, test_class_name=ctx.test_class_name,
                template=ctx.template, cut_symbol=ctx.symbol, collaborators=ctx.collaborators,
                source_imports=ctx.source_imports)
            if res.ok and res.code:
                outcome.notes.extend(res.issues)
                return res.code
            if attempt < self.cfg.max_gen_reasks:
                correction = (
                    f"Your previous output was rejected: {res.reason}. "
                    "Return one valid Java test file per the output contract."
                )
                messages = messages + [{"role": "user", "content": correction}]
        outcome.notes.append(f"generation rejected: {res.reason}")
        return None
