"""Structured ServiceImpl LLM request payloads for v11.

ServiceImpl remains isolated from other target types.  v11 adds complete helper
source closure, exact collaborator consumption contracts, fixture-only setup,
and focused single-test validation/compile/runtime repair payloads.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import json
import re
from typing import Any

from junitforge.execution.assembly import cut_variable_name
from junitforge.generation.source_closure import build_source_closure


_SYSTEM_MESSAGE = (
    "You are a deterministic Java JUnit 5 test-generation engine. "
    "Follow the structured user payload as authoritative for allowed symbols, "
    "generation or repair scope, Mockito, assertions, and output. "
    "Do not invent unsupported APIs or behavior. Return only the requested output."
)

_GENERATION_INSTRUCTION = {'objective': {'tests_to_generate': 1,
               'requested_test_kind': 'normal_success',
               'coverage_scope': 'The authorized target method and all same-class helpers reached by the selected '
                                 'execution path.',
               'authorized_cut_invocation': 'Invoke only the authorized public target method on the supplied '
                                            'class-under-test instance.',
               'output_format': 'One raw Java JUnit 5 @Test method only.'},
 'path_selection': {'instruction': 'Analyze the target method and all reachable supplied same-class helper method '
                                   'bodies as one interprocedural execution unit. Derive feasible execution paths and '
                                   'select one complete path satisfying the requested test kind.',
                    'requirements': ['Derive paths only from control-flow constructs present in the supplied source.',
                                     'Trace if/else branches, ternary expressions, switch cases, loops, null guards, '
                                     'short-circuit expressions, Optional operations, stream operations, returns, '
                                     'throws, catches, and helper calls.',
                                     'Carry values, branch decisions, collaborator returns, object mutations, returned '
                                     'values, and exceptions across same-class helper boundaries.',
                                     'Each candidate path must represent one internally consistent execution from '
                                     'entry of the authorized target method to a terminal outcome.',
                                     'Reject paths containing mutually incompatible conditions.',
                                     'Reject paths requiring one value to satisfy contradictory predicates.',
                                     'Reject paths depending on unresolved methods, constants, types, fields, '
                                     'constructors, enum values, or collaborator contracts.',
                                     'Do not combine branch conditions, collaborator calls, fixture states, or '
                                     'expected outcomes from different paths.',
                                     'After selecting the path, identify only the collaborator calls and same-class '
                                     'helpers reached by that path.',
                                     'Use the selected path to determine fixture state, object relationships, '
                                     'collection contents, collaborator behavior, and observable assertions.'],
                    'requested_test_kind_rules': {'normal_success': ['Select a path that completes normally without '
                                                                     'entering a source-proven failure or exception '
                                                                     'outcome.',
                                                                     'The path must execute meaningful production '
                                                                     'behavior rather than terminate immediately '
                                                                     'because of invalid input.',
                                                                     'For a void method, successful normal completion '
                                                                     'must be demonstrated through source-proven state '
                                                                     'changes or collaborator interactions.',
                                                                     'For a non-void method, derive the expected '
                                                                     'result from the selected return path and '
                                                                     'source-proven mutations.'],
                                                  'handled_failure': ['Select a path where production code handles an '
                                                                      'error and returns, records, or exposes a '
                                                                      'source-proven failure outcome.'],
                                                  'propagated_exception': ['Select a path where a source-proven '
                                                                           'exception leaves the authorized public '
                                                                           'method.'],
                                                  'alternate_branch': ['Select one feasible path exercising the '
                                                                       'requested branch outcome without combining it '
                                                                       'with another execution path.']}},
 'source_analysis': {'instructions': ['Treat the supplied target method and helper method sources as authoritative.',
                                      'Trace assignments, returns, dereferences, branches, loops, Optional flows, '
                                      'collection operations, collaborator calls, and exceptions across helper '
                                      'boundaries.',
                                      'A collaborator return is consumed when it is assigned and later read, '
                                      'dereferenced, branch-tested, used in another call, returned by a helper, or '
                                      'propagated to the target method.',
                                      'A return flow classified as unresolved or unknown must not be treated as '
                                      'ignored.',
                                      'If a required return flow cannot be resolved sufficiently to create a '
                                      'type-correct stub, do not select a path depending on that flow.',
                                      'Respect lazy and conditional execution, including Optional.orElseGet, '
                                      'short-circuit boolean expressions, ternary expressions, callbacks, streams, and '
                                      'loops.',
                                      'Ignore commented-out calls and unreachable source.',
                                      'Do not invent methods, fields, constants, types, constructors, enum values, '
                                      'collaborator behavior, or production outcomes.']},
 'same_class_helper_rule': {'instructions': ['Any same-class helper reached by the selected path must execute as a '
                                             'real method.',
                                             'Never stub, spy, verify, or directly invoke a same-class helper.',
                                             'Cover private, protected, package-visible, and public same-class helpers '
                                             'only through the authorized public target method.',
                                             'Analyze collaborator calls inside reached helpers exactly as '
                                             'collaborator calls inside the target method.',
                                             'Do not include setup for helpers that are not reached by the selected '
                                             'path.']},
 'fixture_rule': {'instructions': ['Use the supplied compiled fixture methods for every fixture-supported application '
                                   'DTO or entity.',
                                   'Assume each compiled fixture provides the normal populated baseline produced by '
                                   'the deterministic test skeleton.',
                                   'Do not construct or recreate fixture-supported application objects using new, '
                                   'builders, mocks, spies, or reflection.',
                                   'A non-fixture-supported type may be constructed only when its verified '
                                   'constructor, builder, factory, or other construction contract is supplied in the '
                                   'request.',
                                   'Inspect the target method and reached same-class helper sources to determine which '
                                   'fixture fields or relationships must be adjusted for the selected path.',
                                   'Apply only the smallest mutations required to satisfy selected-path conditions, '
                                   'dereferences, collaborator arguments, or expected behavior.',
                                   'Do not replace a populated nested object graph when a smaller field mutation is '
                                   'sufficient.',
                                   'Preserve object identity when the same logical object is attached to another '
                                   'object, returned by a collaborator, passed through helpers, persisted, or later '
                                   'dereferenced.',
                                   'Ensure every intermediate object dereferenced by the selected path is non-null and '
                                   'every collection read has sufficient contents.',
                                   'Do not reconstruct the complete project-specific object graph when the supplied '
                                   'fixture already provides a usable baseline.',
                                   'If a selected path requires a field or object relationship that cannot be '
                                   'established using the supplied fixtures and verified available members, do not '
                                   'select that path.',
                                   'Do not invent project-specific field values or object relationships that are not '
                                   'supported by the supplied source.']},
 'fixture_value_rule': {'instructions': ['Use exact resolved constants when source conditions compare against those '
                                         'constants.',
                                         'Use verified enum constants for enum-typed fields.',
                                         'Use deterministic type-correct values for unconstrained scalar fields.',
                                         'Choose values that satisfy the exact predicates of the selected path.',
                                         'When multiple values must compare equal, derive them from one deterministic '
                                         'source value.',
                                         'When values must compare differently, choose values whose difference remains '
                                         'unambiguous under the production comparison logic.',
                                         'Do not guess unresolved constant or enum values.',
                                         'Do not mutate fields unrelated to the selected path.']},
 'collaborator_rule': {'instructions': ['Derive Mockito behavior from the exact target and reached helper method '
                                        'bodies.',
                                        'Stub only collaborator calls reached by the selected path.',
                                        'Every reached non-void collaborator call whose return is consumed must '
                                        'receive a type-correct stub.',
                                        'Do not omit a required stub because the collaborator call occurs inside a '
                                        'same-class helper.',
                                        'Do not stub a collaborator call whose return is conclusively ignored unless '
                                        'the selected path requires a source-proven side effect to be simulated.',
                                        'Normal void collaborator calls require no stub.',
                                        'Use doThrow only when the selected path intentionally requires a collaborator '
                                        'exception.',
                                        'Use Mockito matchers for arguments created or transformed inside production '
                                        'code.',
                                        'Never reference production-local variables or helper parameters directly in '
                                        'the test.',
                                        'Use an exact test-visible expression only when the expression is available in '
                                        'test scope and is equivalent after all production transformations.',
                                        'When one argument uses a Mockito matcher, all arguments in that invocation '
                                        'must use Mockito matchers.']},
 'repository_rule': {'instructions': ['Treat repository methods according to return consumption and selected-path '
                                      'behavior, not merely because they are repository operations.',
                                      'A lookup return used by Optional logic, fallback selection, a branch, a '
                                      'dereference, another call, a helper return, or the target return requires a '
                                      'stub.',
                                      'For lazy fallback logic, stub only lookups executed by the selected path.',
                                      'A save or update result returned by a helper, assigned and later read, '
                                      'branch-tested, or dereferenced requires a stub.',
                                      'When a save method must return the same submitted entity, use '
                                      'thenAnswer(invocation -> invocation.getArgument(0)).',
                                      'When a save or update return is conclusively ignored and no '
                                      'persistence-generated mutation is later read, no normal return stub is '
                                      'required.',
                                      'When production later depends on persistence-generated state, simulate only the '
                                      'source-proven mutation required by the selected path.',
                                      'Normal void repository calls require no doNothing stub.']},
 'collection_rule': {'instructions': ['Use an empty collection only when the selected path permits or requires no '
                                      'existing elements.',
                                      'Populate the minimum number of elements required by the selected path.',
                                      'Provide at least one element when production executes get(0), '
                                      'iterator().next(), findFirst().get(), or equivalent.',
                                      'Use mutable collections only when test setup or production code mutates them.',
                                      'Do not use a null collection when the selected path streams, iterates, checks, '
                                      'indexes, or mutates it.',
                                      'Preserve element identity when an element selected from a collection is passed '
                                      'to later helpers or collaborator calls.']},
 'assertion_rule': {'instructions': ['Derive assertions only from observable behavior produced by the selected path.',
                                     'For a non-void method, assert the returned value according to its verified type '
                                     'and the selected return path.',
                                     'Do not require assertNotNull when the verified successful result may '
                                     'legitimately be null.',
                                     'For a void method, assert source-proven state changes or behaviorally important '
                                     'collaborator interactions.',
                                     'For returned objects, assert only fields assigned, mutated, or deterministically '
                                     'preserved on the selected path.',
                                     'For primitives, strings, enums, collections, arrays, Optional values, and '
                                     'entities, use type-appropriate JUnit assertions.',
                                     'Assert exact values only when they are deterministically derived from fixtures, '
                                     'constants, configuration, inputs, or collaborator returns.',
                                     'For nondeterministic but required values, assert only the source-proven '
                                     'constraint such as non-null, non-empty, positive, or collection size.',
                                     'Do not assert fields populated only by an unselected branch.',
                                     'Do not combine success assertions with handled-failure or propagated-exception '
                                     'assertions.',
                                     'Verify only interactions that demonstrate the selected behavior or distinguish '
                                     'the selected path.']},
 'strict_mockito_rule': {'instructions': ['Keep every stub inside the generated test method.',
                                          'Do not use lenient().',
                                          'Do not create stubs for calls not reached by the selected path.',
                                          'Do not stub or verify the class under test.',
                                          'Do not use doNothing for normal void calls.',
                                          'Do not use exact object equality for arguments constructed internally by '
                                          'production code unless the same instance is supplied by the test.',
                                          'Do not verify every collaborator call when the interaction is not '
                                          'behaviorally relevant.']},
 'compile_safety': {'instructions': ['Use only symbols explicitly supplied in the request.',
                                     'For fixture-supported application types, use only their supplied fixture '
                                     'methods.',
                                     'For non-fixture-supported types, use only supplied constructors, builders, '
                                     'factories, setters, getters, and enum constants.',
                                     'Use only supplied collaborator methods, constants, configuration fields, and '
                                     'fixture methods.',
                                     'Do not add imports.',
                                     'Do not define helper methods.',
                                     'Do not create or start a Spring test context.',
                                     'Do not directly invoke private methods.',
                                     'Do not use ReflectionTestUtils.invokeMethod.',
                                     'Use only JUnit Jupiter assertions and Mockito APIs available in the existing '
                                     'compiled test skeleton.',
                                     'If a compile-safe implementation requires an unresolved symbol or unsupported '
                                     'operation, do not generate that path.']},
 'output': {'instructions': ['Output exactly one complete Java @Test method.',
                             'Do not output markdown fences.',
                             'Do not output prose.',
                             'Do not output package or import declarations.',
                             'Do not output a class declaration.',
                             'Do not output fields, setup methods, or additional helper methods.']}}

# v11 fixture-only setup contract.  Keep scenario state in compiled reusable
# fixtures rather than ad-hoc application-object construction/mutation inside
# generated tests.
_GENERATION_INSTRUCTION['fixture_rule'] = {
    'instructions': [
        'Use only supplied compiled fixture methods for fixture-supported application DTOs and entities.',
        'Do not construct fixture-supported application objects with new, builders, mocks, spies, factories, or reflection inside @Test.',
        'Do not call setters, replace relationships, or manually assemble application-object graphs inside @Test.',
        'Select a feasible path already supported by the supplied compiled baseline or scenario fixture variants.',
        'Preserve object identity by reusing the exact fixture objects returned to collaborators and attached to related fixtures.',
        'Assume compiled fixtures satisfy their recorded non-null paths, collection cardinalities, scalar values, and relationship contracts.',
        'Standard Java scalar and collection values may be created only for method arguments, Mockito behavior, or assertions; they must not recreate a fixture-supported application graph.',
        'If no supplied compiled fixture can satisfy a required path, do not invent a fixture method or mutate a baseline fixture in the returned test.',
    ]
}

_RUNTIME_REPAIR_INSTRUCTIONS = {'objective': 'Repair every supplied runtime error and assertion failure for the selected ServiceImpl public entry '
              'method. Each supplied test failed runtime execution. Return corrected versions of only those tests.',
 'repair_scope': ['Modify only the supplied failing test methods.',
                  'Every supplied test must be returned exactly once.',
                  'Preserve the exact name of every supplied @Test method.',
                  'Preserve the production-method ownership of every supplied test.',
                  'Do not add new tests.',
                  'Do not remove, rename, merge, duplicate, disable, or comment out any supplied test.',
                  'Tests not included in this request have already passed and must not be affected.'],
 'diagnostic_rule': ['Treat each failing test together with only the runtime diagnostics attached to that test.',
                     'Repair all diagnostics attached to each supplied test.',
                     'Use the exception type, message, source line, expected value, actual value, Mockito diagnostic, '
                     'and bounded stack trace as repair evidence.',
                     'Repair the demonstrated root cause rather than suppressing the error or failure.',
                     'Do not infer unrelated failures.'],
 'runtime_error_rule': ['For null-related errors, initialize or populate only the required fixture value, nested '
                        'object, collaborator return, or configuration value.',
                        'For UnnecessaryStubbingException, remove only the stub identified as unnecessary in that '
                        'test.',
                        'For Mockito misuse, correct matcher consistency, matcher type, stubbing form, verification '
                        'count, or invocation arguments.',
                        'For unexpected propagated exceptions, correct the arrangement, required collaborator stub, '
                        'fixture value, or expected exception according to demonstrated execution.',
                        'Do not catch and ignore exceptions.',
                        'Do not introduce @Disabled, assumptions, empty catch blocks, or failure-suppression logic.'],
 'assertion_failure_rule': ['Correct assertions only when supplied runtime evidence demonstrates that the current '
                            'expectation is incorrect.',
                            'Preserve meaningful behavioural verification.',
                            'Do not weaken assertions to assertNotNull, assertTrue(true), empty assertions, or '
                            'similarly non-specific checks merely to obtain a passing result.',
                            'For expected-versus-actual mismatches, correct the arrangement or expectation according '
                            'to the demonstrated scenario and result.',
                            'For assertThrows failures, correct the expected exception, invocation arrangement, or '
                            'collaborator behaviour.',
                            'For Mockito verification failures, correct the expected invocation, arguments, or count '
                            'only when supported by runtime evidence.',
                            'Do not delete a failing assertion without replacing it with a valid assertion that still '
                            'verifies the intended scenario.'],
 'source_faithfulness_rule': ['Use only classes, fields, methods, constructors, getters, setters, constants, fixture '
                              'helpers, mocks, and collaborator APIs present in the supplied tests and shared context.',
                              'Do not invent application APIs.',
                              'Exercise production behaviour only through the selected public ServiceImpl entry '
                              'method.',
                              'Do not call private, protected, or package-visible same-class helper methods directly.',
                              'Do not mock, spy, stub, or verify same-class helper methods.'],
 'fixture_rule': ['Reuse supplied fixture helpers when available.',
                  'Change fixture values only when required by attached diagnostics.',
                  'Prefer a test-local correction over changing shared fixture behaviour.',
                  'Do not replace a verified fixture with manual construction unless the fixture itself is the '
                  'demonstrated cause.',
                  'Do not introduce arbitrary values unrelated to the failing scenario.'],
 'collaborator_rule': ['Use only collaborator fields and methods already present in the supplied test or required '
                       'shared context.',
                       'Add or modify a stub only when required by the demonstrated execution path.',
                       'Do not add unnecessary return stubbing when production code ignores the returned value.',
                       'Do not use doNothing() for non-void methods.',
                       'Do not use thenReturn() for void methods.',
                       'Do not introduce unverified collaborator APIs.'],
 'mockito_rule': ['Do not mix raw arguments and Mockito matchers in the same invocation.',
                  'Use primitive-compatible matchers such as anyChar(), anyInt(), anyLong(), anyBoolean(), '
                  'anyDouble(), and anyFloat() where required.',
                  'Use eq(value) only when the exact value exists in test scope and is relevant to the scenario.',
                  'Do not reference private production fields or production-only local variables.',
                  'Preserve strict-stubbing compatibility.'],
 'assertion_framework_rule': ['Use JUnit Jupiter assertions only.',
                              'Do not introduce AssertJ, Hamcrest, Truth, PowerMock, or Spring context testing.',
                              'Do not assert that unequal objects must have different hash codes.'],
 'compile_safety': ['Returned tests must be valid Java 17.',
                    'Returned tests must compile inside the existing generated test class.',
                    'Do not introduce unsupported imports, fields, annotations, fixture helpers, setup methods, or '
                    'libraries.',
                    'Do not return partial Java syntax.'],
 'acceptance_expectation': ['Every returned test must compile.',
                            'Every returned test must pass targeted runtime execution.',
                            'The complete generated test class must pass with zero errors and zero failures.',
                            'A candidate that breaks a previously passing test is invalid and must be rolled back.'],
 'output': ['Return exactly one complete corrected @Test method for every supplied failing test.',
            'Preserve exact test names and the number of supplied tests.',
            'Return corrected tests in the same order as the request.',
            'Do not return passing tests.',
            'Do not return package declarations, imports, class declarations, setup methods, fixture helpers, '
            'Markdown, explanations, or surrounding prose.']}


# v11 fixture-only generation contract.  Scenario differences belong in
# deterministic compiled fixture variants, never ad-hoc setters inside @Test.
_GENERATION_INSTRUCTION["fixture_rule"]["instructions"].extend([
    "Do not call setters, builders, constructors, mocks, spies, or reflection on fixture-supported application objects inside @Test methods.",
    "Use only the supplied compiled baseline or scenario-specific fixture methods.",
    "Do not invent scenario fixture method names that are not supplied in this request.",
])

@dataclass(frozen=True, slots=True)
class ServiceImplPayloadStageDisabled:
    request_type: str
    reason: str
    disabled: bool = True


def _messages(payload: dict[str, Any]) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": _SYSTEM_MESSAGE},
        {"role": "user", "content": json.dumps(payload, indent=2, ensure_ascii=False)},
    ]


def _method_id(method) -> str:
    return f"{method.name}({','.join(type_name for type_name, _ in method.params)})"


def _method_context(ctx, method):
    method_id = _method_id(method)
    execution = getattr(ctx, "execution_context", None)
    return next((item for item in getattr(execution, "methods", ()) if item.method_id == method_id), None)


def _simple_name(type_name: str) -> str:
    text = (type_name or "Object").strip()
    if "<" in text:
        text = text.split("<", 1)[0]
    return text.rsplit(".", 1)[-1].replace("[]", "")


def _variable_name(type_name: str) -> str:
    simple = _simple_name(type_name)
    return simple[:1].lower() + simple[1:] if simple else "value"


def _fixture_payload(ctx, method_context) -> list[dict[str, Any]]:
    execution = getattr(ctx, "execution_context", None)
    if execution is None or method_context is None:
        return []
    by_id = {fixture.fixture_id: fixture for fixture in execution.fixtures}
    result: list[dict[str, Any]] = []
    for fixture_id in method_context.required_fixture_ids:
        fixture = by_id.get(fixture_id)
        if fixture is None or not fixture.supported:
            continue
        result.append({
            "type": fixture.return_type,
            "fixture_method": fixture.method_name,
            "invocation": f"{fixture.return_type} {_variable_name(fixture.return_type)} = {fixture.method_name}();",
            "status": "compiled",
        })
    return result


def _contract_signature(contract) -> str:
    parameters = ", ".join(
        f"{type_name} {name}" if name else type_name
        for type_name, name in zip(
            contract.parameter_types,
            contract.parameter_names or ("",) * len(contract.parameter_types),
        )
    )
    rendered_return = contract.return_type if contract.return_type is not None else "<unresolved>"
    return f"{rendered_return} {contract.method_name}({parameters})"


def _collaborator_payload(method_context) -> list[dict[str, Any]]:
    if method_context is None:
        return []
    grouped: dict[tuple[str, str], dict[str, Any]] = {}
    seen_methods: set[tuple[str, str, str | None, tuple[str, ...], str]] = set()
    for invocation in method_context.dependency_invocations:
        contract = invocation.contract
        receiver_key = (invocation.dependency_field, invocation.dependency_type)
        receiver = grouped.setdefault(receiver_key, {
            "field": invocation.dependency_field,
            "type": invocation.dependency_type,
            "methods": [],
        })
        resolution = getattr(contract.resolution_status, "value", str(contract.resolution_status))
        key = (
            invocation.dependency_field,
            contract.method_name,
            contract.return_type,
            tuple(contract.parameter_types),
            resolution,
        )
        # Preserve distinct consumption facts for the same contract by folding
        # all observed invocations into one method record below.
        existing = next((item for item in receiver["methods"] if item.get("_key") == key), None)
        consumption = getattr(invocation.consumption_kind, "value", str(invocation.consumption_kind))
        invocation_fact = {
            "caller_method_id": invocation.caller_method_id,
            "return_value_consumed": bool(invocation.return_value_consumed),
            "consumption_kind": consumption,
            "assigned_to": invocation.assigned_to,
            "branch_id": invocation.branch_id,
            "line": invocation.line,
        }
        if existing is not None:
            existing["invocations"].append(invocation_fact)
            existing["return_value_consumed"] = bool(
                existing["return_value_consumed"] or invocation.return_value_consumed
            )
            continue
        method_payload = {
            "_key": key,
            "method_id": f"{contract.method_name}({','.join(contract.parameter_types)})",
            "signature": _contract_signature(contract),
            "return_type": contract.return_type,
            "parameter_types": list(contract.parameter_types),
            "parameter_names": list(contract.parameter_names),
            "declaring_type": contract.declaring_type,
            "inherited_spring_data": bool(contract.inherited_spring_data),
            "resolution_status": resolution,
            "return_value_consumed": bool(invocation.return_value_consumed),
            "invocations": [invocation_fact],
        }
        receiver["methods"].append(method_payload)
        seen_methods.add(key)
    for receiver in grouped.values():
        for method in receiver["methods"]:
            method.pop("_key", None)
    return list(grouped.values())


def _constant_payload(ctx) -> list[dict[str, Any]]:
    result = []
    for field in getattr(ctx.symbol, "fields", ()) or ():
        modifiers = set(getattr(field, "modifiers", ()) or ())
        if not {"static", "final"} <= modifiers:
            continue
        result.append({
            "name": field.name,
            "type": field.type,
            "owner": ctx.symbol.fqcn,
            "test_expression": field.name,
            "resolution_status": "resolved",
        })
    for imported in getattr(ctx, "source_imports", ()) or ():
        text = str(imported).strip().replace("import ", "").rstrip(";")
        if text.startswith("static ") and not text.endswith(".*"):
            body = text[len("static "):]
            result.append({
                "name": body.rsplit(".", 1)[-1],
                "owner": body.rsplit(".", 1)[0],
                "test_expression": body.rsplit(".", 1)[-1],
                "resolution_status": "resolved_static_import",
            })
    unique = {}
    for item in result:
        unique[(item.get("owner"), item["name"])] = item
    return list(unique.values())


def _configuration_payload(ctx) -> list[dict[str, Any]]:
    execution = getattr(ctx, "execution_context", None)
    result = []
    for field in getattr(execution, "configuration_fields", ()) or ():
        result.append({
            "field_name": field.field_name,
            "type": field.type_name,
            "test_value": field.test_value,
            "bare_identifier_allowed_in_test": False,
            "verified_test_expression": field.test_value,
        })
    return result


def _available_static_apis(ctx) -> dict[str, list[str]]:
    imports = [str(value) for value in getattr(ctx, "source_imports", ()) or ()]
    return {
        "junit_jupiter": [
            "assertEquals", "assertNotEquals", "assertTrue", "assertFalse", "assertNull",
            "assertNotNull", "assertSame", "assertNotSame", "assertThrows",
            "assertDoesNotThrow", "assertIterableEquals", "assertArrayEquals", "fail",
        ],
        "mockito_static": [
            "when", "verify", "any", "anyString", "anyInt", "anyLong", "anyChar",
            "anyBoolean", "anyDouble", "anyFloat", "eq", "same", "doThrow", "thenAnswer",
        ],
        "source_imports": imports,
        "qualified_Mockito_allowed": any("org.mockito.Mockito" in value and "static" not in value for value in imports),
    }


def build_generation_payload(ctx, method=None, *_args, mode: str = "method", **_kwargs):
    if mode != "method" or method is None:
        raise ValueError("ServiceImpl generation requires one selected public entry method")
    method_context = _method_context(ctx, method)
    if method_context is None:
        raise ValueError(f"ServiceImpl method context missing for {_method_id(method)}")
    closure = build_source_closure(ctx, method_context)
    reachable_method_ids = tuple(getattr(closure, "reachable_method_ids", ()) or ())
    reachable_methods = tuple(getattr(closure, "reachable_methods", ()) or ())
    unresolved_method_ids = tuple(getattr(closure, "unresolved_method_ids", ()) or ())
    if reachable_method_ids and (
        unresolved_method_ids
        or len(reachable_methods) != len(reachable_method_ids)
    ):
        raise ValueError(
            "ServiceImpl source closure incomplete; unresolved same-class helpers: "
            + ", ".join(unresolved_method_ids or reachable_method_ids)
        )
    target_source = closure.method_source or method_context.method_source
    payload = {
        "request_type": "method_test_generation",
        "target_class": {
            "fqcn": ctx.symbol.fqcn,
            "test_instance": cut_variable_name(ctx.symbol.name),
        },
        "target_method": {
            "method_id": method_context.method_id,
            "signature": method.render(),
            "source": target_source,
        },
        "reachable_same_class_methods": [
            {
                "method_id": item.method_id,
                "signature": item.signature,
                "visibility": item.visibility,
                "source": item.source,
            }
            for item in reachable_methods
        ],
        "fixtures": _fixture_payload(ctx, method_context),
        "collaborators": _collaborator_payload(method_context),
        "constants": _constant_payload(ctx),
        "configuration_fields": _configuration_payload(ctx),
        "available_test_apis": _available_static_apis(ctx),
        "source_closure": {
            "complete": bool(getattr(closure, "complete", not bool(getattr(closure, "unresolved_method_ids", ())))),
            "reachable_method_ids": list(getattr(closure, "reachable_method_ids", (item.method_id for item in reachable_methods))),
            "unresolved_method_ids": list(unresolved_method_ids),
        },
        "generation_instruction": deepcopy(_GENERATION_INSTRUCTION),
    }
    return _messages(payload)


def _diagnostic_payload(errors, source: str) -> list[dict[str, Any]]:
    payload_errors = []
    for error in errors or ():
        line = getattr(error, "line", None)
        payload_errors.append({
            "line": line,
            "column": getattr(error, "col", None),
            "message": getattr(error, "message", None) or str(error),
            "detail": list(getattr(error, "detail", ()) or ()),
            "source_line": _source_line(source, line),
        })
    return payload_errors


def build_validation_repair_payload(
    ctx,
    method,
    current_test: str,
    test_name: str,
    validation_reason: str,
    *_args,
    **_kwargs,
):
    method_context = _method_context(ctx, method)
    if method_context is None:
        raise ValueError(f"ServiceImpl method context missing for {_method_id(method)}")
    return _messages({
        "request_type": "single_test_generation_validation_repair",
        "target_class": {"fqcn": ctx.symbol.fqcn, "test_instance": cut_variable_name(ctx.symbol.name)},
        "target_method": {"method_id": method_context.method_id, "signature": method.render()},
        "test_name": test_name,
        "current_test_source": current_test,
        "validation_diagnostics": [validation_reason],
        "fixtures": _fixture_payload(ctx, method_context),
        "collaborators": _collaborator_payload(method_context),
        "constants": _constant_payload(ctx),
        "configuration_fields": _configuration_payload(ctx),
        "available_test_apis": _available_static_apis(ctx),
        "repair_instructions": {
            "scope": "Return exactly one corrected @Test method with the same test name.",
            "fixture_only": [
                "Use compiled fixture methods for fixture-supported application DTOs/entities.",
                "Do not call application-object setters, builders, constructors, mocks, spies, or reflection inside @Test.",
                "When a scenario fixture is unavailable, simplify to a feasible path supported by supplied compiled fixtures; never invent a fixture method.",
            ],
            "semantic_rules": deepcopy(_GENERATION_INSTRUCTION),
            "output": ["raw Java only", "no Markdown fences", "no prose", "one @Test method"],
        },
    })


def _source_line(source: str, line: int | None) -> str | None:
    if line is None or line < 1:
        return None
    lines = source.splitlines()
    return lines[line - 1].strip() if line <= len(lines) else None


def build_compile_repair_payload(ctx, current_test=None, errors=None, *_args, **kwargs):
    mode = kwargs.get("mode", "individual")
    method = kwargs.get("method")
    test_name = kwargs.get("test_name")
    source = kwargs.get("current") or kwargs.get("source") or current_test or ""
    diagnostics = list(kwargs.get("compilation_errors") or errors or ())
    if mode != "individual" or method is None or not test_name:
        raise ValueError("ServiceImpl v11 compile repair requires one registry-owned @Test method")
    method_context = _method_context(ctx, method)
    if method_context is None:
        raise ValueError(f"ServiceImpl method context missing for {_method_id(method)}")
    return _messages({
        "request_type": "single_test_compile_repair",
        "target_class": {"fqcn": ctx.symbol.fqcn, "test_class_name": ctx.test_class_name},
        "target_method": {"method_id": method_context.method_id, "signature": method.render()},
        "test_name": test_name,
        "current_test_source": source,
        "compiler_diagnostics": _diagnostic_payload(diagnostics, source),
        "relevant_schema_contracts": [
            {
                "type_name": schema.type_name,
                "properties": [
                    {
                        "name": prop.name,
                        "type": prop.type_name,
                        "getter": prop.getter,
                        "setter": prop.setter,
                        "kind": getattr(prop.kind, "value", str(prop.kind)),
                        "element_type": prop.element_type,
                        "enum_constants": list(prop.enum_constants),
                    }
                    for prop in schema.properties
                ],
                "enum_constants": list(schema.enum_constants),
            }
            for schema in method_context.payload_schemas
        ],
        "relevant_collaborator_contracts": _collaborator_payload(method_context),
        "relevant_fixture_contracts": _fixture_payload(ctx, method_context),
        "constants": _constant_payload(ctx),
        "configuration_fields": _configuration_payload(ctx),
        "available_test_apis": _available_static_apis(ctx),
        "repair_instructions": {
            "scope": "Repair only this one @Test method. Preserve its exact name.",
            "rules": [
                "Use only supplied contracts and compiled fixtures.",
                "Do not mutate fixture-supported application objects inside @Test.",
                "Do not use thenReturn for void methods.",
                "Do not use doNothing for non-void methods.",
                "Use exact verified getter/setter/type/enum/collection contracts.",
                "Do not reference private CUT fields or production locals as bare test identifiers.",
                "Return exactly one raw Java @Test method without Markdown or prose.",
            ],
        },
    })



def _extract_braced_member(source: str, name: str) -> str | None:
    match = re.search(rf"\b{re.escape(name)}\s*\(", source)
    if not match:
        return None
    start = source.rfind("\n", 0, match.start()) + 1
    annotation_start = source.rfind("\n@", 0, start)
    if annotation_start >= 0 and source[annotation_start + 1 : start].strip().startswith("@"): 
        start = annotation_start + 1
    brace = source.find("{", match.end())
    if brace < 0:
        return None
    depth = 0
    in_string = False
    quote = ""
    escape = False
    for index in range(brace, len(source)):
        char = source[index]
        if in_string:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == quote:
                in_string = False
            continue
        if char in {"\"", "'"}:
            in_string = True
            quote = char
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return source[start : index + 1].strip()
    return None


def _required_shared_context(ctx, test_class_source: str, failing_tests: list[dict[str, Any]]) -> dict[str, list[str]]:
    combined = "\n".join(str(test.get("source", "")) for test in failing_tests)
    required_mock_fields: list[str] = []
    execution = getattr(ctx, "execution_context", None)
    for dependency in getattr(execution, "dependencies", ()) or ():
        field_name = getattr(dependency, "field_name", None)
        if not field_name or not re.search(rf"\b{re.escape(field_name)}\b", combined):
            continue
        line_match = re.search(
            rf"(?m)(?:^\s*@Mock\s*\n)?^\s*(?:private|protected|public)?\s*"
            rf"[^;\n]+\b{re.escape(field_name)}\s*;",
            test_class_source,
        )
        if line_match:
            required_mock_fields.append(line_match.group(0).strip())

    required_fixture_helpers: list[str] = []
    for fixture in getattr(execution, "fixtures", ()) or ():
        if not getattr(fixture, "supported", False):
            continue
        if not re.search(rf"\b{re.escape(fixture.method_name)}\s*\(", combined):
            continue
        source = _extract_braced_member(test_class_source, fixture.method_name)
        if source:
            required_fixture_helpers.append(source)

    required_setup_fragments: list[str] = []
    if cut_variable_name(ctx.symbol.name) in combined:
        setup = _extract_braced_member(test_class_source, "setUp")
        if setup is None:
            before_each = re.search(r"@BeforeEach", test_class_source)
            if before_each:
                method_match = re.search(r"\b([A-Za-z_$][\w$]*)\s*\(", test_class_source[before_each.end():])
                if method_match:
                    setup = _extract_braced_member(test_class_source, method_match.group(1))
        if setup:
            required_setup_fragments.append(setup)

    return {
        "required_mock_fields": required_mock_fields,
        "required_setup_fragments": required_setup_fragments,
        "required_fixture_helpers": required_fixture_helpers,
    }


def build_runtime_repair_payload(
    ctx,
    method=None,
    *_args,
    failing_tests=None,
    shared_test_context=None,
    test_class_source: str = "",
    **_kwargs,
):
    if method is None:
        raise ValueError("ServiceImpl runtime repair requires the owning production method")
    failing_tests = list(failing_tests or ())
    if shared_test_context is None:
        shared_test_context = _required_shared_context(ctx, test_class_source, failing_tests)
    payload = {
        "request_type": "runtime_repair",
        "target_class": {
            "fqcn": ctx.symbol.fqcn,
            "test_class_name": ctx.test_class_name,
        },
        "target_method": {"method_id": _method_id(method)},
        "failing_tests": failing_tests,
        "shared_test_context": shared_test_context,
        "repair_instructions": deepcopy(_RUNTIME_REPAIR_INSTRUCTIONS),
    }
    return _messages(payload)


def build_coverage_augmentation_payload(*_args, **_kwargs):
    return ServiceImplPayloadStageDisabled(
        request_type="coverage_augmentation",
        reason="ServiceImpl coverage augmentation is disabled",
    )


def build_coverage_repair_payload(*_args, **_kwargs):
    return ServiceImplPayloadStageDisabled(
        request_type="coverage_repair",
        reason="ServiceImpl coverage repair is disabled",
    )


__all__ = [
    "ServiceImplPayloadStageDisabled",
    "build_generation_payload",
    "build_validation_repair_payload",
    "build_compile_repair_payload",
    "build_runtime_repair_payload",
    "build_coverage_augmentation_payload",
    "build_coverage_repair_payload",
]
