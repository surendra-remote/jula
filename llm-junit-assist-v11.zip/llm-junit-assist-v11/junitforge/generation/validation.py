"""Generated-test validation and deterministic validation repair."""

from __future__ import annotations

import re

from junitforge.execution.assembly import (
    MethodBlockValidation,
    cut_variable_name,
    deterministically_repair_test,
    test_method_names,
    validate_method_block,
)


def is_serviceimpl_context(ctx) -> bool:
    execution = getattr(ctx, "execution_context", None)
    target_kind = getattr(getattr(execution, "target_kind", None), "value", None)
    return target_kind == "service-impl"


def validate_serviceimpl_structural_test(
    ctx,
    production_method,
    source: str,
    existing_names=None,
) -> MethodBlockValidation:
    """Compatibility name for the minimal wrapper gate.

    v11 no longer uses this function as the final ServiceImpl acceptance gate;
    ``validate_generated_test`` invokes the full source-backed semantic
    validator.  It remains public for callers/tests that explicitly need the
    lightweight structure check.
    """
    existing_names = existing_names or set()
    if not source.strip() or "@Test" not in source:
        return MethodBlockValidation(False, "no @Test methods returned")
    if re.search(r"(?m)^\s*(?:package|import)\b|\bclass\s+\w+", source):
        return MethodBlockValidation(False, "method response contains package/import/class wrapper")
    names = tuple(test_method_names(source))
    if not names:
        return MethodBlockValidation(False, "unable to identify generated test method names")
    if len(names) != len(set(names)):
        return MethodBlockValidation(False, "duplicate test names within method response")
    duplicates = set(names) & set(existing_names)
    if duplicates:
        return MethodBlockValidation(
            False,
            "duplicate test method names: " + ", ".join(sorted(duplicates)),
        )
    if re.search(
        r"\b(?:assertThat|MatcherAssert\s*\.\s*assertThat|Truth\s*\.\s*assertThat)\s*\(",
        source,
    ):
        return MethodBlockValidation(False, "unsupported assertion framework")
    cut_var = cut_variable_name(ctx.symbol.name)
    if not re.search(
        rf"\b{re.escape(cut_var)}\s*\.\s*{re.escape(production_method.name)}\s*\(",
        source,
    ):
        return MethodBlockValidation(False, "ServiceImpl tests do not call the selected CUT method")
    return MethodBlockValidation(True, test_names=names)


def validate_generated_test(ctx, production_method, method_context, source, existing_names=None):
    """Run the full semantic gate for every method-wise generated test.

    v10.2 intentionally deferred ServiceImpl semantic errors to javac.  That
    allowed known invalid setters/getters, Mockito contracts, enum constants,
    scope identifiers and fixture mutations into class assembly.  v11 uses the
    same authoritative method contract gate for ServiceImpl and Controller.
    """
    return validate_method_block(
        ctx,
        production_method,
        method_context,
        source,
        existing_names or set(),
    )


def repair_validation_failure_deterministically(ctx, production_method, method_context, source):
    return deterministically_repair_test(ctx, production_method, method_context, source)


__all__ = [
    "is_serviceimpl_context",
    "validate_serviceimpl_structural_test",
    "validate_generated_test",
    "repair_validation_failure_deterministically",
]
