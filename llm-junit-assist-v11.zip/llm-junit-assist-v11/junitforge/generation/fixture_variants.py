"""Deterministic scenario-fixture variants for ServiceImpl test methods.

Generated tests may reference compiled application fixtures, but v11 keeps
application-object state preparation out of ``@Test`` bodies.  This module
hoists simple, source-backed setter sequences into reusable private fixture
variants.  It is intentionally bounded: ambiguous multi-line expressions or
unknown application dependencies are left unresolved for one focused LLM
validation-repair attempt rather than guessed.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import re

from junitforge.execution.models import MethodExecutionContext
from junitforge.models import GenerationContext


@dataclass(frozen=True, slots=True)
class FixtureVariantResult:
    source: str
    changed: bool
    helper_sources: tuple[str, ...] = ()
    dependencies: tuple[dict[str, object], ...] = ()
    actions: tuple[str, ...] = ()
    unresolved_reason: str | None = None


def _simple(rendered: str | None) -> str:
    text = (rendered or "").strip().replace("...", "").replace("[]", "")
    if "<" in text:
        text = text.split("<", 1)[0]
    return text.rsplit(".", 1)[-1]


def _safe_pascal(value: str) -> str:
    parts = re.findall(r"[A-Za-z0-9]+", value or "")
    result = "".join(part[:1].upper() + part[1:] for part in parts)
    return result or "Scenario"


def _fixture_contracts(ctx: GenerationContext):
    execution = ctx.execution_context
    if execution is None:
        return {}, {}
    by_type = {}
    by_method = {}
    for fixture in execution.fixtures:
        if not fixture.supported:
            continue
        by_type.setdefault(_simple(fixture.return_type), fixture)
        by_method[fixture.method_name] = fixture
    return by_type, by_method


def _schema_by_type(method_context: MethodExecutionContext):
    result = {}
    for schema in method_context.payload_schemas:
        result.setdefault(_simple(schema.type_name), schema)
        if schema.fqcn:
            result.setdefault(_simple(schema.fqcn), schema)
    return result


def _declared_fixture_variables(source: str, by_type, by_method):
    declarations = {}
    pattern = re.compile(
        r"(?m)^(?P<indent>[ \t]*)(?P<type>[A-Z][A-Za-z0-9_$.<>?, ]*)\s+"
        r"(?P<var>[A-Za-z_$][\w$]*)\s*=\s*(?P<init>[^;\n]+);[ \t]*$"
    )
    for match in pattern.finditer(source):
        type_name = _simple(match.group("type"))
        if type_name not in by_type:
            continue
        init = match.group("init").strip()
        helper_match = re.fullmatch(r"([A-Za-z_$][\w$]*)\s*\(\s*\)", init)
        if helper_match and helper_match.group(1) in by_method:
            base_helper = helper_match.group(1)
        elif re.match(rf"new\s+(?:[\w$.]+\.)?{re.escape(type_name)}\s*\(", init):
            base_helper = by_type[type_name].method_name
        elif re.match(rf"(?:[\w$.]+\.)?{re.escape(type_name)}\s*\.\s*(?:builder|newBuilder)\s*\(", init):
            base_helper = by_type[type_name].method_name
        elif re.match(rf"(?:Mockito\.)?(?:mock|spy)\s*\(", init):
            base_helper = by_type[type_name].method_name
        else:
            continue
        declarations[match.group("var")] = {
            "type": type_name,
            "rendered_type": match.group("type").strip(),
            "base_helper": base_helper,
            "init": init,
            "start": match.start(),
            "end": match.end(),
            "indent": match.group("indent"),
            "source": match.group(0),
        }
    return declarations


def _setter_mutations(source: str, variables: set[str]):
    result: dict[str, list[dict]] = {name: [] for name in variables}
    pattern = re.compile(
        r"(?m)^(?P<indent>[ \t]*)(?P<var>[A-Za-z_$][\w$]*)\."
        r"(?P<setter>set[A-Za-z0-9_$]+)\s*\((?P<arg>[^;\n]*)\)\s*;[ \t]*$"
    )
    for match in pattern.finditer(source):
        var = match.group("var")
        if var not in result:
            continue
        result[var].append({
            "start": match.start(),
            "end": match.end(),
            "setter": match.group("setter"),
            "arg": match.group("arg").strip(),
            "source": match.group(0).strip(),
        })
    return result


def _referenced_fixture_vars(expression: str, declarations: dict) -> list[str]:
    refs = []
    for name in declarations:
        if re.search(rf"(?<![\w$]){re.escape(name)}(?![\w$])", expression):
            refs.append(name)
    return refs


def _validated_setters(schema, mutations) -> tuple[bool, str | None]:
    if schema is None:
        return False, "fixture schema unavailable"
    allowed = {prop.setter for prop in schema.properties if prop.setter}
    for mutation in mutations:
        if mutation["setter"] not in allowed:
            return False, f"unknown fixture setter {schema.type_name}.{mutation['setter']}"
    return True, None


def hoist_fixture_mutations(
    ctx: GenerationContext,
    method_context: MethodExecutionContext,
    test_source: str,
    *,
    test_name: str,
) -> FixtureVariantResult:
    by_type, by_method = _fixture_contracts(ctx)
    if not by_type:
        return FixtureVariantResult(test_source, False)
    declarations = _declared_fixture_variables(test_source, by_type, by_method)
    if not declarations:
        return FixtureVariantResult(test_source, False)
    mutations = _setter_mutations(test_source, set(declarations))
    mutated = [name for name, values in mutations.items() if values]

    schemas = _schema_by_type(method_context)
    helpers: list[str] = []
    dependencies: list[dict[str, object]] = []
    actions: list[str] = []
    replacements: list[tuple[int, int, str]] = []

    # First normalize direct construction/mock/spy of fixture-supported objects
    # even when the object itself has no setter mutations.  Parent fixture
    # variants may still reference these variables as relationship parameters.
    for variable, declaration in declarations.items():
        if variable in mutated:
            continue
        helper_call = f"{declaration['base_helper']}()"
        if declaration["init"].replace(" ", "") == helper_call:
            continue
        replacement = (
            f"{declaration['indent']}{declaration['rendered_type']} {variable} = "
            f"{helper_call};"
        )
        replacements.append((declaration["start"], declaration["end"], replacement))
        dependencies.append({
            "type": declaration["rendered_type"],
            "fixture_method": declaration["base_helper"],
            "fixture_variant": False,
            "state_signature": "baseline",
            "compile_state": "PASSED",
            "base_fixture_method": declaration["base_helper"],
        })
        actions.append(
            f"fixture_construction_replaced:{declaration['type']}:{variable}->{declaration['base_helper']}"
        )

    for variable in mutated:
        declaration = declarations[variable]
        variable_mutations = mutations[variable]
        valid, reason = _validated_setters(schemas.get(declaration["type"]), variable_mutations)
        if not valid:
            return FixtureVariantResult(
                test_source, False, unresolved_reason=reason,
            )
        referenced: list[str] = []
        for mutation in variable_mutations:
            for ref in _referenced_fixture_vars(mutation["arg"], declarations):
                if ref != variable and ref not in referenced:
                    referenced.append(ref)
        # All application dependencies must themselves come from verified fixtures.
        unknown_application_refs = set()
        for mutation in variable_mutations:
            for token in re.findall(r"\b([a-zA-Z_$][\w$]*)\b", mutation["arg"]):
                if token in declarations or token in {
                    "true", "false", "null", "new", "List", "Set", "Map", "Collections",
                    "Arrays", "BigDecimal", "Optional"
                }:
                    continue
                # Method names, constants and scalar locals are allowed; only fail
                # when the token is a known declaration with unsupported type.
        normalized_state = "|".join(
            f"{mutation['setter']}({re.sub(r'\s+', ' ', mutation['arg']).strip()})"
            for mutation in variable_mutations
        )
        helper_seed = f"{declaration['type']}:{normalized_state}:{','.join(referenced)}"
        suffix = hashlib.sha256(helper_seed.encode("utf-8")).hexdigest()[:8]
        helper_name = f"{declaration['base_helper']}Variant{suffix}"
        parameters = ", ".join(
            f"{declarations[ref]['rendered_type']} {ref}" for ref in referenced
        )
        call_args = ", ".join(referenced)
        lines = [
            f"    private {declaration['rendered_type']} {helper_name}({parameters}) {{",
            f"        {declaration['rendered_type']} {variable} = {declaration['base_helper']}();",
        ]
        for mutation in variable_mutations:
            lines.append(f"        {variable}.{mutation['setter']}({mutation['arg']});")
        lines.extend((f"        return {variable};", "    }"))
        helpers.append("\n".join(lines))
        replacement = (
            f"{declaration['indent']}{declaration['rendered_type']} {variable} = "
            f"{helper_name}({call_args});"
        )
        replacements.append((declaration["start"], declaration["end"], replacement))
        for mutation in variable_mutations:
            replacements.append((mutation["start"], mutation["end"], ""))
        state_signature = normalized_state.replace("|", ";")
        dependencies.append({
            "type": declaration["rendered_type"],
            "fixture_method": helper_name,
            "fixture_variant": True,
            "state_signature": state_signature,
            "compile_state": "PENDING_SKELETON_COMPILE",
            "base_fixture_method": declaration["base_helper"],
        })
        actions.append(
            f"fixture_variant_hoisted:{declaration['type']}:{variable}->{helper_name}"
        )

    repaired = test_source
    for start, end, replacement in sorted(replacements, reverse=True):
        repaired = repaired[:start] + replacement + repaired[end:]
    repaired = re.sub(r"\n[ \t]*\n[ \t]*\n", "\n\n", repaired).strip()
    return FixtureVariantResult(
        repaired,
        repaired != test_source.strip(),
        tuple(helpers),
        tuple(dependencies),
        tuple(actions),
    )


def inject_fixture_variant_helpers(suite: str, helpers: tuple[str, ...] | list[str]) -> str:
    unique = []
    seen = set()
    for helper in helpers:
        normalized = helper.strip()
        if not normalized:
            continue
        method_match = re.search(r"\b([A-Za-z_$][\w$]*)\s*\(", normalized)
        key = method_match.group(1) if method_match else normalized
        declaration_pattern = rf"\b(?:private|protected|public)\s+[A-Za-z_$][\w$<>?,.\[\] ]*\s+{re.escape(key)}\s*\("
        if key in seen or re.search(declaration_pattern, suite):
            continue
        seen.add(key)
        unique.append(normalized)
    if not unique:
        return suite
    close = suite.rfind("}")
    if close < 0:
        raise ValueError("test skeleton has no closing class brace")
    body = "\n\n".join(unique)
    return suite[:close].rstrip() + "\n\n" + body + "\n}\n"


__all__ = [
    "FixtureVariantResult",
    "hoist_fixture_mutations",
    "inject_fixture_variant_helpers",
]
