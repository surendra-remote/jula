"""Generation public exports with lazy loading to avoid assembly cycles."""

__all__ = [
    "GenerationMixin",
    "SkeletonResult",
    "generate_skeleton",
    "generate_and_validate_skeleton",
    "payload_builder_for",
    "payload_builder_for_context",
]


def __getattr__(name):
    if name == "GenerationMixin":
        from .method_generator import GenerationMixin
        return GenerationMixin
    if name in {"SkeletonResult", "generate_skeleton", "generate_and_validate_skeleton"}:
        from .skeleton_generator import SkeletonResult, generate_and_validate_skeleton, generate_skeleton
        return {
            "SkeletonResult": SkeletonResult,
            "generate_skeleton": generate_skeleton,
            "generate_and_validate_skeleton": generate_and_validate_skeleton,
        }[name]
    if name in {"payload_builder_for", "payload_builder_for_context"}:
        from .payloads import payload_builder_for, payload_builder_for_context
        return {
            "payload_builder_for": payload_builder_for,
            "payload_builder_for_context": payload_builder_for_context,
        }[name]
    raise AttributeError(name)
