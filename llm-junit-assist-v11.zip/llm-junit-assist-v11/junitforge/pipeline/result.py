"""TargetOutcome creation and authoritative generated-test registry helpers.

v11 treats ``07-class-assembly/registry.json`` as the single repair control
plane.  Original generation source is immutable; candidates are transactional
until validation/compilation (and, when required, focused execution) succeed.
"""

from __future__ import annotations

from copy import deepcopy
from hashlib import sha256

from junitforge.generation.response_extractor import extract_generated_tests
from junitforge.models import CompileState, TargetOutcome, TestDisposition


def _hash(source: str) -> str:
    return sha256((source or "").encode("utf-8")).hexdigest()


def create_target_outcome(*, fqcn: str, module: str, source_path: str) -> TargetOutcome:
    return TargetOutcome(
        fqcn=fqcn,
        module=module,
        source_path=source_path,
        test_path="",
        classification="",
        testable=True,
    )


def test_registry(outcome: TargetOutcome) -> dict[str, list]:
    """Return the authoritative production-method -> TestCaseRecord registry."""
    return {record.method_id: record.tests for record in outcome.method_results}


def test_record_by_name(outcome: TargetOutcome, test_name: str):
    normalized = (test_name or "").split("(", 1)[0]
    for method_record in outcome.method_results:
        for test_record in method_record.tests:
            if test_record.test_name == test_name or test_record.test_name == normalized:
                return test_record
    return None


def test_record_by_id(outcome: TargetOutcome, test_id: str):
    for method_record in outcome.method_results:
        for test_record in method_record.tests:
            if test_record.test_id == test_id:
                return test_record
    return None


def owner_for_test(outcome: TargetOutcome, test_name: str) -> str | None:
    record = test_record_by_name(outcome, test_name)
    return record.owner_method_id if record is not None else None


def refresh_test_registry_ranges(
    outcome: TargetOutcome,
    source: str,
    *,
    compile_state: str | None = None,
) -> None:
    """Refresh volatile source locations without mutating accepted source history."""
    extracted = {test.name: test for test in extract_generated_tests(source)}
    for method_record in outcome.method_results:
        for test_record in method_record.tests:
            current = extracted.get(test_record.test_name)
            if current is None:
                continue
            test_record.source_start_line = current.start_line
            test_record.source_end_line = current.end_line
            test_record.source_hash = _hash(current.source)
            if compile_state is not None and test_record.final_disposition == TestDisposition.RETAINED.value:
                test_record.compile_state = compile_state


def initialize_latest_accepted_sources(outcome: TargetOutcome, source: str) -> None:
    """Initialize accepted generation source once after semantic validation/assembly."""
    extracted = {test.name: test for test in extract_generated_tests(source)}
    for method_record in outcome.method_results:
        for test_record in method_record.tests:
            current = extracted.get(test_record.test_name)
            if current is None:
                continue
            if not test_record.generated_source:
                # Compatibility only: normal generation sets this at extraction time.
                test_record.generated_source = current.source
            if not test_record.latest_accepted_source:
                test_record.latest_accepted_source = current.source
            test_record.source_start_line = current.start_line
            test_record.source_end_line = current.end_line
            test_record.source_hash = _hash(current.source)


def stage_candidate_source(outcome: TargetOutcome, test_name: str, source: str) -> None:
    record = test_record_by_name(outcome, test_name)
    if record is None:
        raise KeyError(f"unknown registry test: {test_name}")
    record.candidate_source = source


def discard_candidate_source(outcome: TargetOutcome, test_name: str) -> None:
    record = test_record_by_name(outcome, test_name)
    if record is not None:
        record.candidate_source = None


def commit_candidate_source(
    outcome: TargetOutcome,
    test_name: str,
    *,
    compile_state: str = CompileState.REPAIRED_AND_PASSED.value,
) -> None:
    """Commit one candidate only after the caller proved all acceptance gates."""
    record = test_record_by_name(outcome, test_name)
    if record is None:
        raise KeyError(f"unknown registry test: {test_name}")
    if not record.candidate_source:
        raise ValueError(f"no candidate source staged for {test_name}")
    if record.latest_accepted_source != record.candidate_source:
        record.previous_accepted_source = record.latest_accepted_source or None
        record.latest_accepted_source = record.candidate_source
    record.source_hash = _hash(record.latest_accepted_source)
    record.candidate_source = None
    record.compile_state = compile_state


def sync_test_registry_sources(
    outcome: TargetOutcome,
    source: str,
    *,
    compile_state: str | None = None,
    accepted: bool = False,
) -> None:
    """Compatibility facade with v11 source semantics.

    ``generated_source`` is never overwritten.  ``accepted=True`` commits the
    currently assembled source only after the caller has already proved the
    relevant gate.  Merely refreshing assembly line ranges uses
    ``accepted=False``.
    """
    extracted = {test.name: test for test in extract_generated_tests(source)}
    for method_record in outcome.method_results:
        for test_record in method_record.tests:
            current = extracted.get(test_record.test_name)
            if current is None:
                continue
            test_record.source_start_line = current.start_line
            test_record.source_end_line = current.end_line
            test_record.source_hash = _hash(current.source)
            if compile_state is not None and test_record.final_disposition == TestDisposition.RETAINED.value:
                test_record.compile_state = compile_state
            if accepted:
                if test_record.latest_accepted_source != current.source:
                    test_record.previous_accepted_source = test_record.latest_accepted_source or None
                    test_record.latest_accepted_source = current.source
                test_record.candidate_source = None


def snapshot_test_registry(outcome: TargetOutcome):
    """Capture all per-method/per-test registry state for transactional rollback."""
    return deepcopy(outcome.method_results)


def restore_test_registry(outcome: TargetOutcome, snapshot) -> None:
    """Restore the authoritative registry after a rejected repair candidate."""
    outcome.method_results = deepcopy(snapshot)


def restore_test_registry_source(outcome: TargetOutcome, source: str) -> None:
    # Rollback should restore ranges only; accepted histories come from snapshot.
    refresh_test_registry_ranges(outcome, source)


__all__ = [
    "commit_candidate_source",
    "create_target_outcome",
    "discard_candidate_source",
    "initialize_latest_accepted_sources",
    "owner_for_test",
    "refresh_test_registry_ranges",
    "restore_test_registry",
    "restore_test_registry_source",
    "snapshot_test_registry",
    "stage_candidate_source",
    "sync_test_registry_sources",
    "test_record_by_id",
    "test_record_by_name",
    "test_registry",
]
