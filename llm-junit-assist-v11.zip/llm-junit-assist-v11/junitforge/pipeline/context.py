"""Target environment, test identity, classpath, and destination helpers."""

from __future__ import annotations

import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.audit.console import stage as console_stage
from junitforge.audit.recorder import sha256_text
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get

log = get("junitforge.loop")


@dataclass(slots=True)
class PreparedTarget:
    outcome: TargetOutcome
    symbol: ClassSymbol | None = None
    module: ModuleInfo | None = None
    test_path: Path | None = None
    context: GenerationContext | None = None
    terminal: bool = False


def parse_target_source(engine, source_path: Path):
    """Parse one selected target through the configured lazy resolver or fallback parser."""
    started = perf_counter()
    started_at = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()
    console_stage("PARSE", "%s started", source_path.name)
    try:
        if engine.symbol_resolver is not None and hasattr(engine.symbol_resolver, "parse_target"):
            source_file = engine.symbol_resolver.parse_target(source_path)
        else:
            source_file = parse_file(source_path)
    except Exception as exc:
        console_stage("PARSE", "%s failed | reason=%s", source_path.name, str(exc)[:180], level="error")
        engine.audit.write_json(source_path.stem, "01-parse/summary.json", {
            "source_file": str(source_path),
            "target_class": source_path.stem,
            "success": False,
            "main_java_type_found": False,
            "failure_reason": str(exc),
            "elapsed_seconds": perf_counter() - started,
        })
        raise
    elapsed = perf_counter() - started
    engine._last_parse_audit = {
        "started_at": started_at,
        "completed_at": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
        "elapsed_seconds": elapsed,
    }
    console_stage("PARSE", "%s completed | elapsed=%.2fs", source_path.name, elapsed)
    return source_file


def resolve_test_destination(engine, source_path: Path, module: ModuleInfo, symbol: ClassSymbol, outcome: TargetOutcome):
    """Resolve package, class name, output path, overwrite, and side-by-side naming."""
    test_package = test_package_for(symbol)
    test_class = f"{symbol.name}Test"
    test_path = engine.test_path_fn(source_path, module, symbol)
    existing = test_path.exists()
    original_preserved = existing
    side_by_side = False
    if existing and not engine.cfg.overwrite:
        outcome.status = "skipped"
        outcome.notes.append("test exists (use --overwrite)")
        outcome.test_path = str(test_path)
        console_stage("DESTINATION", "skipped | reason=test already exists and overwrite is disabled")
        engine.audit.write_json(symbol.name, "03-destination/summary.json", {
            "test_package": test_package,
            "test_class": test_class,
            "test_fqcn": f"{test_package}.{test_class}" if test_package else test_class,
            "test_path": str(test_path),
            "existing_test_present": True,
            "overwrite_enabled": False,
            "side_by_side_class_selected": False,
            "original_source_preserved": True,
        })
        return test_package, test_class, test_path, True
    if existing and engine.cfg.overwrite:
        test_class = f"{symbol.name}JfTest"
        test_path = test_path.parent / f"{test_class}.java"
        side_by_side = True
        outcome.notes.append(f"existing test preserved; generated side-by-side as {test_class}")
        console_stage("DESTINATION", "existing test preserved | generated_class=%s", test_class)
    else:
        display_path = str(test_path)
        try:
            display_path = str(test_path.relative_to(engine.repo_root))
        except ValueError:
            pass
        console_stage("DESTINATION", "class=%s | path=%s", test_class, display_path)
    outcome.test_path = str(test_path)
    engine.audit.write_json(symbol.name, "03-destination/summary.json", {
        "test_package": test_package,
        "test_class": test_class,
        "test_fqcn": f"{test_package}.{test_class}" if test_package else test_class,
        "test_path": str(test_path),
        "existing_test_present": existing,
        "overwrite_enabled": bool(engine.cfg.overwrite),
        "side_by_side_class_selected": side_by_side,
        "original_source_preserved": original_preserved,
    })
    return test_package, test_class, test_path, False


def write_context_diagnostics(engine, symbol: ClassSymbol, execution_context, outcome: TargetOutcome) -> None:
    """Write the existing execution, schema, and fixture reports without changing failure semantics."""
    if execution_context is None:
        return
    diagnostic_name = symbol.fqcn.replace(".", "_") + ".json"
    diagnostic_path = engine.repo_root / "reports" / "execution-context" / diagnostic_name
    try:
        write_execution_context_json(execution_context, diagnostic_path)
        schema_path = engine.repo_root / "reports" / "schema-catalog" / diagnostic_name
        fixture_path = engine.repo_root / "reports" / "fixture-catalog" / diagnostic_name
        write_schema_catalog_json(execution_context, schema_path)
        write_fixture_catalog_json(execution_context, fixture_path)
        outcome.notes.append(f"execution context: {execution_context.extraction_status.value}")
        outcome.notes.append(f"schema catalog: {schema_path}")
        outcome.notes.append(f"fixture catalog: {fixture_path}")
    except Exception as exc:  # noqa: BLE001
        log.warning("Could not write execution context for %s: %s", symbol.fqcn, exc)


def build_pipeline_context(
    engine,
    *,
    source_file,
    source_path: Path,
    symbol: ClassSymbol,
    module: ModuleInfo,
    classpath,
    template,
    test_package: str,
    test_class: str,
    outcome: TargetOutcome,
) -> GenerationContext:
    """Resolve collaborators, execution facts, diagnostics, and the GenerationContext."""
    started = perf_counter()
    collaborators = resolve_collaborators(symbol, engine.lookup)
    elapsed = perf_counter() - started
    # Collaborator contracts are stored in ``Collaborator.signatures``.  The
    # historical ``methods`` lookup marked every resolved collaborator as
    # unresolved even when exact signatures had already been extracted.
    unresolved = [item for item in collaborators if not getattr(item, "signatures", ())]
    console_stage("COLLABORATORS", "resolved=%d | unresolved=%d", len(collaborators) - len(unresolved), len(unresolved))
    engine.audit.write_json(symbol.name, "04-context/collaborators.json", {
        "resolved_count": len(collaborators) - len(unresolved),
        "unresolved_count": len(unresolved),
        "collaborators": collaborators,
        "elapsed_seconds": elapsed,
    })

    execution_target = classify_execution_target(symbol)
    started = perf_counter()
    console_stage("EXECUTION_CONTEXT", "started")
    with heartbeat("engine.execution_context", interval_seconds=90.0, target=symbol.name):
        execution_context = build_execution_context(
            source_file=source_file,
            symbol=symbol,
            lookup=engine.lookup,
            target_kind=execution_target,
            configuration_values=engine.configuration_values,
            schema_lookup=(
                engine.symbol_resolver.lookup_context
                if engine.symbol_resolver is not None and hasattr(engine.symbol_resolver, "lookup_context")
                else engine.lookup
            ),
        )
    elapsed = perf_counter() - started
    methods_count = len(execution_context.methods) if execution_context else 0
    schemas_count = len(execution_context.payload_schemas) if execution_context else 0
    fixtures_count = len(getattr(execution_context, "fixtures", ()) or ()) if execution_context else 0
    helpers = sum(len(getattr(method, "reachable_private_methods", ()) or ()) for method in (execution_context.methods if execution_context else ()))
    branches = sum(len(getattr(method, "branches", ()) or ()) for method in (execution_context.methods if execution_context else ()))
    console_stage("EXECUTION_CONTEXT", "entry_methods=%d | reachable_helpers=%d | branches=%d | fixtures=%d", methods_count, helpers, branches, fixtures_count)
    console_stage("EXECUTION_CONTEXT", "completed | elapsed=%.2fs", elapsed)
    write_context_diagnostics(engine, symbol, execution_context, outcome)
    engine.audit.write_json(symbol.name, "04-context/execution-context-summary.json", {
        "entry_methods": methods_count,
        "reachable_helper_count": helpers,
        "branch_count": branches,
        "fixture_count": fixtures_count,
        "schema_count": schemas_count,
        "context_completeness": getattr(getattr(execution_context, "extraction_status", None), "value", None),
        "elapsed_seconds": elapsed,
        "existing_reports": [note for note in outcome.notes if "catalog:" in note or "execution context:" in note],
    })

    started = perf_counter()
    context = build_context(
        source_file=source_file,
        symbol=symbol,
        collaborators=collaborators,
        test_package=test_package,
        test_class_name=test_class,
        stack=engine.stack,
        classpath=classpath,
        template=template,
        source_path=source_path,
        execution_context=execution_context,
    )
    elapsed = perf_counter() - started
    console_stage(
        "GENERATION_CONTEXT",
        "completed | target=%s | methods=%d | collaborators=%d | fixtures=%d",
        symbol.name,
        len(execution_context.methods) if execution_context else 0,
        len(collaborators),
        fixtures_count,
    )
    engine.audit.write_json(symbol.name, "04-context/generation-context-summary.json", {
        "target_identity": symbol.fqcn,
        "target_kind": execution_target.value,
        "template": getattr(template.kind, "value", str(template.kind)),
        "method_count": len(execution_context.methods) if execution_context else 0,
        "collaborator_count": len(collaborators),
        "fixture_count": fixtures_count,
        "test_package": test_package,
        "test_class": test_class,
        "source_hash": sha256_text(source_file.source),
        "completion_status": "completed",
        "elapsed_seconds": elapsed,
    })
    return context


def prepare_target(engine, source_path: Path) -> PreparedTarget:
    """Prepare all verified per-target facts and return early-stage terminal outcomes explicitly."""
    from junitforge.pipeline.result import create_target_outcome

    source_file = parse_target_source(engine, source_path)
    symbol = source_file.primary_type
    module = module_for_source(engine.modules, source_path)
    outcome = create_target_outcome(
        fqcn=(symbol.fqcn if symbol else source_path.stem),
        module=(module.name if module else ""),
        source_path=str(source_path),
    )
    target_name = symbol.name if symbol else source_path.stem
    engine.audit.register_target(target_name, source_path)
    source_lines = len(source_file.source.splitlines())
    console_stage(
        "SOURCE_FILE_INFO",
        "file=%s | module=%s | package=%s | size=%d lines | target=%s",
        source_path.name,
        module.name if module else "unresolved",
        symbol.fqcn.rpartition(".")[0] if symbol else "",
        source_lines,
        target_name,
    )
    engine.audit.write_json(target_name, "01-parse/summary.json", {
        "source_file": str(source_path),
        "target_class": target_name,
        "package": symbol.fqcn.rpartition(".")[0] if symbol else "",
        "module": module.name if module else "",
        **getattr(engine, "_last_parse_audit", {}),
        "success": symbol is not None,
        "main_java_type_found": symbol is not None,
        "failure_reason": None if symbol is not None else "no main Java type found",
    })

    ok, why = is_test_target(source_file)
    if not ok or symbol is None or module is None:
        outcome.status, outcome.testable, outcome.classification = "skipped", False, "n/a"
        outcome.notes.append(why if not ok else "no module/type")
        return PreparedTarget(outcome=outcome, symbol=symbol, module=module, terminal=True)

    classpath = engine._classpath_profile(module)
    template = classify(symbol, engine.stack, classpath)
    outcome.classification = template.kind.value
    generation_mode = "method-wise" if template.kind.value in {"service-impl", "controller"} else "class-wide"
    console_stage("CLASSIFY", "%s | kind=%s | generation=%s", symbol.name, template.kind.value, generation_mode)
    engine.audit.write_json(symbol.name, "02-classification/summary.json", {
        "target_class": symbol.name,
        "target_kind": template.kind.value,
        "generation_mode": generation_mode,
        "selected_template": template,
        "testable": template.testable,
        "final_reason": list(template.reasons),
    })
    if not template.testable:
        outcome.status, outcome.testable = "integration_only", False
        outcome.notes.extend(template.reasons)
        return PreparedTarget(outcome=outcome, symbol=symbol, module=module, terminal=True)
    if not classpath.has_junit_jupiter:
        outcome.status, outcome.testable = "skipped", False
        outcome.notes.append(
            f"module '{module.name}' has no JUnit on its test classpath "
            "(add spring-boot-starter-test to generate tests here)"
        )
        return PreparedTarget(outcome=outcome, symbol=symbol, module=module, terminal=True)

    test_package, test_class, test_path, terminal = resolve_test_destination(
        engine, source_path, module, symbol, outcome
    )
    if terminal:
        return PreparedTarget(
            outcome=outcome,
            symbol=symbol,
            module=module,
            test_path=test_path,
            terminal=True,
        )

    context = build_pipeline_context(
        engine,
        source_file=source_file,
        source_path=source_path,
        symbol=symbol,
        module=module,
        classpath=classpath,
        template=template,
        test_package=test_package,
        test_class=test_class,
        outcome=outcome,
    )
    return PreparedTarget(
        outcome=outcome,
        symbol=symbol,
        module=module,
        test_path=test_path,
        context=context,
        terminal=False,
    )


class PipelineContextMixin:
    @staticmethod
    def _test_fqcn(ctx) -> str:
        return f"{ctx.test_package}.{ctx.test_class_name}" if ctx.test_package else ctx.test_class_name

    def _classpath_profile(self, module: ModuleInfo):
        """Prefer the resolved test classpath (accurate slice/junit detection);
        fall back to scanning pom artifacts when the compile gate is unavailable."""
        bm = self.stack.boot_major
        if self.compile_gate.ready:
            prof = from_classpath_string(self.compile_gate.classpath_for(module.name), boot_major=bm)
            if any(".jar" in e for e in prof.entries):
                return prof
        return from_pom_artifacts(self.repo_root, module.root, boot_major=bm)
