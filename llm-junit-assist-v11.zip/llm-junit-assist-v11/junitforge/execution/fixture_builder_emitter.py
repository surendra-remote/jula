"""Deterministic reusable Java fixture emission.

The emitter consumes the parser-built class-level schema catalog. It never
invents fields or accessors and emits only construction mechanisms verified by
that catalog. Unsupported schemas remain visible through diagnostics instead of
silently producing shallow objects.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, replace
from typing import Iterable

from junitforge.execution.models import (
    ConstructionKind,
    FixtureSpec,
    MapEntrySchema,
    MapSchema,
    PayloadProperty,
    PayloadSchema,
    PropertyKind,
    ResolutionStatus,
)


def _simple(type_name: str | None) -> str:
    text = (type_name or "Object").strip().replace("...", "")
    return text.rsplit(".", 1)[-1]


def _raw_simple(type_name: str | None) -> str:
    return _simple((type_name or "Object").split("<", 1)[0].replace("[]", ""))


def _cap(value: str) -> str:
    return value[:1].upper() + value[1:] if value else value


def _safe_identifier(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_$]", "", value)
    if not cleaned:
        return "Fixture"
    return cleaned if cleaned[0].isalpha() or cleaned[0] in "_$" else f"T{cleaned}"


@dataclass(slots=True)
class EmittedFixtures:
    helpers: list[str] = field(default_factory=list)
    fixtures: list[FixtureSpec] = field(default_factory=list)
    imports: set[str] = field(default_factory=set)
    diagnostics: list[str] = field(default_factory=list)
    back_edges: list[tuple[str, str]] = field(default_factory=list)


class FixtureBuilderEmitter:
    def __init__(self, schemas: Iterable[PayloadSchema], map_schemas: Iterable[MapSchema] = ()):
        self.schemas = list(schemas)
        self.map_schemas = list(map_schemas)
        self.by_id: dict[str, PayloadSchema] = {}
        self.by_name: dict[str, PayloadSchema] = {}
        for schema in self.schemas:
            sid = schema.fqcn or schema.type_name
            self.by_id[sid] = schema
            self.by_name.setdefault(schema.type_name, schema)
            if schema.fqcn:
                self.by_name.setdefault(schema.fqcn, schema)
        self.map_by_id = {m.schema_id: m for m in self.map_schemas}
        self.imports: set[str] = set()
        self.diagnostics: list[str] = []
        self.back_edges: list[tuple[str, str]] = []
        self._method_name: dict[str, str] = {}
        self._used_names: set[str] = set()
        self._duplicate_simple = {
            name for name in {s.type_name for s in self.schemas}
            if sum(1 for s in self.schemas if s.type_name == name and s.fqcn) > 1
        }
        self._blocked_edges: set[tuple[str, str]] = set()

    @staticmethod
    def _edge_priority(prop: PayloadProperty) -> tuple[int, int, int]:
        """Higher values are more important to preserve in a bounded graph."""
        return (
            1 if prop.baseline_required else 0,
            int(prop.minimum_size or 0),
            1 if not prop.nullable else 0,
        )

    def _schema_edges(self):
        edges = []
        for schema in self.schemas:
            owner_id = schema.fqcn or schema.type_name
            for prop in schema.properties:
                for ref in prop.nested_schema_refs[:1]:
                    child = self.by_id.get(ref) or self.by_name.get(ref) or self.by_name.get(_simple(ref))
                    if child is None or child.kind == "enum":
                        continue
                    child_id = child.fqcn or child.type_name
                    edges.append((owner_id, prop.name, child_id, self._edge_priority(prop), prop))
        return edges

    def _find_cycle(self, edges):
        adjacency: dict[str, list[tuple]] = {}
        for edge in edges:
            if (edge[0], edge[1]) in self._blocked_edges:
                continue
            adjacency.setdefault(edge[0], []).append(edge)
        state: dict[str, int] = {}
        stack_nodes: list[str] = []
        stack_edges: list[tuple] = []

        def visit(node: str):
            state[node] = 1
            stack_nodes.append(node)
            for edge in adjacency.get(node, ()):
                child = edge[2]
                if state.get(child, 0) == 0:
                    stack_edges.append(edge)
                    found = visit(child)
                    if found:
                        return found
                    stack_edges.pop()
                elif state.get(child) == 1:
                    try:
                        index = stack_nodes.index(child)
                    except ValueError:
                        index = 0
                    return stack_edges[index:] + [edge]
            stack_nodes.pop()
            state[node] = 2
            return None

        for node in sorted(adjacency):
            if state.get(node, 0) == 0:
                found = visit(node)
                if found:
                    return found
        return None

    def _plan_cycle_breaks(self) -> None:
        """Break only the least-required edge of each reachable schema cycle.

        v10.2 removed a forward relationship whenever the child could reach the
        owner, which discarded required graphs such as GiPolicy -> GiPerson.
        v11 preserves baseline-required/minimum-size edges and omits the least
        important reverse edge instead.
        """
        edges = self._schema_edges()
        while True:
            cycle = self._find_cycle(edges)
            if not cycle:
                return
            # Lowest priority is removed.  On ties remove the last/back edge so
            # the earlier/root relationship remains populated.
            selected = min(
                enumerate(cycle),
                key=lambda item: (item[1][3], -item[0]),
            )[1]
            owner_id, prop_name, child_id, priority, prop = selected
            self._blocked_edges.add((owner_id, prop_name))
            owner = self.by_id.get(owner_id) or self.by_name.get(owner_id)
            owner_name = owner.type_name if owner else _simple(owner_id)
            marker = "required cycle edge" if prop.baseline_required or prop.minimum_size > 0 else "cycle back-reference"
            message = f"{marker} omitted to bound fixture graph: {owner_name}.{prop_name} -> {_simple(child_id)}"
            self.diagnostics.append(message)
            self.back_edges.append((owner_id, prop_name))

    def emit_all(self) -> EmittedFixtures:
        self._plan_cycle_breaks()
        helpers: list[str] = []
        fixtures: list[FixtureSpec] = []
        emitted: set[str] = set()

        def visit_schema(schema_id: str, stack: tuple[str, ...] = ()) -> None:
            if schema_id in emitted:
                return
            schema = self.by_id.get(schema_id) or self.by_name.get(schema_id)
            if schema is None:
                return
            sid = schema.fqcn or schema.type_name
            if sid in stack:
                return
            for prop in schema.properties:
                for ref in prop.nested_schema_refs:
                    child = self.by_id.get(ref) or self.by_name.get(ref) or self.by_name.get(_simple(ref))
                    if child and child.kind != "enum":
                        visit_schema(child.fqcn or child.type_name, (*stack, sid))
            spec = self._emit_schema(schema)
            emitted.add(sid)
            fixtures.append(spec)
            if spec.supported and spec.method_source:
                helpers.append(spec.method_source)

        for schema in sorted(self.schemas, key=lambda s: (s.depth, s.fqcn or s.type_name), reverse=True):
            if schema.kind != "enum":
                visit_schema(schema.fqcn or schema.type_name)

        emitted_maps: set[str] = set()

        def visit_map(schema_id: str, stack: tuple[str, ...] = ()) -> None:
            if schema_id in emitted_maps or schema_id in stack:
                return
            schema = self.map_by_id.get(schema_id)
            if schema is None:
                return
            for entry in schema.entries:
                if entry.nested_schema_id:
                    visit_map(entry.nested_schema_id, (*stack, schema_id))
            spec = self._emit_map(schema)
            emitted_maps.add(schema_id)
            fixtures.append(spec)
            if spec.supported and spec.method_source:
                helpers.append(spec.method_source)

        for schema in self.map_schemas:
            visit_map(schema.schema_id)

        return EmittedFixtures(
            helpers=helpers,
            fixtures=fixtures,
            imports=set(self.imports),
            diagnostics=list(dict.fromkeys(self.diagnostics)),
            back_edges=list(self.back_edges),
        )

    def _schema_method_name(self, schema: PayloadSchema) -> str:
        sid = schema.fqcn or schema.type_name
        if sid in self._method_name:
            return self._method_name[sid]
        base = schema.fixture_method_name or f"valid{_safe_identifier(schema.type_name)}"
        if schema.type_name in self._duplicate_simple and schema.package_name:
            base += _safe_identifier(schema.package_name.rsplit(".", 1)[-1])
        name = base
        suffix = 2
        while name in self._used_names:
            name = f"{base}{suffix}"
            suffix += 1
        self._used_names.add(name)
        self._method_name[sid] = name
        return name

    def _map_method_name(self, schema: MapSchema) -> str:
        key = schema.schema_id
        if key in self._method_name:
            return self._method_name[key]
        base = schema.fixture_method_name or f"valid{_safe_identifier(schema.semantic_name)}"
        name = base
        suffix = 2
        while name in self._used_names:
            name = f"{base}{suffix}"
            suffix += 1
        self._used_names.add(name)
        self._method_name[key] = name
        return name

    def _type_ref(self, schema: PayloadSchema) -> str:
        if schema.type_name in self._duplicate_simple and schema.fqcn:
            return schema.fqcn
        return schema.type_name

    def _emit_schema(self, schema: PayloadSchema) -> FixtureSpec:
        sid = schema.fqcn or schema.type_name
        method_name = self._schema_method_name(schema)
        type_ref = self._type_ref(schema)
        diagnostics = list(schema.diagnostics)
        if schema.resolution_status != ResolutionStatus.RESOLVED:
            diagnostics.append("schema unresolved")
        if schema.kind == "enum" or schema.construction_kind == ConstructionKind.ENUM:
            return FixtureSpec(sid, method_name, type_ref, sid, supported=False, diagnostics=("enum schemas use constants, not fixture methods",))
        if schema.construction_kind == ConstructionKind.UNSUPPORTED:
            diagnostics.append(f"unsupported construction kind for {type_ref}")
            return FixtureSpec(sid, method_name, type_ref, sid, supported=False, diagnostics=tuple(diagnostics))

        dependencies: list[str] = []
        stack = (sid,)
        prop_values: dict[str, str] = {}
        for prop in schema.properties:
            value = self._value_expr(schema, prop, stack)
            if value is None:
                continue
            prop_values[prop.name] = value
            for ref in prop.nested_schema_refs:
                child = self.by_id.get(ref) or self.by_name.get(ref) or self.by_name.get(_simple(ref))
                if child and child.kind != "enum" and child.construction_kind != ConstructionKind.UNSUPPORTED:
                    dep = child.fqcn or child.type_name
                    if dep not in dependencies:
                        dependencies.append(dep)

        var = re.sub(r"[^A-Za-z0-9_$]", "", schema.type_name[:1].lower() + schema.type_name[1:]) or "value"
        lines = [f"    private {type_ref} {method_name}() {{"]
        if schema.construction_kind == ConstructionKind.BUILDER:
            lines.append(f"        {type_ref} {var} = {type_ref}.builder()")
            builder_count = 0
            for prop in schema.properties:
                value = prop_values.get(prop.name)
                if value is None or not prop.builder_method:
                    continue
                lines.append(f"                .{prop.builder_method}({value})")
                builder_count += 1
            lines.append("                .build();")
            # Verified setters can fill properties excluded from the builder.
            for prop in schema.properties:
                value = prop_values.get(prop.name)
                if value is not None and prop.setter and not prop.builder_method:
                    lines.append(f"        {var}.{prop.setter}({value});")
            if builder_count == 0:
                diagnostics.append("builder detected but no verified builder properties")
        elif schema.construction_kind in {ConstructionKind.CONSTRUCTOR, ConstructionKind.RECORD}:
            values: list[str] = []
            for ptype, pname in schema.constructor_parameters:
                value = prop_values.get(pname)
                if value is None:
                    value = self._scalar_literal(schema.type_name, pname, ptype, ())
                values.append(value)
            lines.append(f"        {type_ref} {var} = new {type_ref}({', '.join(values)});")
            if schema.construction_kind == ConstructionKind.CONSTRUCTOR:
                ctor_names = {name for _, name in schema.constructor_parameters}
                for prop in schema.properties:
                    value = prop_values.get(prop.name)
                    if value is None or prop.name in ctor_names:
                        continue
                    if prop.setter:
                        lines.append(f"        {var}.{prop.setter}({value});")
                    elif prop.field_public:
                        lines.append(f"        {var}.{prop.name} = {value};")
        else:
            lines.append(f"        {type_ref} {var} = new {type_ref}();")
            for prop in schema.properties:
                value = prop_values.get(prop.name)
                if value is None:
                    continue
                if prop.setter:
                    lines.append(f"        {var}.{prop.setter}({value});")
                elif prop.field_public:
                    lines.append(f"        {var}.{prop.name} = {value};")
                elif prop.constructor_index is None:
                    diagnostics.append(f"unwritable property omitted: {schema.type_name}.{prop.name}")
        lines.extend((f"        return {var};", "    }"))
        source = "\n".join(lines)
        return FixtureSpec(
            fixture_id=sid,
            method_name=method_name,
            return_type=type_ref,
            schema_id=sid,
            dependent_fixture_ids=tuple(dependencies),
            imports=tuple(sorted(self.imports)),
            method_source=source,
            supported=True,
            diagnostics=tuple(dict.fromkeys(diagnostics)),
        )

    def _value_expr(self, owner: PayloadSchema, prop: PayloadProperty, stack: tuple[str, ...]) -> str | None:
        refs = prop.nested_schema_refs
        child = None
        if refs:
            child = self.by_id.get(refs[0]) or self.by_name.get(refs[0]) or self.by_name.get(_simple(refs[0]))
        owner_id = owner.fqcn or owner.type_name
        child_id = (child.fqcn or child.type_name) if child else None
        if (owner_id, prop.name) in self._blocked_edges or (child and child_id in stack):
            if (owner_id, prop.name) not in self._blocked_edges:
                self.back_edges.append((owner_id, prop.name))
                self.diagnostics.append(f"cycle back-reference left unset: {owner.type_name}.{prop.name}")
            return None

        if prop.baseline_value:
            return prop.baseline_value
        # An explicit Java ``= null`` initializer describes the production
        # default, not a valid test baseline.  When the parser has resolved a
        # constructible nested schema, hydrate it instead of preserving null.
        # Non-null scalar initializers remain useful deterministic values.
        if (
            prop.default_initializer
            and prop.default_initializer.strip() != "null"
            and self._safe_initializer(prop.default_initializer)
        ):
            return prop.default_initializer
        if prop.kind == PropertyKind.ENUM:
            constants = prop.enum_constants or (child.enum_constants if child else ())
            if constants:
                type_ref = self._type_ref(child) if child else _raw_simple(prop.type_name)
                return f"{type_ref}.{constants[0]}"
            self.diagnostics.append(f"enum constant unresolved: {owner.type_name}.{prop.name}")
            return None
        if prop.kind == PropertyKind.OBJECT:
            if child and child.construction_kind != ConstructionKind.UNSUPPORTED and child.kind != "enum":
                return f"{self._schema_method_name(child)}()"
            if child and child.kind == "enum" and child.enum_constants:
                return f"{self._type_ref(child)}.{child.enum_constants[0]}"
            return self._scalar_literal(owner.type_name, prop.name, prop.type_name, prop.enum_constants)
        if prop.kind in {PropertyKind.PRIMITIVE, PropertyKind.SCALAR, PropertyKind.TEMPORAL}:
            return self._scalar_literal(owner.type_name, prop.name, prop.type_name, prop.enum_constants)
        if prop.kind in {PropertyKind.LIST, PropertyKind.COLLECTION}:
            self.imports.update({"java.util.ArrayList", "java.util.List"})
            element = self._element_expr(owner, prop, child, stack)
            return "new ArrayList<>()" if element is None else self._collection_expr("ArrayList", element, prop.minimum_size)
        if prop.kind == PropertyKind.SET:
            self.imports.update({"java.util.LinkedHashSet", "java.util.List"})
            element = self._element_expr(owner, prop, child, stack)
            return "new LinkedHashSet<>()" if element is None else self._collection_expr("LinkedHashSet", element, prop.minimum_size)
        if prop.kind == PropertyKind.MAP:
            self.imports.add("java.util.LinkedHashMap")
            return "new LinkedHashMap<>()"
        if prop.kind == PropertyKind.OPTIONAL:
            self.imports.add("java.util.Optional")
            inner = self._wrapped_expr(owner, prop, child, stack)
            return "Optional.empty()" if inner is None else f"Optional.of({inner})"
        if prop.kind == PropertyKind.RESPONSE_ENTITY:
            self.imports.add("org.springframework.http.ResponseEntity")
            inner = self._wrapped_expr(owner, prop, child, stack)
            return "ResponseEntity.ok().build()" if inner is None else f"ResponseEntity.ok({inner})"
        if prop.kind == PropertyKind.PAGE:
            self.imports.update({"java.util.ArrayList", "java.util.List", "org.springframework.data.domain.PageImpl"})
            inner = self._element_expr(owner, prop, child, stack)
            return "new PageImpl<>(new ArrayList<>())" if inner is None else f"new PageImpl<>({self._collection_expr('ArrayList', inner, prop.minimum_size)})"
        if prop.kind == PropertyKind.ARRAY:
            component = prop.array_component_type or "Object"
            inner = self._element_expr(owner, prop, child, stack)
            if inner is None:
                return f"new {_raw_simple(component)}[0]"
            count = max(1, prop.minimum_size)
            return f"new {_raw_simple(component)}[] {{{', '.join(inner for _ in range(count))}}}"
        if prop.kind == PropertyKind.WRAPPER:
            raw = _raw_simple(prop.type_name)
            inner = self._wrapped_expr(owner, prop, child, stack)
            if raw == "CompletableFuture":
                self.imports.add("java.util.concurrent.CompletableFuture")
                return "CompletableFuture.completedFuture(null)" if inner is None else f"CompletableFuture.completedFuture({inner})"
            if raw == "Mono":
                return "Mono.empty()" if inner is None else f"Mono.just({inner})"
            if raw == "Flux":
                return "Flux.empty()" if inner is None else f"Flux.just({inner})"
        return None

    @staticmethod
    def _collection_expr(kind: str, element: str, minimum_size: int) -> str:
        count = max(1, minimum_size)
        values = ", ".join(element for _ in range(count))
        return f"new {kind}<>(List.of({values}))"

    def _element_expr(self, owner: PayloadSchema, prop: PayloadProperty, child: PayloadSchema | None, stack: tuple[str, ...]) -> str | None:
        if child:
            if child.kind == "enum" and child.enum_constants:
                return f"{self._type_ref(child)}.{child.enum_constants[0]}"
            if child.construction_kind != ConstructionKind.UNSUPPORTED:
                return f"{self._schema_method_name(child)}()"
        element_type = prop.element_type or prop.array_component_type
        if element_type:
            return self._scalar_literal(owner.type_name, prop.name, element_type, prop.enum_constants)
        return None

    def _wrapped_expr(self, owner: PayloadSchema, prop: PayloadProperty, child: PayloadSchema | None, stack: tuple[str, ...]) -> str | None:
        if child:
            if child.kind == "enum" and child.enum_constants:
                return f"{self._type_ref(child)}.{child.enum_constants[0]}"
            if child.construction_kind != ConstructionKind.UNSUPPORTED:
                return f"{self._schema_method_name(child)}()"
        if prop.wrapped_type:
            return self._scalar_literal(owner.type_name, prop.name, prop.wrapped_type, prop.enum_constants)
        return None

    def _would_cycle(self, start_id: str | None, target_id: str, seen: set[str] | None = None) -> bool:
        if not start_id:
            return False
        if start_id == target_id:
            return True
        seen = set() if seen is None else seen
        if start_id in seen:
            return False
        seen.add(start_id)
        schema = self.by_id.get(start_id) or self.by_name.get(start_id) or self.by_name.get(_simple(start_id))
        if schema is None:
            return False
        for prop in schema.properties:
            for ref in prop.nested_schema_refs:
                child = self.by_id.get(ref) or self.by_name.get(ref) or self.by_name.get(_simple(ref))
                child_id = (child.fqcn or child.type_name) if child else ref
                if child_id == target_id or self._would_cycle(child_id, target_id, seen):
                    return True
        return False

    @staticmethod
    def _safe_initializer(value: str) -> bool:
        text = value.strip()
        return bool(re.fullmatch(r"(?:true|false|null|-?\d+(?:\.\d+)?[fFdDlL]?|'(?:\\.|[^'])'|\"(?:\\.|[^\"])*\")", text))

    def _scalar_literal(self, owner: str, field_name: str, java_type: str, enum_constants: tuple[str, ...]) -> str:
        simple = _raw_simple(java_type)
        lowered = field_name.lower()
        if enum_constants:
            return f"{simple}.{enum_constants[0]}"
        if simple in {"boolean", "Boolean"}:
            return "false"
        # Java permits constant narrowing in assignments, but not in method
        # invocation conversion.  Generated fixture values are passed to setter
        # methods, so byte/short arguments require explicit casts.  The same
        # primitive literals also box correctly for Byte/Short parameters.
        if simple in {"byte", "Byte"}:
            return "(byte) 1"
        if simple in {"short", "Short"}:
            return "(short) 1"
        if simple in {"int", "Integer"}:
            return "1"
        if simple in {"long", "Long"}:
            return "1L"
        if simple in {"float", "Float"}:
            return "1.0f"
        if simple in {"double", "Double"}:
            return "1.0d"
        if simple in {"char", "Character"}:
            return "'A'"
        if simple == "BigDecimal":
            self.imports.add("java.math.BigDecimal")
            return 'new BigDecimal("100.00")'
        if simple == "BigInteger":
            self.imports.add("java.math.BigInteger")
            return "BigInteger.ONE"
        if simple == "UUID":
            self.imports.add("java.util.UUID")
            return 'UUID.fromString("00000000-0000-0000-0000-000000000001")'
        if simple == "LocalDate":
            self.imports.add("java.time.LocalDate")
            return "LocalDate.of(2020, 1, 1)"
        if simple == "LocalDateTime":
            self.imports.add("java.time.LocalDateTime")
            return "LocalDateTime.of(2020, 1, 1, 0, 0)"
        if simple == "LocalTime":
            self.imports.add("java.time.LocalTime")
            return "LocalTime.NOON"
        if simple == "Instant":
            self.imports.add("java.time.Instant")
            return "Instant.EPOCH"
        if simple == "Date":
            self.imports.add("java.util.Date")
            return "new Date(0L)"
        if simple == "String":
            if "email" in lowered:
                value = "test@example.com"
            elif any(x in lowered for x in ("dob", "birthdate", "birth_date")):
                value = "1990-01-01"
            elif "date" in lowered or lowered.endswith("from") or lowered.endswith("to"):
                value = "2020-01-01"
            elif "gender" in lowered:
                value = "M"
            elif "country" in lowered or "nationality" in lowered:
                value = "SG"
            elif "postal" in lowered or "zipcode" in lowered:
                value = "123456"
            elif any(x in lowered for x in ("phone", "mobile", "contactvalue")):
                value = "91234567"
            elif "url" in lowered:
                value = "https://example.test"
            elif "name" in lowered:
                value = "Test Name"
            elif "code" in lowered or "ref" in lowered:
                value = "CODE1"
            elif lowered.endswith("no") or lowered.endswith("number"):
                value = "NO123"
            elif lowered.endswith("id"):
                value = "ID123"
            elif "type" in lowered:
                value = "TYPE1"
            else:
                value = f"{field_name}-value"
            return '"' + value.replace('\\', '\\\\').replace('"', '\\"') + '"'
        # A resolved enum should have been classified earlier. Returning null for
        # unknown external leaves is explicit and reported, not hidden invention.
        self.diagnostics.append(f"no deterministic scalar value for {owner}.{field_name}: {java_type}")
        return "null"

    def _emit_map(self, schema: MapSchema) -> FixtureSpec:
        method_name = self._map_method_name(schema)
        dependencies: list[str] = []
        self.imports.update({"java.util.Map", "java.util.LinkedHashMap", "java.util.ArrayList", "java.util.List"})
        lines = [
            f"    private Map<String, Object> {method_name}() {{",
            "        Map<String, Object> value = new LinkedHashMap<>();",
        ]
        for entry in schema.entries:
            expression = self._map_entry_expr(entry)
            if entry.nested_schema_id:
                dependencies.append(entry.nested_schema_id)
            if entry.collection_element_schema_id:
                dependencies.append(entry.collection_element_schema_id)
            lines.append(f'        value.put("{entry.key_literal}", {expression});')
        lines.extend(("        return value;", "    }"))
        return FixtureSpec(
            fixture_id=schema.schema_id,
            method_name=method_name,
            return_type="Map<String, Object>",
            schema_id=schema.schema_id,
            dependent_fixture_ids=tuple(dict.fromkeys(dependencies)),
            imports=tuple(sorted(self.imports)),
            method_source="\n".join(lines),
            supported=True,
            diagnostics=() if schema.entries else ("map schema has no verified literal keys",),
        )

    def _map_entry_expr(self, entry: MapEntrySchema) -> str:
        if entry.baseline_value:
            return entry.baseline_value
        if entry.nested_schema_id and entry.nested_schema_id in self.map_by_id:
            return f"{self._map_method_name(self.map_by_id[entry.nested_schema_id])}()"
        if entry.collection_element_schema_id and entry.collection_element_schema_id in self.map_by_id:
            child = self._map_method_name(self.map_by_id[entry.collection_element_schema_id])
            return f"new ArrayList<>(List.of({child}()))"
        runtime = entry.runtime_type or "String"
        kind = entry.kind
        if kind in {PropertyKind.LIST, PropertyKind.SET, PropertyKind.COLLECTION}:
            return "new ArrayList<>()"
        if kind == PropertyKind.MAP:
            return "new LinkedHashMap<>()"
        return self._scalar_literal("Map", entry.key_literal, runtime, ())


def emit_fixture_catalog(
    schemas: Iterable[PayloadSchema],
    map_schemas: Iterable[MapSchema] = (),
) -> EmittedFixtures:
    return FixtureBuilderEmitter(schemas, map_schemas).emit_all()
