"""junitforge - standalone, coverage-driven JUnit 5 test generator.

Version 11.0 adds fixture-only ServiceImpl test setup, full semantic validation,
registry-owned focused compile/runtime repair, transactional candidate handling,
and append-only repair evidence.
"""

__version__ = "11.0"
