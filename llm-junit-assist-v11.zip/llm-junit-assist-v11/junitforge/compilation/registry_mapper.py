"""Authoritative compiler-diagnostic mapping for the v11 test registry."""

from __future__ import annotations

import re
from collections import defaultdict
from typing import Iterable

from junitforge.models import CompileError, CompileState, TargetOutcome, TestDisposition
from junitforge.pipeline.result import refresh_test_registry_ranges


_STRUCTURAL_PATTERNS = (
    "reached end of file while parsing",
    "class, interface, enum, or record expected",
    "illegal start of type",
    "'}' expected",
    "'{' expected",
)


def diagnostic_dict(error: CompileError, source: str) -> dict[str, object]:
    lines = source.splitlines()
    line = error.line
    detail = list(error.detail or ())
    expected = next(
        (item.split(":", 1)[1].strip() for item in detail if str(item).startswith("required:")),
        None,
    )
    actual = next(
        (item.split(":", 1)[1].strip() for item in detail if str(item).startswith("found:")),
        None,
    )
    return {
        "file": str(error.file or ""),
        "line": line,
        "column": error.col,
        "message": error.message,
        "source_line": lines[line - 1] if isinstance(line, int) and 0 < line <= len(lines) else None,
        "expected_type": expected,
        "actual_type": actual,
        "detail": detail,
        "raw": error.raw,
    }


def _method_ranges(source: str, name_prefix: str) -> list[tuple[int, int]]:
    """Return approximate Java method ranges for fixture/skeleton classification."""
    lines = source.splitlines()
    ranges: list[tuple[int, int]] = []
    start_re = re.compile(rf"\b(?:private|protected|public)\s+[\w<>?,.\[\]]+\s+{name_prefix}\w*\s*\(")
    for index, line in enumerate(lines, 1):
        if not start_re.search(line):
            continue
        depth = 0
        opened = False
        for end in range(index, len(lines) + 1):
            segment = lines[end - 1]
            depth += segment.count("{") - segment.count("}")
            opened = opened or "{" in segment
            if opened and depth <= 0:
                ranges.append((index, end))
                break
    return ranges


def _inside(line: int | None, ranges: Iterable[tuple[int, int]]) -> bool:
    return isinstance(line, int) and any(start <= line <= end for start, end in ranges)


def map_compile_diagnostics(
    outcome: TargetOutcome,
    source: str,
    errors: Iterable[CompileError],
    *,
    clear_previous: bool = True,
) -> dict[str, list[CompileError]]:
    """Map javac diagnostics to stable registry test IDs and classify the remainder."""
    refresh_test_registry_ranges(outcome, source)
    if clear_previous:
        outcome.class_level_compile_diagnostics.clear()
        outcome.fixture_compile_diagnostics.clear()
        outcome.skeleton_compile_diagnostics.clear()
        outcome.assembly_compile_diagnostics.clear()
        outcome.unmapped_compile_diagnostics.clear()
        for method in outcome.method_results:
            for test in method.tests:
                test.compile_diagnostics.clear()

    fixture_ranges = _method_ranges(source, "valid")
    first_test_line = min(
        (
            test.source_start_line
            for method in outcome.method_results
            for test in method.tests
            if test.source_start_line is not None
        ),
        default=None,
    )
    grouped: dict[str, list[CompileError]] = defaultdict(list)

    for error in errors:
        mapped = None
        if isinstance(error.line, int):
            for method in outcome.method_results:
                for test in method.tests:
                    if (
                        test.source_start_line is not None
                        and test.source_end_line is not None
                        and test.source_start_line <= error.line <= test.source_end_line
                    ):
                        mapped = test
                        break
                if mapped is not None:
                    break

        payload = diagnostic_dict(error, source)
        if mapped is not None:
            mapped.compile_state = CompileState.FAILED.value
            mapped.compile_attempts += 1
            mapped.compile_diagnostics.append(payload)
            grouped[mapped.test_id].append(error)
            continue

        message = (error.message or "").lower()
        if any(pattern in message for pattern in _STRUCTURAL_PATTERNS):
            outcome.assembly_compile_diagnostics.append(payload)
        elif _inside(error.line, fixture_ranges):
            outcome.fixture_compile_diagnostics.append(payload)
        elif isinstance(error.line, int) and first_test_line is not None and error.line < first_test_line:
            outcome.skeleton_compile_diagnostics.append(payload)
        elif isinstance(error.line, int):
            outcome.class_level_compile_diagnostics.append(payload)
        else:
            outcome.unmapped_compile_diagnostics.append(payload)

    for method in outcome.method_results:
        for test in method.tests:
            if (
                test.final_disposition == TestDisposition.RETAINED.value
                and not test.compile_diagnostics
                and test.compile_state not in {
                    CompileState.REPAIRED_AND_PASSED.value,
                    CompileState.REMOVED.value,
                    CompileState.REJECTED.value,
                }
            ):
                test.compile_state = CompileState.PASSED.value
    return dict(grouped)


def failed_registry_tests(outcome: TargetOutcome):
    return [
        test
        for method in outcome.method_results
        for test in method.tests
        if test.compile_state == CompileState.FAILED.value and test.compile_diagnostics
    ]


__all__ = [
    "diagnostic_dict",
    "failed_registry_tests",
    "map_compile_diagnostics",
]
