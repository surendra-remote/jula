"""Compile sequencing, focused repair, candidate acceptance, and Maven recovery."""

from __future__ import annotations

import re
import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import perf_counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from junitforge.timing import event as timing_event, heartbeat
from junitforge.audit.console import stage as console_stage
from junitforge.audit.recorder import sha256_text
from junitforge.compile_gate import CompileGate, parse_maven_compiler_errors
from junitforge.config import GenConfig
from junitforge.kb import KbIndex
from junitforge.context import build_context, collapse_ranges, slice_uncovered
from junitforge.coverage_parse import parse_jacoco_xml
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
)
from junitforge.execution.analyzer import build_execution_context
from junitforge.execution.assembly import (
    build_test_skeleton,
    deterministically_repair_compile_diagnostics,
    deterministically_repair_test,
    extract_test_method_block,
    extract_test_methods,
    focused_validation_category,
    insert_method_block,
    inject_reusable_fixtures,
    method_block_for_id,
    normalize_writable_map_mutations,
    owner_method_id_for_line,
    remove_test_method,
    replace_test_method,
    owner_method_id_for_test_name,
    replace_method_block,
    test_method_for_name,
    test_method_name_for_line,
    test_method_names,
    test_class_structure_error,
    validate_method_block,
)
from junitforge.execution.renderer import (
    write_execution_context_json,
    write_fixture_catalog_json,
    write_schema_catalog_json,
)
from junitforge.discovery import (
    is_test_target,
    module_for_source,
    test_package_for,
    test_path_for,
)
from typing import Callable as _Callable
from junitforge.models import (
    ClassSymbol,
    GenerationContext,
    MethodDisposition,
    MethodGenerationRecord,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TestCaseRecord,
    TestDisposition,
    RuntimeResultSnapshot,
)
from junitforge.parser.collaborators import resolve_collaborators
from junitforge.parser.java_symbols import parse_file
from junitforge.postprocess import finalize_java
from junitforge.prompts.augmentation import build_augmentation_messages, build_method_augmentation_messages
from junitforge.prompts.generation import build_generation_messages, build_method_generation_messages
from junitforge.prompts.repair import (
    build_compile_repair_messages,
    build_individual_test_compile_repair_messages,
    build_individual_test_validation_repair_messages,
    build_method_compile_repair_messages,
    build_method_generation_validation_repair_messages,
    build_method_runtime_repair_messages,
)
from junitforge.stack.classifier import classify, classify_execution_target
from junitforge.stack.classpath_profile import from_classpath_string, from_pom_artifacts
from junitforge.vendor.llm.base import LLMClient
from junitforge.vendor.logging_utils import get

log = get("junitforge.loop")
from junitforge.generation.response_extractor import extract_generated_tests
from junitforge.generation.response_normalizer import normalize_focused_java_response

from junitforge.compilation.candidate_validator import (
    _compile_candidate_is_strict_progress,
)
from junitforge.compilation.diagnostic_mapper import _select_method_repair_owner
from junitforge.compilation.registry_mapper import map_compile_diagnostics, failed_registry_tests
from junitforge.generation.payloads import payload_builder_for_context
from junitforge.pipeline.result import (
    commit_candidate_source,
    discard_candidate_source,
    refresh_test_registry_ranges,
    restore_test_registry,
    snapshot_test_registry,
    stage_candidate_source,
    sync_test_registry_sources,
    test_record_by_name,
)
from junitforge.runtime.state import _mark_retained_compile_state


def _audit_compile_errors(errors, source: str = ""):
    lines = source.splitlines()
    out = []
    for error in errors or ():
        line = getattr(error, "line", None)
        detail = list(getattr(error, "detail", ()) or ())
        expected = next((item.split(":", 1)[1].strip() for item in detail if str(item).startswith("required:")), None)
        actual = next((item.split(":", 1)[1].strip() for item in detail if str(item).startswith("found:")), None)
        out.append({
            "file": str(getattr(error, "file", "") or ""),
            "line": line,
            "column": getattr(error, "col", None),
            "message": getattr(error, "message", str(error)),
            "source_line": lines[line - 1] if isinstance(line, int) and 0 < line <= len(lines) else None,
            "diagnostic_kind": "compiler_error",
            "expected_type": expected,
            "actual_type": actual,
            "detail": detail,
        })
    return out


def _compile_error_signature(source: str, error) -> tuple[str, str, tuple[str, ...], str]:
    """Create a line-shift-resistant diagnostic identity for progress checks."""
    line = getattr(error, "line", None)
    lines = source.splitlines()
    source_line = (
        lines[line - 1].strip()
        if isinstance(line, int) and 0 < line <= len(lines)
        else ""
    )
    message = re.sub(r"\s+", " ", str(getattr(error, "message", "") or "")).strip()
    detail = tuple(
        re.sub(r"\s+", " ", str(item)).strip()
        for item in (getattr(error, "detail", ()) or ())
        if str(item).strip()
    )
    owner = test_method_name_for_line(source, line) or "<outside-selected-test>"
    return owner, message, detail, source_line


class CompilationRepairMixin:
    def _compile_with_repair(self, ctx: GenerationContext, test_path: Path,
                             module: ModuleInfo, outcome: TargetOutcome) -> str | None:
        """Compile once after assembly; repair only the owning method block when possible."""
        execution = ctx.execution_context
        target_kind = execution.target_kind.value if execution is not None else ""
        serviceimpl = target_kind == "service-impl"
        methodwise = target_kind in {"controller", "service-impl"}
        source = test_path.read_text(encoding="utf-8")
        started = perf_counter()
        result, errors = self._compile_candidate(test_path, module)
        elapsed = perf_counter() - started
        audit_errors = _audit_compile_errors(errors, source)
        compile_audit_index = getattr(self, "_compile_audit_index", 0) + 1
        self._compile_audit_index = compile_audit_index
        compile_audit_dir = f"08-compile/invocation-{compile_audit_index:03d}"
        command_payload = {
            "command": getattr(result, "cmd", []),
            "working_directory": str(module.root),
            "selected_test_class": ctx.test_class_name,
            "build_tool": "ant" if self.compile_gate.__class__.__name__.lower().startswith("ant") else "maven",
            "offline": self.cfg.offline,
            "elapsed_seconds": elapsed,
        }
        errors_payload = {
            "errors": audit_errors,
            "error_count": len(audit_errors),
            "truncated": False,
        }
        result_payload = {
            "success": result.ok,
            "exit_code": result.return_code,
            "error_count": len(errors),
            "source_hash": sha256_text(source),
            "test_count": len(test_method_names(source)),
            "elapsed_seconds": elapsed,
        }
        for root in (compile_audit_dir, "08-compile" if compile_audit_index == 1 else None):
            if root is None:
                continue
            self.audit.write_json(ctx.symbol.name, f"{root}/command.json", command_payload)
            self.audit.write_json(ctx.symbol.name, f"{root}/compiler-errors.json", errors_payload)
            self.audit.write_text(ctx.symbol.name, f"{root}/stdout.log", getattr(result, "stdout", "") or "")
            self.audit.write_text(ctx.symbol.name, f"{root}/stderr.log", getattr(result, "stderr", "") or "")
            self.audit.write_json(ctx.symbol.name, f"{root}/result.json", result_payload)
        if result.ok:
            _mark_retained_compile_state(outcome, "PASSED")
            sync_test_registry_sources(outcome, source, compile_state="PASSED", accepted=True)
            if outcome.method_results:
                self._write_registry_audit(ctx, outcome)
            return source

        console_stage("COMPILE", "failed | errors=%d | audit=08-compile/compiler-errors.json", len(errors), level="warning")

        if errors and all(error.file is None and error.line is None for error in errors):
            outcome.compile_errors = [error.render() for error in errors][:4]
            outcome.notes.append("non-repairable compile error (toolchain)")
            log.error(
                "[COMPILE_REPAIR] stop.non_repairable_toolchain_error | test=%s | errors=%d",
                test_path.name,
                len(errors),
            )
            return None

        if serviceimpl:
            log.debug(
                "[COMPILE_REPAIR] route.serviceimpl_registry_focused | test=%s | initial_errors=%d",
                test_path.name,
                len(errors),
            )
            return self._compile_serviceimpl_registry_repair(
                ctx, test_path, module, outcome, errors
            )

        if methodwise:
            log.debug(
                "[COMPILE_REPAIR] route.methodwise | test=%s | initial_errors=%d",
                test_path.name,
                len(errors),
            )
            return self._compile_methodwise_repair(ctx, test_path, module, outcome, errors)

        log.debug(
            "[COMPILE_REPAIR] route.classwide | test=%s | initial_errors=%d",
            test_path.name,
            len(errors),
        )
        current = test_path.read_text(encoding="utf-8")
        for attempt in range(self.cfg.max_compile_repairs):
            outcome.notes.append(f"compile repair {attempt + 1}: {len(errors)} error(s)")
            log.debug(
                "[COMPILE_REPAIR] classwide.attempt.start | attempt=%d/%d | errors_to_llm=%d",
                attempt + 1,
                self.cfg.max_compile_repairs,
                len(errors),
            )
            kb_hints = self.kb.hints_for([error.message for error in errors]) if self.kb else None
            log.debug(
                "[COMPILE_REPAIR] classwide.prompt.build | attempt=%d | kb_hints=%s | source_chars=%d",
                attempt + 1,
                bool(kb_hints),
                len(current),
            )
            builder = payload_builder_for_context(ctx)
            messages = builder.build_compile_repair_payload(ctx, current, errors, kb_hints, mode="classwide")
            log.debug(
                "[COMPILE_REPAIR] classwide.llm.start | attempt=%d/%d | diagnostics=%d",
                attempt + 1,
                self.cfg.max_compile_repairs,
                len(errors),
            )
            raw = self._chat(messages, self.cfg.temperature_repair, self.cfg.max_tokens_repair, outcome)
            candidate = inject_reusable_fixtures(raw or "", ctx)
            res = finalize_java(
                candidate, test_package=ctx.test_package, test_class_name=ctx.test_class_name,
                template=ctx.template, cut_symbol=ctx.symbol, collaborators=ctx.collaborators,
                source_imports=ctx.source_imports)
            if not res.ok or not res.code:
                log.debug(
                    "[COMPILE_REPAIR] classwide.finalize.rejected | attempt=%d/%d | reason=%s",
                    attempt + 1,
                    self.cfg.max_compile_repairs,
                    res.reason or "unknown",
                )
                continue
            current = res.code
            test_path.write_text(current, encoding="utf-8")
            log.debug(
                "[COMPILE_REPAIR] classwide.recompile.start | attempt=%d/%d | test=%s",
                attempt + 1,
                self.cfg.max_compile_repairs,
                test_path.name,
            )
            result, errors = self._compile_candidate(test_path, module)
            if result.ok:
                log.debug(
                    "[COMPILE_REPAIR] classwide.recompile.success | attempt=%d/%d | test=%s",
                    attempt + 1,
                    self.cfg.max_compile_repairs,
                    test_path.name,
                )
                return current
            log.debug(
                "[COMPILE_REPAIR] classwide.recompile.failed | attempt=%d/%d | remaining_errors=%d",
                attempt + 1,
                self.cfg.max_compile_repairs,
                len(errors),
            )
        outcome.compile_errors = [error.render() for error in errors][:12]
        log.error(
            "[COMPILE_REPAIR] exhausted | mode=classwide | test=%s | remaining_errors=%d | saved_to_outcome=%d",
            test_path.name,
            len(errors),
            len(outcome.compile_errors),
        )
        return None

    def _write_registry_audit(self, ctx: GenerationContext, outcome: TargetOutcome) -> None:
        """Persist the authoritative registry after every material state transition."""
        self.audit.write_json(
            ctx.symbol.name,
            "07-class-assembly/registry.json",
            {"methods": outcome.method_results},
        )

    def _compile_serviceimpl_registry_repair(
        self,
        ctx: GenerationContext,
        test_path: Path,
        module: ModuleInfo,
        outcome: TargetOutcome,
        errors,
    ) -> str | None:
        """Repair ServiceImpl compilation by registry-owned individual tests only.

        The complete class is compiled as the safety gate, but it is never sent to
        the LLM.  Each registry test receives at most one focused LLM repair
        candidate.  Failed candidates are rolled back immediately.
        """
        current = test_path.read_text(encoding="utf-8")
        errors = list(errors)
        map_compile_diagnostics(outcome, current, errors)
        self._write_registry_audit(ctx, outcome)

        # First apply source-backed deterministic actions across the currently
        # failing tests.  Keep only actions whose owning test no longer has a
        # compiler diagnostic after the recompile.
        baseline = current
        registry_snapshot = snapshot_test_registry(outcome)
        deterministic = self._repair_compile_diagnostics_deterministically(
            ctx,
            current,
            errors,
            outcome,
            label="serviceimpl deterministic compile repair",
        )
        if deterministic and deterministic != current:
            test_path.write_text(deterministic, encoding="utf-8")
            det_result, det_errors = self._compile_candidate(test_path, module)
            pending = getattr(self, "_last_deterministic_compile_actions", {}) or {}
            remaining_names = {
                test_method_name_for_line(deterministic, error.line)
                for error in det_errors
                if test_method_name_for_line(deterministic, error.line)
            }
            accepted_any = False
            for (owner, test_name), (actions, repaired_source) in pending.items():
                record = test_record_by_name(outcome, test_name)
                if record is None:
                    continue
                if test_name in remaining_names:
                    record.compile_state = "FAILED"
                    continue
                stage_candidate_source(outcome, test_name, repaired_source)
                commit_candidate_source(
                    outcome,
                    test_name,
                    compile_state="REPAIRED_AND_PASSED",
                )
                for sequence, action in enumerate(actions, start=1):
                    record.deterministic_repair_history.append({
                        "sequence": sequence,
                        "stage": "compile_repair",
                        "category": str(action),
                        "source_before": record.previous_accepted_source,
                        "source_after": repaired_source,
                        "authoritative_contract": "schema/execution/compiler diagnostic",
                        "result": "accepted",
                    })
                accepted_any = True
            if accepted_any or det_result.ok:
                current = deterministic
                errors = list(det_errors)
                map_compile_diagnostics(outcome, current, errors)
                self._write_registry_audit(ctx, outcome)
                if det_result.ok:
                    _mark_retained_compile_state(outcome, "PASSED")
                    sync_test_registry_sources(
                        outcome, current, compile_state="PASSED", accepted=False
                    )
                    return current
            else:
                test_path.write_text(baseline, encoding="utf-8")
                restore_test_registry(outcome, registry_snapshot)
                current = baseline

        # One focused LLM attempt per failed registry test.  Re-map after every
        # accepted candidate because source ranges are volatile.
        attempted_test_ids: set[str] = set()
        rejected_response_hashes: dict[str, set[str]] = defaultdict(set)
        while errors:
            map_compile_diagnostics(outcome, current, errors)
            failed = [
                record
                for record in failed_registry_tests(outcome)
                if record.test_id not in attempted_test_ids
            ]
            if not failed:
                break
            record = failed[0]
            attempted_test_ids.add(record.test_id)
            owner = record.owner_method_id
            selected_test = record.test_name
            record.compile_state = "LLM_REPAIR_PENDING"
            self._write_registry_audit(ctx, outcome)

            method_by_id = {
                f"{method.name}({','.join(type_name for type_name, _ in method.params)})": method
                for method in (ctx.symbol.methods or [])
            }
            context_by_id = {
                method.method_id: method
                for method in (ctx.execution_context.methods if ctx.execution_context else ())
            }
            production_method = method_by_id.get(owner)
            method_context = context_by_id.get(owner)
            block = method_block_for_id(current, owner)
            extracted = test_method_for_name(block or "", selected_test)
            selected_errors = [
                error
                for error in errors
                if test_method_name_for_line(current, error.line) == selected_test
            ]
            if production_method is None or method_context is None or extracted is None:
                record.compile_state = "REJECTED"
                record.final_rejection_reason = "focused compile-repair context missing"
                continue

            builder = payload_builder_for_context(ctx)
            messages = builder.build_compile_repair_payload(
                ctx=ctx,
                method=production_method,
                current_test=extracted.source,
                test_name=selected_test,
                errors=selected_errors,
                mode="individual",
            )
            request_serialized = repr(messages)
            request_hash = sha256_text(request_serialized)
            safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", selected_test)
            focused_attempt = 1 + sum(
                1
                for item in record.llm_repair_history
                if isinstance(item, dict) and item.get("stage") == "compile_repair"
            )
            audit_dir = f"09-compile-repair/{safe_name}/attempt-{focused_attempt:03d}"
            self.audit.write_json(ctx.symbol.name, f"{audit_dir}/request.json", {
                "request_type": "single_test_compile_repair",
                "test_id": record.test_id,
                "owner_method_id": owner,
                "test_name": selected_test,
                "request_hash": request_hash,
                "messages": messages,
                "max_tokens": self.cfg.max_tokens_repair,
            })
            self.audit.write_text(ctx.symbol.name, f"{audit_dir}/before.java", extracted.source)
            raw = self._chat(
                messages,
                self.cfg.temperature_repair,
                self.cfg.max_tokens_repair,
                outcome,
            )
            normalized = normalize_focused_java_response(raw or "")
            self.audit.write_text(ctx.symbol.name, f"{audit_dir}/response.txt", raw or "")
            self.audit.write_json(ctx.symbol.name, f"{audit_dir}/response-metadata.json", {
                "state": normalized.state.value,
                "reason": normalized.reason,
                "response_hash": normalized.raw_hash,
                "response_chars": normalized.character_count,
                "finish_reason": normalized.finish_reason,
                "input_tokens": normalized.input_tokens,
                "output_tokens": normalized.output_tokens,
            })
            if normalized.raw_hash in rejected_response_hashes[request_hash]:
                record.llm_repair_history.append({
                    "stage": "compile_repair",
                    "request_hash": request_hash,
                    "response_hash": normalized.raw_hash,
                    "result": "IDENTICAL_REJECTED_RESPONSE",
                })
                record.compile_state = "REJECTED"
                continue
            if not normalized.source is not None or not normalized.source:
                rejected_response_hashes[request_hash].add(normalized.raw_hash)
                record.llm_repair_history.append({
                    "stage": "compile_repair",
                    "request_hash": request_hash,
                    "response_hash": normalized.raw_hash,
                    "response_state": normalized.state.value,
                    "reason": normalized.reason,
                    "result": "rejected",
                })
                record.compile_state = "REJECTED"
                continue

            extracted_repair = extract_generated_tests(normalized.source)
            if len(extracted_repair) != 1 or extracted_repair[0].name != selected_test:
                record.llm_repair_history.append({
                    "stage": "compile_repair",
                    "request_hash": request_hash,
                    "response_hash": normalized.raw_hash,
                    "response_state": "TEST_IDENTITY_MISMATCH",
                    "result": "rejected",
                })
                record.compile_state = "REJECTED"
                continue
            replacement = normalize_writable_map_mutations(extracted_repair[0].source)
            focused = deterministically_repair_test(
                ctx, production_method, method_context, replacement
            )
            replacement = focused.source
            validation = validate_method_block(
                ctx,
                production_method,
                method_context,
                replacement,
                set(test_method_names(current)) - {selected_test},
            )
            if not validation.ok or tuple(validation.test_names) != (selected_test,):
                record.llm_repair_history.append({
                    "stage": "compile_repair",
                    "request_hash": request_hash,
                    "response_hash": normalized.raw_hash,
                    "validation": validation.reason,
                    "result": "rejected",
                })
                record.compile_state = "REJECTED"
                continue

            updated_block = replace_test_method(block or "", selected_test, replacement)
            candidate = replace_method_block(current, owner, updated_block)
            finalized = finalize_java(
                candidate,
                test_package=ctx.test_package,
                test_class_name=ctx.test_class_name,
                template=ctx.template,
                cut_symbol=ctx.symbol,
                collaborators=ctx.collaborators,
                source_imports=ctx.source_imports,
            )
            if not finalized.ok or not finalized.code or test_class_structure_error(
                finalized.code, ctx.test_class_name
            ):
                record.compile_state = "REJECTED"
                continue

            registry_snapshot = snapshot_test_registry(outcome)
            baseline_other_errors = Counter(
                _compile_error_signature(current, error)
                for error in errors
                if test_method_name_for_line(current, getattr(error, "line", None)) != selected_test
            )
            stage_candidate_source(outcome, selected_test, replacement)
            record.compile_state = "REPAIRED_PENDING_COMPILE"
            test_path.write_text(finalized.code, encoding="utf-8")
            candidate_result, candidate_errors = self._compile_candidate(test_path, module)
            selected_remaining = [
                error
                for error in candidate_errors
                if test_method_name_for_line(finalized.code, error.line) == selected_test
            ]
            structural_new = test_class_structure_error(finalized.code, ctx.test_class_name)
            candidate_other_errors = Counter(
                _compile_error_signature(finalized.code, error)
                for error in candidate_errors
                if test_method_name_for_line(finalized.code, getattr(error, "line", None)) != selected_test
            )
            introduced_other_errors = list((candidate_other_errors - baseline_other_errors).elements())
            if selected_remaining or structural_new or introduced_other_errors:
                test_path.write_text(current, encoding="utf-8")
                restore_test_registry(outcome, registry_snapshot)
                restored = test_record_by_name(outcome, selected_test)
                if restored is not None:
                    restored.compile_state = "REJECTED"
                    restored.llm_repair_history.append({
                        "stage": "compile_repair",
                        "request_hash": request_hash,
                        "response_hash": normalized.raw_hash,
                        "compiler_errors": [error.render() for error in selected_remaining],
                        "introduced_non_selected_errors": [repr(item) for item in introduced_other_errors],
                        "result": "rollback",
                    })
                continue

            commit_candidate_source(
                outcome,
                selected_test,
                compile_state="REPAIRED_AND_PASSED",
            )
            record = test_record_by_name(outcome, selected_test)
            if record is not None:
                record.llm_repair_history.append({
                    "stage": "compile_repair",
                    "request_hash": request_hash,
                    "response_hash": normalized.raw_hash,
                    "response_state": normalized.state.value,
                    "result": "accepted",
                })
            current = finalized.code
            errors = list(candidate_errors)
            refresh_test_registry_ranges(outcome, current)
            self._write_registry_audit(ctx, outcome)
            self.audit.write_text(ctx.symbol.name, f"{audit_dir}/candidate.java", current)
            self.audit.write_json(ctx.symbol.name, f"{audit_dir}/compile-after.json", {
                "success": candidate_result.ok,
                "error_count": len(candidate_errors),
                "selected_test_errors": 0,
            })
            if candidate_result.ok:
                _mark_retained_compile_state(outcome, "PASSED")
                return current

        test_path.write_text(current, encoding="utf-8")
        salvaged = self._reject_irreparable_compile_tests(
            ctx, current, test_path, module, outcome, errors
        )
        if salvaged is not None:
            sync_test_registry_sources(outcome, salvaged, compile_state="PASSED", accepted=False)
            self._write_registry_audit(ctx, outcome)
            return salvaged
        outcome.compile_errors = [error.render() for error in errors][:12]
        return None

    def _compile_serviceimpl_class_repair(
        self,
        ctx: GenerationContext,
        test_path: Path,
        module: ModuleInfo,
        outcome: TargetOutcome,
        errors,
    ) -> str | None:
        """Explicitly disabled legacy complete-class ServiceImpl repair route."""
        raise RuntimeError(
            "ServiceImpl complete-class compile repair is disabled in v11; "
            "use registry-focused individual-test repair"
        )

    def _compile_methodwise_repair(
        self,
        ctx: GenerationContext,
        test_path: Path,
        module: ModuleInfo,
        outcome: TargetOutcome,
        errors,
    ) -> str | None:
        current = test_path.read_text(encoding="utf-8")
        blocked_owners: set[str] = set()
        log.debug(
            "[METHOD_COMPILE_REPAIR] start | target=%s | test=%s | initial_errors=%d | max_repairs=%d",
            ctx.symbol.fqcn, test_path.name, len(errors), self.cfg.max_compile_repairs,
        )
        for attempt in range(self.cfg.max_compile_repairs):
            baseline_current = current
            baseline_errors = list(errors)
            mapped_before = [(error, owner_method_id_for_line(current, error.line)) for error in errors]
            unmapped = [error for error, owner in mapped_before if owner is None]
            previous_total = len(errors)

            # Header/import/fixture diagnostics have no method owner and require
            # their own bounded class-surface repair path. They must not be
            # silently discarded while method blocks are repaired.
            if unmapped:
                log.debug(
                    "[METHOD_COMPILE_REPAIR] header.route | attempt=%d/%d | unmapped_errors=%d",
                    attempt + 1, self.cfg.max_compile_repairs, len(unmapped),
                )
                repaired_header = self._repair_methodwise_header_errors(
                    ctx, current, unmapped, outcome,
                    label=f"class header/import/fixture repair {attempt + 1}",
                )
                if repaired_header is not None and repaired_header != current:
                    test_path.write_text(repaired_header, encoding="utf-8")
                    result, header_errors = self._compile_candidate(test_path, module)
                    if result.ok:
                        _mark_retained_compile_state(outcome, "PASSED")
                        sync_test_registry_sources(outcome, repaired_header, compile_state="PASSED", accepted=True)
                        return repaired_header
                    if _compile_candidate_is_strict_progress(
                        baseline_current,
                        baseline_errors,
                        repaired_header,
                        header_errors,
                    ):
                        current = repaired_header
                        errors = header_errors
                        log.debug(
                            "[METHOD_COMPILE_REPAIR] header.recompile.failed_but_improved | "
                            "attempt=%d/%d | remaining_errors=%d",
                            attempt + 1,
                            self.cfg.max_compile_repairs,
                            len(errors),
                        )
                        continue
                    test_path.write_text(baseline_current, encoding="utf-8")
                    current = baseline_current
                    errors = baseline_errors
                    outcome.notes.append(
                        f"class header/import/fixture repair {attempt + 1} rolled back: "
                        f"errors {len(baseline_errors)}->{len(header_errors)}"
                    )
                    log.debug(
                        "[METHOD_COMPILE_REPAIR] header.candidate.rollback | attempt=%d/%d | "
                        "before=%d | after=%d",
                        attempt + 1,
                        self.cfg.max_compile_repairs,
                        len(baseline_errors),
                        len(header_errors),
                    )

            deterministic = self._repair_compile_diagnostics_deterministically(
                ctx,
                current,
                errors,
                outcome,
                label=f"deterministic compile repair {attempt + 1}",
            )
            if deterministic is not None and deterministic != current:
                structure_error = test_class_structure_error(
                    deterministic, ctx.test_class_name
                )
                if structure_error:
                    outcome.notes.append(
                        f"deterministic compile repair {attempt + 1} rolled back: {structure_error}"
                    )
                else:
                    test_path.write_text(deterministic, encoding="utf-8")
                    result, deterministic_errors = self._compile_candidate(test_path, module)
                    if result.ok:
                        self._commit_deterministic_compile_actions(outcome, "PASSED")
                        log.debug(
                            "[METHOD_COMPILE_REPAIR] deterministic.recompile.success | "
                            "attempt=%d/%d | test=%s",
                            attempt + 1,
                            self.cfg.max_compile_repairs,
                            test_path.name,
                        )
                        _mark_retained_compile_state(outcome, "PASSED")
                        sync_test_registry_sources(outcome, deterministic, compile_state="PASSED", accepted=True)
                        return deterministic
                    deterministic_progress = _compile_candidate_is_strict_progress(
                        baseline_current,
                        baseline_errors,
                        deterministic,
                        deterministic_errors,
                    )
                    log.debug(
                        "[METHOD_COMPILE_REPAIR] deterministic.progress | attempt=%d/%d | "
                        "total_before=%d | total_after=%d | accepted=%s",
                        attempt + 1,
                        self.cfg.max_compile_repairs,
                        len(baseline_errors),
                        len(deterministic_errors),
                        deterministic_progress,
                    )
                    if deterministic_progress:
                        self._commit_deterministic_compile_actions(
                            outcome, "DETERMINISTIC_REPAIRED_PENDING_COMPILE"
                        )
                        current = deterministic
                        errors = deterministic_errors
                        log.debug(
                            "[METHOD_COMPILE_REPAIR] deterministic.recompile.failed_but_improved | "
                            "attempt=%d/%d | remaining_errors=%d",
                            attempt + 1,
                            self.cfg.max_compile_repairs,
                            len(errors),
                        )
                        continue
                test_path.write_text(baseline_current, encoding="utf-8")
                current = baseline_current
                errors = baseline_errors

            log.debug(
                "[METHOD_COMPILE_REPAIR] attempt.start | attempt=%d/%d | current_errors=%d | blocked_owners=%s",
                attempt + 1, self.cfg.max_compile_repairs, len(errors), sorted(blocked_owners),
            )
            repaired = self._repair_methodwise_error_batch(
                ctx, current, errors, outcome,
                label=f"method compile repair {attempt + 1}",
                excluded_owners=blocked_owners,
            )
            selected_owner = getattr(self, "_last_methodwise_repair_owner", None)
            selected_test = getattr(self, "_last_methodwise_repair_test", None)
            source_changed = bool(getattr(self, "_last_methodwise_repair_changed", False))
            before_owner_errors = [
                error for error, owner in mapped_before if owner == selected_owner
            ]
            if repaired is None:
                if selected_owner and selected_owner not in blocked_owners:
                    blocked_owners.add(selected_owner)
                    outcome.notes.append(
                        f"compile repair candidate rejected [{selected_owner}]; "
                        "selecting a different failing owner next"
                    )
                    log.debug(
                        "[METHOD_COMPILE_REPAIR] attempt.rejected | attempt=%d/%d | "
                        "owner=%s | rollback=true",
                        attempt + 1,
                        self.cfg.max_compile_repairs,
                        selected_owner,
                    )
                    test_path.write_text(baseline_current, encoding="utf-8")
                    current = baseline_current
                    errors = baseline_errors
                    continue
                log.debug(
                    "[METHOD_COMPILE_REPAIR] attempt.stopped | attempt=%d/%d | no_repaired_class=true",
                    attempt + 1, self.cfg.max_compile_repairs,
                )
                break
            structure_error = test_class_structure_error(repaired, ctx.test_class_name)
            if structure_error:
                if selected_owner:
                    blocked_owners.add(selected_owner)
                outcome.notes.append(
                    f"compile repair rolled back [{selected_owner}/{selected_test}]: {structure_error}"
                )
                log.debug(
                    "[METHOD_COMPILE_REPAIR] structure.rollback | attempt=%d/%d | owner=%s | "
                    "test=%s | reason=%s",
                    attempt + 1,
                    self.cfg.max_compile_repairs,
                    selected_owner,
                    selected_test,
                    structure_error,
                )
                test_path.write_text(baseline_current, encoding="utf-8")
                current = baseline_current
                errors = baseline_errors
                continue
            test_path.write_text(repaired, encoding="utf-8")
            log.debug(
                "[METHOD_COMPILE_REPAIR] recompile.start | attempt=%d/%d | test=%s | owner=%s",
                attempt + 1, self.cfg.max_compile_repairs, test_path.name, selected_owner,
            )
            result, candidate_errors = self._compile_candidate(test_path, module)
            if result.ok:
                self._commit_methodwise_llm_repair(outcome, "PASSED")
                log.debug(
                    "[METHOD_COMPILE_REPAIR] recompile.success | attempt=%d/%d | test=%s",
                    attempt + 1, self.cfg.max_compile_repairs, test_path.name,
                )
                _mark_retained_compile_state(outcome, "PASSED")
                sync_test_registry_sources(outcome, repaired, compile_state="PASSED", accepted=True)
                return repaired

            mapped_after = [(error, owner_method_id_for_line(repaired, error.line)) for error in candidate_errors]
            after_owner_errors = [error for error, owner in mapped_after if owner == selected_owner]
            before_test_errors = [
                error for error in baseline_errors
                if test_method_name_for_line(baseline_current, error.line) == selected_test
            ]
            after_test_errors = [
                error for error in candidate_errors
                if test_method_name_for_line(repaired, error.line) == selected_test
            ]
            materially_improved = (
                source_changed
                and len(after_test_errors) < len(before_test_errors)
                and _compile_candidate_is_strict_progress(
                    baseline_current,
                    baseline_errors,
                    repaired,
                    candidate_errors,
                    selected_owner=selected_owner,
                )
            )
            log.debug(
                "[METHOD_COMPILE_REPAIR] progress | owner=%s | source_changed=%s | "
                "test_errors_before=%d | test_errors_after=%d | owner_errors_before=%d | "
                "owner_errors_after=%d | total_before=%d | total_after=%d | materially_improved=%s",
                selected_owner, source_changed, len(before_test_errors), len(after_test_errors),
                len(before_owner_errors), len(after_owner_errors), previous_total, len(candidate_errors),
                materially_improved,
            )
            if not materially_improved:
                if selected_owner:
                    blocked_owners.add(selected_owner)
                outcome.notes.append(
                    f"compile repair rolled back [{selected_owner}/{selected_test}]: "
                    f"errors {len(baseline_errors)}->{len(candidate_errors)}, "
                    f"owner {len(before_owner_errors)}->{len(after_owner_errors)}"
                )
                test_path.write_text(baseline_current, encoding="utf-8")
                current = baseline_current
                errors = baseline_errors
                log.debug(
                    "[METHOD_COMPILE_REPAIR] candidate.rollback | attempt=%d/%d | owner=%s | "
                    "test=%s | total_before=%d | total_after=%d",
                    attempt + 1,
                    self.cfg.max_compile_repairs,
                    selected_owner,
                    selected_test,
                    len(baseline_errors),
                    len(candidate_errors),
                )
                continue
            current = repaired
            errors = candidate_errors
            self._commit_methodwise_llm_repair(
                outcome, "REPAIRED_PENDING_COMPILE"
            )
            log.debug(
                "[METHOD_COMPILE_REPAIR] recompile.failed | attempt=%d/%d | remaining_errors=%d",
                attempt + 1, self.cfg.max_compile_repairs, len(errors),
            )

        salvaged = self._reject_irreparable_compile_tests(
            ctx, current, test_path, module, outcome, errors
        )
        if salvaged is not None:
            return salvaged
        outcome.compile_errors = [error.render() for error in errors][:12]
        log.error(
            "[METHOD_COMPILE_REPAIR] exhausted | test=%s | remaining_errors=%d | saved_to_outcome=%d",
            test_path.name, len(errors), len(outcome.compile_errors),
        )
        return None

    def _repair_methodwise_header_errors(
        self,
        ctx: GenerationContext,
        current: str,
        errors,
        outcome: TargetOutcome,
        *,
        label: str,
    ) -> str | None:
        if not errors or self.llm is None or not getattr(ctx, "symbol", None):
            return None
        outcome.notes.append(f"{label}: {len(errors)} unmapped error(s)")
        builder = payload_builder_for_context(ctx)
        messages = builder.build_compile_repair_payload(ctx, current, list(errors), None, mode="classwide")
        raw = self._chat(messages, self.cfg.temperature_repair, self.cfg.max_tokens_repair, outcome)
        candidate = inject_reusable_fixtures(raw or "", ctx)
        finalized = finalize_java(
            candidate, test_package=ctx.test_package, test_class_name=ctx.test_class_name,
            template=ctx.template, cut_symbol=ctx.symbol, collaborators=ctx.collaborators,
            source_imports=ctx.source_imports,
        )
        if not finalized.ok or not finalized.code:
            outcome.notes.append(f"{label} rejected: {finalized.reason}")
            return None
        before_tests = {test.name: test.source.strip() for test in extract_generated_tests(current)}
        after_tests = {test.name: test.source.strip() for test in extract_generated_tests(finalized.code)}
        if before_tests != after_tests:
            missing = sorted(set(before_tests) - set(after_tests))
            outcome.tests_lost_during_compile_repair += len(missing)
            outcome.notes.append(
                f"{label} rejected: header/import repair changed test methods; missing={missing}"
            )
            return None
        structure_error = test_class_structure_error(finalized.code, ctx.test_class_name)
        if structure_error:
            outcome.notes.append(f"{label} rejected: {structure_error}")
            return None
        return finalized.code

    def _repair_methodwise_error_batch(
        self,
        ctx: GenerationContext,
        current: str,
        errors,
        outcome: TargetOutcome,
        *,
        label: str,
        excluded_owners: set[str] | None = None,
    ) -> str | None:
        """Repair only one generated block owning authoritative compiler errors."""
        self._last_methodwise_repair_owner = None
        self._last_methodwise_repair_test = None
        self._last_methodwise_repair_changed = False
        self._last_methodwise_repair_record = None
        excluded_owners = excluded_owners or set()
        mapped_errors = [
            (error, owner_method_id_for_line(current, error.line))
            for error in errors
        ]
        for index, (error, owner) in enumerate(mapped_errors, start=1):
            log.debug(
                "[METHOD_COMPILE_REPAIR] diagnostic.map | label=%s | diagnostic=%d/%d | "
                "line=%s | owner=%s | message=%s",
                label,
                index,
                len(mapped_errors),
                error.line if error.line is not None else "n/a",
                owner or "<outside-generated-method-block>",
                error.message,
            )

        owners = [owner for _, owner in mapped_errors if owner]
        if not owners:
            # The failing line is OUTSIDE any generated method block -- almost always
            # a header issue (missing import, or a type invented in a body that has no
            # import). Name it loudly instead of dying silently: list the exact
            # compiler errors so the cause is visible in the report, and flag the
            # likely invented-type case for the schema/import work.
            rendered = [e.render() for e in errors][:8]
            outcome.notes.append(
                f"{label} stopped: compile error outside any generated method block "
                f"(header/import). Errors: " + " | ".join(rendered)
            )
            log.error(
                "[METHOD_COMPILE_REPAIR] stop.unmapped | label=%s | errors=%d | reason=header_or_import",
                label,
                len(errors),
            )
            for e in errors:
                msg = (e.render() or "").lower()
                if "cannot find symbol" in msg or "cannot be resolved" in msg:
                    outcome.notes.append(
                        f"{label} likely unimported or invented type at "
                        f"line {e.line}: {e.render()}"
                    )
            return None

        owner, owner_counts, unmapped_count = _select_method_repair_owner(
            current, errors, excluded_owners
        )
        if owner is None:
            outcome.notes.append(f"{label} stopped: all failing method owners made no progress")
            log.error(
                "[METHOD_COMPILE_REPAIR] stop.no_eligible_owner | label=%s | owner_counts=%s | excluded=%s",
                label, dict(owner_counts), sorted(excluded_owners),
            )
            return None
        self._last_methodwise_repair_owner = owner
        log.debug(
            "[METHOD_COMPILE_REPAIR] owner.select | label=%s | selected=%s | owner_counts=%s | "
            "unmapped_errors=%d",
            label,
            owner,
            dict(owner_counts),
            unmapped_count,
        )
        method_by_id = {
            f"{method.name}({','.join(type_name for type_name, _ in method.params)})": method
            for method in (ctx.symbol.methods or [])
        }
        context_by_id = {
            method.method_id: method
            for method in (ctx.execution_context.methods if ctx.execution_context else ())
        }
        production_method = method_by_id.get(owner)
        method_context = context_by_id.get(owner)
        block = method_block_for_id(current, owner)
        if production_method is None or method_context is None or block is None:
            outcome.notes.append(f"{label} stopped: context missing for {owner}")
            log.error(
                "[METHOD_COMPILE_REPAIR] stop.context_missing | label=%s | owner=%s | "
                "production_method=%s | method_context=%s | block=%s",
                label,
                owner,
                production_method is not None,
                method_context is not None,
                block is not None,
            )
            return None

        owner_errors = [
            error for error, mapped_owner in mapped_errors
            if mapped_owner == owner
        ] or list(errors)
        test_error_groups: dict[str, list] = defaultdict(list)
        for error in owner_errors:
            test_name = test_method_name_for_line(current, error.line)
            if test_name:
                test_error_groups[test_name].append(error)
        if not test_error_groups:
            outcome.notes.append(
                f"{label} stopped [{owner}]: owner diagnostics could not be mapped to an individual test"
            )
            log.error(
                "[METHOD_COMPILE_REPAIR] stop.test_unmapped | label=%s | owner=%s | errors=%d",
                label, owner, len(owner_errors),
            )
            return None

        selected_test, selected_errors = sorted(
            test_error_groups.items(), key=lambda item: (-len(item[1]), item[0])
        )[0]
        self._last_methodwise_repair_test = selected_test
        extracted_test = test_method_for_name(block, selected_test)
        if extracted_test is None:
            outcome.notes.append(f"{label} stopped [{owner}/{selected_test}]: test source missing")
            return None
        test_source = extracted_test.source

        outcome.notes.append(
            f"{label} [{owner}/{selected_test}]: {len(selected_errors)} error(s)"
        )
        log.debug(
            "[METHOD_COMPILE_REPAIR] llm.scope | label=%s | selected_owner=%s | selected_test=%s | "
            "errors_sent=%d | owner_compile_errors=%d | sibling_tests_preserved=%d | test_chars=%d",
            label,
            owner,
            selected_test,
            len(selected_errors),
            len(owner_errors),
            max(0, len(test_method_names(block)) - 1),
            len(test_source),
        )
        for index, error in enumerate(selected_errors, start=1):
            log.error(
                "[METHOD_COMPILE_REPAIR] llm.diagnostic %d/%d | owner=%s | test=%s | %s",
                index,
                len(selected_errors),
                owner,
                selected_test,
                error.render().replace("\n", " | "),
            )
        builder = payload_builder_for_context(ctx)
        messages = builder.build_compile_repair_payload(
            ctx=ctx,
            method=production_method,
            current_test=test_source,
            test_name=selected_test,
            errors=selected_errors,
            mode="individual",
        )
        raw = self._chat(
            messages,
            self.cfg.temperature_repair,
            self.cfg.max_tokens_repair,
            outcome,
        )
        extracted = extract_generated_tests(raw or "")
        if len(extracted) != 1 or extracted[0].name != selected_test:
            outcome.notes.append(
                f"{label} rejected [{owner}/{selected_test}]: repair must return the exact individual test"
            )
            log.debug(
                "[METHOD_COMPILE_REPAIR] identity.rejected | label=%s | owner=%s | test=%s | returned=%s",
                label, owner, selected_test, [test.name for test in extracted],
            )
            return None
        replacement = normalize_writable_map_mutations(extracted[0].source)
        deterministic = deterministically_repair_test(
            ctx, production_method, method_context, replacement
        )
        replacement = deterministic.source
        existing_names = set(test_method_names(current)) - {selected_test}
        validation = validate_method_block(
            ctx,
            production_method,
            method_context,
            replacement,
            existing_names,
        )
        if not validation.ok or tuple(validation.test_names) != (selected_test,):
            reason = validation.reason if not validation.ok else "test identity changed"
            outcome.notes.append(f"{label} rejected [{owner}/{selected_test}]: {reason}")
            log.debug(
                "[METHOD_COMPILE_REPAIR] validation.rejected | label=%s | owner=%s | test=%s | reason=%s",
                label, owner, selected_test, reason,
            )
            return None

        updated_block = replace_test_method(block, selected_test, replacement)
        if updated_block is None:
            outcome.notes.append(
                f"{label} rejected [{owner}/{selected_test}]: individual replacement failed"
            )
            return None
        if set(test_method_names(updated_block)) != set(test_method_names(block)):
            outcome.notes.append(
                f"{label} rejected [{owner}/{selected_test}]: sibling test identity changed"
            )
            return None
        candidate = replace_method_block(current, owner, updated_block)
        finalized = finalize_java(
            candidate,
            test_package=ctx.test_package,
            test_class_name=ctx.test_class_name,
            template=ctx.template,
            cut_symbol=ctx.symbol,
            collaborators=ctx.collaborators,
            source_imports=ctx.source_imports,
        )
        if not finalized.ok or not finalized.code:
            outcome.notes.append(f"{label} rejected [{owner}/{selected_test}]: {finalized.reason}")
            log.debug(
                "[METHOD_COMPILE_REPAIR] finalize.rejected | label=%s | owner=%s | test=%s | reason=%s",
                label, owner, selected_test, finalized.reason or "unknown",
            )
            return None
        structure_error = test_class_structure_error(finalized.code, ctx.test_class_name)
        if structure_error:
            outcome.notes.append(
                f"{label} rejected [{owner}/{selected_test}]: {structure_error}"
            )
            log.debug(
                "[METHOD_COMPILE_REPAIR] finalize.structure_rejected | label=%s | "
                "owner=%s | test=%s | reason=%s",
                label,
                owner,
                selected_test,
                structure_error,
            )
            return None
        if set(test_method_names(finalized.code)) != set(test_method_names(current)):
            outcome.tests_lost_during_compile_repair += max(
                0, len(test_method_names(current)) - len(test_method_names(finalized.code))
            )
            outcome.notes.append(
                f"{label} rejected [{owner}/{selected_test}]: finalization changed test identity"
            )
            return None
        before_sources = {
            test.name: test.source.strip() for test in extract_generated_tests(current)
        }
        after_sources = {
            test.name: test.source.strip() for test in extract_generated_tests(finalized.code)
        }
        changed_siblings = sorted(
            name
            for name, source in before_sources.items()
            if name != selected_test and after_sources.get(name) != source
        )
        if changed_siblings:
            outcome.notes.append(
                f"{label} rejected [{owner}/{selected_test}]: sibling source changed: "
                + ", ".join(changed_siblings)
            )
            log.debug(
                "[METHOD_COMPILE_REPAIR] sibling_source.rejected | label=%s | owner=%s | "
                "test=%s | changed_siblings=%s",
                label,
                owner,
                selected_test,
                changed_siblings,
            )
            return None
        self._last_methodwise_repair_changed = replacement.strip() != test_source.strip()
        self._last_methodwise_repair_record = (
            owner,
            selected_test,
            replacement,
            tuple(deterministic.actions),
            label,
        )
        log.debug(
            "[METHOD_COMPILE_REPAIR] finalize.accepted | label=%s | owner=%s | test=%s | "
            "class_chars=%d | test_changed=%s",
            label, owner, selected_test, len(finalized.code), self._last_methodwise_repair_changed,
        )
        return finalized.code

    def _commit_methodwise_llm_repair(self, outcome: TargetOutcome, state: str) -> None:
        pending = getattr(self, "_last_methodwise_repair_record", None)
        if not pending:
            return
        owner, selected_test, replacement, deterministic_actions, label = pending
        test = test_record_by_name(outcome, selected_test)
        if test is None or test.owner_method_id != owner:
            return
        stage_candidate_source(outcome, selected_test, replacement)
        commit_candidate_source(outcome, selected_test, compile_state=state)
        for sequence, action in enumerate(deterministic_actions, start=1):
            test.deterministic_repair_history.append({
                "sequence": sequence,
                "stage": "compile_repair",
                "category": str(action),
                "source_after": replacement,
                "result": "accepted",
            })
        test.llm_repair_history.append({
            "stage": "compile_repair",
            "label": label,
            "result": "accepted",
        })
        test.compile_state = state

    def _recover_maven_compile(self, ctx, module, test_path, run, outcome):
        """Repair authoritative Maven compile failures without regenerating other methods."""
        target_kind = (
            ctx.execution_context.target_kind.value
            if ctx.execution_context is not None
            else ""
        )
        serviceimpl = target_kind == "service-impl"
        methodwise = target_kind in {"controller", "service-impl"}
        for attempt in range(self.cfg.max_compile_repairs):
            if run.ok:
                return run
            own = self._own_maven_errors(run.log_tail, test_path)
            if not own:
                return run  # not our compile error (sibling/env) -> genuinely unmeasured

            if serviceimpl:
                repaired = self._compile_serviceimpl_registry_repair(
                    ctx, test_path, module, outcome, own
                )
                if repaired is None:
                    return run
                test_path.write_text(repaired, encoding="utf-8")
            elif methodwise:
                current = test_path.read_text(encoding="utf-8")
                repaired = self._repair_methodwise_error_batch(
                    ctx,
                    current,
                    own,
                    outcome,
                    label=f"maven method compile repair {attempt + 1}",
                )
                if repaired is None:
                    return run
                test_path.write_text(repaired, encoding="utf-8")
            else:
                outcome.notes.append(f"maven compile repair: {len(own)} error(s)")
                kb_hints = self.kb.hints_for([e.message for e in own]) if self.kb else None
                builder = payload_builder_for_context(ctx)
                messages = builder.build_compile_repair_payload(
                    ctx,
                    test_path.read_text(encoding="utf-8"),
                    own,
                    kb_hints,
                    mode="classwide",
                )
                raw = self._chat(
                    messages,
                    self.cfg.temperature_repair,
                    self.cfg.max_tokens_repair,
                    outcome,
                )
                candidate = inject_reusable_fixtures(raw or "", ctx)
                res = finalize_java(
                    candidate,
                    test_package=ctx.test_package,
                    test_class_name=ctx.test_class_name,
                    template=ctx.template,
                    cut_symbol=ctx.symbol,
                    collaborators=ctx.collaborators,
                    source_imports=ctx.source_imports,
                )
                if not res.ok or not res.code:
                    return run
                test_path.write_text(res.code, encoding="utf-8")

            run = self._measure_coverage(self.coverage_runner, 
                module,
                test_classes=[self._test_fqcn(ctx)],
            )
        return run
