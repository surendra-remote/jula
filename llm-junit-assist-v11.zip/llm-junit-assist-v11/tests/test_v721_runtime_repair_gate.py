from __future__ import annotations

import subprocess
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from junitforge.config import GenConfig, load_config
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageRunner,
    CoverageSignals,
    RuntimeTestRunResult,
    SurefireFailure,
    parse_surefire_failures_from_log,
    parse_surefire_reports,
)
from junitforge.execution.assembly import owner_method_id_for_test_name, validate_method_block
from junitforge.execution.models import (
    DependencyInvocation,
    DependencyMethodContract,
    ExecutionContext,
    ExecutionTargetKind,
    MethodExecutionContext,
    ResolutionStatus,
)
from junitforge.loop import Engine, _deterministic_runtime_replacement, _group_runtime_failures
from junitforge.models import (
    ClassSymbol,
    ClasspathProfile,
    GenerationContext,
    MethodSig,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TemplateSpec,
    TestKind,
)
from junitforge.report import write_reports


class CoverageLifecycleAndResultSemanticsTest(unittest.TestCase):
    def _runner(self, root: Path) -> tuple[CoverageRunner, ModuleInfo]:
        (root / "pom.xml").write_text("<project/>", encoding="utf-8")
        module = ModuleInfo("sample", root, root / "pom.xml")
        return CoverageRunner(root, mvn_path="mvn", timeout_sec=30), module

    def test_tests_green_is_independent_of_maven_success_and_coverage(self) -> None:
        signals = CoverageSignals(
            tests_executed=True,
            tests_run=75,
            tests_failed=29,
            tests_errors=12,
        )
        result = CoverageRunResult(
            ok=True,
            measured=True,
            note="coverage measured",
            return_code=0,
            signals=signals,
            maven_execution_success=True,
            coverage_current=True,
        )
        self.assertFalse(result.tests_green)
        self.assertTrue(result.measured)
        self.assertTrue(result.maven_execution_success)

    def test_normal_lifecycle_uses_target_pom_surefire(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            runner, module = self._runner(root)
            captured: list[list[str]] = []

            def fake_run(command, **_kwargs):
                captured.append(list(command))
                runner.exec_path(module).parent.mkdir(parents=True, exist_ok=True)
                runner.exec_path(module).write_bytes(b"exec")
                runner.xml_path(module).parent.mkdir(parents=True, exist_ok=True)
                runner.xml_path(module).write_text("<report/>", encoding="utf-8")
                return subprocess.CompletedProcess(
                    command,
                    0,
                    "Tests run: 1, Failures: 0, Errors: 0, Skipped: 0\n"
                    "argLine set to -javaagent:org.jacoco.agent",
                    "",
                )

            with patch.object(runner, "available", return_value=True), patch(
                "junitforge.coverage_run.subprocess.run", side_effect=fake_run
            ):
                result = runner.measure(module, ["sample.PaymentServiceImplTest"])

            self.assertTrue(result.ok, result.note)
            command = captured[0]
            self.assertIn("test", command)
            self.assertNotIn("test-compile", command)
            self.assertFalse(any("maven-surefire-plugin:" in value for value in command))

    def test_runtime_rerun_does_not_generate_jacoco_report(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            runner, module = self._runner(root)
            captured: list[list[str]] = []

            def fake_run(command, **_kwargs):
                captured.append(list(command))
                return subprocess.CompletedProcess(
                    command,
                    0,
                    "Tests run: 1, Failures: 0, Errors: 0, Skipped: 0",
                    "",
                )

            with patch.object(runner, "available", return_value=True), patch(
                "junitforge.coverage_run.subprocess.run", side_effect=fake_run
            ):
                result = runner.run_tests(
                    module,
                    ["sample.PaymentServiceImplTest#scenario"],
                    label="targeted",
                )

            self.assertTrue(result.tests_green)
            command = captured[0]
            self.assertIn("test", command)
            self.assertIn("-Djacoco.skip=true", command)
            self.assertFalse(any("jacoco-maven-plugin" in value for value in command))
            self.assertFalse(any("maven-surefire-plugin:" in value for value in command))

    def test_test_source_change_marks_measurement_stale(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            runner, module = self._runner(root)
            test_path = root / "src/test/java/sample/PaymentServiceImplTest.java"
            test_path.parent.mkdir(parents=True)
            test_path.write_text("class PaymentServiceImplTest {}", encoding="utf-8")

            def fake_run(command, **_kwargs):
                test_path.write_text("class PaymentServiceImplTest { int changed; }", encoding="utf-8")
                runner.exec_path(module).parent.mkdir(parents=True, exist_ok=True)
                runner.exec_path(module).write_bytes(b"exec")
                runner.xml_path(module).parent.mkdir(parents=True, exist_ok=True)
                runner.xml_path(module).write_text("<report/>", encoding="utf-8")
                return subprocess.CompletedProcess(
                    command,
                    0,
                    "Tests run: 1, Failures: 0, Errors: 0, Skipped: 0\n-javaagent:org.jacoco.agent",
                    "",
                )

            with patch.object(runner, "available", return_value=True), patch(
                "junitforge.coverage_run.subprocess.run", side_effect=fake_run
            ):
                result = runner.measure(module, ["sample.PaymentServiceImplTest"])

            self.assertTrue(result.measured)
            self.assertFalse(result.coverage_current)
            self.assertNotEqual(result.test_source_sha256, result.coverage_source_sha256)


class SurefireStructuredDiagnosticsTest(unittest.TestCase):
    def test_xml_failure_is_parsed_and_classified(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            reports = root / "target/surefire-reports"
            reports.mkdir(parents=True)
            report = reports / "TEST-sample.PaymentServiceImplTest.xml"
            report.write_text(
                """<?xml version="1.0" encoding="UTF-8"?>
<testsuite tests="1" failures="0" errors="1" skipped="0">
  <testcase classname="sample.PaymentServiceImplTest" name="getNextReceiptNo_WhenException">
    <error type="org.mockito.exceptions.base.MockitoException" message="Checked exception is invalid for this method!">org.mockito.exceptions.base.MockitoException: Checked exception is invalid for this method!
 at sample.PaymentServiceImplTest.getNextReceiptNo_WhenException(PaymentServiceImplTest.java:2510)
 at sample.PaymentServiceImpl.getNextReceiptNo(PaymentServiceImpl.java:921)
    </error>
  </testcase>
</testsuite>""",
                encoding="utf-8",
            )
            failures, paths = parse_surefire_reports(
                root,
                ["sample.PaymentServiceImplTest"],
                started_epoch=time.time() - 5,
            )
            self.assertEqual((report,), paths)
            self.assertEqual(1, len(failures))
            failure = failures[0]
            self.assertEqual("INVALID_CHECKED_EXCEPTION_STUB", failure.category)
            self.assertEqual(2510, failure.generated_test_line)
            self.assertEqual("PaymentServiceImpl.java", failure.production_file)
            self.assertEqual(921, failure.production_line)

    def test_complete_maven_log_is_used_when_xml_is_absent(self) -> None:
        blob = """
[ERROR] sample.PaymentServiceImplTest.isNewBusiness_returnsFalse -- Time elapsed: 0.010 s <<< ERROR!
java.lang.NullPointerException: policy is null
 at sample.PaymentServiceImplTest.isNewBusiness_returnsFalse(PaymentServiceImplTest.java:2056)
 at sample.PaymentServiceImpl.isNewBusiness(PaymentServiceImpl.java:605)
"""
        failures = parse_surefire_failures_from_log(
            blob,
            ["sample.PaymentServiceImplTest"],
        )
        self.assertEqual(1, len(failures))
        self.assertEqual("UNEXPECTED_NULL_POINTER", failures[0].category)
        self.assertEqual(2056, failures[0].generated_test_line)


class RuntimeOwnerMappingTest(unittest.TestCase):
    SUITE = """
class PaymentServiceImplTest {
    // JUNITFORGE_METHOD_BEGIN: getNextReceiptNo(GiPaymentEntity)
    @Test
    void getNextReceiptNo_WhenPayIndIsDV_ShouldReturnReceiptNo() {}
    // JUNITFORGE_METHOD_END: getNextReceiptNo(GiPaymentEntity)
}
"""

    def test_test_name_maps_to_deterministic_owner(self) -> None:
        owner = owner_method_id_for_test_name(
            self.SUITE,
            "getNextReceiptNo_WhenPayIndIsDV_ShouldReturnReceiptNo",
        )
        self.assertEqual("getNextReceiptNo(GiPaymentEntity)", owner)

    def test_same_line_test_annotation_maps_to_owner(self) -> None:
        suite = """
class PaymentServiceImplTest {
// JUNITFORGE_METHOD_BEGIN: execute()
@Test void execute_whenCalled() {}
// JUNITFORGE_METHOD_END: execute()
}
"""
        self.assertEqual(
            "execute()",
            owner_method_id_for_test_name(suite, "execute_whenCalled"),
        )

    def test_multiple_failures_group_by_owner(self) -> None:
        failures = (
            SurefireFailure(
                "sample.PaymentServiceImplTest",
                "getNextReceiptNo_WhenPayIndIsDV_ShouldReturnReceiptNo",
                "failure",
                "AssertionFailedError",
                "expected not null",
                "",
                category="ASSERTION_NULLABILITY_MISMATCH",
            ),
        )
        grouped, unmapped = _group_runtime_failures(self.SUITE, failures)
        self.assertFalse(unmapped)
        self.assertEqual(1, len(grouped["getNextReceiptNo(GiPaymentEntity)"]))

    def test_unused_local_stub_is_removed_deterministically(self) -> None:
        suite = """
class PaymentServiceImplTest {
    // JUNITFORGE_METHOD_BEGIN: getNextReceiptNo(GiPaymentEntity)
    @Test
    void getNextReceiptNo_WhenPayIndIsDV_ShouldReturnReceiptNo() {
        when(repo.find()).thenReturn(value);
        assertNotNull(paymentServiceImpl.getNextReceiptNo(payment));
    }
    // JUNITFORGE_METHOD_END: getNextReceiptNo(GiPaymentEntity)
}
"""
        failure = SurefireFailure(
            "sample.PaymentServiceImplTest",
            "getNextReceiptNo_WhenPayIndIsDV_ShouldReturnReceiptNo",
            "error",
            "org.mockito.exceptions.misusing.UnnecessaryStubbingException",
            "Unnecessary stubbings detected",
            "",
            generated_test_line=6,
            category="UNNECESSARY_STUBBING",
        )
        replacement, action = _deterministic_runtime_replacement(
            suite,
            "getNextReceiptNo(GiPaymentEntity)",
            [failure],
        )
        self.assertIsNotNone(replacement)
        self.assertNotIn("when(repo.find())", replacement)
        self.assertIn("removed_unused_local_stubs=1", action)


class RuntimeStructuralValidationTest(unittest.TestCase):
    def test_illegal_checked_exception_stub_is_rejected_before_runtime(self) -> None:
        production = MethodSig("execute", modifiers={"public"}, return_type="Object")
        contract = DependencyMethodContract(
            dependency_field="repo",
            dependency_type="Repo",
            method_name="find",
            return_type="Object",
            throws=(),
            resolution_status=ResolutionStatus.RESOLVED,
        )
        invocation = DependencyInvocation(
            invocation_id="execute():repo.find:1",
            caller_method_id="execute()",
            dependency_field="repo",
            dependency_type="Repo",
            method_name="find",
            arguments=(),
            contract=contract,
            return_value_consumed=True,
        )
        method_context = MethodExecutionContext(
            method_id="execute()",
            signature=production.render(),
            source_range=(1, 3),
            method_source="public Object execute() { return repo.find(); }",
            endpoint=None,
            dependency_invocations=(invocation,),
        )
        execution = ExecutionContext(
            target_kind=ExecutionTargetKind.SERVICE_IMPL,
            target_fqcn="sample.PaymentServiceImpl",
            methods=(method_context,),
        )
        symbol = ClassSymbol(
            "PaymentServiceImpl",
            "sample.PaymentServiceImpl",
            "class",
            modifiers={"public"},
            methods=[production],
        )
        ctx = GenerationContext(
            cut_source=method_context.method_source,
            symbol=symbol,
            collaborators=[],
            test_package="sample",
            test_class_name="PaymentServiceImplTest",
            stack=StackProfile(),
            classpath=ClasspathProfile(),
            template=TemplateSpec(TestKind.PURE_UNIT, "unit"),
            source_path=Path("PaymentServiceImpl.java"),
            execution_context=execution,
        )
        block = """
@Test void invalidCheckedException() {
    when(repo.find()).thenThrow(new InterruptedException("stop"));
    assertThrows(RuntimeException.class, () -> paymentServiceImpl.execute());
}
"""
        validation = validate_method_block(ctx, production, method_context, block, set())
        self.assertFalse(validation.ok)
        self.assertIn("checked-exception stubbing", validation.reason)


class RuntimeGateOrchestrationTest(unittest.TestCase):
    def _context(self, root: Path) -> tuple[GenerationContext, ModuleInfo, Path, TargetOutcome]:
        method = MethodSig("execute", modifiers={"public"}, return_type="Object")
        method_context = MethodExecutionContext(
            method_id="execute()",
            signature=method.render(),
            source_range=(1, 3),
            method_source="public Object execute() { return new Object(); }",
            endpoint=None,
        )
        execution = ExecutionContext(
            target_kind=ExecutionTargetKind.SERVICE_IMPL,
            target_fqcn="sample.PaymentServiceImpl",
            methods=(method_context,),
        )
        symbol = ClassSymbol(
            "PaymentServiceImpl",
            "sample.PaymentServiceImpl",
            "class",
            modifiers={"public"},
            methods=[method],
        )
        ctx = GenerationContext(
            cut_source=method_context.method_source,
            symbol=symbol,
            collaborators=[],
            test_package="sample",
            test_class_name="PaymentServiceImplTest",
            stack=StackProfile(),
            classpath=ClasspathProfile(has_junit_jupiter=True, has_mockito=True),
            template=TemplateSpec(TestKind.PURE_UNIT, "unit", line_target=80, branch_target=80),
            source_path=root / "PaymentServiceImpl.java",
            execution_context=execution,
        )
        module = ModuleInfo("sample", root, root / "pom.xml")
        test_path = root / "PaymentServiceImplTest.java"
        test_path.write_text("class PaymentServiceImplTest {}", encoding="utf-8")
        outcome = TargetOutcome(
            fqcn=symbol.fqcn,
            module=module.name,
            source_path=str(ctx.source_path),
            test_path=str(test_path),
            classification="pure_unit",
            testable=True,
        )
        return ctx, module, test_path, outcome

    def _engine(self, root: Path, runner) -> Engine:
        return Engine(
            llm=MagicMock(),
            compile_gate=MagicMock(),
            coverage_runner=runner,
            stack=StackProfile(),
            modules=[],
            repo_root=root,
            lookup=lambda _name: None,
            cfg=GenConfig(max_runtime_repair_rounds=2),
        )

    def test_failing_tests_block_augmentation_and_end_runtime_failed(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ctx, module, test_path, outcome = self._context(root)
            signals = CoverageSignals(tests_executed=True, tests_run=3, tests_failed=1)
            run = CoverageRunResult(
                True,
                True,
                "coverage measured",
                xml_path=root / "jacoco.xml",
                signals=signals,
                coverage_current=True,
                maven_execution_success=True,
            )
            runner = MagicMock()
            runner.measure.return_value = run
            engine = self._engine(root, runner)
            with patch.object(engine, "_recover_maven_compile", return_value=run), patch.object(
                engine, "_runtime_failure_repair_loop", return_value=None
            ), patch.object(engine, "_augment") as augment:
                engine._coverage_loop(
                    ctx,
                    module,
                    test_path,
                    ctx.symbol,
                    test_path.read_text(encoding="utf-8"),
                    outcome,
                )
            self.assertEqual("runtime_failed", outcome.status)
            augment.assert_not_called()

    def test_candidate_repair_runs_targeted_then_full_class(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ctx, module, test_path, outcome = self._context(root)
            current = """class PaymentServiceImplTest {
// JUNITFORGE_METHOD_BEGIN: execute()
@Test void execute_whenCalled_returnsObject() { assertNull(paymentServiceImpl.execute()); }
// JUNITFORGE_METHOD_END: execute()
}
"""
            test_path.write_text(current, encoding="utf-8")
            failure = SurefireFailure(
                "sample.PaymentServiceImplTest",
                "execute_whenCalled_returnsObject",
                "failure",
                "org.opentest4j.AssertionFailedError",
                "expected null",
                "at sample.PaymentServiceImplTest.execute_whenCalled_returnsObject(PaymentServiceImplTest.java:3)",
                generated_test_line=3,
                category="ASSERTION_VALUE_MISMATCH",
            )
            before = CoverageRunResult(
                True,
                True,
                "coverage measured",
                signals=CoverageSignals(tests_executed=True, tests_run=1, tests_failed=1),
                failures=(failure,),
                coverage_current=True,
            )
            green = RuntimeTestRunResult(
                True,
                "green",
                signals=CoverageSignals(tests_executed=True, tests_run=1),
            )
            runner = MagicMock()
            runner.run_tests.side_effect = [green, green]
            engine = self._engine(root, runner)
            replacement = """@Test void execute_whenCalled_returnsObject() {
    Object result = paymentServiceImpl.execute();
    assertNotNull(result);
}"""
            finalized = SimpleNamespace(ok=True, code=current.replace(
                "@Test void execute_whenCalled_returnsObject() { assertNull(paymentServiceImpl.execute()); }",
                replacement,
            ), reason=None)
            compile_success = (
                SimpleNamespace(ok=True, return_code=0, stdout="", stderr=""),
                [],
            )
            with patch.object(engine, "_chat", return_value=replacement), patch(
                "junitforge.runtime.repair_coordinator.finalize_java", return_value=finalized
            ), patch.object(engine, "_compile_candidate", return_value=compile_success), patch.object(
                engine, "_compile_with_repair", side_effect=AssertionError("nested compile repair must not run")
            ):
                accepted, result, _reason = engine._repair_runtime_owner(
                    ctx=ctx,
                    test_path=test_path,
                    module=module,
                    owner="execute()",
                    owner_failures=[failure],
                    before_run=before,
                    outcome=outcome,
                    test_fqcn="sample.PaymentServiceImplTest",
                    round_no=1,
                    attempt_no=1,
                )
            self.assertTrue(accepted)
            self.assertTrue(result.tests_green)
            self.assertEqual(2, runner.run_tests.call_count)
            targeted_selector = runner.run_tests.call_args_list[0].args[1][0]
            full_selector = runner.run_tests.call_args_list[1].args[1][0]
            self.assertIn("#execute_whenCalled_returnsObject", targeted_selector)
            self.assertEqual("sample.PaymentServiceImplTest", full_selector)

    def test_worsening_full_class_rerun_rolls_back_candidate(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ctx, module, test_path, outcome = self._context(root)
            current = """class PaymentServiceImplTest {
// JUNITFORGE_METHOD_BEGIN: execute()
@Test void execute_whenCalled_returnsObject() { assertNull(paymentServiceImpl.execute()); }
// JUNITFORGE_METHOD_END: execute()
}
"""
            test_path.write_text(current, encoding="utf-8")
            original_failure = SurefireFailure(
                "sample.PaymentServiceImplTest",
                "execute_whenCalled_returnsObject",
                "failure",
                "AssertionFailedError",
                "expected null",
                "",
                generated_test_line=3,
                category="ASSERTION_VALUE_MISMATCH",
            )
            before = CoverageRunResult(
                True,
                True,
                "coverage measured",
                signals=CoverageSignals(tests_executed=True, tests_run=2, tests_failed=1),
                failures=(original_failure,),
                coverage_current=True,
            )
            targeted_green = RuntimeTestRunResult(
                True,
                "green",
                signals=CoverageSignals(tests_executed=True, tests_run=1),
            )
            new_failure = SurefireFailure(
                "sample.PaymentServiceImplTest",
                "unrelatedTest",
                "failure",
                "AssertionFailedError",
                "new regression",
                "",
                category="ASSERTION_VALUE_MISMATCH",
            )
            full_worse = RuntimeTestRunResult(
                True,
                "worse",
                signals=CoverageSignals(tests_executed=True, tests_run=2, tests_failed=2),
                failures=(original_failure, new_failure),
            )
            runner = MagicMock()
            runner.run_tests.side_effect = [targeted_green, full_worse]
            engine = self._engine(root, runner)
            replacement = """@Test void execute_whenCalled_returnsObject() {
    Object result = paymentServiceImpl.execute();
    assertNotNull(result);
}"""
            finalized_code = current.replace(
                "@Test void execute_whenCalled_returnsObject() { assertNull(paymentServiceImpl.execute()); }",
                replacement,
            )
            finalized = SimpleNamespace(ok=True, code=finalized_code, reason=None)
            compile_success = (
                SimpleNamespace(ok=True, return_code=0, stdout="", stderr=""),
                [],
            )
            with patch.object(engine, "_chat", return_value=replacement), patch(
                "junitforge.runtime.repair_coordinator.finalize_java", return_value=finalized
            ), patch.object(engine, "_compile_candidate", return_value=compile_success), patch.object(
                engine, "_compile_with_repair", side_effect=AssertionError("nested compile repair must not run")
            ):
                accepted, _result, reason = engine._repair_runtime_owner(
                    ctx=ctx,
                    test_path=test_path,
                    module=module,
                    owner="execute()",
                    owner_failures=[original_failure],
                    before_run=before,
                    outcome=outcome,
                    test_fqcn="sample.PaymentServiceImplTest",
                    round_no=1,
                    attempt_no=1,
                )
            self.assertFalse(accepted)
            self.assertEqual("FULL_SUITE_NOT_GREEN", reason)
            self.assertEqual(current, test_path.read_text(encoding="utf-8"))

    def test_green_runtime_repair_invalidates_and_remeasures_coverage(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ctx, module, test_path, outcome = self._context(root)
            suite = """class PaymentServiceImplTest {
// JUNITFORGE_METHOD_BEGIN: execute()
@Test void execute_whenCalled_returnsObject() { assertNotNull(paymentServiceImpl.execute()); }
// JUNITFORGE_METHOD_END: execute()
}
"""
            test_path.write_text(suite, encoding="utf-8")
            failure = SurefireFailure(
                "sample.PaymentServiceImplTest",
                "execute_whenCalled_returnsObject",
                "failure",
                "AssertionFailedError",
                "expected not null",
                "",
                generated_test_line=3,
                category="ASSERTION_NULLABILITY_MISMATCH",
            )
            initial = CoverageRunResult(
                True,
                True,
                "diagnostic coverage",
                signals=CoverageSignals(tests_executed=True, tests_run=1, tests_failed=1),
                failures=(failure,),
                coverage_current=True,
            )
            green_runtime = RuntimeTestRunResult(
                True,
                "green",
                signals=CoverageSignals(tests_executed=True, tests_run=1),
            )
            fresh = CoverageRunResult(
                True,
                True,
                "fresh coverage",
                xml_path=root / "jacoco.xml",
                signals=CoverageSignals(tests_executed=True, tests_run=1),
                coverage_current=True,
                test_source_sha256="same",
                coverage_source_sha256="same",
            )
            runner = MagicMock()
            runner.measure.return_value = fresh
            engine = self._engine(root, runner)
            with patch.object(
                engine,
                "_repair_runtime_owner",
                return_value=(True, green_runtime, "accepted"),
            ):
                result = engine._runtime_failure_repair_loop(
                    ctx,
                    test_path,
                    module,
                    initial,
                    outcome,
                )
            self.assertIs(result, fresh)
            runner.invalidate_coverage.assert_called_once_with(module)
            runner.measure.assert_called_once_with(
                module,
                test_classes=["sample.PaymentServiceImplTest"],
            )
            self.assertEqual("pending", outcome.status)


class RuntimeConfigTest(unittest.TestCase):
    def test_runtime_repair_cli_options_are_loaded(self) -> None:
        cfg = load_config(
            [
                "--repo-path",
                ".",
                "--max-runtime-repair-rounds",
                "9",
                "--max-runtime-repairs-per-owner",
                "3",
                "--runtime-repair-timeout-seconds",
                "75",
            ]
        )
        self.assertEqual(9, cfg.gen.max_runtime_repair_rounds)
        self.assertEqual(3, cfg.gen.max_runtime_repairs_per_owner)
        self.assertEqual(75, cfg.gen.runtime_repair_timeout_seconds)

    def test_report_exposes_runtime_gate_and_repair_results(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            outcome = TargetOutcome(
                fqcn="sample.PaymentServiceImpl",
                module="sample",
                source_path="PaymentServiceImpl.java",
                test_path="PaymentServiceImplTest.java",
                classification="pure_unit",
                testable=True,
                status="runtime_failed",
                runtime_tests_run=75,
                runtime_failures_initial=29,
                runtime_errors_initial=12,
                runtime_failures_final=3,
                runtime_errors_final=1,
                runtime_repair_attempts=8,
                runtime_failure_categories_initial={"UNEXPECTED_NULL_POINTER": 4},
                runtime_failure_categories={"ASSERTION_VALUE_MISMATCH": 3},
                remaining_runtime_owners=["getNextReceiptNo(GiPaymentEntity)"],
            )
            _json_path, markdown_path = write_reports(
                root / "reports",
                root,
                StackProfile(),
                [outcome],
                timestamp="fixed",
            )
            markdown = markdown_path.read_text(encoding="utf-8")
            self.assertIn("Runtime validation and repair", markdown)
            self.assertIn("initial=29F/12E", markdown)
            self.assertIn("final=3F/1E", markdown)
            self.assertIn("remaining owners", markdown)


if __name__ == "__main__":
    unittest.main()
