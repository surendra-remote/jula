from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from junitforge.compilation.registry_mapper import map_compile_diagnostics
from junitforge.compilation.repair_coordinator import CompilationRepairMixin
from junitforge.execution.analyzer import _helper_calls
from junitforge.execution.dependencies import resolve_method_contract
from junitforge.execution.models import (
    ConstructionKind,
    DependencyInvocation,
    DependencyMethodContract,
    DependencyRef,
    ExecutionContext,
    ExecutionTargetKind,
    FixtureSpec,
    InvocationArgument,
    MethodExecutionContext,
    PayloadProperty,
    PayloadSchema,
    PropertyKind,
    ResolutionStatus,
    ReturnConsumptionKind,
)
from junitforge.generation.fixture_variants import (
    hoist_fixture_mutations,
    inject_fixture_variant_helpers,
)
from junitforge.generation.method_generator import _register_compiled_fixture_variants
from junitforge.generation.payloads import serviceimpl
from junitforge.generation.response_normalizer import ResponseState, normalize_focused_java_response
from junitforge.generation.source_closure import build_source_closure
from junitforge.models import (
    ClassSymbol,
    ClasspathProfile,
    CompileError,
    GenerationContext,
    MethodGenerationRecord,
    MethodSig,
    StackProfile,
    TargetOutcome,
    TemplateSpec,
    TestCaseRecord,
    TestDisposition,
    TestKind,
)
from junitforge.pipeline.result import (
    commit_candidate_source,
    restore_test_registry,
    snapshot_test_registry,
    stage_candidate_source,
)


def _ctx(
    method: MethodSig,
    method_context: MethodExecutionContext,
    *,
    schemas: tuple[PayloadSchema, ...] = (),
    fixtures: tuple[FixtureSpec, ...] = (),
    source_path: Path | None = None,
    symbol_methods: list[MethodSig] | None = None,
) -> GenerationContext:
    execution = ExecutionContext(
        target_kind=ExecutionTargetKind.SERVICE_IMPL,
        target_fqcn="sample.SampleServiceImpl",
        methods=(method_context,),
        payload_schemas=schemas,
        fixtures=fixtures,
    )
    symbol = ClassSymbol(
        "SampleServiceImpl",
        "sample.SampleServiceImpl",
        "class",
        modifiers={"public"},
        methods=symbol_methods or [method],
    )
    return GenerationContext(
        cut_source=method_context.method_source,
        symbol=symbol,
        collaborators=[],
        test_package="sample",
        test_class_name="SampleServiceImplTest",
        stack=StackProfile(java_version="17"),
        classpath=ClasspathProfile(has_junit_jupiter=True, has_mockito=True),
        template=TemplateSpec(TestKind.PURE_UNIT, "unit"),
        source_path=source_path or Path("SampleServiceImpl.java"),
        execution_context=execution,
    )


def _outcome(test_source: str = "@Test\nvoid execute_case() {}") -> TargetOutcome:
    outcome = TargetOutcome(
        fqcn="sample.SampleServiceImpl",
        module="sample",
        source_path="SampleServiceImpl.java",
        test_path="SampleServiceImplTest.java",
        classification="pure_unit",
        testable=True,
    )
    outcome.method_results = [
        MethodGenerationRecord(
            method_id="execute()",
            tests=[
                TestCaseRecord(
                    owner_method_id="execute()",
                    test_name="execute_case",
                    generated_source=test_source,
                    latest_accepted_source=test_source,
                    final_disposition=TestDisposition.RETAINED.value,
                )
            ],
        )
    ]
    return outcome


class RegistryTransactionV11Test(unittest.TestCase):
    def test_generated_source_is_immutable_and_candidate_is_transactional(self) -> None:
        original = "@Test\nvoid execute_case() { assertTrue(true); }"
        repaired = "@Test\nvoid execute_case() { assertNotNull(new Object()); }"
        outcome = _outcome(original)
        snapshot = snapshot_test_registry(outcome)

        stage_candidate_source(outcome, "execute_case", repaired)
        record = outcome.method_results[0].tests[0]
        self.assertEqual(original, record.generated_source)
        self.assertEqual(original, record.latest_accepted_source)
        self.assertEqual(repaired, record.candidate_source)

        restore_test_registry(outcome, snapshot)
        record = outcome.method_results[0].tests[0]
        self.assertEqual(original, record.generated_source)
        self.assertEqual(original, record.latest_accepted_source)
        self.assertIsNone(record.candidate_source)

        stage_candidate_source(outcome, "execute_case", repaired)
        commit_candidate_source(outcome, "execute_case")
        record = outcome.method_results[0].tests[0]
        self.assertEqual(original, record.generated_source)
        self.assertEqual(original, record.previous_accepted_source)
        self.assertEqual(repaired, record.latest_accepted_source)
        self.assertIsNone(record.candidate_source)

    def test_compiler_diagnostics_group_by_stable_test_id_and_classify_fixture(self) -> None:
        source = """class SampleServiceImplTest {
    private Object validObject() {
        Missing fixtureValue;
        return null;
    }

    @Test
    void execute_case() {
        Missing first;
        Missing second;
    }
}
"""
        outcome = _outcome()
        lines = source.splitlines()
        fixture_line = next(i for i, value in enumerate(lines, 1) if "fixtureValue" in value)
        first_line = next(i for i, value in enumerate(lines, 1) if "Missing first" in value)
        second_line = next(i for i, value in enumerate(lines, 1) if "Missing second" in value)
        errors = [
            CompileError(Path("SampleServiceImplTest.java"), fixture_line, 9, "cannot find symbol"),
            CompileError(Path("SampleServiceImplTest.java"), first_line, 9, "cannot find symbol"),
            CompileError(Path("SampleServiceImplTest.java"), second_line, 9, "cannot find symbol"),
        ]

        grouped = map_compile_diagnostics(outcome, source, errors)
        record = outcome.method_results[0].tests[0]
        self.assertEqual("execute()::execute_case", record.test_id)
        self.assertEqual(2, len(grouped[record.test_id]))
        self.assertEqual(2, len(record.compile_diagnostics))
        self.assertEqual(1, len(outcome.fixture_compile_diagnostics))


class FocusedResponseV11Test(unittest.TestCase):
    def test_complete_outer_fence_is_stripped_and_unmatched_fence_is_truncated(self) -> None:
        complete = normalize_focused_java_response(
            "```java\n@Test\nvoid execute_case() {}\n```"
        )
        unmatched = normalize_focused_java_response(
            "```java\n@Test\nvoid execute_case() {"
        )
        self.assertEqual(ResponseState.MARKDOWN_WRAPPER_STRIPPED, complete.state)
        self.assertIn("void execute_case", complete.source or "")
        self.assertEqual(ResponseState.TRUNCATED_RESPONSE, unmatched.state)
        self.assertIsNone(unmatched.source)

    def test_output_limit_is_reported_separately_from_markdown(self) -> None:
        result = normalize_focused_java_response(
            "```java\n@Test void execute_case() {",
            finish_reason="length",
            output_tokens=8000,
        )
        self.assertEqual(ResponseState.OUTPUT_LIMIT_REACHED, result.state)
        self.assertEqual(8000, result.output_tokens)


class FixtureVariantV11Test(unittest.TestCase):
    def _fixture_context(self):
        method = MethodSig("execute", modifiers={"public"}, return_type="Object")
        property_ = PayloadProperty(
            name="type",
            type_name="Character",
            readable=True,
            writable=True,
            getter="getType",
            setter="setType",
            kind=PropertyKind.SCALAR,
        )
        schema = PayloadSchema(
            type_name="GiPolicyEntity",
            fqcn="sample.GiPolicyEntity",
            kind="class",
            properties=(property_,),
            resolution_status=ResolutionStatus.RESOLVED,
            construction_kind=ConstructionKind.NO_ARGS_SETTERS,
            fixture_method_name="validGiPolicyEntity",
        )
        fixture = FixtureSpec(
            fixture_id="sample.GiPolicyEntity",
            method_name="validGiPolicyEntity",
            return_type="GiPolicyEntity",
            schema_id="sample.GiPolicyEntity",
            method_source=(
                "    private GiPolicyEntity validGiPolicyEntity() {\n"
                "        return new GiPolicyEntity();\n"
                "    }"
            ),
        )
        method_context = MethodExecutionContext(
            method_id="execute()",
            signature=method.render(),
            source_range=(1, 1),
            method_source="public Object execute() { return new Object(); }",
            endpoint=None,
            payload_schemas=(schema,),
            required_fixture_ids=(fixture.fixture_id,),
        )
        return _ctx(method, method_context, schemas=(schema,), fixtures=(fixture,)), method_context

    def test_application_setters_are_hoisted_out_of_test_into_compiled_variant(self) -> None:
        ctx, method_context = self._fixture_context()
        source = """@Test
void execute_case() {
    GiPolicyEntity giPolicyEntity = validGiPolicyEntity();
    giPolicyEntity.setType('M');
    sampleServiceImpl.execute();
}
"""
        result = hoist_fixture_mutations(
            ctx, method_context, source, test_name="execute_case"
        )
        self.assertTrue(result.changed)
        self.assertNotIn("giPolicyEntity.setType", result.source)
        self.assertIn("Variant", result.source)
        self.assertIn("giPolicyEntity.setType('M')", result.helper_sources[0])
        suite = inject_fixture_variant_helpers("class T {\n}\n", result.helper_sources)
        self.assertIn("private GiPolicyEntity validGiPolicyEntityVariant", suite)

    def test_unmutated_direct_application_construction_uses_baseline_fixture(self) -> None:
        ctx, method_context = self._fixture_context()
        source = """@Test
void execute_case() {
    GiPolicyEntity giPolicyEntity = new GiPolicyEntity();
    sampleServiceImpl.execute();
}
"""
        result = hoist_fixture_mutations(
            ctx, method_context, source, test_name="execute_case"
        )
        self.assertTrue(result.changed)
        self.assertIn(
            "GiPolicyEntity giPolicyEntity = validGiPolicyEntity();",
            result.source,
        )
        self.assertNotIn("new GiPolicyEntity", result.source)

    def test_compiled_variant_is_added_to_authoritative_fixture_catalogue(self) -> None:
        ctx, method_context = self._fixture_context()
        source = """@Test
void execute_case() {
    GiPolicyEntity giPolicyEntity = validGiPolicyEntity();
    giPolicyEntity.setType('M');
    sampleServiceImpl.execute();
}
"""
        variant = hoist_fixture_mutations(
            ctx, method_context, source, test_name="execute_case"
        )
        test_record = TestCaseRecord(
            owner_method_id="execute()",
            test_name="execute_case",
            generated_source=source,
            latest_accepted_source=variant.source,
            fixture_dependencies=[dict(item, compile_state="PASSED") for item in variant.dependencies],
            fixture_variant_sources=list(variant.helper_sources),
            final_disposition=TestDisposition.RETAINED.value,
        )
        method_record = MethodGenerationRecord(method_id="execute()", tests=[test_record])
        fake_result = (0, method_context, variant.source, ("execute_case",), 0, None, method_record)

        added = _register_compiled_fixture_variants(ctx, [fake_result])
        self.assertEqual(1, len(added))
        self.assertTrue(added[0].fixture_variant)
        self.assertEqual("PASSED", added[0].compile_state)
        self.assertIn("sample.GiPolicyEntity", added[0].dependent_fixture_ids)
        self.assertIn(added[0], ctx.execution_context.fixtures)


class SourceClosureAndContractV11Test(unittest.TestCase):
    def test_helper_source_uses_complete_file_not_truncated_prompt_source(self) -> None:
        entry = MethodSig(
            "execute", modifiers={"public"}, return_type="Object", line=2, end_line=4
        )
        helper = MethodSig(
            "helper", modifiers={"private"}, return_type="Object", line=125, end_line=127
        )
        lines = ["public class SampleServiceImpl {", "public Object execute() {", "return helper();", "}"]
        lines.extend("// filler" for _ in range(120))
        lines.extend(["private Object helper() {", "return new Object();", "}", "}"])
        source = "\n".join(lines)
        with tempfile.TemporaryDirectory() as tmp:
            source_path = Path(tmp) / "SampleServiceImpl.java"
            source_path.write_text(source, encoding="utf-8")
            method_context = MethodExecutionContext(
                method_id="execute()",
                signature=entry.render(),
                source_range=(2, 4),
                method_source="\n".join(lines[1:4]),
                endpoint=None,
                reachable_private_methods=("helper()",),
            )
            ctx = _ctx(
                entry,
                method_context,
                source_path=source_path,
                symbol_methods=[entry, helper],
            )
            ctx.cut_source = method_context.method_source
            closure = build_source_closure(ctx, method_context)
        self.assertTrue(closure.complete)
        self.assertEqual(1, len(closure.reachable_methods))
        self.assertIn("private Object helper()", closure.reachable_methods[0].source)

    def test_commented_helper_call_is_not_an_execution_edge(self) -> None:
        entry = MethodSig("execute", modifiers={"public"}, return_type="void")
        calls = _helper_calls(
            entry,
            "public void execute() { // helper();\n String text = \"helper()\";\n }",
            1,
            {("helper", 0): "helper()"},
            [],
        )
        self.assertEqual([], calls)

    def test_unresolved_collaborator_contract_remains_null_not_fake_void(self) -> None:
        method = MethodSig("execute", modifiers={"public"}, return_type="Object")
        contract = DependencyMethodContract(
            dependency_field="repo",
            dependency_type="Repo",
            method_name="saveAndFlush",
            return_type=None,
            parameter_types=("?",),
            resolution_status=ResolutionStatus.PARTIAL,
        )
        invocation = DependencyInvocation(
            invocation_id="execute():I1",
            caller_method_id="execute()",
            dependency_field="repo",
            dependency_type="Repo",
            method_name="saveAndFlush",
            arguments=(InvocationArgument("entity"),),
            contract=contract,
            return_value_consumed=False,
            consumption_kind=ReturnConsumptionKind.IGNORED,
        )
        method_context = MethodExecutionContext(
            method_id="execute()",
            signature=method.render(),
            source_range=(1, 1),
            method_source="public Object execute() { return null; }",
            endpoint=None,
            dependency_invocations=(invocation,),
        )
        payload = serviceimpl._collaborator_payload(method_context)
        method_payload = payload[0]["methods"][0]
        self.assertIsNone(method_payload["return_type"])
        self.assertEqual(["?"], method_payload["parameter_types"])
        self.assertEqual("partial", method_payload["resolution_status"])
        self.assertIn("<unresolved>", method_payload["signature"])

    def test_inherited_spring_data_contract_uses_repository_generic_types(self) -> None:
        repository = ClassSymbol(
            "GiPolicyRepository",
            "sample.GiPolicyRepository",
            "interface",
            extends="JpaRepository<GiPolicyEntity, Long>",
        )
        dependency = DependencyRef(
            field_name="giPolicyRepository",
            parameter_name=None,
            declared_type="GiPolicyRepository",
            simple_type="GiPolicyRepository",
            fqcn=repository.fqcn,
            origin="field",
            resolution_status=ResolutionStatus.RESOLVED,
        )
        contract = resolve_method_contract(
            dependency,
            "saveAndFlush",
            (InvocationArgument("policy", inferred_type="GiPolicyEntity"),),
            lambda name: repository if name == "GiPolicyRepository" else None,
        )
        self.assertEqual("GiPolicyEntity", contract.return_type)
        self.assertEqual(("GiPolicyEntity",), contract.parameter_types)
        self.assertTrue(contract.inherited_spring_data)


class CompleteClassRepairDisabledV11Test(unittest.TestCase):
    def test_legacy_serviceimpl_complete_class_repair_is_explicitly_disabled(self) -> None:
        mixin = CompilationRepairMixin()
        with self.assertRaisesRegex(RuntimeError, "complete-class compile repair is disabled"):
            mixin._compile_serviceimpl_class_repair(None, None, None, None, [])


if __name__ == "__main__":
    unittest.main()
