from __future__ import annotations

import json
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from junitforge.config import GenConfig
from junitforge.generation.payloads import payload_builder_for, payload_builder_for_context
from junitforge.generation.payloads import controller, dto_entity, other, serviceimpl
from junitforge.generation.source_closure import build_source_closure
from junitforge.loop import Engine, _select_method_repair_owner
from junitforge.models import ClassSymbol, JavaSourceFile, MethodSig, ModuleInfo, StackProfile
from junitforge.pipeline.engine import GenerationPipeline
from junitforge.pipeline.state import PipelineState


class LoopFacadeRegressionTest(unittest.TestCase):
    def _engine(self) -> Engine:
        return Engine(
            llm=None,
            compile_gate=SimpleNamespace(ready=False),
            coverage_runner=None,
            stack=StackProfile(),
            modules=[],
            repo_root=Path('.'),
            lookup=lambda _name: None,
            cfg=GenConfig(),
        )

    def test_engine_remains_generation_pipeline_compatible(self) -> None:
        engine = self._engine()
        self.assertIsInstance(engine, GenerationPipeline)
        self.assertTrue(callable(engine.run_target))

    def test_all_original_engine_methods_remain_available(self) -> None:
        engine = self._engine()
        original_methods = {
            'run_target', '_generate', '_generate_methodwise', '_generate_classwide',
            '_compile_with_repair', '_compile_methodwise_repair',
            '_reject_irreparable_compile_tests', '_repair_methodwise_header_errors',
            '_repair_compile_diagnostics_deterministically',
            '_commit_deterministic_compile_actions', '_repair_methodwise_error_batch',
            '_commit_methodwise_llm_repair', '_coverage_loop', '_augment',
            '_augment_methodwise', '_record_coverage_runtime_result',
            '_record_runtime_test_result', '_runtime_failure_repair_loop',
            '_repair_runtime_owner', '_build_failure_reason', '_restore_or_remove',
            '_capture_failed_test_snapshot', '_log_compile_failure', '_test_fqcn',
            '_own_maven_errors', '_recover_maven_compile', '_classpath_profile',
            '_class_cov', '_branch_hints', '_chat',
        }
        missing = sorted(name for name in original_methods if not callable(getattr(engine, name, None)))
        self.assertEqual([], missing)

    def test_moved_methods_resolve_to_authoritative_modules(self) -> None:
        engine = self._engine()
        expected = {
            '_generate_methodwise': 'junitforge.generation.method_generator',
            '_compile_methodwise_repair': 'junitforge.compilation.repair_coordinator',
            '_repair_runtime_owner': 'junitforge.runtime.repair_coordinator',
            '_coverage_loop': 'junitforge.coverage.coordinator',
            '_augment_methodwise': 'junitforge.coverage.augmentation',
            '_restore_or_remove': 'junitforge.publication.publisher',
        }
        for name, module in expected.items():
            self.assertEqual(module, getattr(engine, name).__module__)

    def test_loop_facade_does_not_contain_moved_implementations(self) -> None:
        source = Path('junitforge/loop.py').read_text(encoding='utf-8')
        self.assertNotIn('def _coverage_loop(', source)
        self.assertNotIn('def _compile_methodwise_repair(', source)
        self.assertNotIn('def _generate_methodwise(', source)
        self.assertLess(len(source.splitlines()), 100)


    def test_run_target_uses_facade_pipeline_without_state_regression(self) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            source_path = root / 'src/main/java/sample/SampleServiceImpl.java'
            source_path.parent.mkdir(parents=True)
            source_path.write_text('package sample; public class SampleServiceImpl {}', encoding='utf-8')
            test_path = root / 'src/test/java/sample/SampleServiceImplTest.java'
            symbol = ClassSymbol(
                name='SampleServiceImpl',
                fqcn='sample.SampleServiceImpl',
                kind='class',
                modifiers={'public'},
                package_name='sample',
            )
            java_file = JavaSourceFile(path=source_path, package='sample', types=[symbol], source=source_path.read_text())
            module = ModuleInfo('root', root, root / 'pom.xml')
            engine = Engine(
                llm=None,
                compile_gate=SimpleNamespace(ready=False),
                coverage_runner=None,
                stack=StackProfile(),
                modules=[module],
                repo_root=root,
                lookup=lambda _name: None,
                cfg=GenConfig(run_coverage=False),
                test_path_fn=lambda *_args: test_path,
                symbol_resolver=SimpleNamespace(parse_target=lambda _path: java_file),
            )
            template = SimpleNamespace(kind=SimpleNamespace(value='pure_unit'), testable=True, reasons=[])
            cp = SimpleNamespace(has_junit_jupiter=True)
            ctx = SimpleNamespace(
                execution_context=None,
                test_package='sample',
                test_class_name='SampleServiceImplTest',
            )
            generated = 'package sample; class SampleServiceImplTest {}'
            with (
                patch('junitforge.pipeline.context.module_for_source', return_value=module),
                patch('junitforge.pipeline.context.is_test_target', return_value=(True, '')),
                patch.object(engine, '_classpath_profile', return_value=cp),
                patch('junitforge.pipeline.context.classify', return_value=template),
                patch('junitforge.pipeline.context.resolve_collaborators', return_value=[]),
                patch('junitforge.pipeline.context.classify_execution_target', return_value=SimpleNamespace(value='service-impl')),
                patch('junitforge.pipeline.context.build_execution_context', return_value=None),
                patch('junitforge.pipeline.context.build_context', return_value=ctx),
                patch.object(engine, '_generate', return_value=generated),
                patch.object(engine, '_compile_with_repair', return_value=generated),
            ):
                outcome = engine.run_target(source_path)

            self.assertEqual('compiled', outcome.status)
            self.assertEqual(generated, test_path.read_text(encoding='utf-8'))

    def test_legacy_top_level_helper_is_reexported(self) -> None:
        self.assertTrue(callable(_select_method_repair_owner))


class PayloadRoutingRegressionTest(unittest.TestCase):
    def test_payload_builder_routes_each_target_type(self) -> None:
        self.assertIs(serviceimpl, payload_builder_for('service-impl'))
        self.assertIs(controller, payload_builder_for('controller'))
        self.assertIs(dto_entity, payload_builder_for('dto'))
        self.assertIs(dto_entity, payload_builder_for('entity'))
        self.assertIs(other, payload_builder_for('utility'))

    def test_payload_builder_routes_from_execution_context(self) -> None:
        ctx = SimpleNamespace(
            execution_context=SimpleNamespace(
                target_kind=SimpleNamespace(value='service-impl')
            )
        )
        self.assertIs(serviceimpl, payload_builder_for_context(ctx))

    def test_payload_builder_uses_template_style_for_non_suffix_dto_and_entity(self) -> None:
        dto_ctx = SimpleNamespace(
            execution_context=None,
            template=SimpleNamespace(style='dto-pojo'),
            symbol=SimpleNamespace(name='PaymentResource', annotations=[]),
        )
        entity_ctx = SimpleNamespace(
            execution_context=None,
            template=SimpleNamespace(style='entity-pojo'),
            symbol=SimpleNamespace(name='PolicyRecord', annotations=[]),
        )
        self.assertIs(dto_entity, payload_builder_for_context(dto_ctx))
        self.assertIs(dto_entity, payload_builder_for_context(entity_ctx))

    def test_serviceimpl_builder_emits_structured_generation_payload(self) -> None:
        method = SimpleNamespace(render=lambda: "public Result execute()", name="execute", params=[])
        method_context = SimpleNamespace(
            method_id="execute()",
            method_source="public Result execute() { return null; }",
            required_fixture_ids=(),
            dependency_invocations=(),
        )
        ctx = SimpleNamespace(
            symbol=SimpleNamespace(fqcn="sample.SampleServiceImpl", name="SampleServiceImpl"),
            execution_context=SimpleNamespace(methods=(method_context,), fixtures=()),
        )
        closure = SimpleNamespace(method_source=method_context.method_source, reachable_methods=())
        with patch.object(serviceimpl, "build_source_closure", return_value=closure):
            messages = serviceimpl.build_generation_payload(ctx, method, mode="method")
        payload = json.loads(messages[1]["content"])
        self.assertEqual("method_test_generation", payload["request_type"])
        self.assertEqual(method_context.method_source, payload["target_method"]["source"])
        self.assertEqual([], payload["reachable_same_class_methods"])

    def test_serviceimpl_builder_uses_v11_focused_stage_contracts(self) -> None:
        method = SimpleNamespace(render=lambda: "public Result execute()", name="execute", params=[])
        method_context = SimpleNamespace(
            method_id="execute()",
            method_source="public Result execute() { return null; }",
            required_fixture_ids=(),
            dependency_invocations=(),
            payload_schemas=(),
        )
        ctx = SimpleNamespace(
            symbol=SimpleNamespace(fqcn="sample.SampleServiceImpl", name="SampleServiceImpl", fields=()),
            execution_context=SimpleNamespace(
                methods=(method_context,), fixtures=(), configuration_fields=(), dependencies=()
            ),
            test_class_name="SampleServiceImplTest",
            source_imports=(),
        )
        messages = serviceimpl.build_validation_repair_payload(
            ctx, method, "@Test void execute_fails() {}", "execute_fails", "invalid getter"
        )
        validation_payload = json.loads(messages[1]["content"])
        self.assertEqual("single_test_generation_validation_repair", validation_payload["request_type"])

        error = SimpleNamespace(line=2, col=3, message="cannot find symbol", detail=[], raw="", file=None)
        messages = serviceimpl.build_compile_repair_payload(
            ctx=ctx,
            method=method,
            current_test="@Test void execute_fails() {}",
            test_name="execute_fails",
            errors=[error],
            mode="individual",
        )
        compile_payload = json.loads(messages[1]["content"])
        self.assertEqual("single_test_compile_repair", compile_payload["request_type"])
        self.assertEqual(1, len(compile_payload["compiler_diagnostics"]))

        coverage_disabled = serviceimpl.build_coverage_augmentation_payload("x")
        self.assertEqual("coverage_augmentation", coverage_disabled.request_type)
        self.assertIn("disabled", coverage_disabled.reason.lower())


class PipelineStateRegressionTest(unittest.TestCase):
    def test_rollback_selects_strongest_accepted_source(self) -> None:
        state = PipelineState(original_source='original')
        state.record_generated_candidate('generated')
        state.record_compiling_source('compiled')
        self.assertEqual('compiled', state.rollback_to_last_accepted())
        state.record_runtime_green_source('green')
        self.assertEqual('green', state.rollback_to_last_accepted())
        state.record_coverage_valid_source('covered')
        self.assertEqual('covered', state.rollback_to_last_accepted())

    def test_source_closure_resolves_exact_helper_source_from_verified_ranges(self) -> None:
        cut_source = """public class Sample {
    public void execute(String value) { normalize(value); }
    private String normalize(String value) { return value.trim(); }
}
"""
        symbol = ClassSymbol(
            name='Sample',
            fqcn='sample.Sample',
            kind='class',
            modifiers={'public'},
            methods=[
                MethodSig('execute', {'public'}, 'void', [('String', 'value')], line=2, end_line=2),
                MethodSig('normalize', {'private'}, 'String', [('String', 'value')], line=3, end_line=3),
            ],
        )
        ctx = SimpleNamespace(symbol=symbol, cut_source=cut_source)
        method = SimpleNamespace(
            method_id='execute(String)',
            method_source='public void execute(String value) { normalize(value); }',
            reachable_private_methods=('normalize(String)',),
            diagnostics=(),
        )
        closure = build_source_closure(ctx, method)
        self.assertTrue(closure.complete)
        self.assertEqual(1, len(closure.reachable_methods))
        self.assertIn('return value.trim()', closure.reachable_methods[0].source)

    def test_source_closure_uses_existing_v733_reachable_helper_facts(self) -> None:
        method = SimpleNamespace(
            method_id='execute(String)',
            method_source='public void execute(String value) {}',
            reachable_private_methods=('normalize(String)', 'validate(String)'),
            diagnostics=(),
        )
        closure = build_source_closure(method)
        self.assertEqual('execute(String)', closure.method_id)
        self.assertEqual(('normalize(String)', 'validate(String)'), closure.reachable_method_ids)
        self.assertTrue(closure.complete)


if __name__ == '__main__':
    unittest.main()
