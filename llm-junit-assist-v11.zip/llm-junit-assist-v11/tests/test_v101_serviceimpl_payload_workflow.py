from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from junitforge.compilation.candidate_validator import complete_test_class_response_error
from junitforge.generation.response_normalizer import normalize_focused_java_response, ResponseState
from junitforge.config import GenConfig
from junitforge.coverage.augmentation import CoverageAugmentationMixin
from junitforge.coverage_run import (
    CoverageRunResult,
    CoverageSignals,
    RuntimeTestRunResult,
    SurefireFailure,
)
from junitforge.generation.payloads import serviceimpl
from junitforge.execution.models import ExecutionContext, ExecutionTargetKind, MethodExecutionContext
from junitforge.loop import Engine
from junitforge.models import (
    ClassCoverage,
    ClassSymbol,
    ClasspathProfile,
    CompileError,
    GenerationContext,
    LineCoverage,
    MethodCoverage,
    MethodGenerationRecord,
    MethodSig,
    ModuleInfo,
    StackProfile,
    TargetOutcome,
    TemplateSpec,
    TestCaseRecord as CaseRecord,
    TestDisposition as Disposition,
    TestKind as Kind,
)
from junitforge.pipeline.result import (
    owner_for_test,
    sync_test_registry_sources,
    test_registry as registry_for_outcome,
)
from junitforge.runtime.candidate_validator import validate_runtime_candidate_identity
from junitforge.runtime.result_parser import _group_runtime_failures, runtime_diagnostic
from junitforge.report import write_reports
from junitforge.runtime.state import _record_test_runtime_states


def _payload(messages):
    return json.loads(messages[1]["content"])


def _context(root: Path | None = None) -> tuple[GenerationContext, MethodSig, MethodExecutionContext]:
    root = root or Path(".")
    method = MethodSig("execute", modifiers={"public"}, return_type="Object")
    method_context = MethodExecutionContext(
        method_id="execute()",
        signature=method.render(),
        source_range=(1, 3),
        method_source="public Object execute() { return new Object(); }",
        endpoint=None,
    )
    execution = ExecutionContext(
        target_kind=ExecutionTargetKind.SERVICE_IMPL,
        target_fqcn="sample.PaymentServiceImpl",
        methods=(method_context,),
    )
    symbol = ClassSymbol(
        "PaymentServiceImpl",
        "sample.PaymentServiceImpl",
        "class",
        modifiers={"public"},
        methods=[method],
    )
    ctx = GenerationContext(
        cut_source=method_context.method_source,
        symbol=symbol,
        collaborators=[],
        test_package="sample",
        test_class_name="PaymentServiceImplTest",
        stack=StackProfile(java_version="17"),
        classpath=ClasspathProfile(has_junit_jupiter=True, has_mockito=True),
        template=TemplateSpec(Kind.PURE_UNIT, "unit", line_target=80, branch_target=80),
        source_path=root / "PaymentServiceImpl.java",
        execution_context=execution,
    )
    return ctx, method, method_context


def _outcome() -> TargetOutcome:
    outcome = TargetOutcome(
        fqcn="sample.PaymentServiceImpl",
        module="sample",
        source_path="PaymentServiceImpl.java",
        test_path="PaymentServiceImplTest.java",
        classification="pure_unit",
        testable=True,
    )
    outcome.method_results = [
        MethodGenerationRecord(
            method_id="execute()",
            tests=[
                CaseRecord(
                    owner_method_id="execute()",
                    test_name="execute_passes",
                    generated_source="@Test void execute_passes() { assertTrue(true); }",
                    final_disposition=Disposition.RETAINED.value,
                ),
                CaseRecord(
                    owner_method_id="execute()",
                    test_name="execute_fails",
                    generated_source="@Test void execute_fails() { assertNull(paymentServiceImpl.execute()); }",
                    final_disposition=Disposition.RETAINED.value,
                ),
            ],
        )
    ]
    return outcome


class ServiceImplPayloadV101Test(unittest.TestCase):
    def test_generation_payload_uses_finalized_top_level_structure(self) -> None:
        ctx, method, method_context = _context()
        closure = SimpleNamespace(
            method_source=method_context.method_source,
            reachable_methods=(
                SimpleNamespace(
                    method_id="helper()",
                    signature="private Object helper()",
                    visibility="private",
                    source="private Object helper() { return new Object(); }",
                ),
            ),
        )
        with patch.object(serviceimpl, "build_source_closure", return_value=closure):
            payload = _payload(serviceimpl.build_generation_payload(ctx, method, mode="method"))
        self.assertEqual(
            {
                "request_type",
                "target_class",
                "target_method",
                "reachable_same_class_methods",
                "fixtures",
                "collaborators",
                "constants",
                "configuration_fields",
                "available_test_apis",
                "source_closure",
                "generation_instruction",
            },
            set(payload),
        )
        self.assertEqual(method_context.method_source, payload["target_method"]["source"])
        self.assertEqual("helper()", payload["reachable_same_class_methods"][0]["method_id"])

    def test_compile_payload_is_focused_single_test_only(self) -> None:
        ctx, method, _method_context = _context()
        source = "@Test void execute_fails() { Missing first; Missing second; }"
        errors = [
            CompileError(Path("PaymentServiceImplTest.java"), 1, 1, "cannot find symbol"),
            CompileError(Path("PaymentServiceImplTest.java"), 1, 4, "incompatible types"),
        ]
        payload = _payload(serviceimpl.build_compile_repair_payload(
            ctx=ctx,
            method=method,
            current_test=source,
            test_name="execute_fails",
            errors=errors,
            mode="individual",
        ))
        self.assertEqual("single_test_compile_repair", payload["request_type"])
        self.assertEqual(source, payload["current_test_source"])
        self.assertEqual(2, len(payload["compiler_diagnostics"]))
        self.assertNotIn("test_class", payload)

    def test_focused_repair_strips_complete_markdown_and_rejects_unmatched_fence(self) -> None:
        complete = normalize_focused_java_response(
            "```java\n@Test void execute_fails() {}\n```"
        )
        truncated = normalize_focused_java_response(
            "```java\n@Test void execute_fails() {"
        )
        self.assertEqual(ResponseState.MARKDOWN_WRAPPER_STRIPPED, complete.state)
        self.assertIsNotNone(complete.source)
        self.assertEqual(ResponseState.TRUNCATED_RESPONSE, truncated.state)
        self.assertIsNone(truncated.source)

    def test_runtime_payload_contains_only_supplied_failing_tests(self) -> None:
        ctx, method, _method_context = _context()
        failing = [{
            "test_name": "execute_fails",
            "source": "@Test void execute_fails() { assertNull(paymentServiceImpl.execute()); }",
            "runtime_status": "failure",
            "diagnostics": [{"type": "assertion_failure", "message": "expected null"}],
        }]
        payload = _payload(serviceimpl.build_runtime_repair_payload(
            ctx,
            method,
            failing_tests=failing,
            shared_test_context={
                "required_mock_fields": [],
                "required_setup_fragments": [],
                "required_fixture_helpers": [],
            },
        ))
        self.assertEqual(["execute_fails"], [item["test_name"] for item in payload["failing_tests"]])
        self.assertNotIn("test_class", payload)
        self.assertNotIn("execute_passes", json.dumps(payload))

    def test_validation_repair_is_focused_and_coverage_llm_stages_remain_disabled(self) -> None:
        ctx, method, _method_context = _context()
        payload = _payload(serviceimpl.build_validation_repair_payload(
            ctx, method, "@Test void execute_fails() {}", "execute_fails", "invalid"
        ))
        self.assertEqual("single_test_generation_validation_repair", payload["request_type"])
        self.assertEqual(
            "coverage_augmentation",
            serviceimpl.build_coverage_augmentation_payload().request_type,
        )
        self.assertEqual("coverage_repair", serviceimpl.build_coverage_repair_payload().request_type)


class ServiceImplRegistryV101Test(unittest.TestCase):
    def test_registry_tracks_owner_order_and_current_accepted_source(self) -> None:
        outcome = _outcome()
        source = """class PaymentServiceImplTest {
// JUNITFORGE_METHOD_BEGIN: execute()
@Test void execute_passes() { assertTrue(true); }
@Test void execute_fails() { assertNotNull(paymentServiceImpl.execute()); }
// JUNITFORGE_METHOD_END: execute()
}
"""
        sync_test_registry_sources(outcome, source, compile_state="PASSED", accepted=True)
        registry = registry_for_outcome(outcome)
        method_record = outcome.method_results[0]
        self.assertEqual(2, method_record.generated_test_count)
        self.assertEqual(("execute_passes", "execute_fails"), method_record.ordered_test_names)
        self.assertEqual(["execute_passes", "execute_fails"], [test.test_name for test in registry["execute()"]])
        self.assertEqual("execute()", owner_for_test(outcome, "execute_fails"))
        self.assertIn("assertNotNull", registry["execute()"][1].latest_accepted_source)
        self.assertEqual("PASSED", registry["execute()"][1].compile_state)

    def test_runtime_state_pairs_error_and_assertion_failure_to_exact_tests(self) -> None:
        outcome = _outcome()
        failures = (
            SurefireFailure(
                "sample.PaymentServiceImplTest",
                "execute_fails",
                "failure",
                "org.opentest4j.AssertionFailedError",
                "expected: <null> but was: <value>",
                "trace",
                generated_test_line=4,
                category="ASSERTION_VALUE_MISMATCH",
            ),
        )
        run = RuntimeTestRunResult(
            True,
            "failed",
            signals=CoverageSignals(tests_executed=True, tests_run=2, tests_failed=1),
            failures=failures,
            executed_test_names=("execute_passes", "execute_fails"),
        )
        _record_test_runtime_states(outcome, run)
        tests = registry_for_outcome(outcome)["execute()"]
        self.assertEqual("PASSED", tests[0].runtime_state)
        self.assertEqual("FAILURE", tests[1].runtime_state)
        self.assertEqual("assertion_failure", tests[1].runtime_diagnostics[0]["type"])
        self.assertEqual("null", tests[1].runtime_diagnostics[0]["expected"])
        self.assertEqual("value", tests[1].runtime_diagnostics[0]["actual"])

    def test_runtime_owner_grouping_prefers_authoritative_registry(self) -> None:
        outcome = _outcome()
        failure = SurefireFailure(
            "sample.PaymentServiceImplTest",
            "execute_fails",
            "error",
            "java.lang.NullPointerException",
            "null",
            "trace",
        )
        grouped, unmapped = _group_runtime_failures("class PaymentServiceImplTest {}", [failure], outcome)
        self.assertEqual([failure], grouped["execute()"])
        self.assertEqual([], unmapped)


class ServiceImplRuntimePayloadRoutingV101Test(unittest.TestCase):
    def test_runtime_coordinator_excludes_passed_sibling_from_llm_request(self) -> None:
        class CaptureStop(RuntimeError):
            pass

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ctx, _method, _method_context = _context(root)
            test_path = root / "PaymentServiceImplTest.java"
            source = """class PaymentServiceImplTest {
// JUNITFORGE_METHOD_BEGIN: execute()
@Test void execute_passes() { assertTrue(true); }
@Test void execute_fails() { assertNull(paymentServiceImpl.execute()); }
// JUNITFORGE_METHOD_END: execute()
}
"""
            test_path.write_text(source, encoding="utf-8")
            outcome = _outcome()
            failure = SurefireFailure(
                "sample.PaymentServiceImplTest",
                "execute_fails",
                "failure",
                "org.opentest4j.AssertionFailedError",
                "expected: <null> but was: <value>",
                "trace",
                generated_test_line=4,
                category="ASSERTION_VALUE_MISMATCH",
            )
            before = RuntimeTestRunResult(
                True,
                "failed",
                signals=CoverageSignals(tests_executed=True, tests_run=2, tests_failed=1),
                failures=(failure,),
                executed_test_names=("execute_passes", "execute_fails"),
            )
            engine = Engine(
                llm=MagicMock(),
                compile_gate=MagicMock(),
                coverage_runner=MagicMock(),
                stack=StackProfile(),
                modules=[],
                repo_root=root,
                lookup=lambda _name: None,
                cfg=GenConfig(),
            )
            captured = {}
            builder = MagicMock()

            def build_runtime(*args, **kwargs):
                captured.update(kwargs)
                return [{"role": "system", "content": "x"}, {"role": "user", "content": "{}"}]

            builder.build_runtime_repair_payload.side_effect = build_runtime
            engine._chat = MagicMock(side_effect=CaptureStop)
            with patch(
                "junitforge.runtime.repair_coordinator.payload_builder_for_context",
                return_value=builder,
            ):
                with self.assertRaises(CaptureStop):
                    engine._repair_runtime_owner(
                        ctx=ctx,
                        test_path=test_path,
                        module=ModuleInfo("sample", root, root / "pom.xml"),
                        owner="execute()",
                        owner_failures=[failure],
                        before_run=before,
                        outcome=outcome,
                        test_fqcn="sample.PaymentServiceImplTest",
                        round_no=1,
                        attempt_no=1,
                    )
            self.assertEqual(["execute_fails"], [item["test_name"] for item in captured["failing_tests"]])
            self.assertNotIn("execute_passes", json.dumps(captured["failing_tests"]))


class ServiceImplRuntimeAcceptanceV101Test(unittest.TestCase):
    def test_runtime_candidate_rejects_changes_to_passed_sibling_source(self) -> None:
        before_source = """class PaymentServiceImplTest {
// JUNITFORGE_METHOD_BEGIN: execute()
@Test void execute_passes() { assertTrue(true); }
@Test void execute_fails() { assertNull(paymentServiceImpl.execute()); }
// JUNITFORGE_METHOD_END: execute()
}
"""
        after_source = before_source.replace(
            "assertTrue(true);", "assertNotNull(new Object());"
        ).replace(
            "assertNull(paymentServiceImpl.execute());",
            "assertNotNull(paymentServiceImpl.execute());",
        )
        failure = SurefireFailure(
            "sample.PaymentServiceImplTest",
            "execute_fails",
            "failure",
            "AssertionFailedError",
            "expected null",
            "trace",
        )
        before_run = RuntimeTestRunResult(
            True,
            "before",
            signals=CoverageSignals(tests_executed=True, tests_run=2, tests_failed=1),
            failures=(failure,),
            executed_test_names=("execute_passes", "execute_fails"),
        )
        targeted = RuntimeTestRunResult(
            True,
            "targeted",
            signals=CoverageSignals(tests_executed=True, tests_run=1),
            executed_test_names=("execute_fails",),
        )
        full = RuntimeTestRunResult(
            True,
            "full",
            signals=CoverageSignals(tests_executed=True, tests_run=2),
            executed_test_names=("execute_passes", "execute_fails"),
        )
        accepted, reason, details = validate_runtime_candidate_identity(
            before_source=before_source,
            after_source=after_source,
            owner="execute()",
            selected_test_names={"execute_fails"},
            before_run=before_run,
            targeted_run=targeted,
            full_run=full,
            owner_failures_before=[failure],
            require_full_green=True,
        )
        self.assertFalse(accepted)
        self.assertEqual("PASSED_TEST_SOURCE_CHANGED", reason)
        self.assertEqual(("execute_passes",), details)

    def test_rejected_runtime_candidate_restores_registry_source_and_state(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ctx, _method, _method_context = _context(root)
            test_path = root / "PaymentServiceImplTest.java"
            source = """class PaymentServiceImplTest {
// JUNITFORGE_METHOD_BEGIN: execute()
@Test void execute_passes() { assertTrue(true); }
@Test void execute_fails() { assertNull(paymentServiceImpl.execute()); }
// JUNITFORGE_METHOD_END: execute()
}
"""
            test_path.write_text(source, encoding="utf-8")
            outcome = _outcome()
            sync_test_registry_sources(outcome, source, compile_state="PASSED", accepted=True)
            original_failed_source = registry_for_outcome(outcome)["execute()"][1].generated_source
            failure = SurefireFailure(
                "sample.PaymentServiceImplTest",
                "execute_fails",
                "failure",
                "org.opentest4j.AssertionFailedError",
                "expected: <null> but was: <value>",
                "trace",
                generated_test_line=4,
                category="ASSERTION_VALUE_MISMATCH",
            )
            before = RuntimeTestRunResult(
                True,
                "before",
                signals=CoverageSignals(tests_executed=True, tests_run=2, tests_failed=1),
                failures=(failure,),
                executed_test_names=("execute_passes", "execute_fails"),
            )
            targeted = RuntimeTestRunResult(
                True,
                "targeted",
                signals=CoverageSignals(tests_executed=True, tests_run=1),
                executed_test_names=("execute_fails",),
            )
            full_failed = RuntimeTestRunResult(
                True,
                "full failed",
                signals=CoverageSignals(tests_executed=True, tests_run=2, tests_failed=1),
                failures=(failure,),
                executed_test_names=("execute_passes", "execute_fails"),
            )
            runner = MagicMock()
            runner.run_tests.side_effect = [targeted, full_failed]
            engine = Engine(
                llm=MagicMock(),
                compile_gate=MagicMock(),
                coverage_runner=runner,
                stack=StackProfile(),
                modules=[],
                repo_root=root,
                lookup=lambda _name: None,
                cfg=GenConfig(),
            )
            repaired = "@Test void execute_fails() { assertNotNull(paymentServiceImpl.execute()); }"
            candidate = source.replace(
                "@Test void execute_fails() { assertNull(paymentServiceImpl.execute()); }",
                repaired,
            )

            compile_success = (
                SimpleNamespace(ok=True, return_code=0, stdout="", stderr=""),
                [],
            )

            with patch.object(engine, "_chat", return_value=repaired), patch(
                "junitforge.runtime.repair_coordinator.finalize_java",
                return_value=SimpleNamespace(ok=True, code=candidate, reason=None),
            ), patch.object(engine, "_compile_candidate", return_value=compile_success), patch.object(
                engine, "_compile_with_repair", side_effect=AssertionError("nested compile repair must not run")
            ):
                accepted, _result, reason = engine._repair_runtime_owner(
                    ctx=ctx,
                    test_path=test_path,
                    module=ModuleInfo("sample", root, root / "pom.xml"),
                    owner="execute()",
                    owner_failures=[failure],
                    before_run=before,
                    outcome=outcome,
                    test_fqcn="sample.PaymentServiceImplTest",
                    round_no=1,
                    attempt_no=1,
                )
            self.assertFalse(accepted)
            self.assertEqual("FULL_SUITE_NOT_GREEN", reason)
            self.assertEqual(source, test_path.read_text(encoding="utf-8"))
            restored = registry_for_outcome(outcome)["execute()"][1]
            self.assertEqual(original_failed_source, restored.generated_source)
            self.assertEqual("FAILED", restored.runtime_state)
            self.assertEqual(1, restored.runtime_repair_attempts)
            self.assertEqual("ROLLBACK", restored.runtime_repair_history[-1]["result"])


class ServiceImplCoverageV101Test(unittest.TestCase):
    def test_green_serviceimpl_coverage_is_measured_reported_and_not_augmented(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ctx, _method, _method_context = _context(root)
            outcome = _outcome()
            xml_path = root / "target/site/jacoco/jacoco.xml"
            exec_path = root / "target/jacoco.exec"
            run = CoverageRunResult(
                True,
                True,
                "measured",
                xml_path=xml_path,
                expected_exec_path=exec_path,
                selected_exec_path=exec_path,
                signals=CoverageSignals(tests_executed=True, tests_run=2),
                executed_test_names=("execute_passes", "execute_fails"),
                maven_execution_success=True,
                coverage_current=True,
                coverage_source_sha256="abc123",
            )
            coverage = ClassCoverage(
                fqcn=ctx.symbol.fqcn,
                binary_name=ctx.symbol.fqcn,
                methods=[
                    MethodCoverage("execute", covered_instr=7),
                    MethodCoverage("helper", missed_instr=3),
                ],
                lines={
                    10: LineCoverage(10, ci=2),
                    11: LineCoverage(11, mi=1),
                    12: LineCoverage(12, mi=1, ci=1, mb=1, cb=1),
                },
                missed_instr=3,
                covered_instr=7,
                missed_branch=1,
                covered_branch=1,
                missed_line=1,
                covered_line=2,
            )
            runner = SimpleNamespace()
            engine = Engine(
                llm=MagicMock(),
                compile_gate=MagicMock(),
                coverage_runner=runner,
                stack=StackProfile(),
                modules=[],
                repo_root=root,
                lookup=lambda _name: None,
                cfg=GenConfig(),
            )
            with patch.object(engine, "_measure_coverage", return_value=run), patch.object(
                engine, "_class_cov", return_value=coverage
            ), patch.object(engine, "_augment") as augment:
                engine._serviceimpl_runtime_and_coverage(
                    ctx,
                    ModuleInfo("sample", root, root / "pom.xml"),
                    root / "PaymentServiceImplTest.java",
                    ctx.symbol,
                    outcome,
                )
            augment.assert_not_called()
            self.assertEqual("below_threshold", outcome.status)
            self.assertEqual(0, outcome.runtime_skipped_final)
            self.assertEqual(70.0, outcome.instruction_pct)
            self.assertEqual(50.0, outcome.branch_pct)
            self.assertEqual(50.0, outcome.method_pct)
            self.assertEqual([11], outcome.uncovered_lines)
            self.assertEqual([12], outcome.partially_covered_branch_lines)
            self.assertEqual(str(xml_path), outcome.jacoco_xml_path)
            self.assertEqual(str(exec_path), outcome.jacoco_exec_path)

            _json_path, md_path = write_reports(
                root / "reports", root, StackProfile(), [outcome], timestamp="v101"
            )
            markdown = md_path.read_text(encoding="utf-8")
            self.assertIn("ServiceImpl coverage details", markdown)
            self.assertIn("Instructions: 7 covered / 3 missed", markdown)
            self.assertIn("Partially covered branch lines: 12", markdown)
            self.assertIn(str(xml_path), markdown)

    def test_serviceimpl_augmentation_stops_without_payload_or_llm_call(self) -> None:
        class Subject(CoverageAugmentationMixin):
            pass

        subject = Subject()
        subject._chat = MagicMock()
        outcome = _outcome()
        ctx = SimpleNamespace(
            execution_context=SimpleNamespace(target_kind=SimpleNamespace(value="service-impl"))
        )
        self.assertFalse(subject._augment(ctx, Path("unused.java"), None, None, outcome))
        subject._chat.assert_not_called()
        self.assertTrue(any("disabled" in note.lower() for note in outcome.notes))


if __name__ == "__main__":
    unittest.main()
