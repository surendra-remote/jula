# llm-junit-assist v11 Change Manifest

## Scope

v11 modifies the existing v10.2 ServiceImpl pipeline only. It preserves the class-level lifecycle while moving semantic rejection, fixture preparation, compile repair, and runtime repair to registry-owned test units.

## Production changes

- `junitforge/__init__.py` — version changed to 11.0.
- `junitforge/timing.py` — timing/version events changed to 11.0.
- `junitforge/models.py` — added explicit compile states and expanded authoritative per-test registry state, including immutable generated source, accepted/candidate sources, diagnostics, and repair histories.
- `junitforge/execution/models.py` — extended fixture contracts with scenario-variant metadata and compile state.
- `junitforge/pipeline/result.py` — added stable test lookup, transactional snapshots, candidate staging/commit/rollback, immutable generated-source handling, and volatile range refresh.
- `junitforge/pipeline/context.py` — corrected collaborator resolution counts to use extracted signatures rather than a nonexistent methods field.
- `junitforge/execution/analyzer.py` — preserved public/protected/package/private same-class helper edges and excluded helper-looking calls inside comments and literals.
- `junitforge/generation/source_closure.py` — resolves helper ranges from the complete production source file instead of the token-truncated prompt source.
- `junitforge/generation/payloads/serviceimpl.py` — added complete helper closure checks, exact nullable collaborator contracts, return-consumption metadata, constants/configuration/API scope, fixture-only generation rules, and focused single-test repair payloads.
- `junitforge/generation/validation.py` — ServiceImpl generation now uses complete method-level semantic validation.
- `junitforge/execution/assembly.py` — added source-backed semantic checks and deterministic corrections for members, getters, setters, enums, collection families, Mockito contracts, matcher scope, configuration fields, and fixture-only setup.
- `junitforge/generation/fixture_variants.py` — new bounded fixture-variant hoisting, direct-construction replacement, normalized state signatures, helper injection, and deduplication.
- `junitforge/execution/fixture_builder_emitter.py` — honours required nested relationships and minimum collection cardinalities while bounding cycles.
- `junitforge/generation/method_generator.py` — validates/repairs each test before assembly, compiles fixture variants before use, registers compiled variants in the fixture catalogue, and records structured repair history.
- `junitforge/generation/response_normalizer.py` — new safe Markdown-wrapper normalization with distinct truncation, output-limit, identity, and structural states.
- `junitforge/generation/__init__.py` — changed to lazy exports to prevent circular imports introduced by shared fixture-variant processing.
- `junitforge/compilation/registry_mapper.py` — new compiler-diagnostic mapping from source ranges to stable registry test IDs, with fixture/skeleton/assembly/class/unmapped classification.
- `junitforge/compilation/deterministic_repairs.py` — commits repaired candidates without overwriting original generated source.
- `junitforge/compilation/repair_coordinator.py` — replaced ServiceImpl complete-class LLM repair with registry-focused test repair, deterministic-first handling, one focused LLM attempt, candidate rollback, no-new-error checks, unique audit attempts, and append-only compile invocations.
- `junitforge/compilation/salvage.py` — records irreparable removed tests using the explicit REMOVED state.
- `junitforge/runtime/repair_coordinator.py` — runtime candidates compile once without nested compile repair, use transactional registry candidates, persist runtime histories, run targeted then full tests, and commit or roll back.
- `junitforge/coverage/augmentation.py` — updated the preserved ServiceImpl coverage-augmentation status message for v11.

## Test changes

- `tests/test_v11_registry_focused_repair.py` — new v11 regression suite for registry transactions, diagnostic mapping, response normalization, fixture variants, source closure, collaborator contracts, inherited Spring Data contracts, and complete-class repair disablement.
- `tests/test_loop_restructuring.py` — updated payload-routing expectations for structured ServiceImpl generation.
- `tests/test_v101_serviceimpl_payload_workflow.py` — updated focused payload, registry, Markdown, and runtime rollback expectations.
- `tests/test_v102_logging_audit.py` — updated audit expectations for append-only compile evidence and registry-focused repair.
- `tests/test_v721_runtime_repair_gate.py` — verifies runtime repair never invokes nested compile repair.
- `tests/test_v72_deterministic_contracts.py` — updated semantic validation and deterministic contract expectations.
- `tests/test_v73_generation_recovery.py` — updated focused validation-repair and fixture-only generation behavior.

## Repair flow change

### v10.2

```text
assembled class
    -> compile
    -> complete ServiceImpl class sent to LLM up to three times
    -> runtime candidate compile failure
    -> nested complete-class compile repair
```

### v11

```text
method generation
    -> structural + semantic validation per @Test
    -> deterministic repair / compiled fixture augmentation
    -> one focused generation repair if required
    -> assemble retained tests
    -> compile once
    -> map diagnostics to registry test IDs
    -> deterministic repair per failed test
    -> at most one focused LLM repair per failed test
    -> assemble and compile candidate once
    -> commit or rollback
    -> runtime repair one failing test set
    -> compile once, targeted run, full run
    -> commit or rollback; no nested compile repair
```
