Act as a Principal Python Developer-Tools Engineer and Senior Java/JUnit 5/Mockito/Spring Data Engineer.

I am providing the existing llm-junit-assist v10.2 source code.

Modify the existing project only to correct ServiceImpl method-generation validation, fixture graph construction, compilation repair, runtime repair, and registry-driven diagnostic handling.

Do not perform another general audit.
Do not redesign the complete architecture.
Do not create a parallel registry, compilation, validation, or repair framework.
Do not replace the existing class-level generation lifecycle.
Do not modify unrelated DTO, entity, controller, repository, or configuration generation.
Do not stop after producing an analysis or implementation plan.

Implement the following requirements completely.

# Requirement 1: Complete fixture graphs from schema requirements

The fixture builder must honour schema properties marked as:

- baseline_required = true;
- minimum_size greater than zero;
- required nested object;
- required collection element;
- required dereference path.

For example, when the schema catalogue for GiPolicyEntity marks the following relationships as required:

- giPersonEntity;
- giBillEntities with minimum size 1;
- giMotorEntities with minimum size 1;

then validGiPolicyEntity() must initialise those relationships using their compiled fixture methods.

The fixture catalogue must record the dependent fixture IDs.

Example expected dependency relationship:

GiPolicyEntity
    -> GiPersonEntity
    -> GiBillEntity
    -> GiMotorEntity

Do not leave required relationships null or empty when production code dereferences, iterates, streams, indexes, or calls iterator().next() on them.

Do not introduce recursive fixture loops.

When cyclic relationships exist:

- construct the minimum safe graph;
- preserve required object identity;
- stop expansion at the existing configured schema depth;
- omit only the reverse relationship that would create an infinite cycle;
- record the cycle decision in fixture diagnostics.

The fixture catalogue and generated fixture source must remain consistent with the schema catalogue.

# Requirement 2: ServiceImpl method-generation semantic validation and fixture-only test setup

Every generated ServiceImpl @Test method must pass deterministic structural and semantic validation before it is accepted into 07-class-assembly.

The current limited ServiceImpl structural validation is insufficient.

## 2.1 Required semantic validation

ServiceImpl tests must run the existing or enhanced method-level contract validations for:

- exact setter parameter types;
- exact getter names;
- Boolean versus boolean getter conventions;
- unknown methods and members;
- unknown setters;
- unknown fields;
- unknown enum constants;
- collection family compatibility;
- generic collection element compatibility;
- Mockito method contracts;
- void versus non-void collaborator methods;
- production-only identifiers unavailable in test scope;
- fixture-supported object construction restrictions;
- JUnit assertion compatibility;
- Mockito matcher consistency;
- imported versus statically imported Mockito API use;
- nested DTO and entity type compatibility.

The following categories must be rejected or corrected before class assembly:

1. thenReturn(...) used on a void method;
2. wrong getter such as isPaymentStatus() when getPaymentStatus() is authoritative;
3. unsupported Mockito.when or Mockito.any qualification when only static imports are available;
4. String supplied to Character or char;
5. int supplied to Character or char;
6. double supplied to Integer;
7. double supplied to BigDecimal;
8. BigDecimal supplied to String;
9. List supplied to Set;
10. incorrect generic collection element type;
11. nonexistent enum constant;
12. nonexistent setter or getter;
13. nonexistent field or property;
14. private CUT configuration field referenced as a bare test variable;
15. unresolved or invented application type;
16. wrong nested DTO or entity type;
17. fixture-supported application object constructed or mutated directly inside an @Test method.

No test containing a known semantic violation may be marked:

validation_state = VALID

All validation failures must be written to:

validation_diagnostics

## 2.2 Fixture-only application-object setup

For every fixture-supported application DTO or entity, generated @Test methods must use compiled fixture methods.

Inside an @Test method, do not perform ad hoc field assignments, nested graph construction, or relationship replacement on fixture-supported application objects.

Forbidden example:

GiPolicyEntity giPolicyEntity = validGiPolicyEntity();
giPolicyEntity.setType('M');
giPolicyEntity.setStatus('P');
giPolicyEntity.setGiMotorEntities(Set.of(giMotorEntity));
giPolicyEntity.setGiBillEntities(Set.of(giBillEntity));

Required form:

GiPolicyEntity giPolicyEntity = validMotorPendingGiPolicyEntity();

Similarly, do not generate:

PaymentResource paymentResource = validPaymentResource();
paymentResource.setPolicyId("1");
paymentResource.setPaymentMode("C");
paymentResource.setProductType("M");

Generate or reuse an appropriate compiled fixture variant:

PaymentResource paymentResource = validKMMotorCardPaymentResource();

## 2.3 Forbidden application-object setup inside @Test methods

For fixture-supported application types, forbid inside @Test methods:

- setter calls;
- builder calls;
- direct field assignments;
- direct constructors;
- mocks or spies used as data objects;
- reflection-based field mutation;
- manual nested object construction;
- manual relationship replacement;
- manual application collection graph construction.

This restriction applies only to fixture-supported application DTOs and entities.

It does not prohibit normal creation of standard Java values such as:

- String;
- BigDecimal;
- Date;
- List;
- Set;
- Map;
- Optional;
- primitive values;
- primitive wrapper values;

when they are used as method arguments, Mockito return values, verified collaborator arguments, or assertion values.

## 2.4 Scenario-specific fixture variants

A single baseline fixture is not expected to satisfy every production branch.

When the selected execution path requires a different fixture state, do not mutate the baseline fixture inside the test.

Create or reuse a compiled named fixture variant.

Examples:

validGiPolicyEntity()
validMotorGiPolicyEntity()
validMotorPendingGiPolicyEntity()
validMotorInforceGiPolicyEntity()
validDualYearGiPolicyEntity()
validTravelGiPolicyEntity()

validPaymentResource()
validKMPaymentResource()
validKMMotorCardPaymentResource()
validKMMotorPayNowPaymentResource()
validRenewalPaymentResource()

The generated @Test method must call the most appropriate compiled fixture directly.

## 2.5 Fixture variant discovery and reuse

Before creating a new fixture variant:

1. derive the required state from the selected source path;
2. search the fixture catalogue for an existing compatible fixture;
3. reuse an existing fixture when its normalized state satisfies the path;
4. create a new fixture variant only when no compatible fixture exists;
5. deduplicate fixture variants using type and normalized state signature.

Example normalized state signature:

GiPolicyEntity:
    type = 'M'
    status = 'P'
    planType = "SINGLE"
    giPersonEntity.required = true
    giBillEntities.minimumSize = 1
    giMotorEntities.minimumSize = 1

Multiple tests requiring the same state must reuse the same compiled fixture variant.

## 2.6 Bounded fixture augmentation before rejection

Do not immediately reject a generated test merely because the current baseline fixture does not satisfy the selected path.

When validation detects necessary fixture mutations inside an @Test method:

1. identify the application type being mutated;
2. derive the required state from the mutation sequence and selected source path;
3. search for an existing compiled fixture variant;
4. replace the mutation sequence with the existing fixture call when possible;
5. otherwise perform one bounded fixture-augmentation attempt;
6. generate the new fixture variant in the shared fixture section;
7. validate its setters, getters, types, enum constants, collection types, and relationships;
8. compile the updated skeleton;
9. add the compiled fixture variant to the fixture catalogue;
10. regenerate or normalize the individual @Test method to use the fixture variant;
11. rerun semantic validation.

Reject the test only when:

- the required state depends on an unresolved member;
- the required state depends on an unresolved constant or enum value;
- a type-correct fixture cannot be constructed;
- required branch conditions are contradictory;
- a required cyclic graph cannot be bounded safely;
- fixture augmentation fails validation;
- fixture augmentation fails compilation;
- the regenerated test remains semantically invalid.

Do not simply remove mutation statements when those mutations are required to reach the selected execution path.

Do not retain a test whose resulting fixture no longer satisfies the selected path.

## 2.7 Fixture compilation requirement

A fixture variant must not be exposed to method generation until it has:

1. valid Java source;
2. passed fixture semantic validation;
3. passed skeleton compilation;
4. been added to the fixture catalogue;
5. received a stable fixture method name;
6. received a normalized state signature.

Only compiled fixtures may be referenced by generated tests.

## 2.8 Allowed generated @Test structure

A generated ServiceImpl @Test method should normally contain only:

- compiled fixture method calls;
- local references to fixture results;
- standard Java scalar or collection values where necessary;
- Mockito stubbing;
- invocation of the authorised public class-under-test method;
- JUnit Jupiter assertions;
- behaviourally relevant Mockito verification.

Example:

@Test
void generateKMPaymentRequest_shouldReturnSuccessfulCardPayment() {
    PaymentResource paymentResource = validKMMotorCardPaymentResource();
    GiPolicyEntity giPolicyEntity = validMotorPendingGiPolicyEntity();
    BillResource billResource = validKMMotorBillResource();

    when(giPolicyRepository.findById(anyLong()))
            .thenReturn(Optional.of(giPolicyEntity));

    when(iBillService.saveAndReadKMBill(
            same(giPolicyEntity),
            any(BillParam.class),
            anyString()))
            .thenReturn(billResource);

    PaymentResponse result =
            paymentServiceImpl.generateKMPaymentRequest(paymentResource);

    assertNotNull(result);
    assertTrue(result.isSuccess());
}

## 2.9 Validation outcome

After validation and any bounded fixture augmentation:

- valid tests may be retained;
- corrected tests must record their deterministic repair history;
- tests requiring a new fixture must record the fixture dependency;
- unresolved tests may receive one focused method-generation repair attempt;
- tests still invalid after the focused repair must be rejected;
- invalid tests must not enter 07-class-assembly.

The objective is not to reject every test that initially contains fixture mutations.

The objective is to move application-object construction and scenario state preparation out of individual @Test methods and into validated, compiled, reusable fixture variants.

# Requirement 3: Deterministic correction before LLM generation repair

Apply deterministic correction when the intended correction is authoritative and unambiguous.

At minimum, support deterministic handling for:

- remove normal void-method stubbing using when(...).thenReturn(...);
- replace a wrong getter with the exact getter from the schema catalogue;
- normalize Mockito.when(...) to when(...);
- normalize Mockito.any(...) to any(...);
- normalize any(char.class) to anyChar();
- convert a source-proven one-character String literal to a char literal;
- convert an appropriate numeric literal to BigDecimal.valueOf(...);
- convert an appropriate collection construction from List to Set;
- remove an unknown setter statement when it is unrelated to the selected path;
- replace a private CUT configuration identifier with its verified test value;
- replace an enum constant only when the authoritative enum constant is supplied.

Every deterministic change must be stored in:

deterministic_repair_history

Each history entry must contain:

- timestamp or sequence;
- diagnostic category;
- source before;
- source after;
- authoritative contract used;
- result.

If deterministic correction is unsafe or ambiguous, do not guess.

Send only the individual invalid @Test method for one focused generation-repair attempt.

Reject the test when the focused repair remains invalid.

# Requirement 4: Registry is the authoritative compilation control plane

Use the existing:

07-class-assembly/registry.json

as the authoritative state for:

- generated test source;
- latest accepted source;
- validation state;
- source line ranges;
- compile diagnostics;
- deterministic repair;
- LLM repair;
- runtime diagnostics;
- runtime repair;
- final disposition.

Do not create a second independent compile-repair registry.

Each test entry must have a stable test identity:

test_id = owner_method_id + "::" + test_name

The test ID must not depend on source line numbers.

Each test entry must contain at least:

- test_id;
- owner_method_id;
- test_name;
- scenario_id;
- generated_source;
- latest_accepted_source;
- previous_accepted_source;
- candidate_source;
- source_start_line;
- source_end_line;
- source_hash;
- validation_state;
- validation_diagnostics;
- compile_state;
- compile_diagnostics;
- compile_attempts;
- deterministic_repair_history;
- llm_repair_history;
- runtime_state;
- runtime_diagnostics;
- runtime_repair_attempts;
- final_disposition;
- final_rejection_reason.

# Requirement 5: Source field semantics

generated_source must be immutable.

It must always contain the original source accepted from method generation before compile repair or runtime repair.

latest_accepted_source must contain the source currently authorised for class assembly.

previous_accepted_source must contain the prior accepted version when a new version is committed.

candidate_source must be temporary.

Do not update latest_accepted_source merely because:

- deterministic repair produced a candidate;
- an LLM returned a candidate;
- structural validation passed;
- a runtime repair response was received.

Commit candidate_source to latest_accepted_source only after:

1. structural validation passes;
2. semantic validation passes;
3. the candidate is assembled into the class;
4. compilation passes;
5. any required focused execution check passes.

On failure:

- preserve latest_accepted_source;
- discard candidate_source;
- record the rejection;
- roll back the assembled class.

# Requirement 6: Map compiler diagnostics to registry tests

After assembling the complete class:

1. compile once;
2. parse all compiler diagnostics;
3. map each diagnostic to the owning registry test using:

source_start_line <= diagnostic.line <= source_end_line

4. append the diagnostic to that test's compile_diagnostics;
5. set compile_state appropriately;
6. group all diagnostics belonging to the same test;
7. repair the test as one unit.

Do not make one LLM call per compiler diagnostic.

One test with multiple compiler errors must produce at most one focused repair request per repair attempt.

Line numbers are not stable identities.

After every:

- test replacement;
- test removal;
- deterministic repair;
- LLM repair;
- class reassembly;

recalculate source_start_line and source_end_line for every registry entry and rewrite registry.json.

# Requirement 7: Classify diagnostics outside test ranges

Not every compiler diagnostic belongs to an @Test method.

Maintain separate diagnostic collections for:

- class-level compile diagnostics;
- fixture compile diagnostics;
- skeleton/setup compile diagnostics;
- assembly structural diagnostics;
- unmapped compile diagnostics.

Route diagnostics as follows:

Inside an @Test range:
    test-level repair

Inside a fixture method range:
    fixture-level repair

Inside setup, field, constructor, or import ranges:
    skeleton-level repair

Malformed class structure or unmatched braces:
    assembly-level repair

Do not assign an unmapped diagnostic to the nearest test merely because it is nearby.

# Requirement 8: Explicit compile states

Use explicit compile states:

- NOT_RUN;
- PASSED;
- FAILED;
- DETERMINISTIC_REPAIR_PENDING;
- LLM_REPAIR_PENDING;
- REPAIRED_PENDING_COMPILE;
- REPAIRED_AND_PASSED;
- REJECTED;
- REMOVED.

Valid examples:

NOT_RUN
    -> FAILED
    -> DETERMINISTIC_REPAIR_PENDING
    -> REPAIRED_PENDING_COMPILE
    -> REPAIRED_AND_PASSED

or:

NOT_RUN
    -> FAILED
    -> LLM_REPAIR_PENDING
    -> REJECTED
    -> REMOVED

Compile states must be persisted after each transition.

# Requirement 9: Remove complete-class ServiceImpl compile repair

Do not send the complete generated ServiceImpl test class to the LLM for ordinary compilation errors.

Remove or disable the route equivalent to:

route.serviceimpl_complete_class

for test-level compiler diagnostics.

The normal ServiceImpl compile-repair unit must be one registry-owned @Test method.

The focused compile-repair request must contain only:

- target class identity;
- owner production method ID;
- test name;
- current test source;
- grouped compiler diagnostics for that test;
- relevant schema contracts;
- relevant collaborator contracts;
- relevant fixture contracts;
- relevant constants and configuration values;
- authorised imports and available static APIs;
- output requirement for exactly one corrected @Test method.

Do not include:

- the complete test class;
- unrelated test methods;
- unrelated fixtures;
- unrelated production methods;
- unrelated compiler diagnostics.

# Requirement 10: Focused compile-repair lifecycle

For each failed test:

1. apply deterministic repair;
2. validate the deterministic candidate;
3. assemble it into the class;
4. compile once;
5. commit it when successful;
6. otherwise roll back;
7. perform at most one focused LLM repair attempt when deterministic repair cannot resolve the test;
8. validate the LLM candidate;
9. assemble and compile once;
10. commit or reject.

Do not recursively call complete-class compile repair.

Do not repeatedly send an unchanged request after an identical rejected response.

Track:

- request hash;
- response hash;
- previous rejection reason.

When the response hash is identical to a previously rejected response for the same request, stop retrying and record:

IDENTICAL_REJECTED_RESPONSE

# Requirement 11: Markdown response normalization

A focused LLM repair response should normally contain one raw Java @Test method.

Strip exactly one complete outer Markdown code fence only when:

- one opening fence exists;
- one closing fence exists;
- no prose exists outside the fence;
- no additional fence exists inside;
- the enclosed Java is structurally complete.

Reject unmatched or nested fences. Record distinct response states:

- RAW_JAVA_ACCEPTED;
- MARKDOWN_WRAPPER_STRIPPED;
- MARKDOWN_RESPONSE_INVALID;
- MULTIPLE_MARKDOWN_FENCES;
- TRUNCATED_RESPONSE;
- OUTPUT_LIMIT_REACHED;
- UNBALANCED_JAVA_STRUCTURE;
- TEST_IDENTITY_MISMATCH.

Persist finish reason, token usage when available, response character count, response hash, and truncation state.

# Requirement 12: Runtime repair must not invoke compile repair recursively

Runtime repair must operate on registry-owned failing tests only.

The runtime flow must be:

runtime failure
    -> map failure to test_id
    -> generate one candidate replacement
    -> structural validation
    -> semantic validation
    -> assemble candidate
    -> compile once
    -> reject and roll back immediately when compilation fails
    -> run the focused test when compilation passes
    -> run the complete retained test class
    -> commit only after required checks pass

Do not call _compile_with_repair(...) from runtime repair.

# Requirement 13: Limit repeated repair calls

Use these ServiceImpl defaults:

- complete-class compile-repair attempts: 0;
- focused compile-repair attempts per test: 1;
- identical-response retries: 0;
- nested compile repair from runtime repair: disabled.

Retry only when the request materially changes.

# Requirement 14: Correct inherited Spring Data contracts

Resolve inherited repository methods using repository generic entity and ID types.

Do not render unresolved inherited methods as void. Preserve unresolved contracts as:

return_type = null
resolution_status = partial

Parameter type "?" means unresolved. It does not mean void or ignored return.

# Requirement 15: Preserve return-consumption semantics

Distinguish:

1. genuinely void method;
2. non-void method with ignored return;
3. non-void method with consumed return;
4. unresolved return contract.

Persist return_value_consumed, consumption_kind, assigned_to, and resolution_status separately from return type.

# Requirement 16: Generation-time acceptance target

All previously observed setter, getter, enum, member, Mockito, scope, and type diagnostics must be intercepted before class assembly. The compile gate remains a final safety check, not the primary semantic validator.

# Requirement 17: Audit and registry history

Persist every deterministic, LLM compile, and runtime repair state transition. Do not overwrite earlier evidence. Use unique attempt directories or append-only records.

# Requirement 18: Required tests

Add or update tests proving:

1. baseline-required fixture relationships are generated;
2. minimum-size collections receive fixture elements;
3. cyclic graphs are bounded;
4. semantic Mockito/getter/setter/member/type violations are rejected or corrected;
5. fixture-supported construction and mutation are moved to compiled fixtures;
6. compiler diagnostics map to stable registry test IDs;
7. multiple diagnostics for one test form one focused repair unit;
8. line ranges are recomputed;
9. generated_source remains immutable;
10. candidates commit only after successful gates and roll back otherwise;
11. complete-class ServiceImpl repair is disabled;
12. runtime repair does not nest compile repair;
13. Markdown normalization and truncation detection work;
14. inherited Spring Data contracts are exact;
15. unresolved contracts remain unresolved rather than fake void;
16. audit records are append-only.

# Requirement 19: Validation and reporting

Run the complete Python test suite and provide:

- changed-file list;
- concise explanation of each changed file;
- tests added or updated;
- test execution result;
- before-and-after repair flow;
- confirmation that complete-class ServiceImpl repair is disabled;
- confirmation that runtime repair cannot recursively call compile repair;
- confirmation that generated_source remains immutable;
- confirmation that registry.json is authoritative;
- known limitations.

Do not claim success unless implementation and tests are complete.
