# llm-junit-assist v11 Validation Report

## Result

The v10.2 project was modified in place and versioned as v11.0. The complete Python regression suite passes.

## Confirmed behavior

- `07-class-assembly/registry.json` is the authoritative ServiceImpl repair state.
- `generated_source` is immutable after method generation.
- `candidate_source` is temporary and is committed to `latest_accepted_source` only after required gates pass.
- Compiler diagnostics are grouped by stable `test_id`, not used as one-LLM-call-per-error inputs.
- Source ranges are recalculated after assembly changes.
- ServiceImpl semantic validation runs before class assembly.
- Fixture-supported application construction and scenario mutations are moved to compiled reusable fixture variants when deterministically possible.
- Baseline fixture graphs honour required nested relationships and minimum collection sizes while bounding cycles.
- Same-class helper source closure uses the complete production source file and includes non-private sibling helpers.
- Commented helper calls are excluded from the call graph.
- Unresolved collaborator contracts remain unresolved and are never converted to fake void contracts.
- Inherited Spring Data methods resolve from repository entity/ID generic bindings.
- Complete-class ServiceImpl LLM compile repair is explicitly disabled.
- Runtime repair calls a compile check once and never recursively calls `_compile_with_repair`.
- A complete outer Markdown fence may be stripped safely; unmatched fences, output-limit responses, and unbalanced Java are rejected distinctly.
- Compile audit evidence is written to unique `08-compile/invocation-NNN` directories while preserving the initial top-level compile evidence.

## Test execution

```text
pytest: 207 passed
unittest: 207 passed
compileall: passed
```

## Known limitations

- Scenario fixture augmentation is intentionally bounded to source-backed direct construction and setter sequences. Complex multiline mutations, reflective mutations, dynamic builders, or unresolved constants are rejected or sent through one focused repair attempt rather than guessed.
- Scenario variants discovered from an LLM response are compiled and registered before class assembly; they are not available to earlier concurrently running initial method-generation calls in the same batch.
- Exact LLM input/output token and finish-reason fields are persisted only when the configured provider exposes them.
- Validation here covers the Python engine regression suite. A protected enterprise Java repository was not included, so no end-to-end Maven generation run against PaymentServiceImpl was executed in this environment.
